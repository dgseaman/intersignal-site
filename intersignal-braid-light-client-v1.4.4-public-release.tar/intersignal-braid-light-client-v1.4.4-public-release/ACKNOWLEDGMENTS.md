# Optical Transport Lineage and Acknowledgments

Animated QR sequences and screen-to-camera data transport are established, openly explored design patterns with multiple independent implementations. Intersignal does not claim ownership of the general idea of streaming data through changing visual codes.

The Braid Light Client optical layer was independently implemented for a different application boundary: signed and canonical 384-dimensional machine-state frames, bounded `BRAD1` chunks, receiver-controlled authority, payload binding, and state-specific validation.

We acknowledge open-source projects that have explored adjacent parts of the optical-transfer design space, including:

- **txqr** by Ivan Danyliuk — animated QR data transfer with fountain coding: <https://github.com/divan/txqr>
- **libcimbar** by sz3 — high-density color-icon matrix barcodes for air-gapped transfer: <https://github.com/sz3/libcimbar>
- **Decimen Optical Transfer** by bashalarmistalt — browser-based fountain-coded QR file transfer: <https://github.com/bashalarmistalt/decimen-optical-transfer>

No source code from those projects is incorporated into the Braid Light Client release. Their mention does not imply compatibility, sponsorship, certification, affiliation, or endorsement. Each project remains owned by its respective contributors and governed by its own license.

Braid's contribution is not the abstract optical channel. It is the binding of that channel to signed machine-state frames, receiver sovereignty, bounded authority, and an inspectable validation path.
