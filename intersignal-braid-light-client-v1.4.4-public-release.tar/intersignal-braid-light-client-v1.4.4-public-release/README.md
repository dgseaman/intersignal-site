# Braid Light Client v1.4.4

**Portable, signed, inspectable AI state transport for independent local nodes.**

Braid Light Client is an MIT-licensed developer reference client from **Intersignal LLC**. It generates, inspects, transfers, and validates compact 384-dimensional FP16 state frames across files, loopback APIs, and standards-compliant optical QR streams.

The receiver remains authoritative: a sender may request capabilities, but the receiving node verifies the frame, applies local policy, and independently accepts or rejects the proposed state handoff.

## Included in this public release bundle

- `packages/braid_client-1.4.4-py3-none-any.whl` — installable Python wheel.
- `packages/braid_client-1.4.4.tar.gz` — Python source distribution.
- `LICENSE` — canonical MIT License, copyright 2026 Intersignal LLC.
- `THIRD_PARTY_NOTICES.md` — dependency-license guidance.
- `ACKNOWLEDGMENTS.md` — optical-transport lineage and independent-implementation note.
- `docs/` — release notes, technical audit summary, test evidence, and physical-camera UAT.
- `media/` — homepage and press hero artwork.
- `press/` — concise distribution press release.
- `homepage/` — ready-to-use download-module copy for Intersignal.org.

## Installation

Python 3.9 or newer is required.

```bash
pip install ./packages/braid_client-1.4.4-py3-none-any.whl
```

Install the optional local OpenCV camera-decoding fallback:

```bash
pip install './packages/braid_client-1.4.4-py3-none-any.whl[camera]'
```

## Quick start

```bash
# Generate a signed 384D state frame and persistent Ed25519 keypair.
braid-client generate --signing-key sender.key --output state.brad

# Verify the frame in a separate process.
braid-client inspect --trusted-key sender.pub state.brad

# Launch the local visual and optical transport studio.
braid-client serve --port 8080 --signing-key sender.key --trusted-key sender.pub
```

Open `http://127.0.0.1:8080/` in a browser.

Run the end-to-end image-channel test with the camera extra installed:

```bash
braid-client smoke-test
```

## Verified release state

The finalized source tree passed **27 of 27** unit, integration, browser-module, security, key-boundary, HTTP, and optical-transport tests. The image-channel smoke path covers QR generation, rasterization, computer-vision decoding, out-of-order delivery, duplicate handling, byte-identical reconstruction, Phase A validation, and 384-dimensional vector recovery.

## Honest deployment boundary

Version 1.4.4 is a developer reference client. Its successful receiver result is a **Phase A non-locking pre-validation**, not replay-safe transaction finality. Production routes should use persistent replay-ledger commitment and replace the bundled demonstration PCA/covariance artifacts with trained, route-owned artifacts and pinned digests.

A physical two-device camera test remains the environmental acceptance step for each target display, camera, lighting, distance, and glare profile. See `docs/PHYSICAL_CAMERA_UAT.md`.

## License and ownership

Braid Light Client is released by **Intersignal LLC** under the **MIT License**.

Copyright (c) 2026 Intersignal LLC.

“MIT License” identifies the software license only and does not imply affiliation with or endorsement by the Massachusetts Institute of Technology. Third-party dependencies remain governed by their own licenses.
