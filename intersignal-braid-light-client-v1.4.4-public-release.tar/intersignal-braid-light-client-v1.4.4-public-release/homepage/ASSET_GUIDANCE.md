# Homepage asset guidance

Use `../media/braid-societal-potential-hero.png` as the principal Braid release image.

Recommended placement:

- Full-width or wide two-column release feature.
- Preserve the complete composition; avoid aggressive center crops that remove the independent nodes.
- Pair with the CTA copy in `HOMEPAGE_DOWNLOAD_COPY.md`.
- Link the CTA directly to the public `.tar.gz` release bundle rather than to an individual wheel, so developers receive the license, notices, documentation, test evidence, and source distribution together.
