# Homepage download module

## Braid Light Client v1.4.4

**Machine state moves. Control remains local.**

Generate, inspect, sign, and transfer compact 384-dimensional AI state between independent local nodes—including through a live screen-to-camera QR channel.

- MIT-licensed developer reference client
- Signed `.brad` frames and persistent Ed25519 keys
- Local-only visual and optical transport studio
- Receiver-controlled authority and independent validation gates
- 27/27 automated tests passed

**Primary CTA:** Download Braid Light Client v1.4.4

**Supporting line:** Source distribution, Python wheel, documentation, test evidence, and optical-camera UAT included in one verified release bundle.

**Boundary note:** Phase A reference implementation. Production routes require replay-ledger commitment and trained route-specific anomaly artifacts.
