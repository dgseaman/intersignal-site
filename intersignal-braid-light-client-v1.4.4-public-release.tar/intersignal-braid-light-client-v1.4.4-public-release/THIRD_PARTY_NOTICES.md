# Third-Party Software Notices

The Braid Light Client source code is released by Intersignal LLC under the MIT License. That license applies to the Braid Light Client code and does not relicense third-party packages installed alongside it.

## Declared runtime dependencies

- **NumPy** — distributed under the BSD 3-Clause License, with additional notices for software bundled by NumPy distributions.
- **cryptography** — distributed under the Apache License 2.0 or the BSD 3-Clause License.

## Optional camera fallback

- **opencv-python-headless / OpenCV** — distributed under the Apache License 2.0 and related upstream notices.

These packages are resolved and installed separately by Python packaging tools; they are not copied into the Braid Light Client source tree. Recipients should review the license metadata and notice files included with the specific dependency versions they install.

No reference to a third-party project, institution, or license name implies sponsorship, certification, affiliation, or endorsement of Intersignal LLC or the Braid Light Client.
