# Braid v1.4.4 Physical Two-Device Camera Acceptance

## Purpose

Verify the final environmental path that cannot be reproduced inside a headless build container: one physical display emitting the QR reel and a second physical camera decoding it into an independently configured receiver.

## Preparation

Install the wheel with the local camera fallback on both devices:

```bash
pip install 'braid_client-1.4.4-py3-none-any.whl[camera]'
```

### Node A — transmitter

```bash
braid-client serve \
  --port 8080 \
  --signing-key node-a.key
```

Open `http://127.0.0.1:8080/` and securely copy `node-a.pub` to Node B.

### Node B — receiver

```bash
braid-client serve \
  --port 8080 \
  --signing-key node-b.key \
  --trusted-key node-a.pub
```

Open `http://127.0.0.1:8080/` on Node B and grant camera permission.

## Positive acceptance run

1. On Node A, generate a fresh sample and leave the optical reel running at 4–6 FPS.
2. On Node B, select **Start Camera Scan** and point the camera squarely at Node A's QR display.
3. Confirm the backend reports either `native-barcode-detector` or `loopback-opencv-fallback`.
4. Move the camera slightly off-axis and vary distance until decoding begins.
5. Confirm `Accepted` increments and collector progress advances despite reel order and repeated frames.
6. Wait for `N/N Chunks (100%)`.
7. Confirm Node B displays:
   - the same object digest shown on Node A;
   - Gate 1 PASS;
   - Gate 2 PASS;
   - Gate 3 evidence labeled DEMO;
   - PHASE A PASS;
   - a recovered 384-dimensional vector and updated visualizations.
8. Stop scanning and verify the camera indicator turns off and the browser releases the camera.

## Negative checks

- Launch Node B with an unrelated trusted public key. A complete stream must fail Gate 1.
- Cover the camera intermittently. Progress may pause but must resume without resetting valid collected slots.
- Present the same chunk repeatedly. Duplicate count may increase; accepted count and slot count must not falsely advance.
- Present a non-BRAD1 QR symbol. It must be ignored.
- Paste a malformed completed chunk stream. The server must return a bounded error and remain available.
- Request an oversized QR payload. The API must return `ERR_QR_CAPACITY` rather than a malformed symbol.

## Environmental matrix

Record at least these runs:

| Condition | Target |
|---|---:|
| Bright indoor light, display straight-on | Complete frame |
| Moderate glare, 10–20° camera angle | Complete frame |
| 1 meter distance | Complete frame |
| Reel at 3 FPS | Complete frame |
| Reel at 6 FPS | Complete frame |
| Native detector available | Complete frame |
| OpenCV fallback forced | Complete frame |

## Promotion gate

Publicly describe the client as a live camera optical receiver only after two independent physical devices complete the positive run and at least one native and one fallback decoder run are recorded. Keep Phase A and DEMO-artifact labeling visible in screenshots and demonstrations.
