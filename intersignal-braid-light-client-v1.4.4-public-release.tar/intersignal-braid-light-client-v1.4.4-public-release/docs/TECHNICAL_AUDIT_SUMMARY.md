# Braid Light Client v1.4.4 — Technical Audit Summary

## Release posture

Braid Light Client v1.4.4 is a release candidate for developer evaluation and physical two-device acceptance. The current build implements a complete software path for signed 384-dimensional state framing, dynamic optical QR transport, bounded reassembly, and Phase A receiver pre-validation.

## Verified implementation

### Dual-path browser receiver

- Uses the browser-native `BarcodeDetector` API when available.
- Falls back to the local loopback `/api/decode_qr` OpenCV endpoint when native QR detection is unavailable or misses a frame.
- Keeps captured camera frames in browser memory or on the local `127.0.0.1` service; the client defines no external image endpoint.
- Deduplicates in-flight chunks and expires stale collector sessions after 300 seconds.

### Optical transport

- Generates QR matrices for Versions 1–12 at error-correction Level M.
- Applies Reed–Solomon error correction, format masking, alignment patterns, byte-mode framing, and interleaving.
- Fails closed with `ERR_QR_CAPACITY` when an optical payload exceeds supported capacity.
- Uses a four-module quiet zone for raster output.
- Supports duplicate and out-of-order BRAD1 chunk delivery with per-chunk CRC32 validation and byte-identical reassembly.

### Key and receiver hygiene

- Treats Ed25519 private keys as opaque 32-byte binary values.
- Writes private keys atomically with `0600` permissions and public companions with `0644` permissions.
- Repairs missing or mismatched public-key companion files from the persistent private key.
- Reports Gate 1, Gate 2, and Gate 3 evidence independently.

## Verification evidence

- 27 of 27 Python unit, integration, subprocess, browser-module, key-boundary, HTTP, and security tests passed in repeated runs.
- The image-channel smoke test exercised matrix generation, rasterization, computer-vision decode, out-of-order and duplicate delivery, byte-identical reassembly, and 384-dimensional vector recovery.
- Built wheel and source distributions contain the browser visualizer, camera receiver module, documentation, and test materials.

## Explicit boundaries

1. **Gate 3 artifacts are demonstrations.** The bundled PCA and covariance artifacts are labeled `DEMO`. Production routes require route-specific trained artifacts with pinned digests.
2. **Phase A is non-locking.** A `PHASE A PASS` is pre-validation, not replay-safe transaction finality. A production receiver must execute the persistent `ReplayLedger` commit path.
3. **Physical camera UAT remains required.** Software and raster/JPEG paths have been tested, but public promotion should follow a real screen-to-camera run across two physical devices under variable lighting, distance, glare, and motion. See `PHYSICAL_CAMERA_UAT.md`.
4. **Runtime dependencies are declared, not vendored.** NumPy and cryptography are core dependencies; OpenCV is an optional local camera-decoder fallback. No external network service is required for normal operation.
