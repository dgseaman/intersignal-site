// background.js — right-click to summarize + score
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'intersignal_summarize',
    title: 'Intersignal: Summarize + Score This Page',
    contexts: ['page']
  });
});

async function collectPageText(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let out = '';
      while (walker.nextNode()) {
        const t = walker.currentNode.nodeValue;
        if (t && t.trim().length > 0) out += ' ' + t;
      }
      return out.replace(/\s+/g, ' ').trim().slice(0, 120000);
    }
  });
  return result || '';
}

async function summarizeInPage(tabId, text) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    args: [text],
    func: async (t) => {
      try {
        const api = window?.ai?.summarizer;
        if (!api) return { error: 'Summarizer API not available in page context.' };
        const h = await api.create({ type: 'key-points', format: 'markdown', length: 'medium' });
        const out = await h.summarize(t);
        return { summary: out?.summary || '' };
      } catch (e) { return { error: e?.message || String(e) }; }
    }
  });
  return result;
}

async function runIntegrity(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['src/integrity.js'] });
  const [{ result }] = await chrome.scripting.executeScript({ target: { tabId }, func: () => window.__ISIG_RESULT || null });
  return result;
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'intersignal_summarize' || !tab?.id) return;
  try {
    const text = await collectPageText(tab.id);
    const sumRes = await summarizeInPage(tab.id, text);
    const integ = await runIntegrity(tab.id);
    const score = (integ && typeof integ.integrityScore === 'number') ? integ.integrityScore : 0;
    const short = (sumRes?.summary || sumRes?.error || '').slice(0, 180).replace(/\s+/g, ' ');
    const message = (sumRes?.error ? 'Error: ' : `Score: ${score} — `) + short + (short.length >= 180 ? '…' : '');

    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'assets/icon128.png',
      title: 'Intersignal',
      message,
      priority: 1
    });
  } catch (e) {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'assets/icon128.png',
      title: 'Intersignal — Error',
      message: e.message || String(e),
      priority: 2
    });
  }
});
