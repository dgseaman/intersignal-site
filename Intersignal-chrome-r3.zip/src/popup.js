// src/popup.js
const btn = document.getElementById('run');
const statusEl = document.getElementById('status');
const summaryEl = document.getElementById('summary');
const integrityEl = document.getElementById('integrity');
const scoreValEl = document.getElementById('score-val');
const tagsContainer = document.getElementById('tags');

function setStatus(msg=''){ statusEl.textContent = msg; }
function renderTags(tags){ tagsContainer.innerHTML=''; (tags||[]).forEach(tag=>{ const el=document.createElement('span'); el.className=`tag ${tag.type}`; el.textContent=tag.label; tagsContainer.appendChild(el); }); }

async function getActiveTab(){ const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); if(!tab) throw new Error('No active tab found.'); return tab; }
async function collectPageText(tabId){
  const [{result}] = await chrome.scripting.executeScript({ target:{tabId}, func:()=>{
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT); let out='';
    while(walker.nextNode()){ const t=walker.currentNode.nodeValue; if(t && t.trim().length>0) out+=' '+t; }
    return out.replace(/\s+/g,' ').trim().slice(0,120000);
  }});
  return result||'';
}

async function summarizeViaDomInjection(tabId, text){
  // Inject a runner into MAIN world so it can access window.ai.summarizer
  await chrome.scripting.executeScript({
    target:{tabId}, world:'MAIN', args:[text], func:(pageText)=>{
      const id='__isig_runner'; const prior=document.getElementById(id); if(prior) prior.remove();
      const s=document.createElement('script'); s.id=id; s.textContent = `
        (async()=>{
          try{
            const api = window?.ai?.summarizer;
            if(!api){ window.__ISIG_SUMMARY={ error:'Summarizer API not available (model may still be downloading).' }; }
            else{
              const h = await api.create({ type:'key-points', format:'markdown', length:'medium' });
              const out = await h.summarize(${JSON.stringify(text)});
              window.__ISIG_SUMMARY = { summary: out?.summary || '' };
            }
          }catch(e){ window.__ISIG_SUMMARY = { error: e?.message || String(e) }; }
          window.dispatchEvent(new CustomEvent('ISIG_SUMMARY_READY'));
        })();`;
      document.documentElement.appendChild(s); s.remove();
    }
  });
  // Poll for result
  const max=160, interval=250;
  for(let i=0;i<max;i++){
    const [{result}] = await chrome.scripting.executeScript({ target:{tabId}, world:'MAIN', func:()=>window.__ISIG_SUMMARY||null });
    if(result) return result;
    await new Promise(r=>setTimeout(r,interval));
  }
  return { error:'Timed out waiting for summary (model may still be downloading).' };
}

async function injectIntegrity(tabId){ await chrome.scripting.executeScript({ target:{tabId}, files:['src/integrity.js'] }); }
async function pollIntegrity(tabId, tries=50, step=120){
  return new Promise((resolve)=>{
    let n=0; const iv=setInterval(async()=>{
      n++; const [{result}] = await chrome.scripting.executeScript({ target:{tabId}, func:()=>window.__ISIG_RESULT||null });
      if(result || n>tries){ clearInterval(iv); resolve(result||null); }
    }, step);
  });
}

async function exec(){
  try{
    setStatus('Collecting page text…');
    const tab = await getActiveTab();
    const text = await collectPageText(tab.id);

    setStatus('Summarizing on-device…');
    const sum = await summarizeViaDomInjection(tab.id, text);
    summaryEl.textContent = sum?.error ? ('Summarization failed: ' + sum.error) : (sum?.summary || '(no summary)');

    setStatus('Scoring integrity…');
    await injectIntegrity(tab.id);
    const res = await pollIntegrity(tab.id);

    if(res && typeof res.integrityScore==='number'){
      integrityEl.textContent = JSON.stringify(res.diagnostics, null, 2);
      scoreValEl.textContent = String(res.integrityScore);
      renderTags(res.tags);
      setStatus('Done.');
    }else{
      integrityEl.textContent = 'No integrity result.';
      setStatus('');
    }
  }catch(e){
    setStatus(''); summaryEl.textContent=''; integrityEl.textContent=''; scoreValEl.textContent='--'; tagsContainer.innerHTML='';
    alert('Intersignal error: ' + (e?.message || String(e)));
  }
}
btn.addEventListener('click', exec);
