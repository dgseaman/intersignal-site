from __future__ import annotations

import hashlib
import os
from pathlib import Path
from tempfile import NamedTemporaryFile


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "PACKAGE_MANIFEST_SHA256.txt"
INCLUDED_ROOT_FILES = {
    "CHANGELOG.md",
    "MANIFEST.in",
    "PUBLIC_RELEASE_CHECKLIST.md",
    "README.md",
    "RELEASE_GATE.md",
    "RELEASE_NOTES.md",
    "SECURITY.md",
    "TEST_EVIDENCE.md",
    "WAN_UAT.md",
    "pyproject.toml",
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def included_files() -> list[Path]:
    files = [ROOT / name for name in INCLUDED_ROOT_FILES]
    for directory in (ROOT / "scripts", ROOT / "src" / "braid_jumpkit", ROOT / "tests"):
        files.extend(path for path in directory.rglob("*") if path.is_file() and "__pycache__" not in path.parts)
    return sorted(files, key=lambda path: path.relative_to(ROOT).as_posix())


def main() -> None:
    lines = [f"{digest(path)}  ./{path.relative_to(ROOT).as_posix()}" for path in included_files()]
    with NamedTemporaryFile("w", encoding="utf-8", dir=ROOT, delete=False) as handle:
        handle.write("\n".join(lines) + "\n")
        temporary = Path(handle.name)
    os.replace(temporary, OUTPUT)


if __name__ == "__main__":
    main()
