$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
py -3.12 -m pytest -q (Join-Path $Root 'tests')
