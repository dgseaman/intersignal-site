$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$RequiredPython = '3.12.10'
$Venv = Join-Path $Root '.build-venv'
$Dist = Join-Path $Root 'dist'
if (Test-Path $Venv) { Remove-Item -Recurse -Force $Venv }
$ActualPython = (& py -3.12 -c "import platform; print(platform.python_version())").Trim()
if ($ActualPython -ne $RequiredPython) {
    throw "Python $RequiredPython x64 is required; py -3.12 resolved to $ActualPython."
}
$ActualArch = (& py -3.12 -c "import platform; print(platform.architecture()[0])").Trim()
if ($ActualArch -ne '64bit') {
    throw "64-bit CPython is required; py -3.12 resolved to $ActualArch."
}
py -3.12 -m venv $Venv
$Python = Join-Path $Venv 'Scripts\python.exe'
& $Python -m pip install 'pip==26.1.1'
& $Python -m pip install 'setuptools==80.9.0' 'wheel==0.45.1' 'cryptography==49.0.0' 'pyinstaller==6.21.0' 'pyinstaller-hooks-contrib==2026.6'
& $Python -m pip install --no-deps $Root
if (Test-Path $Dist) { Remove-Item -Recurse -Force $Dist }
New-Item -ItemType Directory -Force -Path $Dist | Out-Null
& (Join-Path $Venv 'Scripts\pyinstaller.exe') --noconfirm --clean --onefile --name 'Braid-Jump-Kit' --distpath $Dist --workpath (Join-Path $Root 'build\pyinstaller') --specpath (Join-Path $Root 'build') (Join-Path $Root 'scripts\jumpkit_entry.py')
$Exe = Join-Path $Dist 'Braid-Jump-Kit.exe'
if (-not (Test-Path $Exe)) { throw 'Braid-Jump-Kit.exe was not produced.' }
Get-FileHash -Algorithm SHA256 $Exe | Format-List
Write-Host "Built: $Exe"
