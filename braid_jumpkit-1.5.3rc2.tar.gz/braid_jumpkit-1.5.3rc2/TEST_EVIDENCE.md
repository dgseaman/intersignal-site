# RC2 reproducible test evidence

Date: 2026-08-26  
Environment: macOS sandbox, Python 3.12 bundled runtime  
Scope: source-level, localhost integration, and referenced physical WAN UAT

## Command

```text
PYTHONPATH=src:<test-dependencies> python3 -m pytest -q
```

## Result

PASS: 56 tests. The suite covers protocol framing, TLS 1.3 pinning, exact byte-for-byte BTP1 preservation through relay-to-agent-to-local-Braid handoff, rejection of trailing bytes before the local receiver socket is opened, ACK invariants, end-to-end encryption/signatures, pairing-code tamper/expiry, authorization expiry/revocation, relay opacity, device-ID proof, direct-first success, forced relay fallback, local-Core failure, reconnect after relay interruption, live revocation, timeout bounds/default ordering, and a delayed semantic ACK completing inside hierarchical deadlines.

Physical UAT evidence supplied on 2026-08-26 records macOS → DigitalOcean relay → Windows agent → Windows Braid receiver → ACK with `TLSv1.3`, `RELAYED`, `validated=true`, `stored=true`, and `accepted=true`.

This evidence is intentionally bounded. One accepted WAN direction does not prove automatic direct NAT traversal, reverse-direction WAN operation, Linux WAN operation, native Windows/macOS/Linux packaging, relay interruption recovery under public load, or production operations. Those rows remain open in `RELEASE_GATE.md`.
