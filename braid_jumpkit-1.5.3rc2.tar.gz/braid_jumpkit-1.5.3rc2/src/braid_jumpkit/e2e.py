from __future__ import annotations

import base64
import os
import time
import uuid
from typing import Any

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .device import DeviceIdentity
from .errors import PolicyError, ProtocolError
from .protocol import canonical_json_bytes

E2E_VERSION = 1
E2E_DOMAIN = b"braid-jumpkit-e2e-v1"
MAX_CLOCK_SKEW_SECONDS = 300


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _unb64(value: Any, *, limit: int) -> bytes:
    if not isinstance(value, str) or len(value) > limit * 2:
        raise ProtocolError("ERR_E2E_ENCODING")
    try:
        data = base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except Exception as exc:
        raise ProtocolError("ERR_E2E_ENCODING") from exc
    if len(data) > limit:
        raise ProtocolError("ERR_E2E_LENGTH")
    return data


def _key(shared: bytes, source: str, destination: str, message_id: str, kind: str) -> bytes:
    info = E2E_DOMAIN + b"\0" + source.encode() + b"\0" + destination.encode() + b"\0" + message_id.encode() + b"\0" + kind.encode()
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=info).derive(shared)


def seal(identity: DeviceIdentity, peer_id: str, kind: str, plaintext: bytes) -> dict[str, Any]:
    peer = identity.active_peer(peer_id)
    if kind not in {"btp1", "ack", "error"}:
        raise ProtocolError("ERR_E2E_KIND")
    if not plaintext or len(plaintext) > 3 * 1024 * 1024:
        raise ProtocolError("ERR_E2E_LENGTH")
    ephemeral = X25519PrivateKey.generate()
    ephemeral_public = ephemeral.public_key().public_bytes_raw()
    message_id = str(uuid.uuid4())
    nonce = os.urandom(12)
    header: dict[str, Any] = {
        "destination": peer.device_id,
        "ephemeral_public": _b64(ephemeral_public),
        "kind": kind,
        "message_id": message_id,
        "nonce": _b64(nonce),
        "sent_at_unix": int(time.time()),
        "source": identity.device_id,
        "version": E2E_VERSION,
    }
    shared = ephemeral.exchange(X25519PublicKey.from_public_bytes(peer.exchange_public))
    cipher = ChaCha20Poly1305(_key(shared, identity.device_id, peer.device_id, message_id, kind))
    ciphertext = cipher.encrypt(nonce, plaintext, canonical_json_bytes(header))
    signed = {**header, "ciphertext": _b64(ciphertext)}
    signed["signature"] = _b64(identity.sign_private.sign(canonical_json_bytes(signed)))
    return signed


def open_envelope(
    identity: DeviceIdentity,
    envelope: dict[str, Any],
    *,
    expected_kind: str,
    replay_ids: set[str] | None = None,
    now: int | None = None,
) -> tuple[str, bytes]:
    required = {
        "version", "source", "destination", "kind", "message_id", "sent_at_unix",
        "ephemeral_public", "nonce", "ciphertext", "signature",
    }
    if set(envelope) != required or envelope.get("version") != E2E_VERSION:
        raise ProtocolError("ERR_E2E_SCHEMA")
    source = envelope.get("source")
    destination = envelope.get("destination")
    kind = envelope.get("kind")
    message_id = envelope.get("message_id")
    sent_at = envelope.get("sent_at_unix")
    if not all(isinstance(x, str) for x in (source, destination, kind, message_id)) or type(sent_at) is not int:
        raise ProtocolError("ERR_E2E_SCHEMA")
    if destination != identity.device_id:
        raise PolicyError("ERR_E2E_WRONG_DESTINATION")
    if kind != expected_kind:
        raise ProtocolError("ERR_E2E_KIND")
    peer = identity.active_peer(source, now=now)
    try:
        uuid.UUID(message_id)
    except ValueError as exc:
        raise ProtocolError("ERR_E2E_MESSAGE_ID") from exc
    current = int(time.time()) if now is None else now
    if abs(current - sent_at) > MAX_CLOCK_SKEW_SECONDS:
        raise ProtocolError("ERR_E2E_STALE")
    if replay_ids is not None and message_id in replay_ids:
        raise ProtocolError("ERR_E2E_REPLAY")
    signature = _unb64(envelope["signature"], limit=64)
    signed = dict(envelope)
    del signed["signature"]
    try:
        Ed25519PublicKey.from_public_bytes(peer.sign_public).verify(signature, canonical_json_bytes(signed))
    except InvalidSignature as exc:
        raise PolicyError("ERR_E2E_SIGNATURE") from exc
    ephemeral_public = _unb64(envelope["ephemeral_public"], limit=32)
    nonce = _unb64(envelope["nonce"], limit=12)
    ciphertext = _unb64(envelope["ciphertext"], limit=3 * 1024 * 1024)
    if len(ephemeral_public) != 32 or len(nonce) != 12:
        raise ProtocolError("ERR_E2E_ENCODING")
    shared = identity.exchange_private.exchange(X25519PublicKey.from_public_bytes(ephemeral_public))
    cipher = ChaCha20Poly1305(_key(shared, source, identity.device_id, message_id, kind))
    header = dict(signed)
    del header["ciphertext"]
    try:
        plaintext = cipher.decrypt(nonce, ciphertext, canonical_json_bytes(header))
    except InvalidTag as exc:
        raise PolicyError("ERR_E2E_DECRYPT") from exc
    if replay_ids is not None:
        replay_ids.add(message_id)
        if len(replay_ids) > 4096:
            replay_ids.pop()
    return source, plaintext
