from __future__ import annotations

import hashlib
import io
import json
import os
import socket
import struct
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO

from .errors import ProtocolError

MAGIC = b"BTP1"
ACK_MAGIC = b"BTA1"
WIRE_VERSION = 1
HEADER = struct.Struct("!4sBBHQ")  # magic, version, flags, metadata_len, payload_len
ACK_HEADER = struct.Struct("!4sBH")  # magic, status, metadata_len
MAX_METADATA_BYTES = 16_384
DEFAULT_MAX_FRAME_BYTES = 2 * 1024 * 1024
CONTENT_TYPE = "application/vnd.intersignal.brad"


@dataclass(frozen=True)
class TransferMetadata:
    transfer_id: str
    filename: str
    transport_sha256: str
    sent_at_unix: int
    content_type: str = CONTENT_TYPE

    def to_dict(self) -> dict[str, Any]:
        return {
            "content_type": self.content_type,
            "filename": self.filename,
            "transport_sha256": self.transport_sha256,
            "sent_at_unix": self.sent_at_unix,
            "transfer_id": self.transfer_id,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "TransferMetadata":
        required = {
            "transfer_id": str,
            "filename": str,
            "transport_sha256": str,
            "sent_at_unix": int,
            "content_type": str,
        }
        if set(value) != set(required):
            raise ProtocolError("ERR_METADATA_SCHEMA")
        for key, expected in required.items():
            if type(value[key]) is not expected:
                raise ProtocolError(f"ERR_METADATA_TYPE:{key}")
        if value["content_type"] != CONTENT_TYPE:
            raise ProtocolError("ERR_CONTENT_TYPE")
        if len(value["transfer_id"]) > 64:
            raise ProtocolError("ERR_TRANSFER_ID")
        try:
            uuid.UUID(value["transfer_id"])
        except ValueError as exc:
            raise ProtocolError("ERR_TRANSFER_ID") from exc
        digest = value["transport_sha256"]
        if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
            raise ProtocolError("ERR_OBJECT_DIGEST")
        if value["sent_at_unix"] < 0:
            raise ProtocolError("ERR_SENT_AT")
        return cls(**value)


@dataclass(frozen=True)
class Ack:
    stored: bool
    validated: bool
    accepted: bool
    reason: str
    transport_sha256: str
    destination: str | None = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "accepted": self.accepted,
            "transport_sha256": self.transport_sha256,
            "reason": self.reason,
            "stored": self.stored,
            "validated": self.validated,
        }
        if self.destination is not None:
            result["destination"] = self.destination
        return result


def canonical_json_bytes(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sanitize_filename(filename: str) -> str:
    name = Path(filename).name
    safe = "".join(ch for ch in name if ch.isalnum() or ch in "._-")
    if not safe or safe in {".", ".."}:
        safe = "frame.brad"
    if not safe.lower().endswith(".brad"):
        safe += ".brad"
    return safe[:180]


def build_metadata(data: bytes, filename: str) -> TransferMetadata:
    return TransferMetadata(
        transfer_id=str(uuid.uuid4()),
        filename=sanitize_filename(filename),
        transport_sha256=sha256_bytes(data),
        sent_at_unix=int(time.time()),
    )


def encode_transfer(data: bytes, filename: str, max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES) -> bytes:
    if not isinstance(data, bytes):
        raise TypeError("data must be bytes")
    if len(data) == 0:
        raise ProtocolError("ERR_EMPTY_FRAME")
    if len(data) > max_frame_bytes:
        raise ProtocolError("ERR_FRAME_TOO_LARGE")
    metadata = build_metadata(data, filename)
    metadata_bytes = canonical_json_bytes(metadata.to_dict())
    if len(metadata_bytes) > MAX_METADATA_BYTES:
        raise ProtocolError("ERR_METADATA_TOO_LARGE")
    return HEADER.pack(MAGIC, WIRE_VERSION, 0, len(metadata_bytes), len(data)) + metadata_bytes + data


def read_exact(stream: BinaryIO | socket.socket, length: int) -> bytes:
    if length < 0:
        raise ProtocolError("ERR_NEGATIVE_READ_LENGTH")
    chunks: list[bytes] = []
    remaining = length
    while remaining:
        chunk = stream.recv(remaining) if hasattr(stream, "recv") else stream.read(remaining)
        if not chunk:
            raise ProtocolError("ERR_TRUNCATED_STREAM")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def decode_transfer_from_socket(sock: socket.socket, max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES) -> tuple[TransferMetadata, bytes]:
    raw_header = read_exact(sock, HEADER.size)
    magic, version, flags, metadata_len, payload_len = HEADER.unpack(raw_header)
    if magic != MAGIC:
        raise ProtocolError("ERR_MAGIC")
    if version != WIRE_VERSION:
        raise ProtocolError("ERR_WIRE_VERSION")
    if flags != 0:
        raise ProtocolError("ERR_FLAGS")
    if metadata_len <= 0 or metadata_len > MAX_METADATA_BYTES:
        raise ProtocolError("ERR_METADATA_LENGTH")
    if payload_len <= 0 or payload_len > max_frame_bytes:
        raise ProtocolError("ERR_PAYLOAD_LENGTH")
    metadata_raw = read_exact(sock, metadata_len)
    try:
        metadata_obj = json.loads(metadata_raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("ERR_METADATA_JSON") from exc
    if not isinstance(metadata_obj, dict):
        raise ProtocolError("ERR_METADATA_JSON_TYPE")
    metadata = TransferMetadata.from_dict(metadata_obj)
    payload = read_exact(sock, payload_len)
    if sha256_bytes(payload) != metadata.transport_sha256:
        raise ProtocolError("ERR_DIGEST_MISMATCH")
    return metadata, payload


def encode_ack(ack: Ack) -> bytes:
    body = canonical_json_bytes(ack.to_dict())
    if len(body) > MAX_METADATA_BYTES:
        raise ProtocolError("ERR_ACK_TOO_LARGE")
    status = 1 if ack.accepted else 0
    return ACK_HEADER.pack(ACK_MAGIC, status, len(body)) + body


def decode_ack_from_socket(sock: socket.socket) -> Ack:
    raw_header = read_exact(sock, ACK_HEADER.size)
    magic, status, metadata_len = ACK_HEADER.unpack(raw_header)
    if magic != ACK_MAGIC:
        raise ProtocolError("ERR_ACK_MAGIC")
    if status not in (0, 1):
        raise ProtocolError("ERR_ACK_STATUS")
    if metadata_len <= 0 or metadata_len > MAX_METADATA_BYTES:
        raise ProtocolError("ERR_ACK_LENGTH")
    body = read_exact(sock, metadata_len)
    try:
        obj = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("ERR_ACK_JSON") from exc
    required = {"stored", "validated", "accepted", "reason", "transport_sha256"}
    allowed = required | {"destination"}
    if not isinstance(obj, dict) or not required.issubset(obj) or not set(obj).issubset(allowed):
        raise ProtocolError("ERR_ACK_SCHEMA")
    if type(obj["stored"]) is not bool or type(obj["validated"]) is not bool or type(obj["accepted"]) is not bool:
        raise ProtocolError("ERR_ACK_BOOL_TYPE")
    if type(obj["reason"]) is not str or len(obj["reason"]) > 512:
        raise ProtocolError("ERR_ACK_REASON")
    digest = obj["transport_sha256"]
    if type(digest) is not str or (digest and (len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest))):
        raise ProtocolError("ERR_ACK_DIGEST")
    destination = obj.get("destination")
    if destination is not None and (type(destination) is not str or destination not in {"accepted", "quarantine", "rejected"}):
        raise ProtocolError("ERR_ACK_DESTINATION")
    accepted = obj["accepted"]
    if bool(status) is not accepted:
        raise ProtocolError("ERR_ACK_STATUS_MISMATCH")
    if accepted and (not obj["stored"] or not obj["validated"] or destination != "accepted"):
        raise ProtocolError("ERR_ACK_ACCEPTANCE_INVARIANT")
    if not accepted and destination == "accepted":
        raise ProtocolError("ERR_ACK_ACCEPTANCE_INVARIANT")
    return Ack(
        stored=obj["stored"],
        validated=obj["validated"],
        accepted=obj["accepted"],
        reason=obj["reason"],
        transport_sha256=digest,
        destination=destination,
    )


def decode_ack_bytes(data: bytes) -> Ack:
    stream = io.BytesIO(data)
    ack = decode_ack_from_socket(stream)  # type: ignore[arg-type]
    if stream.read(1):
        raise ProtocolError("ERR_ACK_TRAILING_BYTES")
    return ack


def atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass
