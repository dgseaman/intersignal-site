from __future__ import annotations

import argparse
import json
import platform
import socket
import ssl
import sys
import time
from pathlib import Path

from . import __version__
from .agent import AgentConfig, JumpKitAgent, send_direct_first
from .certs import init_ca, issue_identity
from .client import _read_bounded_frame, send_frame
from .device import DeviceIdentity, pairing_words
from .errors import PolicyError, ProtocolError
from .protocol import decode_ack_bytes, encode_transfer, sha256_bytes
from .proxy import JumpKitProxy, ProxyConfig
from .relay import RelayConfig, RendezvousRelay, connect_relay, relay_hello
from .timeouts import (
    DEFAULT_CONNECT_TIMEOUT_SECONDS,
    DEFAULT_DIRECT_TIMEOUT_SECONDS,
    DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS,
    DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS,
    DEFAULT_UPSTREAM_TIMEOUT_SECONDS,
)
from .wire import recv_message, send_message


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, sort_keys=True))


def _add_relay_client_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--relay-host", required=True)
    parser.add_argument("--relay-port", type=int, default=8750)
    parser.add_argument("--relay-ca", type=Path, required=True)
    parser.add_argument("--relay-server-name", required=True)
    parser.add_argument("--relay-fingerprint", help="Pinned SHA-256 fingerprint of the relay TLS certificate")
    parser.add_argument("--relay-node-id", help="Pinned braid:// NodeId SAN of the relay certificate")
    parser.add_argument("--relay-token-file", type=Path, required=True, help="File containing the relay enrollment token")
    parser.add_argument("--connect-timeout", type=float, default=DEFAULT_CONNECT_TIMEOUT_SECONDS,
                        help="Seconds allowed for TCP/TLS connection and relay authentication (default: 15)")


def _secret(path: Path) -> str:
    value = path.read_text(encoding="utf-8").strip()
    if len(value) < 16 or len(value) > 4096:
        raise PolicyError("ERR_RELAY_TOKEN_STRENGTH")
    return value


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="braid-jumpkit", description="BRAID 1.5.3 — JUMP. Local by default. Remote when invited.")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)

    doctor = sub.add_parser("doctor", help="Report local Jump Kit and Braid receiver readiness")
    doctor.add_argument("--upstream-host", default="127.0.0.1")
    doctor.add_argument("--upstream-port", type=int, default=8745)
    doctor.add_argument("--timeout", type=float, default=1.0)

    ca = sub.add_parser("init-ca", help="Create a private local Jump Kit CA")
    ca.add_argument("--out-dir", type=Path, required=True)
    ca.add_argument("--name", default="Braid Jump Kit Local CA")

    issue = sub.add_parser("issue", help="Issue a server or client TLS identity from the local CA")
    issue.add_argument("--out-dir", type=Path, required=True)
    issue.add_argument("--ca-key", type=Path, required=True)
    issue.add_argument("--ca-cert", type=Path, required=True)
    issue.add_argument("--name", required=True)
    issue.add_argument("--role", choices=("server", "client"), required=True)
    issue.add_argument("--dns", action="append", default=[])
    issue.add_argument("--ip", action="append", default=[])
    issue.add_argument("--braid-node-id", help="64-hex Braid identity NodeId to embed as braid:// SAN URI")
    issue.add_argument("--braid-scheme-id-hex", help="Exact scheme_id bytes as hex for NodeId derivation")
    issue.add_argument("--braid-public-key-hex", help="Exact Braid public-key bytes as hex for NodeId derivation")

    listen = sub.add_parser("listen", help="Terminate TLS 1.3 and proxy BTP1 to the local Braid receiver")
    listen.add_argument("--bind", default="127.0.0.1")
    listen.add_argument("--port", type=int, default=8746)
    listen.add_argument("--cert", type=Path, required=True)
    listen.add_argument("--key", type=Path, required=True)
    listen.add_argument("--client-ca", type=Path)
    listen.add_argument("--require-client-cert", action="store_true")
    listen.add_argument("--peer-fingerprint", help="Pinned SHA-256 fingerprint of the allowed client certificate")
    listen.add_argument("--peer-node-id", help="Allowed client braid:// NodeId SAN (64 hex)")
    listen.add_argument("--allow-public", action="store_true")
    listen.add_argument("--upstream-host", default="127.0.0.1")
    listen.add_argument("--upstream-port", type=int, default=8745)
    listen.add_argument("--audit-log", type=Path)
    listen.add_argument("--max-connections", type=int, default=64)

    send = sub.add_parser("send", help="Send exact signed .brad bytes to a remote Jump Kit endpoint over TLS 1.3")
    send.add_argument("frame", type=Path)
    send.add_argument("--host", required=True)
    send.add_argument("--port", type=int, default=8746)
    send.add_argument("--ca-file", type=Path, required=True)
    send.add_argument("--server-name")
    send.add_argument("--client-cert", type=Path)
    send.add_argument("--client-key", type=Path)
    send.add_argument("--peer-fingerprint", help="Required peer certificate SHA-256 pin")
    send.add_argument("--peer-node-id", help="Required peer braid:// NodeId SAN (64 hex)")

    init_device = sub.add_parser("init-device", help="Name this device and create its Jump Kit transport identity")
    init_device.add_argument("--name", required=True)
    init_device.add_argument("--identity-file", type=Path, required=True)

    pair_code = sub.add_parser("pair-code", help="Show this device's pairing code and comparison words")
    pair_code.add_argument("--identity-file", type=Path, required=True)
    pair_code.add_argument("--ttl-seconds", type=int, default=600)

    approve = sub.add_parser("pair-approve", help="Approve a peer pairing code")
    approve.add_argument("code")
    approve.add_argument("--identity-file", type=Path, required=True)
    approve.add_argument("--access-seconds", type=int, help="Optional expiry for the approved peer authorization")

    revoke = sub.add_parser("pair-revoke", help="Revoke an approved peer immediately")
    revoke.add_argument("peer", help="Approved peer name or full device ID")
    revoke.add_argument("--identity-file", type=Path, required=True)

    peers = sub.add_parser("peers", help="List approved peer devices")
    peers.add_argument("--identity-file", type=Path, required=True)

    relay = sub.add_parser("relay", help="Run the TLS 1.3 rendezvous and opaque relay service")
    relay.add_argument("--bind", default="127.0.0.1")
    relay.add_argument("--port", type=int, default=8750)
    relay.add_argument("--cert", type=Path, required=True)
    relay.add_argument("--key", type=Path, required=True)
    relay.add_argument("--relay-token-file", type=Path, required=True)
    relay.add_argument("--max-connections", type=int, default=256)
    relay.add_argument("--audit-log", type=Path)
    relay.add_argument("--connection-timeout", type=float, default=DEFAULT_CONNECT_TIMEOUT_SECONDS,
                       help="Seconds allowed for TLS and authenticated relay setup (default: 15)")
    relay.add_argument("--response-timeout", type=float, default=DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS,
                       help="Seconds the relay waits for an agent response (default: 120)")

    agent = sub.add_parser("agent", help="Keep this device reachable through the rendezvous/relay")
    agent.add_argument("--identity-file", type=Path, required=True)
    _add_relay_client_args(agent)
    agent.add_argument("--upstream-host", default="127.0.0.1")
    agent.add_argument("--upstream-port", type=int, default=8745)
    agent.add_argument("--direct-bind", default="0.0.0.0")
    agent.add_argument("--direct-port", type=int, default=8747)
    agent.add_argument("--no-direct", action="store_true")
    agent.add_argument("--upstream-timeout", type=float, default=DEFAULT_UPSTREAM_TIMEOUT_SECONDS,
                       help="Seconds allowed for the local Braid receiver to complete processing (default: 90)")
    agent.add_argument("--direct-timeout", type=float, default=DEFAULT_DIRECT_TIMEOUT_SECONDS,
                       help="Seconds allowed for direct-path operations (default: 3)")

    send_peer = sub.add_parser("send-peer", help="Send a signed .brad object to an approved device by name or ID")
    send_peer.add_argument("frame", type=Path)
    send_peer.add_argument("--to", required=True, help="Approved peer name or full device ID")
    send_peer.add_argument("--identity-file", type=Path, required=True)
    _add_relay_client_args(send_peer)
    send_peer.add_argument("--response-timeout", type=float, default=DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS,
                           help="Seconds allowed for the complete relayed round trip (default: 150)")
    send_peer.add_argument("--direct-timeout", type=float, default=DEFAULT_DIRECT_TIMEOUT_SECONDS,
                           help="Seconds allowed for a direct-path attempt before relay fallback (default: 3)")

    peer_status = sub.add_parser("peer-status", help="Check relay reachability and whether an approved peer is online")
    peer_status.add_argument("--peer", required=True, help="Approved peer name or full device ID")
    peer_status.add_argument("--identity-file", type=Path, required=True)
    _add_relay_client_args(peer_status)
    return p


def _peer_id(identity: DeviceIdentity, value: str) -> str:
    if value in identity.peers:
        return value
    matches = [peer.device_id for peer in identity.peers.values() if peer.name.casefold() == value.casefold()]
    if len(matches) != 1:
        raise PolicyError("ERR_PEER_NOT_APPROVED")
    return matches[0]


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "doctor":
            reachable = False
            error = None
            try:
                with socket.create_connection((args.upstream_host, args.upstream_port), timeout=args.timeout):
                    reachable = True
            except OSError as exc:
                error = str(exc)
            _json({
                "version": __version__,
                "platform": platform.platform(),
                "python": platform.python_version(),
                "tls13_available": getattr(ssl, "HAS_TLSv1_3", False),
                "upstream": f"{args.upstream_host}:{args.upstream_port}",
                "upstream_reachable": reachable,
                "upstream_error": error,
                "authority_model": "transport_only; Braid receiver owns acceptance/finality",
            })
            return 0 if getattr(ssl, "HAS_TLSv1_3", False) else 2
        if args.command == "init-ca":
            _json(init_ca(args.out_dir, args.name))
            return 0
        if args.command == "issue":
            scheme_id = bytes.fromhex(args.braid_scheme_id_hex) if args.braid_scheme_id_hex is not None else None
            public_key = bytes.fromhex(args.braid_public_key_hex) if args.braid_public_key_hex is not None else None
            _json(issue_identity(
                args.out_dir, args.ca_key, args.ca_cert, args.name,
                role=args.role, dns_names=args.dns, ip_addresses=args.ip,
                braid_node_id=args.braid_node_id,
                braid_scheme_id=scheme_id, braid_public_key=public_key,
            ))
            return 0
        if args.command == "listen":
            config = ProxyConfig(
                bind=args.bind, port=args.port, cert=args.cert, key=args.key,
                client_ca=args.client_ca, require_client_cert=args.require_client_cert,
                peer_fingerprint=args.peer_fingerprint, peer_node_id=args.peer_node_id,
                allow_public=args.allow_public, upstream_host=args.upstream_host,
                upstream_port=args.upstream_port, audit_log=args.audit_log, max_connections=args.max_connections,
            )
            server = JumpKitProxy(config)
            host, port = server.address
            _json({"status": "STARTING", "bind": host, "port": port, "tls": "1.3-only", "upstream": f"{args.upstream_host}:{args.upstream_port}"})
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                return 130
            return 0
        if args.command == "send":
            result = send_frame(
                args.frame, args.host, args.port, ca_file=args.ca_file,
                server_name=args.server_name, client_cert=args.client_cert, client_key=args.client_key,
                peer_fingerprint=args.peer_fingerprint, peer_node_id=args.peer_node_id,
            )
            _json({"host": result.host, "port": result.port, "tls": result.tls_version, "ack": result.ack.to_dict()})
            return 0 if result.ack.accepted else 2
        if args.command == "init-device":
            if args.identity_file.exists():
                raise PolicyError("ERR_DEVICE_FILE_EXISTS")
            identity = DeviceIdentity.create(args.name)
            identity.save(args.identity_file)
            _json({
                "device_id": identity.device_id,
                "identity_file": str(args.identity_file),
                "name": identity.name,
                "pairing_words": pairing_words(identity.device_id),
                "status": "created",
            })
            return 0
        if args.command == "pair-code":
            identity = DeviceIdentity.load(args.identity_file)
            issued_at = int(time.time())
            _json({
                "device_id": identity.device_id,
                "name": identity.name,
                "pairing_code": identity.pairing_code(ttl_seconds=args.ttl_seconds, now=issued_at),
                "pairing_words": pairing_words(identity.device_id),
                "expires_at_unix": issued_at + args.ttl_seconds,
                "jump_code": "READY",
            })
            return 0
        if args.command == "pair-approve":
            identity = DeviceIdentity.load(args.identity_file)
            peer = identity.approve(args.code, access_seconds=args.access_seconds)
            identity.save(args.identity_file)
            _json({
                "device_id": peer.device_id,
                "name": peer.name,
                "pairing_words": pairing_words(peer.device_id),
                "receipt": "CODE ACCEPTED",
                "status": "approved",
            })
            return 0
        if args.command == "pair-revoke":
            identity = DeviceIdentity.load(args.identity_file)
            peer_id = _peer_id(identity, args.peer)
            peer = identity.revoke(peer_id)
            identity.save(args.identity_file)
            _json({"device_id": peer.device_id, "name": peer.name, "receipt": "REJECTED", "status": "revoked"})
            return 0
        if args.command == "peers":
            identity = DeviceIdentity.load(args.identity_file)
            _json({"device": identity.name, "peers": [
                {
                    "device_id": peer.device_id,
                    "name": peer.name,
                    "pairing_words": pairing_words(peer.device_id),
                    "authorization": peer.authorization_status(),
                    "access_expires_at_unix": peer.access_expires_at_unix,
                }
                for peer in sorted(identity.peers.values(), key=lambda item: item.name.casefold())
            ]})
            return 0
        if args.command == "relay":
            relay = RendezvousRelay(RelayConfig(
                bind=args.bind, port=args.port, cert=args.cert, key=args.key,
                enrollment_token=_secret(args.relay_token_file), max_connections=args.max_connections,
                audit_log=args.audit_log, connection_timeout_seconds=args.connection_timeout,
                response_timeout_seconds=args.response_timeout,
            ))
            _json({"bind": args.bind, "port": args.port, "status": "starting", "tls": "1.3-only", "payload_visibility": "opaque-e2e-ciphertext"})
            try:
                relay.serve_forever()
            except KeyboardInterrupt:
                return 130
            return 0
        if args.command == "agent":
            identity = DeviceIdentity.load(args.identity_file)
            _json({
                "device_id": identity.device_id,
                "name": identity.name,
                "relay": f"{args.relay_host}:{args.relay_port}",
                "status": "connecting",
                "upstream": f"{args.upstream_host}:{args.upstream_port}",
            })
            agent = JumpKitAgent(AgentConfig(
                identity_file=args.identity_file, relay_host=args.relay_host, relay_port=args.relay_port,
                relay_ca=args.relay_ca, relay_server_name=args.relay_server_name,
                relay_token=_secret(args.relay_token_file), relay_fingerprint=args.relay_fingerprint,
                relay_node_id=args.relay_node_id, upstream_host=args.upstream_host, upstream_port=args.upstream_port,
                direct_bind=args.direct_bind, direct_port=args.direct_port, direct_enabled=not args.no_direct,
                connect_timeout_seconds=args.connect_timeout, upstream_timeout_seconds=args.upstream_timeout,
                direct_timeout_seconds=args.direct_timeout,
            ))
            try:
                agent.start()
                if not agent.wait_ready(15.0):
                    raise ProtocolError("ERR_AGENT_CONNECT:" + (agent.last_error or "timeout"))
                _json({"device_id": identity.device_id, "name": identity.name, "status": "online"})
                while True:
                    time.sleep(1.0)
            except KeyboardInterrupt:
                agent.stop()
                return 130
            return 0
        if args.command == "send-peer":
            identity = DeviceIdentity.load(args.identity_file)
            peer_id = _peer_id(identity, args.to)
            data = _read_bounded_frame(args.frame, 2 * 1024 * 1024)
            packet = encode_transfer(data, args.frame.name)
            result = send_direct_first(
                identity, peer_id, packet, relay_host=args.relay_host, relay_port=args.relay_port,
                relay_ca=args.relay_ca, relay_server_name=args.relay_server_name,
                relay_token=_secret(args.relay_token_file), relay_fingerprint=args.relay_fingerprint,
                relay_node_id=args.relay_node_id, connect_timeout_seconds=args.connect_timeout,
                response_timeout_seconds=args.response_timeout, direct_timeout_seconds=args.direct_timeout,
            )
            ack = decode_ack_bytes(result["ack_bytes"])
            if ack.transport_sha256 != sha256_bytes(data):
                raise ProtocolError("ERR_ACK_DIGEST_MISMATCH")
            _json({
                "ack": ack.to_dict(),
                "path": result["path"],
                "peer_id": peer_id,
                "receipt": result["path"] if ack.accepted else "REJECTED",
                "tls": result["tls_version"],
            })
            return 0 if ack.accepted else 2
        if args.command == "peer-status":
            identity = DeviceIdentity.load(args.identity_file)
            peer_id = _peer_id(identity, args.peer)
            with connect_relay(
                args.relay_host, args.relay_port, ca_file=args.relay_ca,
                server_name=args.relay_server_name, peer_fingerprint=args.relay_fingerprint,
                peer_node_id=args.relay_node_id, timeout_seconds=args.connect_timeout,
            ) as sock:
                hello = relay_hello(sock, identity=identity, token=_secret(args.relay_token_file), role="sender")
                send_message(sock, {"peer_id": peer_id, "type": "status"})
                status = recv_message(sock)
            _json({
                "observed_ip": hello.get("observed_ip"), "peer_id": peer_id,
                "peer_name": identity.peers[peer_id].name, "relay_tls": "TLSv1.3",
                "status": status.get("online") and "online" or "offline",
            })
            return 0 if status.get("online") else 2
    except Exception as exc:
        error = str(exc)
        receipt = "EXPIRED" if "EXPIRED" in error else "REJECTED"
        _json({"status": "error", "error": error, "receipt": receipt, "type": exc.__class__.__name__})
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
