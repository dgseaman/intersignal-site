from __future__ import annotations

import math

from .errors import PolicyError


# These budgets are intentionally hierarchical. Semantic processing happens at
# the receiver; each outer hop must remain alive longer than the work inside it.
DEFAULT_CONNECT_TIMEOUT_SECONDS = 15.0
DEFAULT_DIRECT_TIMEOUT_SECONDS = 3.0
DEFAULT_UPSTREAM_TIMEOUT_SECONDS = 90.0
DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS = 120.0
DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS = 150.0
DEFAULT_RECONNECT_SECONDS = 1.0
MAX_TIMEOUT_SECONDS = 600.0


def validate_timeout(value: float, *, name: str) -> float:
    if not math.isfinite(value) or not 0.1 <= value <= MAX_TIMEOUT_SECONDS:
        raise PolicyError(f"ERR_TIMEOUT_RANGE:{name}")
    return value


def validate_timeout_hierarchy(*, upstream: float, relay_response: float, sender_response: float) -> None:
    validate_timeout(upstream, name="upstream")
    validate_timeout(relay_response, name="relay_response")
    validate_timeout(sender_response, name="sender_response")
    if not upstream < relay_response < sender_response:
        raise PolicyError("ERR_TIMEOUT_HIERARCHY")
