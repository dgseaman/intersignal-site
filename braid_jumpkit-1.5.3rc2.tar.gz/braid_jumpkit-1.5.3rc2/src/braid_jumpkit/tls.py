from __future__ import annotations

import ssl
from pathlib import Path

from .errors import PolicyError


def client_context(*, ca_file: Path, client_cert: Path | None = None, client_key: Path | None = None) -> ssl.SSLContext:
    if not ca_file.is_file():
        raise FileNotFoundError(ca_file)
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=str(ca_file))
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    if (client_cert is None) != (client_key is None):
        raise PolicyError("ERR_CLIENT_CERT_KEY_PAIR_REQUIRED")
    if client_cert is not None and client_key is not None:
        context.load_cert_chain(str(client_cert), str(client_key))
    return context


def server_context(*, cert: Path, key: Path, client_ca: Path | None = None, require_client_cert: bool = False) -> ssl.SSLContext:
    if not cert.is_file():
        raise FileNotFoundError(cert)
    if not key.is_file():
        raise FileNotFoundError(key)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.load_cert_chain(str(cert), str(key))
    if require_client_cert:
        if client_ca is None or not client_ca.is_file():
            raise PolicyError("ERR_CLIENT_CA_REQUIRED")
        context.load_verify_locations(cafile=str(client_ca))
        context.verify_mode = ssl.CERT_REQUIRED
    return context
