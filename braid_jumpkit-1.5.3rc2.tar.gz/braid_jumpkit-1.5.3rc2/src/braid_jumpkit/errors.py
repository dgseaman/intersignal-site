class JumpKitTransportError(Exception):
    """Base error for Jump Kit transport failures."""


class ProtocolError(JumpKitTransportError):
    """Malformed or unsupported wire data."""


class PolicyError(JumpKitTransportError):
    """Local policy rejected an operation."""


class ValidationError(JumpKitTransportError):
    """Reserved for receiver-side validation reporting."""
