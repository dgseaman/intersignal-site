from __future__ import annotations

import ipaddress
import os
from datetime import UTC, datetime, timedelta
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

from .errors import PolicyError
from .identity import NODE_ID_PREFIX, certificate_file_fingerprint, derive_node_id, normalize_node_id


def _write_private(path: Path, key: rsa.RSAPrivateKey) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    path.write_bytes(data)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _write_cert(path: Path, cert: x509.Certificate) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))


def init_ca(out_dir: Path, common_name: str = "Braid Jump Kit Local CA") -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    ca_key_path = out_dir / "jumpkit-ca.key.pem"
    ca_cert_path = out_dir / "jumpkit-ca.crt.pem"
    if ca_key_path.exists() or ca_cert_path.exists():
        raise FileExistsError("CA files already exist")
    key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    now = datetime.now(UTC)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, common_name)])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5))
        .not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(key.public_key()), critical=False)
        .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=False, content_commitment=False,
                                     data_encipherment=False, key_agreement=False, key_cert_sign=True,
                                     crl_sign=True, encipher_only=False, decipher_only=False), critical=True)
        .sign(key, hashes.SHA256())
    )
    _write_private(ca_key_path, key)
    _write_cert(ca_cert_path, cert)
    return {"ca_key": str(ca_key_path), "ca_cert": str(ca_cert_path)}


def issue_identity(
    out_dir: Path,
    ca_key_path: Path,
    ca_cert_path: Path,
    name: str,
    *,
    role: str,
    dns_names: list[str] | None = None,
    ip_addresses: list[str] | None = None,
    braid_node_id: str | None = None,
    braid_scheme_id: bytes | None = None,
    braid_public_key: bytes | None = None,
    days: int = 825,
) -> dict[str, str]:
    if role not in {"server", "client"}:
        raise ValueError("role must be server or client")
    ca_key = serialization.load_pem_private_key(ca_key_path.read_bytes(), password=None)
    ca_cert = x509.load_pem_x509_certificate(ca_cert_path.read_bytes())
    key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    now = datetime.now(UTC)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, name)])
    sans: list[x509.GeneralName] = [x509.DNSName(name)]
    for dns in dns_names or []:
        if dns != name:
            sans.append(x509.DNSName(dns))
    for value in ip_addresses or []:
        sans.append(x509.IPAddress(ipaddress.ip_address(value)))
    if (braid_scheme_id is None) != (braid_public_key is None):
        raise PolicyError("ERR_BRAID_IDENTITY_PAIR_REQUIRED")
    derived_node_id = (
        derive_node_id(braid_scheme_id, braid_public_key)
        if braid_scheme_id is not None and braid_public_key is not None
        else None
    )
    normalized_node_id = normalize_node_id(braid_node_id) if braid_node_id is not None else derived_node_id
    if normalized_node_id is not None and derived_node_id is not None and normalized_node_id != derived_node_id:
        raise PolicyError("ERR_CONFIGURED_NODE_ID_MISMATCH")
    if normalized_node_id is not None:
        sans.append(x509.UniformResourceIdentifier(f"{NODE_ID_PREFIX}{normalized_node_id}"))
    eku = ExtendedKeyUsageOID.SERVER_AUTH if role == "server" else ExtendedKeyUsageOID.CLIENT_AUTH
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5))
        .not_valid_after(now + timedelta(days=days))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
        .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=True, content_commitment=False, data_encipherment=False, key_agreement=False, key_cert_sign=False, crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
        .add_extension(x509.SubjectAlternativeName(sans), critical=False)
        .add_extension(x509.ExtendedKeyUsage([eku]), critical=False)
        .sign(ca_key, hashes.SHA256())
    )
    stem = f"jumpkit-{role}-{name}".replace(" ", "-")
    key_path = out_dir / f"{stem}.key.pem"
    cert_path = out_dir / f"{stem}.crt.pem"
    _write_private(key_path, key)
    _write_cert(cert_path, cert)
    result = {
        "key": str(key_path),
        "cert": str(cert_path),
        "certificate_sha256": certificate_file_fingerprint(cert_path),
    }
    if normalized_node_id is not None:
        result["braid_node_id"] = normalized_node_id
    return result
