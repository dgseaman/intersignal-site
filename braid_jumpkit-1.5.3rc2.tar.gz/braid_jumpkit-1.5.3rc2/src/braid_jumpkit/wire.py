from __future__ import annotations

import json
import socket
import struct
from typing import Any

from .errors import ProtocolError
from .protocol import canonical_json_bytes, read_exact

LENGTH = struct.Struct("!I")
MAX_WAN_MESSAGE_BYTES = 3 * 1024 * 1024


def send_message(sock: socket.socket, value: dict[str, Any]) -> None:
    body = canonical_json_bytes(value)
    if not body or len(body) > MAX_WAN_MESSAGE_BYTES:
        raise ProtocolError("ERR_WAN_MESSAGE_LENGTH")
    sock.sendall(LENGTH.pack(len(body)) + body)


def recv_message(sock: socket.socket) -> dict[str, Any]:
    raw_length = read_exact(sock, LENGTH.size)
    (length,) = LENGTH.unpack(raw_length)
    if length <= 0 or length > MAX_WAN_MESSAGE_BYTES:
        raise ProtocolError("ERR_WAN_MESSAGE_LENGTH")
    raw = read_exact(sock, length)
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("ERR_WAN_MESSAGE_JSON") from exc
    if not isinstance(value, dict):
        raise ProtocolError("ERR_WAN_MESSAGE_SCHEMA")
    return value
