from __future__ import annotations

import base64
import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey

from .errors import PolicyError
from .protocol import atomic_write, canonical_json_bytes

DEVICE_DOMAIN = b"braid-jumpkit-device-v1"
DEVICE_FILE_VERSION = 2
PAIRING_VERSION = 2
DEFAULT_PAIRING_TTL_SECONDS = 600
MAX_PAIRING_TTL_SECONDS = 3600
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._-]{0,62}[A-Za-z0-9]$|^[A-Za-z0-9]$")


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _unb64(value: str) -> bytes:
    if not isinstance(value, str) or len(value) > 8192:
        raise PolicyError("ERR_PAIRING_CODE")
    try:
        return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except Exception as exc:
        raise PolicyError("ERR_PAIRING_CODE") from exc


def _raw_public(key: Ed25519PublicKey | X25519PublicKey) -> bytes:
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def _raw_private(key: Ed25519PrivateKey | X25519PrivateKey) -> bytes:
    return key.private_bytes(
        serialization.Encoding.Raw,
        serialization.PrivateFormat.Raw,
        serialization.NoEncryption(),
    )


def derive_device_id(sign_public: bytes, exchange_public: bytes) -> str:
    if len(sign_public) != 32 or len(exchange_public) != 32:
        raise PolicyError("ERR_DEVICE_PUBLIC_KEY")
    return hashlib.sha256(DEVICE_DOMAIN + sign_public + exchange_public).hexdigest()


def _validate_name(name: str) -> str:
    value = name.strip()
    if not NAME_RE.fullmatch(value):
        raise PolicyError("ERR_DEVICE_NAME")
    return value


@dataclass
class Peer:
    device_id: str
    name: str
    sign_public: bytes
    exchange_public: bytes
    approved_at_unix: int = 0
    access_expires_at_unix: int | None = None
    revoked_at_unix: int | None = None

    def authorization_status(self, now: int | None = None) -> str:
        current = int(time.time()) if now is None else now
        if self.revoked_at_unix is not None:
            return "revoked"
        if self.access_expires_at_unix is not None and current >= self.access_expires_at_unix:
            return "expired"
        return "active"

    def to_dict(self) -> dict[str, Any]:
        return {
            "device_id": self.device_id,
            "exchange_public": _b64(self.exchange_public),
            "name": self.name,
            "sign_public": _b64(self.sign_public),
            "approved_at_unix": self.approved_at_unix,
            "access_expires_at_unix": self.access_expires_at_unix,
            "revoked_at_unix": self.revoked_at_unix,
        }


@dataclass
class DeviceIdentity:
    name: str
    sign_private: Ed25519PrivateKey
    exchange_private: X25519PrivateKey
    peers: dict[str, Peer] = field(default_factory=dict)

    @property
    def sign_public(self) -> bytes:
        return _raw_public(self.sign_private.public_key())

    @property
    def exchange_public(self) -> bytes:
        return _raw_public(self.exchange_private.public_key())

    @property
    def device_id(self) -> str:
        return derive_device_id(self.sign_public, self.exchange_public)

    @classmethod
    def create(cls, name: str) -> "DeviceIdentity":
        return cls(_validate_name(name), Ed25519PrivateKey.generate(), X25519PrivateKey.generate())

    def to_dict(self) -> dict[str, Any]:
        return {
            "device_id": self.device_id,
            "exchange_private": _b64(_raw_private(self.exchange_private)),
            "name": self.name,
            "peers": {key: peer.to_dict() for key, peer in sorted(self.peers.items())},
            "sign_private": _b64(_raw_private(self.sign_private)),
            "version": DEVICE_FILE_VERSION,
        }

    def save(self, path: Path) -> None:
        atomic_write(path, canonical_json_bytes(self.to_dict()) + b"\n")

    @classmethod
    def load(cls, path: Path) -> "DeviceIdentity":
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(value, dict) or value.get("version") not in {1, DEVICE_FILE_VERSION}:
                raise PolicyError("ERR_DEVICE_FILE_SCHEMA")
            identity = cls(
                _validate_name(value["name"]),
                Ed25519PrivateKey.from_private_bytes(_unb64(value["sign_private"])),
                X25519PrivateKey.from_private_bytes(_unb64(value["exchange_private"])),
            )
            if value.get("device_id") != identity.device_id:
                raise PolicyError("ERR_DEVICE_ID_MISMATCH")
            raw_peers = value.get("peers", {})
            if not isinstance(raw_peers, dict) or len(raw_peers) > 1024:
                raise PolicyError("ERR_DEVICE_FILE_SCHEMA")
            for raw in raw_peers.values():
                peer = parse_peer_value(raw)
                identity.peers[peer.device_id] = peer
            return identity
        except (KeyError, TypeError, ValueError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise PolicyError("ERR_DEVICE_FILE_SCHEMA") from exc

    def pairing_code(self, *, ttl_seconds: int = DEFAULT_PAIRING_TTL_SECONDS, now: int | None = None) -> str:
        if not (30 <= ttl_seconds <= MAX_PAIRING_TTL_SECONDS):
            raise PolicyError("ERR_PAIRING_TTL")
        issued_at = int(time.time()) if now is None else now
        value = {
            "device_id": self.device_id,
            "exchange_public": _b64(self.exchange_public),
            "name": self.name,
            "sign_public": _b64(self.sign_public),
            "issued_at_unix": issued_at,
            "expires_at_unix": issued_at + ttl_seconds,
            "version": PAIRING_VERSION,
        }
        return _b64(canonical_json_bytes(value))

    def approve(self, code: str, *, access_seconds: int | None = None, now: int | None = None) -> Peer:
        try:
            value = json.loads(_unb64(code).decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise PolicyError("ERR_PAIRING_CODE") from exc
        current = int(time.time()) if now is None else now
        peer = parse_pairing_code_value(value, now=current)
        if peer.device_id == self.device_id:
            raise PolicyError("ERR_PAIR_SELF")
        if access_seconds is not None and not (60 <= access_seconds <= 31_536_000):
            raise PolicyError("ERR_ACCESS_TTL")
        peer.approved_at_unix = current
        peer.access_expires_at_unix = current + access_seconds if access_seconds is not None else None
        self.peers[peer.device_id] = peer
        return peer

    def active_peer(self, peer_id: str, *, now: int | None = None) -> Peer:
        peer = self.peers.get(peer_id)
        if peer is None:
            raise PolicyError("ERR_PEER_NOT_APPROVED")
        status = peer.authorization_status(now)
        if status == "revoked":
            raise PolicyError("ERR_PEER_REVOKED")
        if status == "expired":
            raise PolicyError("ERR_PEER_EXPIRED")
        return peer

    def revoke(self, peer_id: str, *, now: int | None = None) -> Peer:
        peer = self.active_peer(peer_id, now=now)
        peer.revoked_at_unix = int(time.time()) if now is None else now
        return peer


def _parse_public_identity(value: Any, *, allowed: set[str]) -> Peer:
    if not isinstance(value, dict):
        raise PolicyError("ERR_PAIRING_CODE")
    if not set(value).issubset(allowed):
        raise PolicyError("ERR_PAIRING_CODE")
    try:
        sign_public = _unb64(value["sign_public"])
        exchange_public = _unb64(value["exchange_public"])
        expected = derive_device_id(sign_public, exchange_public)
        if value["device_id"] != expected:
            raise PolicyError("ERR_DEVICE_ID_MISMATCH")
        return Peer(expected, _validate_name(value["name"]), sign_public, exchange_public)
    except (KeyError, TypeError, ValueError) as exc:
        raise PolicyError("ERR_PAIRING_CODE") from exc


def parse_pairing_code_value(value: Any, *, now: int | None = None) -> Peer:
    allowed = {
        "version", "device_id", "name", "sign_public", "exchange_public",
        "issued_at_unix", "expires_at_unix",
    }
    if not isinstance(value, dict) or value.get("version") != PAIRING_VERSION:
        raise PolicyError("ERR_PAIRING_CODE")
    issued_at = value.get("issued_at_unix")
    expires_at = value.get("expires_at_unix")
    if type(issued_at) is not int or type(expires_at) is not int:
        raise PolicyError("ERR_PAIRING_CODE")
    if expires_at <= issued_at or expires_at - issued_at > MAX_PAIRING_TTL_SECONDS:
        raise PolicyError("ERR_PAIRING_CODE")
    current = int(time.time()) if now is None else now
    if current < issued_at - 300:
        raise PolicyError("ERR_PAIRING_NOT_YET_VALID")
    if current >= expires_at:
        raise PolicyError("ERR_PAIRING_EXPIRED")
    return _parse_public_identity(value, allowed=allowed)


def parse_peer_value(value: Any) -> Peer:
    allowed = {
        "version", "device_id", "name", "sign_public", "exchange_public",
        "approved_at_unix", "access_expires_at_unix", "revoked_at_unix",
    }
    peer = _parse_public_identity(value, allowed=allowed)
    for key in ("approved_at_unix", "access_expires_at_unix", "revoked_at_unix"):
        field_value = value.get(key)
        if field_value is not None and type(field_value) is not int:
            raise PolicyError("ERR_DEVICE_FILE_SCHEMA")
    peer.approved_at_unix = value.get("approved_at_unix", 0)
    peer.access_expires_at_unix = value.get("access_expires_at_unix")
    peer.revoked_at_unix = value.get("revoked_at_unix")
    return peer


# Compatibility name for callers that inspect stored peer records.
parse_pairing_value = parse_peer_value


def pairing_words(device_id: str) -> str:
    # A compact out-of-band comparison value; the full cryptographic identity
    # remains in the pairing code and is checked again on import.
    return "-".join(device_id[index:index + 4] for index in range(0, 16, 4))
