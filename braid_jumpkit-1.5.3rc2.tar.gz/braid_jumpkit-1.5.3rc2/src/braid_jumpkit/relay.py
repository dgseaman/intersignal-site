from __future__ import annotations

import hmac
import base64
import json
import logging
import os
import queue
import socket
import socketserver
import ssl
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .device import DeviceIdentity, derive_device_id
from .errors import PolicyError, ProtocolError
from .identity import normalize_sha256, verify_peer_certificate
from .protocol import canonical_json_bytes
from .tls import client_context, server_context
from .timeouts import (
    DEFAULT_CONNECT_TIMEOUT_SECONDS,
    DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS,
    validate_timeout,
)
from .wire import recv_message, send_message

LOGGER = logging.getLogger("braid_jumpkit.relay")


def _device_id(value: Any) -> str:
    if not isinstance(value, str):
        raise ProtocolError("ERR_RELAY_DEVICE_ID")
    return normalize_sha256(value, error="ERR_RELAY_DEVICE_ID")


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _unb64(value: Any, expected_length: int) -> bytes:
    if not isinstance(value, str) or len(value) > expected_length * 2:
        raise ProtocolError("ERR_RELAY_IDENTITY_KEY")
    try:
        data = base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except Exception as exc:
        raise ProtocolError("ERR_RELAY_IDENTITY_KEY") from exc
    if len(data) != expected_length:
        raise ProtocolError("ERR_RELAY_IDENTITY_KEY")
    return data


@dataclass(frozen=True)
class RelayConfig:
    bind: str = "127.0.0.1"
    port: int = 8750
    cert: Path = Path("relay.crt.pem")
    key: Path = Path("relay.key.pem")
    enrollment_token: str = ""
    connection_timeout_seconds: float = DEFAULT_CONNECT_TIMEOUT_SECONDS
    response_timeout_seconds: float = DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS
    max_connections: int = 256
    audit_log: Path | None = None


@dataclass
class _AgentSession:
    device_id: str
    sock: ssl.SSLSocket
    observed_ip: str
    direct_port: int | None = None
    send_lock: threading.Lock = field(default_factory=threading.Lock)

    def send(self, value: dict[str, Any]) -> None:
        with self.send_lock:
            send_message(self.sock, value)


class _RelayTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, address: tuple[str, int], config: RelayConfig, context: ssl.SSLContext):
        self.config = config
        self.context = context
        self.agents: dict[str, _AgentSession] = {}
        self.agent_lock = threading.Lock()
        self.pending: dict[str, queue.Queue[dict[str, Any]]] = {}
        self.pending_lock = threading.Lock()
        self.audit_lock = threading.Lock()
        self.slots = threading.BoundedSemaphore(config.max_connections)
        super().__init__(address, _RelayHandler)

    def audit(self, event: dict[str, Any]) -> None:
        safe_event = {"ts_unix": int(time.time()), **event}
        LOGGER.info("%s", json.dumps(safe_event, sort_keys=True))
        if self.config.audit_log is None:
            return
        self.config.audit_log.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(safe_event, sort_keys=True, separators=(",", ":")) + "\n"
        with self.audit_lock:
            with self.config.audit_log.open("a", encoding="utf-8") as handle:
                handle.write(line)

    def get_request(self) -> tuple[socket.socket, Any]:
        sock, address = super().get_request()
        if not self.slots.acquire(blocking=False):
            sock.close()
            raise ConnectionAbortedError("ERR_CONNECTION_LIMIT")
        sock.settimeout(self.config.connection_timeout_seconds)
        return sock, address

    def process_request_thread(self, request: socket.socket, client_address: Any) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

    def register(self, session: _AgentSession) -> None:
        with self.agent_lock:
            previous = self.agents.get(session.device_id)
            self.agents[session.device_id] = session
        if previous is not None and previous is not session:
            try:
                previous.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def unregister(self, session: _AgentSession) -> None:
        with self.agent_lock:
            if self.agents.get(session.device_id) is session:
                del self.agents[session.device_id]

    def route(self, source: str, destination: str, envelope: dict[str, Any]) -> dict[str, Any]:
        if envelope.get("source") != source or envelope.get("destination") != destination:
            raise ProtocolError("ERR_RELAY_ROUTE_BINDING")
        request_id = str(uuid.uuid4())
        response_queue: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=1)
        with self.pending_lock:
            self.pending[request_id] = response_queue
        try:
            with self.agent_lock:
                target = self.agents.get(destination)
            if target is None:
                raise ProtocolError("ERR_PEER_OFFLINE")
            target.send({"envelope": envelope, "request_id": request_id, "type": "deliver"})
            try:
                return response_queue.get(timeout=self.config.response_timeout_seconds)
            except queue.Empty as exc:
                raise ProtocolError("ERR_RELAY_RESPONSE_TIMEOUT") from exc
        finally:
            with self.pending_lock:
                self.pending.pop(request_id, None)

    def resolve(self, request_id: Any, envelope: Any) -> None:
        if not isinstance(request_id, str) or not isinstance(envelope, dict):
            raise ProtocolError("ERR_RELAY_REPLY_SCHEMA")
        with self.pending_lock:
            target = self.pending.get(request_id)
        if target is None:
            raise ProtocolError("ERR_RELAY_UNKNOWN_REQUEST")
        try:
            target.put_nowait(envelope)
        except queue.Full as exc:
            raise ProtocolError("ERR_RELAY_DUPLICATE_REPLY") from exc


class _RelayHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server: _RelayTCPServer = self.server  # type: ignore[assignment]
        session: _AgentSession | None = None
        event: dict[str, Any] = {"peer_ip": self.client_address[0], "status": "failed"}
        try:
            with server.context.wrap_socket(self.request, server_side=True) as sock:
                sock.settimeout(server.config.connection_timeout_seconds)
                if sock.version() != "TLSv1.3":
                    raise PolicyError("ERR_TLS13_REQUIRED")
                hello = recv_message(sock)
                if set(hello) != {"device_id", "direct_port", "exchange_public", "role", "sign_public", "token", "type"} or hello.get("type") != "hello_begin":
                    raise ProtocolError("ERR_RELAY_HELLO_SCHEMA")
                if not isinstance(hello["token"], str) or not hmac.compare_digest(hello["token"], server.config.enrollment_token):
                    raise PolicyError("ERR_RELAY_AUTH")
                device_id = _device_id(hello["device_id"])
                role = hello["role"]
                event.update(device_id=device_id, role=role)
                if role not in {"agent", "sender"}:
                    raise ProtocolError("ERR_RELAY_ROLE")
                direct_port = hello["direct_port"]
                if direct_port is not None and (role != "agent" or type(direct_port) is not int or not 1 <= direct_port <= 65535):
                    raise ProtocolError("ERR_DIRECT_PORT")
                sign_public = _unb64(hello["sign_public"], 32)
                exchange_public = _unb64(hello["exchange_public"], 32)
                if derive_device_id(sign_public, exchange_public) != device_id:
                    raise PolicyError("ERR_DEVICE_ID_MISMATCH")
                challenge = _b64(os.urandom(32))
                send_message(sock, {"challenge": challenge, "type": "hello_challenge"})
                proof = recv_message(sock)
                if set(proof) != {"challenge", "device_id", "role", "signature", "type"} or proof.get("type") != "hello_proof":
                    raise ProtocolError("ERR_RELAY_PROOF_SCHEMA")
                if proof.get("challenge") != challenge or proof.get("device_id") != device_id or proof.get("role") != role:
                    raise PolicyError("ERR_RELAY_PROOF_BINDING")
                signed = {key: value for key, value in proof.items() if key != "signature"}
                try:
                    Ed25519PublicKey.from_public_bytes(sign_public).verify(
                        _unb64(proof["signature"], 64),
                        canonical_json_bytes(signed),
                    )
                except InvalidSignature as exc:
                    raise PolicyError("ERR_RELAY_IDENTITY_PROOF") from exc
                send_message(sock, {"observed_ip": self.client_address[0], "status": "ok", "type": "hello_ack"})
                event["status"] = "authenticated"
                if role == "agent":
                    session = _AgentSession(device_id, sock, self.client_address[0], direct_port)
                    server.register(session)
                    sock.settimeout(None)
                    while True:
                        message = recv_message(sock)
                        if message.get("type") != "route_reply" or set(message) != {"envelope", "request_id", "type"}:
                            raise ProtocolError("ERR_RELAY_AGENT_MESSAGE")
                        server.resolve(message["request_id"], message["envelope"])
                message = recv_message(sock)
                if message.get("type") == "status" and set(message) == {"peer_id", "type"}:
                    peer_id = _device_id(message["peer_id"])
                    with server.agent_lock:
                        target = server.agents.get(peer_id)
                    candidate = None
                    if target is not None and target.direct_port is not None:
                        candidate = {"host": target.observed_ip, "port": target.direct_port}
                    send_message(sock, {
                        "direct_candidate": candidate,
                        "online": target is not None,
                        "peer_id": peer_id,
                        "type": "status_result",
                    })
                    return
                if message.get("type") != "route" or set(message) != {"envelope", "to", "type"} or not isinstance(message["envelope"], dict):
                    raise ProtocolError("ERR_RELAY_ROUTE_SCHEMA")
                destination = _device_id(message["to"])
                response = server.route(device_id, destination, message["envelope"])
                send_message(sock, {"envelope": response, "type": "route_result"})
                event.update(status="routed", destination=destination)
        except (OSError, ssl.SSLError, PolicyError, ProtocolError) as exc:
            # Closing without a success message is the fail-closed wire behavior.
            event["reason"] = str(exc) or exc.__class__.__name__
            return
        finally:
            if session is not None:
                server.unregister(session)
            server.audit(event)


@dataclass
class RendezvousRelay:
    config: RelayConfig
    _server: _RelayTCPServer | None = field(default=None, init=False, repr=False)
    _thread: threading.Thread | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        if not self.config.enrollment_token or len(self.config.enrollment_token) < 16:
            raise PolicyError("ERR_RELAY_TOKEN_STRENGTH")
        if not (0 <= self.config.port <= 65535):
            raise PolicyError("ERR_PORT_RANGE")
        if not (1 <= self.config.max_connections <= 4096):
            raise PolicyError("ERR_MAX_CONNECTIONS")
        validate_timeout(self.config.connection_timeout_seconds, name="connect")
        validate_timeout(self.config.response_timeout_seconds, name="relay_response")

    def _new_server(self) -> _RelayTCPServer:
        context = server_context(cert=self.config.cert, key=self.config.key)
        return _RelayTCPServer((self.config.bind, self.config.port), self.config, context)

    @property
    def address(self) -> tuple[str, int]:
        if self._server is None:
            return self.config.bind, self.config.port
        host, port = self._server.server_address[:2]
        return str(host), int(port)

    def start(self) -> "RendezvousRelay":
        self._server = self._new_server()
        self._thread = threading.Thread(target=self._server.serve_forever, name="jumpkit-relay", daemon=True)
        self._thread.start()
        return self

    def serve_forever(self) -> None:
        self._server = self._new_server()
        self._server.serve_forever()

    def stop(self) -> None:
        if self._server is None:
            return
        # Closing the listening socket alone leaves established agent sessions
        # alive and falsely "ready". Tear them down so clients enter their
        # bounded reconnect loop and pending routes fail closed.
        with self._server.agent_lock:
            sessions = list(self._server.agents.values())
        for session in sessions:
            try:
                session.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._server = None
        self._thread = None


def connect_relay(
    host: str,
    port: int,
    *,
    ca_file: Path,
    server_name: str,
    peer_fingerprint: str | None,
    peer_node_id: str | None,
    timeout_seconds: float,
) -> ssl.SSLSocket:
    context = client_context(ca_file=ca_file)
    raw = socket.create_connection((host, port), timeout=timeout_seconds)
    raw.settimeout(timeout_seconds)
    try:
        sock = context.wrap_socket(raw, server_hostname=server_name)
        if sock.version() != "TLSv1.3":
            raise PolicyError("ERR_TLS13_REQUIRED")
        verify_peer_certificate(sock, expected_fingerprint=peer_fingerprint, expected_node_id=peer_node_id)
        return sock
    except Exception:
        raw.close()
        raise


def relay_hello(
    sock: socket.socket,
    *,
    identity: DeviceIdentity,
    token: str,
    role: str,
    direct_port: int | None = None,
) -> dict[str, Any]:
    send_message(sock, {
        "device_id": identity.device_id,
        "direct_port": direct_port,
        "exchange_public": _b64(identity.exchange_public),
        "role": role,
        "sign_public": _b64(identity.sign_public),
        "token": token,
        "type": "hello_begin",
    })
    challenge = recv_message(sock)
    if set(challenge) != {"challenge", "type"} or challenge.get("type") != "hello_challenge":
        raise ProtocolError("ERR_RELAY_CHALLENGE")
    proof = {
        "challenge": challenge["challenge"],
        "device_id": identity.device_id,
        "role": role,
        "type": "hello_proof",
    }
    proof["signature"] = _b64(identity.sign_private.sign(canonical_json_bytes(proof)))
    send_message(sock, proof)
    response = recv_message(sock)
    if response.get("type") != "hello_ack" or response.get("status") != "ok":
        raise ProtocolError("ERR_RELAY_HELLO_ACK")
    return response
