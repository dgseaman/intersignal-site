from __future__ import annotations

import json
import logging
import socket
import socketserver
import ssl
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .errors import JumpKitTransportError, PolicyError, ProtocolError
from .policy import BindDecision, BindScope, classify_bind_scope
from .identity import verify_peer_certificate
from .protocol import ACK_HEADER, HEADER, MAX_METADATA_BYTES, decode_ack_bytes, read_exact
from .tls import server_context

LOGGER = logging.getLogger("braid_jumpkit")


def _read_one_btp1_packet(sock: socket.socket, max_frame_bytes: int) -> bytes:
    raw_header = read_exact(sock, HEADER.size)
    magic, version, flags, metadata_len, payload_len = HEADER.unpack(raw_header)
    if magic != b"BTP1":
        raise ProtocolError("ERR_MAGIC")
    if version != 1 or flags != 0:
        raise ProtocolError("ERR_WIRE_HEADER")
    if metadata_len <= 0 or metadata_len > MAX_METADATA_BYTES:
        raise ProtocolError("ERR_METADATA_LENGTH")
    if payload_len <= 0 or payload_len > max_frame_bytes:
        raise ProtocolError("ERR_PAYLOAD_LENGTH")
    return raw_header + read_exact(sock, metadata_len) + read_exact(sock, payload_len)


def _read_one_ack(sock: socket.socket) -> bytes:
    raw_header = read_exact(sock, ACK_HEADER.size)
    magic, status, metadata_len = ACK_HEADER.unpack(raw_header)
    if magic != b"BTA1" or status not in (0, 1):
        raise ProtocolError("ERR_ACK_HEADER")
    if metadata_len <= 0 or metadata_len > MAX_METADATA_BYTES:
        raise ProtocolError("ERR_ACK_LENGTH")
    raw = raw_header + read_exact(sock, metadata_len)
    decode_ack_bytes(raw)
    return raw


@dataclass(frozen=True)
class ProxyConfig:
    bind: str = "127.0.0.1"
    port: int = 8746
    cert: Path = Path("jumpkit-server.crt.pem")
    key: Path = Path("jumpkit-server.key.pem")
    client_ca: Path | None = None
    require_client_cert: bool = False
    peer_fingerprint: str | None = None
    peer_node_id: str | None = None
    allow_public: bool = False
    upstream_host: str = "127.0.0.1"
    upstream_port: int = 8745
    max_frame_bytes: int = 2 * 1024 * 1024
    timeout_seconds: float = 15.0
    audit_log: Path | None = None
    max_connections: int = 64


class _Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, address: tuple[str, int], config: ProxyConfig, context: ssl.SSLContext):
        self.config = config
        self.context = context
        self.audit_lock = threading.Lock()
        self.connection_slots = threading.BoundedSemaphore(config.max_connections)
        super().__init__(address, _Handler)

    def get_request(self) -> tuple[socket.socket, Any]:
        sock, address = super().get_request()
        if not self.connection_slots.acquire(blocking=False):
            sock.close()
            raise ConnectionAbortedError("ERR_CONNECTION_LIMIT")
        sock.settimeout(self.config.timeout_seconds)
        return sock, address

    def process_request_thread(self, request: socket.socket, client_address: Any) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.connection_slots.release()

    def audit(self, event: dict[str, Any]) -> None:
        event = {"ts_unix": int(time.time()), **event}
        LOGGER.info("%s", json.dumps(event, sort_keys=True))
        if self.config.audit_log is None:
            return
        self.config.audit_log.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n"
        with self.audit_lock:
            with self.config.audit_log.open("a", encoding="utf-8") as handle:
                handle.write(line)


class _Handler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server: _Server = self.server  # type: ignore[assignment]
        config = server.config
        event: dict[str, Any] = {
            "peer": self.client_address[0],
            "tls": None,
            "upstream": f"{config.upstream_host}:{config.upstream_port}",
            "status": "failed",
        }
        try:
            with server.context.wrap_socket(self.request, server_side=True) as client:
                client.settimeout(config.timeout_seconds)
                event["tls"] = client.version()
                if client.version() != "TLSv1.3":
                    raise PolicyError("ERR_TLS13_REQUIRED")
                if config.require_client_cert:
                    fingerprint, node_id = verify_peer_certificate(
                        client,
                        expected_fingerprint=config.peer_fingerprint,
                        expected_node_id=config.peer_node_id,
                    )
                    event["peer_certificate_sha256"] = fingerprint
                    if node_id is not None:
                        event["peer_node_id"] = node_id
                packet = _read_one_btp1_packet(client, config.max_frame_bytes)
                with socket.create_connection((config.upstream_host, config.upstream_port), timeout=config.timeout_seconds) as upstream:
                    upstream.settimeout(config.timeout_seconds)
                    upstream.sendall(packet)
                    ack = _read_one_ack(upstream)
                client.sendall(ack)
                event.update(status="forwarded", bytes=len(packet))
        except (JumpKitTransportError, OSError, ValueError, ssl.SSLError) as exc:
            event["reason"] = str(exc) or exc.__class__.__name__
            # Do not synthesize an acceptance ACK. If local Braid cannot answer,
            # the transport connection fails closed.
        finally:
            server.audit(event)


@dataclass
class JumpKitProxy:
    config: ProxyConfig
    decision: BindDecision = field(init=False)
    _server: _Server | None = field(default=None, init=False, repr=False)
    _thread: threading.Thread | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        if not (0 <= self.config.port <= 65535 and 1 <= self.config.upstream_port <= 65535):
            raise PolicyError("ERR_PORT_RANGE")
        self.decision = classify_bind_scope(self.config.bind)
        if self.decision.scope in {BindScope.PUBLIC, BindScope.WILDCARD} and not self.config.allow_public:
            raise PolicyError("ERR_PUBLIC_BIND_REQUIRES_ALLOW_PUBLIC")
        if self.decision.scope in {BindScope.PUBLIC, BindScope.WILDCARD}:
            if not self.config.require_client_cert:
                raise PolicyError("ERR_PUBLIC_BIND_REQUIRES_MTLS")
            if self.config.peer_fingerprint is None and self.config.peer_node_id is None:
                raise PolicyError("ERR_PUBLIC_BIND_REQUIRES_PEER_PIN")
        if self.config.require_client_cert:
            if self.config.client_ca is None:
                raise PolicyError("ERR_CLIENT_CA_REQUIRED")
            if self.config.peer_fingerprint is None and self.config.peer_node_id is None:
                raise PolicyError("ERR_EXPLICIT_PEER_IDENTITY_REQUIRED")
        elif self.config.peer_fingerprint is not None or self.config.peer_node_id is not None:
            raise PolicyError("ERR_PEER_PIN_REQUIRES_MTLS")
        upstream = classify_bind_scope(self.config.upstream_host)
        if upstream.scope != BindScope.LOOPBACK:
            raise PolicyError("ERR_PLAINTEXT_UPSTREAM_MUST_BE_LOOPBACK")
        if self.config.max_frame_bytes <= 0:
            raise PolicyError("ERR_MAX_FRAME_BYTES")
        if not (1 <= self.config.max_connections <= 1024):
            raise PolicyError("ERR_MAX_CONNECTIONS")
        if not (0.1 <= self.config.timeout_seconds <= 300):
            raise PolicyError("ERR_TIMEOUT_RANGE")

    def _context(self) -> ssl.SSLContext:
        return server_context(
            cert=self.config.cert,
            key=self.config.key,
            client_ca=self.config.client_ca,
            require_client_cert=self.config.require_client_cert,
        )

    @property
    def address(self) -> tuple[str, int]:
        if self._server is None:
            return self.config.bind, self.config.port
        host, port = self._server.server_address[:2]
        return str(host), int(port)

    def start(self) -> "JumpKitProxy":
        if self._server is not None:
            return self
        self._server = _Server((self.config.bind, self.config.port), self.config, self._context())
        self._thread = threading.Thread(target=self._server.serve_forever, name="braid-jumpkit", daemon=True)
        self._thread.start()
        return self

    def serve_forever(self) -> None:
        self._server = _Server((self.config.bind, self.config.port), self.config, self._context())
        self._server.serve_forever()

    def stop(self) -> None:
        if self._server is None:
            return
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._server = None
        self._thread = None

    def __enter__(self) -> "JumpKitProxy":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()
