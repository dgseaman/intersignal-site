from __future__ import annotations

import io
import socket
import ssl
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .device import DeviceIdentity
from .direct import DirectConfig, DirectListener, send_direct
from .e2e import open_envelope, seal
from .errors import JumpKitTransportError, ProtocolError
from .proxy import _read_one_ack, _read_one_btp1_packet
from .relay import connect_relay, relay_hello
from .timeouts import (
    DEFAULT_CONNECT_TIMEOUT_SECONDS,
    DEFAULT_DIRECT_TIMEOUT_SECONDS,
    DEFAULT_RECONNECT_SECONDS,
    DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS,
    DEFAULT_UPSTREAM_TIMEOUT_SECONDS,
    validate_timeout,
)
from .wire import recv_message, send_message


@dataclass(frozen=True)
class AgentConfig:
    identity_file: Path
    relay_host: str
    relay_port: int
    relay_ca: Path
    relay_server_name: str
    relay_token: str
    relay_fingerprint: str | None = None
    relay_node_id: str | None = None
    upstream_host: str = "127.0.0.1"
    upstream_port: int = 8745
    connect_timeout_seconds: float = DEFAULT_CONNECT_TIMEOUT_SECONDS
    upstream_timeout_seconds: float = DEFAULT_UPSTREAM_TIMEOUT_SECONDS
    reconnect_seconds: float = DEFAULT_RECONNECT_SECONDS
    max_frame_bytes: int = 2 * 1024 * 1024
    direct_bind: str = "0.0.0.0"
    direct_port: int = 8747
    direct_enabled: bool = True
    direct_timeout_seconds: float = DEFAULT_DIRECT_TIMEOUT_SECONDS


@dataclass
class JumpKitAgent:
    config: AgentConfig
    identity: DeviceIdentity = field(init=False)
    _stop: threading.Event = field(default_factory=threading.Event, init=False, repr=False)
    _ready: threading.Event = field(default_factory=threading.Event, init=False, repr=False)
    _thread: threading.Thread | None = field(default=None, init=False, repr=False)
    _socket: ssl.SSLSocket | None = field(default=None, init=False, repr=False)
    _socket_lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _replays: set[str] = field(default_factory=set, init=False, repr=False)
    _identity_lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _replay_lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _direct: DirectListener | None = field(default=None, init=False, repr=False)
    last_error: str | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        self.identity = DeviceIdentity.load(self.config.identity_file)
        if self.config.upstream_host not in {"127.0.0.1", "::1", "localhost"}:
            raise ProtocolError("ERR_PLAINTEXT_UPSTREAM_MUST_BE_LOOPBACK")
        validate_timeout(self.config.connect_timeout_seconds, name="connect")
        validate_timeout(self.config.upstream_timeout_seconds, name="upstream")
        validate_timeout(self.config.direct_timeout_seconds, name="direct")
        validate_timeout(self.config.reconnect_seconds, name="reconnect")

    @property
    def ready(self) -> bool:
        return self._ready.is_set()

    def wait_ready(self, timeout: float = 5.0) -> bool:
        return self._ready.wait(timeout)

    def start(self) -> "JumpKitAgent":
        self._thread = threading.Thread(target=self.serve_forever, name="jumpkit-agent", daemon=True)
        self._thread.start()
        return self

    def serve_forever(self) -> None:
        if self.config.direct_enabled:
            self._direct = DirectListener(
                DirectConfig(
                    bind=self.config.direct_bind,
                    port=self.config.direct_port,
                    timeout_seconds=self.config.direct_timeout_seconds,
                ),
                self._handle_envelope,
            ).start()
        while not self._stop.is_set():
            try:
                self._serve_connection()
                self.last_error = None
            except (OSError, ssl.SSLError, JumpKitTransportError, ValueError) as exc:
                self.last_error = str(exc) or exc.__class__.__name__
            finally:
                self._ready.clear()
                with self._socket_lock:
                    self._socket = None
            if not self._stop.wait(self.config.reconnect_seconds):
                continue

    def _serve_connection(self) -> None:
        sock = connect_relay(
            self.config.relay_host,
            self.config.relay_port,
            ca_file=self.config.relay_ca,
            server_name=self.config.relay_server_name,
            peer_fingerprint=self.config.relay_fingerprint,
            peer_node_id=self.config.relay_node_id,
            timeout_seconds=self.config.connect_timeout_seconds,
        )
        with sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            direct_port = self._direct.address[1] if self._direct is not None else None
            relay_hello(
                sock,
                identity=self.identity,
                token=self.config.relay_token,
                role="agent",
                direct_port=direct_port,
            )
            sock.settimeout(None)
            with self._socket_lock:
                self._socket = sock
            self._ready.set()
            while not self._stop.is_set():
                message = recv_message(sock)
                if message.get("type") != "deliver" or set(message) != {"envelope", "request_id", "type"}:
                    raise ProtocolError("ERR_AGENT_MESSAGE")
                envelope = self._handle_envelope(message["envelope"])
                send_message(sock, {"envelope": envelope, "request_id": message["request_id"], "type": "route_reply"})

    def _handle_envelope(self, envelope: Any) -> dict[str, Any]:
        source: str | None = None
        try:
            if not isinstance(envelope, dict):
                raise ProtocolError("ERR_E2E_SCHEMA")
            # Reload authorization state for every admission decision so an
            # on-disk revoke or expiry takes effect without restarting the agent.
            with self._identity_lock:
                self.identity = DeviceIdentity.load(self.config.identity_file)
                identity = self.identity
            with self._replay_lock:
                source, packet = open_envelope(identity, envelope, expected_kind="btp1", replay_ids=self._replays)
            stream = io.BytesIO(packet)
            _read_one_btp1_packet(stream, self.config.max_frame_bytes)  # type: ignore[arg-type]
            if stream.read(1):
                raise ProtocolError("ERR_BTP1_TRAILING_BYTES")
            with socket.create_connection((self.config.upstream_host, self.config.upstream_port), timeout=self.config.connect_timeout_seconds) as upstream:
                upstream.settimeout(self.config.upstream_timeout_seconds)
                # Validation above consumes exactly one BTP1 frame. Forward the
                # original decrypted bytes so the local receiver gets the exact
                # header, metadata, and payload emitted by the sender.
                upstream.sendall(packet)
                ack = _read_one_ack(upstream)
            return seal(identity, source, "ack", ack)
        except (OSError, ssl.SSLError, JumpKitTransportError, ValueError) as exc:
            if source is None and isinstance(envelope, dict) and isinstance(envelope.get("source"), str):
                candidate = envelope["source"]
                if candidate in self.identity.peers:
                    source = candidate
            if source is None:
                raise
            reason = (str(exc) or exc.__class__.__name__)[:512].encode("utf-8", errors="replace")
            return seal(self.identity, source, "error", reason)

    def stop(self) -> None:
        self._stop.set()
        with self._socket_lock:
            sock = self._socket
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None
        if self._direct is not None:
            self._direct.stop()
            self._direct = None


@dataclass(frozen=True)
class WanSendResult:
    peer_id: str
    path: str
    tls_version: str
    ack: Any


def send_via_relay(
    identity: DeviceIdentity,
    peer_id: str,
    packet: bytes,
    *,
    relay_host: str,
    relay_port: int,
    relay_ca: Path,
    relay_server_name: str,
    relay_token: str,
    relay_fingerprint: str | None,
    relay_node_id: str | None,
    connect_timeout_seconds: float = DEFAULT_CONNECT_TIMEOUT_SECONDS,
    response_timeout_seconds: float = DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    validate_timeout(connect_timeout_seconds, name="connect")
    validate_timeout(response_timeout_seconds, name="sender_response")
    envelope = seal(identity, peer_id, "btp1", packet)
    with connect_relay(
        relay_host,
        relay_port,
        ca_file=relay_ca,
        server_name=relay_server_name,
        peer_fingerprint=relay_fingerprint,
        peer_node_id=relay_node_id,
        timeout_seconds=connect_timeout_seconds,
    ) as sock:
        version = sock.version() or "unknown"
        relay_hello(sock, identity=identity, token=relay_token, role="sender")
        sock.settimeout(response_timeout_seconds)
        send_message(sock, {"envelope": envelope, "to": peer_id, "type": "route"})
        response = recv_message(sock)
    if response.get("type") != "route_result" or set(response) != {"envelope", "type"} or not isinstance(response["envelope"], dict):
        raise ProtocolError("ERR_RELAY_ROUTE_RESULT")
    returned = response["envelope"]
    kind = returned.get("kind")
    if kind not in {"ack", "error"}:
        raise ProtocolError("ERR_E2E_KIND")
    source, plaintext = open_envelope(identity, returned, expected_kind=kind)
    if source != peer_id:
        raise ProtocolError("ERR_E2E_WRONG_SOURCE")
    if kind == "error":
        raise ProtocolError("ERR_REMOTE_FAIL_CLOSED:" + plaintext.decode("utf-8", errors="replace"))
    return {"ack_bytes": plaintext, "path": "RELAYED", "tls_version": version}


def send_direct_first(
    identity: DeviceIdentity,
    peer_id: str,
    packet: bytes,
    *,
    relay_host: str,
    relay_port: int,
    relay_ca: Path,
    relay_server_name: str,
    relay_token: str,
    relay_fingerprint: str | None,
    relay_node_id: str | None,
    connect_timeout_seconds: float = DEFAULT_CONNECT_TIMEOUT_SECONDS,
    response_timeout_seconds: float = DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS,
    direct_timeout_seconds: float = DEFAULT_DIRECT_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    direct_candidate: tuple[str, int] | None = None
    try:
        with connect_relay(
            relay_host,
            relay_port,
            ca_file=relay_ca,
            server_name=relay_server_name,
            peer_fingerprint=relay_fingerprint,
            peer_node_id=relay_node_id,
            timeout_seconds=connect_timeout_seconds,
        ) as sock:
            relay_hello(sock, identity=identity, token=relay_token, role="sender")
            send_message(sock, {"peer_id": peer_id, "type": "status"})
            status = recv_message(sock)
        if status.get("online") is True and isinstance(status.get("direct_candidate"), dict):
            candidate = status["direct_candidate"]
            if isinstance(candidate.get("host"), str) and type(candidate.get("port")) is int:
                direct_candidate = (candidate["host"], candidate["port"])
    except (OSError, ssl.SSLError, JumpKitTransportError, ValueError):
        # A failed plan lookup does not weaken relay authentication; the relay
        # connection below repeats the full pinned TLS and device proof.
        pass
    if direct_candidate is not None:
        try:
            return send_direct(
                identity,
                peer_id,
                packet,
                direct_candidate[0],
                direct_candidate[1],
                timeout_seconds=direct_timeout_seconds,
            )
        except (OSError, JumpKitTransportError, ValueError):
            pass
    return send_via_relay(
        identity,
        peer_id,
        packet,
        relay_host=relay_host,
        relay_port=relay_port,
        relay_ca=relay_ca,
        relay_server_name=relay_server_name,
        relay_token=relay_token,
        relay_fingerprint=relay_fingerprint,
        relay_node_id=relay_node_id,
        connect_timeout_seconds=connect_timeout_seconds,
        response_timeout_seconds=response_timeout_seconds,
    )
