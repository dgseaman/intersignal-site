from __future__ import annotations

import socket
import socketserver
import threading
from dataclasses import dataclass, field
from typing import Any, Callable

from .device import DeviceIdentity
from .e2e import open_envelope, seal
from .errors import ProtocolError
from .wire import recv_message, send_message


EnvelopeHandler = Callable[[Any], dict[str, Any]]


@dataclass(frozen=True)
class DirectConfig:
    bind: str = "0.0.0.0"
    port: int = 8747
    timeout_seconds: float = 3.0
    max_connections: int = 64


class _DirectServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, address: tuple[str, int], config: DirectConfig, handler: EnvelopeHandler):
        self.config = config
        self.envelope_handler = handler
        self.slots = threading.BoundedSemaphore(config.max_connections)
        super().__init__(address, _DirectHandler)

    def get_request(self) -> tuple[socket.socket, Any]:
        sock, address = super().get_request()
        if not self.slots.acquire(blocking=False):
            sock.close()
            raise ConnectionAbortedError("ERR_CONNECTION_LIMIT")
        sock.settimeout(self.config.timeout_seconds)
        return sock, address

    def process_request_thread(self, request: socket.socket, client_address: Any) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()


class _DirectHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server: _DirectServer = self.server  # type: ignore[assignment]
        try:
            message = recv_message(self.request)
            if set(message) != {"envelope", "type"} or message.get("type") != "direct":
                raise ProtocolError("ERR_DIRECT_SCHEMA")
            response = server.envelope_handler(message["envelope"])
            send_message(self.request, {"envelope": response, "type": "direct_result"})
        except (OSError, ProtocolError, ValueError):
            return


@dataclass
class DirectListener:
    config: DirectConfig
    envelope_handler: EnvelopeHandler
    _server: _DirectServer | None = field(default=None, init=False, repr=False)
    _thread: threading.Thread | None = field(default=None, init=False, repr=False)

    @property
    def address(self) -> tuple[str, int]:
        if self._server is None:
            return self.config.bind, self.config.port
        host, port = self._server.server_address[:2]
        return str(host), int(port)

    def start(self) -> "DirectListener":
        self._server = _DirectServer((self.config.bind, self.config.port), self.config, self.envelope_handler)
        self._thread = threading.Thread(target=self._server.serve_forever, name="jumpkit-direct", daemon=True)
        self._thread.start()
        return self

    def stop(self) -> None:
        if self._server is None:
            return
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._server = None
        self._thread = None


def send_direct(
    identity: DeviceIdentity,
    peer_id: str,
    packet: bytes,
    host: str,
    port: int,
    *,
    timeout_seconds: float = 3.0,
) -> dict[str, Any]:
    envelope = seal(identity, peer_id, "btp1", packet)
    with socket.create_connection((host, port), timeout=timeout_seconds) as sock:
        sock.settimeout(timeout_seconds)
        send_message(sock, {"envelope": envelope, "type": "direct"})
        response = recv_message(sock)
    if set(response) != {"envelope", "type"} or response.get("type") != "direct_result":
        raise ProtocolError("ERR_DIRECT_RESULT")
    returned = response["envelope"]
    if not isinstance(returned, dict) or returned.get("kind") not in {"ack", "error"}:
        raise ProtocolError("ERR_DIRECT_RESULT")
    kind = returned["kind"]
    source, plaintext = open_envelope(identity, returned, expected_kind=kind)
    if source != peer_id:
        raise ProtocolError("ERR_E2E_WRONG_SOURCE")
    if kind == "error":
        raise ProtocolError("ERR_REMOTE_FAIL_CLOSED:" + plaintext.decode("utf-8", errors="replace"))
    return {"ack_bytes": plaintext, "path": "DIRECT", "tls_version": None}
