from __future__ import annotations

import socket
from dataclasses import dataclass
from pathlib import Path

from .errors import PolicyError, ProtocolError
from .protocol import Ack, decode_ack_from_socket, encode_transfer, sha256_bytes
from .identity import verify_peer_certificate
from .tls import client_context


@dataclass(frozen=True)
class SendResult:
    host: str
    port: int
    tls_version: str
    ack: Ack


def _read_bounded_frame(path: Path, max_frame_bytes: int) -> bytes:
    if max_frame_bytes <= 0:
        raise ProtocolError("ERR_MAX_FRAME_BYTES")
    with path.open("rb") as handle:
        data = handle.read(max_frame_bytes + 1)
    if not data:
        raise ProtocolError("ERR_EMPTY_FRAME")
    if len(data) > max_frame_bytes:
        raise ProtocolError("ERR_FRAME_TOO_LARGE")
    return data


def send_frame(
    frame_path: Path,
    host: str,
    port: int,
    *,
    ca_file: Path,
    server_name: str | None = None,
    client_cert: Path | None = None,
    client_key: Path | None = None,
    peer_fingerprint: str | None = None,
    peer_node_id: str | None = None,
    timeout_seconds: float = 15.0,
    max_frame_bytes: int = 2 * 1024 * 1024,
) -> SendResult:
    if not frame_path.is_file():
        raise FileNotFoundError(frame_path)
    if not (1 <= port <= 65535):
        raise PolicyError("ERR_PORT_RANGE")
    data = _read_bounded_frame(frame_path, max_frame_bytes)
    packet = encode_transfer(data, frame_path.name, max_frame_bytes=max_frame_bytes)
    context = client_context(ca_file=ca_file, client_cert=client_cert, client_key=client_key)
    with socket.create_connection((host, port), timeout=timeout_seconds) as raw_sock:
        raw_sock.settimeout(timeout_seconds)
        with context.wrap_socket(raw_sock, server_hostname=server_name or host) as sock:
            version = sock.version() or "unknown"
            if version != "TLSv1.3":
                raise PolicyError("ERR_TLS13_REQUIRED")
            verify_peer_certificate(
                sock,
                expected_fingerprint=peer_fingerprint,
                expected_node_id=peer_node_id,
            )
            sock.sendall(packet)
            ack = decode_ack_from_socket(sock)
            if ack.transport_sha256 != sha256_bytes(data):
                raise ProtocolError("ERR_ACK_DIGEST_MISMATCH")
    return SendResult(host=host, port=port, tls_version=version, ack=ack)
