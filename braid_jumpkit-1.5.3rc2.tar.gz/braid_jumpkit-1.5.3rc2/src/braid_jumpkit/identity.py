from __future__ import annotations

import hashlib
import hmac
import ssl
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import serialization

from .errors import PolicyError

NODE_ID_PREFIX = "braid://"
NODE_ID_DOMAIN = b"braid-node-id-v1"


def normalize_sha256(value: str, *, error: str) -> str:
    normalized = value.strip().lower().replace(":", "")
    if len(normalized) != 64 or any(ch not in "0123456789abcdef" for ch in normalized):
        raise PolicyError(error)
    return normalized


def normalize_node_id(value: str) -> str:
    raw = value.strip()
    if raw.lower().startswith(NODE_ID_PREFIX):
        raw = raw[len(NODE_ID_PREFIX):]
    return normalize_sha256(raw, error="ERR_NODE_ID_FORMAT")


def derive_node_id(scheme_id: bytes, public_key: bytes) -> str:
    if not isinstance(scheme_id, bytes) or not scheme_id:
        raise PolicyError("ERR_SCHEME_ID_BYTES")
    if not isinstance(public_key, bytes) or not public_key:
        raise PolicyError("ERR_PUBLIC_KEY_BYTES")
    return hashlib.sha256(NODE_ID_DOMAIN + scheme_id + public_key).hexdigest()


def certificate_fingerprint(cert_der: bytes) -> str:
    if not cert_der:
        raise PolicyError("ERR_PEER_CERT_REQUIRED")
    return hashlib.sha256(cert_der).hexdigest()


def certificate_file_fingerprint(cert_path: Path) -> str:
    cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
    return certificate_fingerprint(cert.public_bytes(serialization.Encoding.DER))


def certificate_node_ids(cert_der: bytes) -> set[str]:
    cert = x509.load_der_x509_certificate(cert_der)
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return set()
    result: set[str] = set()
    for uri in san.get_values_for_type(x509.UniformResourceIdentifier):
        if uri.lower().startswith(NODE_ID_PREFIX):
            try:
                result.add(normalize_node_id(uri))
            except PolicyError:
                continue
    return result


def verify_peer_certificate(
    sock: ssl.SSLSocket,
    *,
    expected_fingerprint: str | None,
    expected_node_id: str | None,
) -> tuple[str, str | None]:
    if expected_fingerprint is None and expected_node_id is None:
        raise PolicyError("ERR_EXPLICIT_PEER_IDENTITY_REQUIRED")
    cert_der = sock.getpeercert(binary_form=True)
    actual_fingerprint = certificate_fingerprint(cert_der)
    normalized_node_id: str | None = None
    if expected_fingerprint is not None:
        expected = normalize_sha256(expected_fingerprint, error="ERR_CERT_FINGERPRINT_FORMAT")
        if not hmac.compare_digest(actual_fingerprint, expected):
            raise PolicyError("ERR_PEER_CERT_FINGERPRINT_MISMATCH")
    if expected_node_id is not None:
        normalized_node_id = normalize_node_id(expected_node_id)
        if normalized_node_id not in certificate_node_ids(cert_der):
            raise PolicyError("ERR_PEER_NODE_ID_MISMATCH")
    return actual_fingerprint, normalized_node_id
