# Changelog

## 1.5.3rc2 — 2026-08-26

- Replaced temporary equal 20/60-second UAT patches with separately configurable connection, upstream-processing, relay-response, and sender-response budgets.
- Set hierarchical defaults to 90/120/150 seconds for upstream semantic processing, relay response, and sender round trip.
- Preserved TLS 1.3 pinning, device proof, end-to-end encryption/signatures, replay protection, exact BTP1 forwarding, ACK digest validation, and fail-closed receipts.
- Added delayed-semantic regression coverage and recorded the successful physical macOS → public relay → Windows acceptance path.
- Prepared Python wheel and source distribution for free public testing; the obsolete 0.2.0-alpha3 package is not part of this release.

## 1.5.3rc1 — 2026-08-25

- Rebased Jump Kit as the optional BRAID 1.5.3 — JUMP sidecar candidate.
- Added direct-first candidate selection with authenticated relay fallback.
- Added short-lived Jump Codes, authorization expiry, live revocation, and receipt vocabulary.
- Added direct, fallback, reconnect, expiry, revocation, and authority-boundary tests.
- Documented the threat model and a hard, evidence-backed release gate.
- Withheld the clean release tag because automatic NAT traversal and physical cross-OS WAN gates remain open.
