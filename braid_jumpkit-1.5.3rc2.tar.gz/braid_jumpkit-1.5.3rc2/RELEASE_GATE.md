# v1.5.3 hard release gate

The `v1.5.3` tag and GA packages are authorized only when every required row is PASS with attached evidence. A local simulation is never recorded as physical WAN or cross-OS evidence.

| Gate | Required evidence | RC2 status |
|---|---|---|
| Core remains local-first/free and works without Jump Kit | Clean Core install and LAN transfer with no sidecar/service account | NOT RUN |
| Short-lived pairing | Valid code accepted; expired/tampered code rejected | LOCAL PASS |
| Explicit admission | Unapproved peer rejected; comparison words recorded | LOCAL PASS |
| Revocation/expiry | Running receiver rejects revoked and expired authorization | LOCAL PASS |
| E2E payload authentication | Tamper, wrong destination, replay, and relay plaintext inspection | LOCAL PASS |
| Relay has no model authority | Relay cannot create a valid envelope or Braid acceptance | LOCAL PASS |
| Direct first | Routable direct candidate returns `DIRECT` | LOCAL PASS |
| Automatic NAT traversal | Two unrelated consumer NATs, no manual port forwarding, direct where topology permits | NOT IMPLEMENTED / BLOCKER |
| Relay fallback | Forced direct failure returns `RELAYED` and exact ACK | LOCAL PASS; PHYSICAL macOS → Windows PASS |
| WAN reconnect | Interrupt WAN/relay, restore, transfer succeeds without re-pairing | LOCAL PASS; PHYSICAL NOT RUN |
| Windows ↔ macOS | Both directions, unrelated networks, direct/relay receipts captured | macOS → Windows RELAYED PASS; reverse direction OPEN |
| Linux ↔ Windows | Both directions, unrelated networks, direct/relay receipts captured | NOT RUN |
| Install → pair → transfer UX | Fresh machines; no source checkout or debugging shell work | NOT RUN |
| Native packages | Signed/notarized or documented trust path; hashes and malware scans | NOT RUN |
| Relay operations | Per-device enrollment, rotation/revocation, quotas, monitoring, recovery | UAT relay PASS; token rotation and production controls OPEN |
| Reproducibility | Source revision, commands, raw logs, hashes, UTC timestamps, operator sign-off | PARTIAL |

Release decision: **CONDITIONAL GO for free public testing after `PUBLIC_RELEASE_CHECKLIST.md`; NO-GO for the clean GA tag** until all blocker and physical rows pass.
