# BRAID 1.5.3 — JUMP RC2

**Local by default. Remote when invited.**

RC2 turns the successful WAN UAT configuration into a clean public-testing candidate. Braid Core remains untouched and authoritative; Jump Kit only extends reach.

## Added

- Separate, configurable budgets for connection setup, direct attempts, local semantic processing, relay response, and sender round trip.
- Hierarchical defaults of 90 seconds at the receiver-facing agent, 120 seconds at the relay, and 150 seconds at the sender.
- Regression coverage for a delayed semantic ACK completing without an equal-deadline relay race.
- Physical macOS → DigitalOcean relay → Windows Braid acceptance evidence (`RELAYED`, TLS 1.3, validated, stored, accepted).

- Direct candidate discovery and authenticated direct delivery before relay fallback.
- `DIRECT`, `RELAYED`, `REJECTED`, and `EXPIRED` receipts.
- Ten-minute default Jump Codes with bounded 30–3600 second lifetimes.
- Optional approved-peer expiry and immediate `pair-revoke`.
- Live authorization reload, so receiving agents enforce expiry/revocation without restart.
- Concurrent direct-listener replay protection.
- Relay interruption/reconnect, direct success, forced fallback, code expiry, and live revocation tests.

## Preserved

- Exact BTP1 bytes reach loopback Braid Core.
- Braid Core alone creates acceptance/finality ACKs.
- Ed25519 device identity and signatures.
- Ephemeral X25519 + HKDF-SHA256 + ChaCha20-Poly1305 envelopes.
- Pinned TLS 1.3 device-to-relay transport.
- Relay metadata/content boundary and fail-closed behavior.

## Public-testing decision

**READY AFTER OPERATIONS CHECKLIST for free public testing; NO-GO for the clean `v1.5.3` GA tag.** Rotate the UAT relay enrollment token and update enrolled test clients before publishing access. RC2 does not claim automatic ICE/QUIC hole punching, native signed installers, or complete bidirectional/cross-platform WAN coverage.
