# Jump Kit security and threat model

## Security invariant

Jump Kit changes reach, not authority. Braid Core alone owns signer trust, `.brad` interpretation, replay/session policy, quarantine, validation, acceptance, and finality. Relay presence, transport identity, or a successful route can never imply `accepted=true`.

## Trust boundaries

- **Device identity:** local Ed25519 signing and X25519 exchange private keys.
- **Peer admission:** a short-lived self-authenticating Jump Code plus explicit local approval and out-of-band comparison words.
- **Direct path:** network metadata is visible; payload and ACK remain end-to-end signed and encrypted.
- **Relay path:** pinned TLS 1.3 protects each relay connection; separate end-to-end cryptography keeps payload and ACK plaintext from the relay.
- **Core boundary:** only exact, bounded BTP1 reaches `127.0.0.1:8745`; only a structurally valid Braid ACK is returned.

## Threats addressed

- Pairing-code tampering, substitution, use before validity, and use after expiry.
- Device-ID squatting by another relay-token holder.
- Relay challenge replay and role/device confusion.
- Unapproved, expired, or revoked peers.
- Envelope source/destination/kind/timestamp/message-ID substitution.
- Ciphertext/signature tampering and replay.
- Malformed or oversized BTP1 and ACK frames.
- Relay or local-Core outage cosmetically appearing as acceptance.
- Relay inspection of `.brad` or ACK plaintext.
- Slow/over-limit relay and direct connections.

## Relay capabilities and non-capabilities

The relay can observe device IDs, IP addresses, timing, sizes, online state, path-planning queries, and ciphertext. It can deny, delay, reorder, replay, misroute, or drop traffic. It can suggest a false direct candidate and thereby induce a bounded TCP connection attempt. It cannot decrypt or undetectably modify an envelope, sign as a paired device, or manufacture a Braid acceptance ACK.

The shared relay enrollment token is service admission, not peer admission. A hosted multi-tenant relay still requires per-account/per-device enrollment, rotation, revocation, quotas, abuse controls, and operational monitoring.

The enrollment token used during UAT was temporarily copied to endpoint-accessible files. It must be rotated before public testing, removed from temporary endpoint and operator locations, and never bundled into source distributions, site assets, logs, screenshots, or examples. Rotation does not replace device proof or peer approval.

Longer semantic-processing budgets change availability only. Timeout expiry, malformed responses, late replies, and unknown request IDs remain rejection paths and cannot produce acceptance.

## Direct-path caveats

RC2 direct transport relies on the end-to-end envelope rather than a second TLS layer. It exposes connection metadata and is reachable only when the advertised socket is actually routable. The relay-observed IP plus listener port is a candidate, not proof of NAT mapping. Automatic ICE/QUIC traversal is not implemented or claimed.

If a direct attempt reaches Core but its authenticated ACK is lost before the sender receives it, relay fallback can redeliver the signed Braid object. Core replay/finality policy must remain authoritative and idempotent.

## Fail-closed cases

Unavailable relay, unreachable direct candidate, offline peer, wrong relay token or pin, failed device proof, unapproved/expired/revoked peer, invalid signature, decryption failure, replay, stale timestamp, malformed BTP1, unavailable Core, malformed ACK, or digest mismatch cannot produce an acceptance receipt.

Report suspected vulnerabilities privately to Intersignal LLC. Never include live private keys, relay tokens, or sensitive `.brad` objects.
