# RC2 public-testing operations checklist

Complete these steps before publishing the Jump Kit access section or relay coordinates.

- Generate a new high-entropy relay enrollment token on the relay host; do not transmit it through chat, commit it, or place it in a public download.
- Replace the relay service token file atomically, restrict it to the service account, restart the relay, and confirm the old token fails authentication.
- Provision the new token to explicitly enrolled test devices through a private channel; remove the UAT token copies from Mac, Windows, deployment staging, shell history where practical, and temporary support bundles.
- Confirm source archives, wheels, website files, logs, and release notes contain no token, private key, Jump Code, `.brad` payload, public IP credential bundle, or operator home-directory path.
- Keep the CA private key offline. Publish only the relay CA certificate and an independently verified certificate fingerprint or NodeId pin.
- Configure service limits, log rotation, monitoring/alerting, backup/recovery, abuse response, and a documented relay access revocation path.
- Re-run one accepted WAN transfer and the wrong-token fail-closed check after rotation.
- Publish `1.5.3rc2` only. Do not upload or link `0.2.0-alpha3`.

The public-testing release is free during the experimental period. A future hosted tier is planned as a premium product because public relay/VPS capacity has continuing operating costs.
