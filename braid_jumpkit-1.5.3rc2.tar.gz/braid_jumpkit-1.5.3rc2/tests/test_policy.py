import pytest

from braid_jumpkit.errors import PolicyError
from braid_jumpkit.proxy import JumpKitProxy, ProxyConfig
from braid_jumpkit.relay import RelayConfig, RendezvousRelay
from braid_jumpkit.timeouts import (
    DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS,
    DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS,
    DEFAULT_UPSTREAM_TIMEOUT_SECONDS,
    validate_timeout_hierarchy,
)


def test_wildcard_requires_explicit_public_opt_in(tmp_path):
    with pytest.raises(PolicyError, match="ERR_PUBLIC_BIND_REQUIRES_ALLOW_PUBLIC"):
        JumpKitProxy(ProxyConfig(bind="0.0.0.0", cert=tmp_path / "c", key=tmp_path / "k"))


def test_public_bind_requires_mtls_and_explicit_pin(tmp_path):
    with pytest.raises(PolicyError, match="ERR_PUBLIC_BIND_REQUIRES_MTLS"):
        JumpKitProxy(ProxyConfig(bind="0.0.0.0", allow_public=True, cert=tmp_path / "c", key=tmp_path / "k"))
    with pytest.raises(PolicyError, match="ERR_PUBLIC_BIND_REQUIRES_PEER_PIN"):
        JumpKitProxy(ProxyConfig(bind="0.0.0.0", allow_public=True, cert=tmp_path / "c", key=tmp_path / "k", require_client_cert=True, client_ca=tmp_path / "ca"))


@pytest.mark.parametrize("host", ["192.0.2.10", "10.0.0.8", "0.0.0.0"])
def test_plaintext_upstream_is_restricted_to_loopback(host, tmp_path):
    with pytest.raises(PolicyError, match="ERR_PLAINTEXT_UPSTREAM_MUST_BE_LOOPBACK"):
        JumpKitProxy(ProxyConfig(upstream_host=host, cert=tmp_path / "c", key=tmp_path / "k"))


def test_invalid_connection_and_timeout_bounds(tmp_path):
    with pytest.raises(PolicyError, match="ERR_MAX_CONNECTIONS"):
        JumpKitProxy(ProxyConfig(max_connections=0, cert=tmp_path / "c", key=tmp_path / "k"))
    with pytest.raises(PolicyError, match="ERR_TIMEOUT_RANGE"):
        JumpKitProxy(ProxyConfig(timeout_seconds=0, cert=tmp_path / "c", key=tmp_path / "k"))


def test_timeout_defaults_are_hierarchical():
    assert DEFAULT_UPSTREAM_TIMEOUT_SECONDS < DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS
    assert DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS < DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS
    validate_timeout_hierarchy(
        upstream=DEFAULT_UPSTREAM_TIMEOUT_SECONDS,
        relay_response=DEFAULT_RELAY_RESPONSE_TIMEOUT_SECONDS,
        sender_response=DEFAULT_SENDER_RESPONSE_TIMEOUT_SECONDS,
    )


def test_timeout_hierarchy_and_bounds_fail_closed(tmp_path):
    with pytest.raises(PolicyError, match="ERR_TIMEOUT_HIERARCHY"):
        validate_timeout_hierarchy(upstream=90, relay_response=90, sender_response=150)
    with pytest.raises(PolicyError, match="ERR_TIMEOUT_RANGE:relay_response"):
        RendezvousRelay(RelayConfig(
            cert=tmp_path / "c", key=tmp_path / "k", enrollment_token="x" * 32,
            response_timeout_seconds=float("inf"),
        ))
