from __future__ import annotations

import json
import socket
import socketserver
import ssl
import threading
import time
from pathlib import Path

import pytest

from braid_jumpkit.certs import init_ca, issue_identity
from braid_jumpkit.client import send_frame
from braid_jumpkit.errors import PolicyError, ProtocolError
from braid_jumpkit.identity import certificate_file_fingerprint, derive_node_id
from braid_jumpkit.protocol import ACK_HEADER, ACK_MAGIC, Ack, decode_transfer_from_socket, encode_ack
from braid_jumpkit.proxy import JumpKitProxy, ProxyConfig

SERVER_NODE = "11" * 32
CLIENT_NODE = "22" * 32


class FakeBraidHandler(socketserver.BaseRequestHandler):
    def handle(self):
        meta, payload = decode_transfer_from_socket(self.request)
        self.server.capture = (meta, payload)  # type: ignore[attr-defined]
        ack = Ack(True, True, True, "RECEIVER_ACCEPTED", meta.transport_sha256, "accepted")
        self.request.sendall(encode_ack(ack))


class MalformedAckHandler(socketserver.BaseRequestHandler):
    def handle(self):
        meta, _ = decode_transfer_from_socket(self.request)
        body = json.dumps({
            "stored": True,
            "validated": True,
            "accepted": "true",
            "reason": "MALFORMED",
            "transport_sha256": meta.transport_sha256,
            "destination": "accepted",
        }, separators=(",", ":")).encode()
        self.request.sendall(ACK_HEADER.pack(ACK_MAGIC, 1, len(body)) + body)


class WrongDigestAckHandler(socketserver.BaseRequestHandler):
    def handle(self):
        decode_transfer_from_socket(self.request)
        self.request.sendall(encode_ack(Ack(True, True, True, "RECEIVER_ACCEPTED", "00" * 32, "accepted")))


class FakeBraid(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def _identities(tmp_path: Path):
    ca = init_ca(tmp_path)
    server = issue_identity(
        tmp_path, Path(ca["ca_key"]), Path(ca["ca_cert"]), "jumpkit.test",
        role="server", dns_names=["localhost"], ip_addresses=["127.0.0.1"],
        braid_node_id=SERVER_NODE,
    )
    client = issue_identity(
        tmp_path, Path(ca["ca_key"]), Path(ca["ca_cert"]), "jumpkit-client",
        role="client", braid_node_id=CLIENT_NODE,
    )
    return ca, server, client


def _upstream(handler=FakeBraidHandler):
    server = FakeBraid(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def _proxy(tmp_path: Path, upstream: FakeBraid, **overrides):
    ca, server, client = _identities(tmp_path)
    values = dict(
        bind="127.0.0.1", port=0,
        cert=Path(server["cert"]), key=Path(server["key"]),
        upstream_host="127.0.0.1", upstream_port=upstream.server_address[1],
    )
    values.update(overrides)
    return ca, server, client, JumpKitProxy(ProxyConfig(**values)).start()


def _send(frame: Path, proxy: JumpKitProxy, ca: dict, server: dict, **overrides):
    values = dict(
        ca_file=Path(ca["ca_cert"]), server_name="jumpkit.test",
        peer_fingerprint=server["certificate_sha256"],
    )
    values.update(overrides)
    return send_frame(frame, "127.0.0.1", proxy.address[1], **values)


def test_tls13_proxy_preserves_exact_signed_brad_bytes_and_receiver_ack(tmp_path):
    upstream = _upstream()
    ca, server, _, proxy = _proxy(tmp_path, upstream)
    try:
        payload = bytes(range(256)) * 17 + b"\x00\xffsigned-braid"
        frame = tmp_path / "state.brad"
        frame.write_bytes(payload)
        result = _send(frame, proxy, ca, server)
        assert result.tls_version == "TLSv1.3"
        assert result.ack.accepted is True
        captured_meta, captured_payload = upstream.capture
        assert captured_payload == payload
        assert captured_meta.transport_sha256 == result.ack.transport_sha256
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_node_id_san_pin_succeeds(tmp_path):
    upstream = _upstream()
    ca, server, _, proxy = _proxy(tmp_path, upstream)
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        result = _send(frame, proxy, ca, server, peer_fingerprint=None, peer_node_id=SERVER_NODE)
        assert result.ack.accepted
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_wrong_ca_fails_closed(tmp_path):
    upstream = _upstream()
    ca, server, _, proxy = _proxy(tmp_path / "good", upstream)
    bad_ca = init_ca(tmp_path / "bad")
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        with pytest.raises(ssl.SSLCertVerificationError):
            _send(frame, proxy, bad_ca, server)
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


@pytest.mark.parametrize(
    ("kwargs", "error"),
    [
        ({"peer_fingerprint": "00" * 32}, "ERR_PEER_CERT_FINGERPRINT_MISMATCH"),
        ({"peer_fingerprint": None, "peer_node_id": "33" * 32}, "ERR_PEER_NODE_ID_MISMATCH"),
        ({"peer_fingerprint": None, "peer_node_id": None}, "ERR_EXPLICIT_PEER_IDENTITY_REQUIRED"),
    ],
)
def test_wrong_or_missing_explicit_server_identity_fails_closed(tmp_path, kwargs, error):
    upstream = _upstream()
    ca, server, _, proxy = _proxy(tmp_path, upstream)
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        with pytest.raises(PolicyError, match=error):
            _send(frame, proxy, ca, server, **kwargs)
        assert not hasattr(upstream, "capture")
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_mtls_client_pin_and_node_id_mismatch_fail_closed(tmp_path):
    upstream = _upstream()
    ca, server, client, proxy = _proxy(
        tmp_path, upstream,
        client_ca=Path(tmp_path / "jumpkit-ca.crt.pem"),
        require_client_cert=True,
        peer_node_id="33" * 32,
    )
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        with pytest.raises((ProtocolError, OSError, ssl.SSLError)):
            _send(frame, proxy, ca, server, client_cert=Path(client["cert"]), client_key=Path(client["key"]))
        assert not hasattr(upstream, "capture")
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_mtls_client_node_id_pin_succeeds(tmp_path):
    upstream = _upstream()
    ca, server, client, proxy = _proxy(
        tmp_path, upstream,
        client_ca=Path(tmp_path / "jumpkit-ca.crt.pem"),
        require_client_cert=True,
        peer_node_id=CLIENT_NODE,
    )
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        result = _send(frame, proxy, ca, server, client_cert=Path(client["cert"]), client_key=Path(client["key"]))
        assert result.ack.accepted
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_tls12_client_is_rejected(tmp_path):
    upstream = _upstream()
    _, _, _, proxy = _proxy(tmp_path, upstream)
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.maximum_version = ssl.TLSVersion.TLSv1_2
        with socket.create_connection(("127.0.0.1", proxy.address[1]), timeout=2) as raw:
            with pytest.raises(ssl.SSLError):
                ctx.wrap_socket(raw, server_hostname="jumpkit.test")
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_plaintext_to_jumpkit_never_reaches_upstream(tmp_path):
    upstream = _upstream()
    _, _, _, proxy = _proxy(tmp_path, upstream)
    try:
        with socket.create_connection(("127.0.0.1", proxy.address[1]), timeout=2) as raw:
            raw.sendall(b"BTP1 plaintext is forbidden")
        time.sleep(0.1)
        assert not hasattr(upstream, "capture")
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_upstream_down_never_returns_acceptance(tmp_path):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); dead_port = s.getsockname()[1]; s.close()
    placeholder = FakeBraid(("127.0.0.1", 0), FakeBraidHandler)
    ca, server, _, proxy = _proxy(tmp_path, placeholder, upstream_port=dead_port, timeout_seconds=0.3)
    placeholder.server_close()
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        with pytest.raises((ProtocolError, OSError, ssl.SSLError)):
            _send(frame, proxy, ca, server, timeout_seconds=1.0)
    finally:
        proxy.stop()


def test_malformed_upstream_ack_is_not_forwarded(tmp_path):
    upstream = _upstream(MalformedAckHandler)
    ca, server, _, proxy = _proxy(tmp_path, upstream)
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        with pytest.raises((ProtocolError, OSError, ssl.SSLError)):
            _send(frame, proxy, ca, server)
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_receiver_ack_for_different_payload_is_rejected(tmp_path):
    upstream = _upstream(WrongDigestAckHandler)
    ca, server, _, proxy = _proxy(tmp_path, upstream)
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        with pytest.raises(ProtocolError, match="ERR_ACK_DIGEST_MISMATCH"):
            _send(frame, proxy, ca, server)
    finally:
        proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_connection_bound_includes_slow_tls_handshakes_and_times_out(tmp_path):
    upstream = _upstream()
    ca, server, _, proxy = _proxy(tmp_path, upstream, max_connections=1, timeout_seconds=0.25)
    slow = socket.create_connection(("127.0.0.1", proxy.address[1]), timeout=1)
    frame = tmp_path / "x.brad"; frame.write_bytes(b"x")
    try:
        time.sleep(0.05)
        with pytest.raises((ConnectionError, OSError, ssl.SSLError, ProtocolError)):
            _send(frame, proxy, ca, server, timeout_seconds=0.5)
        time.sleep(0.35)
        assert _send(frame, proxy, ca, server, timeout_seconds=1.0).ack.accepted
    finally:
        slow.close(); proxy.stop(); upstream.shutdown(); upstream.server_close()


def test_certificate_fingerprint_matches_issued_metadata(tmp_path):
    _, server, _ = _identities(tmp_path)
    assert certificate_file_fingerprint(Path(server["cert"])) == server["certificate_sha256"]


def test_node_id_derivation_and_configured_cross_check(tmp_path):
    ca = init_ca(tmp_path)
    scheme_id = bytes.fromhex("01")
    public_key = bytes(range(32))
    expected = derive_node_id(scheme_id, public_key)
    issued = issue_identity(
        tmp_path, Path(ca["ca_key"]), Path(ca["ca_cert"]), "derived-node",
        role="server", braid_node_id=expected,
        braid_scheme_id=scheme_id, braid_public_key=public_key,
    )
    assert issued["braid_node_id"] == expected
    with pytest.raises(PolicyError, match="ERR_CONFIGURED_NODE_ID_MISMATCH"):
        issue_identity(
            tmp_path, Path(ca["ca_key"]), Path(ca["ca_cert"]), "wrong-derived-node",
            role="server", braid_node_id="ff" * 32,
            braid_scheme_id=scheme_id, braid_public_key=public_key,
        )
