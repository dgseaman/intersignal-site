import json
import socket

import pytest

from braid_jumpkit.errors import ProtocolError
from braid_jumpkit.protocol import (
    ACK_HEADER, ACK_MAGIC, HEADER, MAGIC, MAX_METADATA_BYTES, WIRE_VERSION,
    decode_ack_from_socket, encode_transfer, sanitize_filename,
)
from braid_jumpkit.proxy import _read_one_btp1_packet


class ChunkStream:
    def __init__(self, data: bytes, chunk_size: int = 1):
        self.data = data
        self.chunk_size = chunk_size
        self.requests: list[int] = []

    def recv(self, length: int) -> bytes:
        self.requests.append(length)
        if not self.data:
            return b""
        size = min(length, self.chunk_size, len(self.data))
        result, self.data = self.data[:size], self.data[size:]
        return result


def test_sanitize_filename():
    assert sanitize_filename("../../thing.brad") == "thing.brad"
    assert sanitize_filename("thing") == "thing.brad"


def test_empty_and_oversize_reject():
    with pytest.raises(ProtocolError, match="ERR_EMPTY_FRAME"):
        encode_transfer(b"", "x.brad")
    with pytest.raises(ProtocolError, match="ERR_FRAME_TOO_LARGE"):
        encode_transfer(b"1234", "x.brad", max_frame_bytes=3)


@pytest.mark.parametrize(
    ("metadata_len", "payload_len", "error"),
    [
        (MAX_METADATA_BYTES + 1, 1, "ERR_METADATA_LENGTH"),
        (1, 2 * 1024 * 1024 + 1, "ERR_PAYLOAD_LENGTH"),
        (65535, (1 << 64) - 1, "ERR_METADATA_LENGTH"),
    ],
)
def test_absurd_lengths_rejected_before_body_read_or_allocation(metadata_len, payload_len, error):
    stream = ChunkStream(HEADER.pack(MAGIC, WIRE_VERSION, 0, metadata_len, payload_len), chunk_size=HEADER.size)
    with pytest.raises(ProtocolError, match=error):
        _read_one_btp1_packet(stream, 2 * 1024 * 1024)  # type: ignore[arg-type]
    assert stream.requests == [HEADER.size]


def test_slow_partial_stream_reassembles_exact_packet():
    packet = encode_transfer(b"\x00signed\xffbytes", "state.brad")
    stream = ChunkStream(packet, chunk_size=1)
    assert _read_one_btp1_packet(stream, 2 * 1024 * 1024) == packet  # type: ignore[arg-type]
    assert len(stream.requests) > HEADER.size


@pytest.mark.parametrize("cut", [0, 1, HEADER.size - 1, HEADER.size + 3])
def test_truncated_stream_fails_closed(cut):
    packet = encode_transfer(b"payload", "state.brad")
    with pytest.raises(ProtocolError, match="ERR_TRUNCATED_STREAM"):
        _read_one_btp1_packet(ChunkStream(packet[:cut], chunk_size=2), 2 * 1024 * 1024)  # type: ignore[arg-type]


def _ack_bytes(body: dict, status: int = 0) -> bytes:
    raw = json.dumps(body, separators=(",", ":")).encode()
    return ACK_HEADER.pack(ACK_MAGIC, status, len(raw)) + raw


def test_ack_boolean_type_confusion_rejected():
    body = {"stored": True, "validated": True, "accepted": "false", "reason": "x", "transport_sha256": "0" * 64}
    a, b = socket.socketpair()
    try:
        a.sendall(_ack_bytes(body))
        with pytest.raises(ProtocolError, match="ERR_ACK_BOOL_TYPE"):
            decode_ack_from_socket(b)
    finally:
        a.close(); b.close()


@pytest.mark.parametrize(
    ("body", "status", "error"),
    [
        ({"stored": True, "validated": True, "accepted": False, "reason": "x", "transport_sha256": "0" * 64}, 1, "ERR_ACK_STATUS_MISMATCH"),
        ({"stored": True, "validated": True, "accepted": True, "reason": "x", "transport_sha256": "0" * 64, "destination": "quarantine"}, 1, "ERR_ACK_ACCEPTANCE_INVARIANT"),
        ({"stored": True, "validated": True, "accepted": False, "reason": "x", "transport_sha256": "0" * 64, "destination": "accepted"}, 0, "ERR_ACK_ACCEPTANCE_INVARIANT"),
    ],
)
def test_malformed_or_non_authoritative_ack_contract_rejected(body, status, error):
    a, b = socket.socketpair()
    try:
        a.sendall(_ack_bytes(body, status))
        with pytest.raises(ProtocolError, match=error):
            decode_ack_from_socket(b)
    finally:
        a.close(); b.close()
