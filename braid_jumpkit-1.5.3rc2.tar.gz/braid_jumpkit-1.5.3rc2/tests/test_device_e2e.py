import json

import pytest

from braid_jumpkit.device import DeviceIdentity, pairing_words
from braid_jumpkit.e2e import open_envelope, seal
from braid_jumpkit.errors import PolicyError, ProtocolError


def _paired():
    alice = DeviceIdentity.create("Alice Laptop")
    bob = DeviceIdentity.create("Bob Workstation")
    alice.approve(bob.pairing_code())
    bob.approve(alice.pairing_code())
    return alice, bob


def test_device_identity_roundtrip_and_pairing(tmp_path):
    alice, bob = _paired()
    path = tmp_path / "device.json"
    alice.save(path)
    loaded = DeviceIdentity.load(path)
    assert loaded.device_id == alice.device_id
    assert loaded.name == "Alice Laptop"
    assert loaded.peers[bob.device_id].name == "Bob Workstation"
    assert len(pairing_words(alice.device_id).split("-")) == 4
    assert path.stat().st_mode & 0o077 == 0


def test_pairing_code_identity_tamper_fails_closed():
    alice = DeviceIdentity.create("Alice")
    raw = json.loads(__import__("base64").urlsafe_b64decode(alice.pairing_code() + "=="))
    raw["device_id"] = "00" * 32
    tampered = __import__("base64").urlsafe_b64encode(json.dumps(raw).encode()).decode().rstrip("=")
    with pytest.raises(PolicyError, match="ERR_DEVICE_ID_MISMATCH"):
        DeviceIdentity.create("Bob").approve(tampered)


def test_authenticated_encryption_roundtrip_is_opaque_and_replay_bounded():
    alice, bob = _paired()
    plaintext = b"BTP1 exact signed bytes that the relay must not see"
    envelope = seal(alice, bob.device_id, "btp1", plaintext)
    assert plaintext not in json.dumps(envelope, sort_keys=True).encode()
    replays: set[str] = set()
    source, opened = open_envelope(bob, envelope, expected_kind="btp1", replay_ids=replays)
    assert source == alice.device_id
    assert opened == plaintext
    with pytest.raises(ProtocolError, match="ERR_E2E_REPLAY"):
        open_envelope(bob, envelope, expected_kind="btp1", replay_ids=replays)


def test_ciphertext_signature_and_destination_tamper_fail_closed():
    alice, bob = _paired()
    envelope = seal(alice, bob.device_id, "btp1", b"payload")
    altered = dict(envelope)
    altered["ciphertext"] = ("A" if envelope["ciphertext"][0] != "A" else "B") + envelope["ciphertext"][1:]
    with pytest.raises(PolicyError, match="ERR_E2E_SIGNATURE"):
        open_envelope(bob, altered, expected_kind="btp1")
    with pytest.raises(PolicyError, match="ERR_E2E_WRONG_DESTINATION"):
        open_envelope(alice, envelope, expected_kind="btp1")


def test_unapproved_sender_cannot_be_opened():
    alice = DeviceIdentity.create("Alice")
    bob = DeviceIdentity.create("Bob")
    alice.approve(bob.pairing_code())
    envelope = seal(alice, bob.device_id, "btp1", b"payload")
    with pytest.raises(PolicyError, match="ERR_PEER_NOT_APPROVED"):
        open_envelope(bob, envelope, expected_kind="btp1")


def test_pairing_code_expires_and_cannot_be_approved():
    alice = DeviceIdentity.create("Alice")
    bob = DeviceIdentity.create("Bob")
    code = alice.pairing_code(ttl_seconds=60, now=1_000)
    with pytest.raises(PolicyError, match="ERR_PAIRING_EXPIRED"):
        bob.approve(code, now=1_060)


def test_expired_and_revoked_authorizations_cannot_seal_or_open():
    alice = DeviceIdentity.create("Alice")
    bob = DeviceIdentity.create("Bob")
    alice.approve(bob.pairing_code(now=1_000), access_seconds=60, now=1_000)
    bob.approve(alice.pairing_code(now=1_000), now=1_000)
    with pytest.raises(PolicyError, match="ERR_PEER_EXPIRED"):
        alice.active_peer(bob.device_id, now=1_060)
    alice.peers[bob.device_id].access_expires_at_unix = None
    alice.revoke(bob.device_id, now=1_020)
    with pytest.raises(PolicyError, match="ERR_PEER_REVOKED"):
        seal(alice, bob.device_id, "btp1", b"payload")
