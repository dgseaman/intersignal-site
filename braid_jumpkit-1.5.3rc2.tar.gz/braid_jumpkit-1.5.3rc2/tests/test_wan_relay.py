from __future__ import annotations

import socket
import socketserver
import threading
import time
import base64
import io
from pathlib import Path

import pytest

from braid_jumpkit.agent import AgentConfig, JumpKitAgent, send_direct_first, send_via_relay
from braid_jumpkit.certs import init_ca, issue_identity
from braid_jumpkit.device import DeviceIdentity
from braid_jumpkit.errors import ProtocolError
from braid_jumpkit.protocol import Ack, decode_ack_bytes, decode_transfer_from_socket, encode_ack, encode_transfer
from braid_jumpkit.proxy import _read_one_btp1_packet
from braid_jumpkit.relay import RelayConfig, RendezvousRelay, connect_relay
from braid_jumpkit.wire import recv_message, send_message

TOKEN = "jump-rc2-test-enrollment-token-32bytes"


class FakeBraidHandler(socketserver.BaseRequestHandler):
    def handle(self):
        raw_packet = _read_one_btp1_packet(self.request, 2 * 1024 * 1024)
        meta, payload = decode_transfer_from_socket(io.BytesIO(raw_packet))  # type: ignore[arg-type]
        self.server.capture = (meta, payload, raw_packet)  # type: ignore[attr-defined]
        self.request.sendall(encode_ack(Ack(True, True, True, "RECEIVER_ACCEPTED", meta.transport_sha256, "accepted")))


class SlowSemanticBraidHandler(FakeBraidHandler):
    def handle(self):
        time.sleep(0.35)
        super().handle()


class FakeBraid(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def _identities(tmp_path: Path):
    alice = DeviceIdentity.create("Alice Laptop")
    bob = DeviceIdentity.create("Bob Workstation")
    alice.approve(bob.pairing_code())
    bob.approve(alice.pairing_code())
    alice_file = tmp_path / "alice.json"
    bob_file = tmp_path / "bob.json"
    alice.save(alice_file)
    bob.save(bob_file)
    return alice, bob, alice_file, bob_file


def _relay(tmp_path: Path, audit_log: Path | None = None, response_timeout: float = 4):
    ca = init_ca(tmp_path / "certs")
    cert = issue_identity(
        tmp_path / "certs", Path(ca["ca_key"]), Path(ca["ca_cert"]), "relay.test",
        role="server", dns_names=["localhost"], ip_addresses=["127.0.0.1"],
    )
    relay = RendezvousRelay(RelayConfig(
        bind="127.0.0.1", port=0, cert=Path(cert["cert"]), key=Path(cert["key"]),
        enrollment_token=TOKEN, connection_timeout_seconds=3,
        response_timeout_seconds=response_timeout, audit_log=audit_log,
    )).start()
    return ca, cert, relay


def _agent_config(identity_file: Path, ca: dict, cert: dict, relay: RendezvousRelay, upstream_port: int):
    return AgentConfig(
        identity_file=identity_file, relay_host="127.0.0.1", relay_port=relay.address[1],
        relay_ca=Path(ca["ca_cert"]), relay_server_name="relay.test", relay_token=TOKEN,
        relay_fingerprint=cert["certificate_sha256"], upstream_port=upstream_port,
        connect_timeout_seconds=3, upstream_timeout_seconds=3,
        reconnect_seconds=0.1, direct_bind="127.0.0.1", direct_port=0,
    )


def _send(alice, bob, ca, cert, relay, packet, token=TOKEN):
    return send_via_relay(
        alice, bob.device_id, packet, relay_host="127.0.0.1", relay_port=relay.address[1],
        relay_ca=Path(ca["ca_cert"]), relay_server_name="relay.test", relay_token=token,
        relay_fingerprint=cert["certificate_sha256"], relay_node_id=None,
        connect_timeout_seconds=3, response_timeout_seconds=5,
    )


def test_true_outbound_only_wan_relay_preserves_btp1_and_receiver_ack(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    upstream = FakeBraid(("127.0.0.1", 0), FakeBraidHandler)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    agent = JumpKitAgent(_agent_config(bob_file, ca, cert, relay, upstream.server_address[1])).start()
    try:
        assert agent.wait_ready(3), agent.last_error
        payload = bytes(range(256)) * 31 + b"\x00\xffsigned-braid"
        packet = encode_transfer(payload, "state.brad")
        result = _send(alice, bob, ca, cert, relay, packet)
        ack = decode_ack_bytes(result["ack_bytes"])
        assert result["path"] == "RELAYED"
        assert result["tls_version"] == "TLSv1.3"
        assert ack.accepted is True
        assert upstream.capture[1] == payload
        assert upstream.capture[0].transport_sha256 == ack.transport_sha256
        assert upstream.capture[2] == packet
    finally:
        agent.stop(); relay.stop(); upstream.shutdown(); upstream.server_close()


def test_hierarchical_timeouts_allow_slow_semantic_ack_without_relay_race(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path, response_timeout=0.75)
    upstream = FakeBraid(("127.0.0.1", 0), SlowSemanticBraidHandler)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    config = _agent_config(bob_file, ca, cert, relay, upstream.server_address[1])
    config = AgentConfig(**{**config.__dict__, "upstream_timeout_seconds": 0.5})
    agent = JumpKitAgent(config).start()
    try:
        assert agent.wait_ready(3), agent.last_error
        result = send_via_relay(
            alice, bob.device_id, encode_transfer(b"slow semantic work", "slow.brad"),
            relay_host="127.0.0.1", relay_port=relay.address[1],
            relay_ca=Path(ca["ca_cert"]), relay_server_name="relay.test", relay_token=TOKEN,
            relay_fingerprint=cert["certificate_sha256"], relay_node_id=None,
            connect_timeout_seconds=1, response_timeout_seconds=1,
        )
        assert decode_ack_bytes(result["ack_bytes"]).accepted is True
    finally:
        agent.stop(); relay.stop(); upstream.shutdown(); upstream.server_close()


def test_windows_handoff_rejects_trailing_bytes_before_opening_braid_socket(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    upstream = FakeBraid(("127.0.0.1", 0), FakeBraidHandler)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    agent = JumpKitAgent(_agent_config(bob_file, ca, cert, relay, upstream.server_address[1])).start()
    try:
        assert agent.wait_ready(3), agent.last_error
        packet = encode_transfer(b"signed Windows handoff bytes", "windows.brad") + b"trailing"
        with pytest.raises(ProtocolError, match="ERR_REMOTE_FAIL_CLOSED:ERR_BTP1_TRAILING_BYTES"):
            _send(alice, bob, ca, cert, relay, packet)
        assert not hasattr(upstream, "capture")
    finally:
        agent.stop(); relay.stop(); upstream.shutdown(); upstream.server_close()


def test_local_braid_down_returns_only_authenticated_fail_closed_error(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    probe = socket.socket(); probe.bind(("127.0.0.1", 0)); dead_port = probe.getsockname()[1]; probe.close()
    agent = JumpKitAgent(_agent_config(bob_file, ca, cert, relay, dead_port)).start()
    try:
        assert agent.wait_ready(3), agent.last_error
        with pytest.raises(ProtocolError, match="ERR_REMOTE_FAIL_CLOSED"):
            _send(alice, bob, ca, cert, relay, encode_transfer(b"signed", "x.brad"))
    finally:
        agent.stop(); relay.stop()


def test_wrong_relay_token_and_offline_peer_fail_without_ack(tmp_path):
    alice, bob, _, _ = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    try:
        with pytest.raises((ProtocolError, OSError)):
            _send(alice, bob, ca, cert, relay, encode_transfer(b"signed", "x.brad"), token="wrong-token-is-still-long")
        with pytest.raises((ProtocolError, OSError)):
            _send(alice, bob, ca, cert, relay, encode_transfer(b"signed", "x.brad"))
    finally:
        relay.stop()


def test_enrollment_token_holder_cannot_claim_another_device_id(tmp_path):
    alice, bob, _, _ = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    encode = lambda value: base64.urlsafe_b64encode(value).decode().rstrip("=")
    try:
        with connect_relay(
            "127.0.0.1", relay.address[1], ca_file=Path(ca["ca_cert"]), server_name="relay.test",
            peer_fingerprint=cert["certificate_sha256"], peer_node_id=None, timeout_seconds=3,
        ) as sock:
            send_message(sock, {
                "device_id": alice.device_id,
                "exchange_public": encode(bob.exchange_public),
                "role": "agent",
                "sign_public": encode(bob.sign_public),
                "token": TOKEN,
                "type": "hello_begin",
            })
            with pytest.raises((ProtocolError, OSError)):
                recv_message(sock)
    finally:
        relay.stop()


def test_relay_audit_excludes_secrets_and_payload_material(tmp_path):
    alice, bob, _, _ = _identities(tmp_path)
    audit = tmp_path / "relay-audit.jsonl"
    ca, cert, relay = _relay(tmp_path, audit)
    try:
        with pytest.raises((ProtocolError, OSError)):
            _send(alice, bob, ca, cert, relay, encode_transfer(b"secret-signed-payload", "x.brad"))
    finally:
        relay.stop()
    recorded = audit.read_text(encoding="utf-8")
    assert TOKEN not in recorded
    assert "secret-signed-payload" not in recorded
    assert "ciphertext" not in recorded
    assert alice.device_id in recorded


def test_direct_first_uses_authenticated_direct_candidate(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    upstream = FakeBraid(("127.0.0.1", 0), FakeBraidHandler)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    agent = JumpKitAgent(_agent_config(bob_file, ca, cert, relay, upstream.server_address[1])).start()
    try:
        assert agent.wait_ready(3), agent.last_error
        result = send_direct_first(
            alice, bob.device_id, encode_transfer(b"direct signed bytes", "direct.brad"),
            relay_host="127.0.0.1", relay_port=relay.address[1],
            relay_ca=Path(ca["ca_cert"]), relay_server_name="relay.test", relay_token=TOKEN,
            relay_fingerprint=cert["certificate_sha256"], relay_node_id=None,
            connect_timeout_seconds=3, response_timeout_seconds=5, direct_timeout_seconds=1,
        )
        assert result["path"] == "DIRECT"
        assert decode_ack_bytes(result["ack_bytes"]).accepted is True
        assert upstream.capture[1] == b"direct signed bytes"
    finally:
        agent.stop(); relay.stop(); upstream.shutdown(); upstream.server_close()


def test_direct_failure_falls_back_to_relay(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    upstream = FakeBraid(("127.0.0.1", 0), FakeBraidHandler)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    config = _agent_config(bob_file, ca, cert, relay, upstream.server_address[1])
    config = AgentConfig(**{**config.__dict__, "direct_enabled": False})
    agent = JumpKitAgent(config).start()
    try:
        assert agent.wait_ready(3), agent.last_error
        result = send_direct_first(
            alice, bob.device_id, encode_transfer(b"fallback signed bytes", "fallback.brad"),
            relay_host="127.0.0.1", relay_port=relay.address[1],
            relay_ca=Path(ca["ca_cert"]), relay_server_name="relay.test", relay_token=TOKEN,
            relay_fingerprint=cert["certificate_sha256"], relay_node_id=None,
            connect_timeout_seconds=3, response_timeout_seconds=5, direct_timeout_seconds=0.1,
        )
        assert result["path"] == "RELAYED"
        assert decode_ack_bytes(result["ack_bytes"]).accepted is True
    finally:
        agent.stop(); relay.stop(); upstream.shutdown(); upstream.server_close()


def test_agent_reconnects_after_relay_interruption(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    relay_port = relay.address[1]
    upstream = FakeBraid(("127.0.0.1", 0), FakeBraidHandler)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    config = _agent_config(bob_file, ca, cert, relay, upstream.server_address[1])
    config = AgentConfig(**{**config.__dict__, "direct_enabled": False})
    agent = JumpKitAgent(config).start()
    replacement = None
    try:
        assert agent.wait_ready(3), agent.last_error
        relay.stop()
        deadline = time.monotonic() + 3
        while agent.ready and time.monotonic() < deadline:
            time.sleep(0.02)
        replacement = RendezvousRelay(RelayConfig(
            bind="127.0.0.1", port=relay_port, cert=Path(cert["cert"]), key=Path(cert["key"]),
            enrollment_token=TOKEN, connection_timeout_seconds=3, response_timeout_seconds=4,
        )).start()
        assert agent.wait_ready(5), agent.last_error
        result = send_via_relay(
            alice, bob.device_id, encode_transfer(b"after interruption", "reconnect.brad"),
            relay_host="127.0.0.1", relay_port=relay_port,
            relay_ca=Path(ca["ca_cert"]), relay_server_name="relay.test", relay_token=TOKEN,
            relay_fingerprint=cert["certificate_sha256"], relay_node_id=None,
            connect_timeout_seconds=3, response_timeout_seconds=5,
        )
        assert result["path"] == "RELAYED"
        assert decode_ack_bytes(result["ack_bytes"]).accepted is True
    finally:
        agent.stop()
        if replacement is not None:
            replacement.stop()
        upstream.shutdown(); upstream.server_close()


def test_live_revocation_disconnects_transport_authority(tmp_path):
    alice, bob, _, bob_file = _identities(tmp_path)
    ca, cert, relay = _relay(tmp_path)
    upstream = FakeBraid(("127.0.0.1", 0), FakeBraidHandler)
    threading.Thread(target=upstream.serve_forever, daemon=True).start()
    config = _agent_config(bob_file, ca, cert, relay, upstream.server_address[1])
    config = AgentConfig(**{**config.__dict__, "direct_enabled": False})
    agent = JumpKitAgent(config).start()
    try:
        assert agent.wait_ready(3), agent.last_error
        stored = DeviceIdentity.load(bob_file)
        stored.revoke(alice.device_id)
        stored.save(bob_file)
        with pytest.raises((ProtocolError, OSError)):
            _send(alice, bob, ca, cert, relay, encode_transfer(b"must not arrive", "revoked.brad"))
        assert not hasattr(upstream, "capture")
    finally:
        agent.stop(); relay.stop(); upstream.shutdown(); upstream.server_close()
