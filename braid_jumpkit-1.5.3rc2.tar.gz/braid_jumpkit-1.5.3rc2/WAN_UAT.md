# BRAID 1.5.3 — JUMP physical WAN UAT

## 2026-08-26 result

PASS for the tested macOS → public relay → Windows direction. The destination receiver validated, stored, and accepted an exact in-domain signed capsule and returned the ACK through the relay over TLS 1.3. This is evidence for relay-backed WAN/NAT reachability, not automatic direct hole punching or all platform/direction combinations.

The UAT also exposed an equal-deadline race. Temporary 20/60-second edits are superseded in RC2 by configurable hierarchical defaults: receiver-facing agent 90 seconds, relay response 120 seconds, sender round trip 150 seconds.

Use three physical hosts: endpoint A, endpoint B, and a public relay R. A and B must be behind unrelated ordinary consumer/office NATs. At minimum run Windows↔macOS and Linux↔Windows in both directions.

## Evidence header

Record UTC start/end, operator, OS/build, hardware architecture, network providers, NAT/CGNAT observations, source revision/archive hash, wheel/native-package hashes, Python/runtime versions, relay revision, relay certificate fingerprint, and redacted commands. Never record private keys, tokens, Jump Codes, or `.brad` plaintext.

## Fresh-install workflow

1. Install Braid Core without Jump Kit and prove local Core plus LAN transfer still work.
2. Install Jump Kit on fresh A and B machines.
3. Run `doctor` and prove Core is reachable specifically on `127.0.0.1:8745`.
4. Create identities and ten-minute Jump Codes.
5. Compare the displayed words out of band and approve both directions.
6. Start both agents and confirm relay TLS 1.3 plus the pinned certificate.
7. Send a signed object by device name without source checkout or debugging intervention.

## Required path tests

1. With a topology that permits a direct candidate, capture a valid `DIRECT` receipt and exact Core ACK.
2. Block the direct socket while preserving relay access; capture `RELAYED` and the exact Core ACK.
3. Confirm the relay capture contains no `.brad` or ACK plaintext.
4. Confirm a Braid rejection produces `REJECTED`, never a successful path receipt.
5. Attempt an expired Jump Code and an expired authorization; capture `EXPIRED`.
6. Revoke the peer while the agent is running and prove another transfer cannot reach Core.

## Interruption and recovery

During active/idle sessions separately interrupt endpoint WAN, relay WAN, relay process, and local Core. Restore each component and prove the agent reconnects without re-pairing. A failed or partial attempt must never manufacture acceptance. Record reconnect time and whether the eventual path is direct or relayed.

## Adversarial checks

- Wrong relay token and wrong TLS pin.
- Device-ID claim with another device's keys.
- Envelope signature, destination, kind, timestamp, ciphertext, and message-ID tampering.
- Replayed envelope and replay after agent reconnect.
- Malformed/oversized BTP1 and ACK.
- Core timeout, close, wrong digest, and false acceptance invariant.
- Direct listener connection exhaustion and slow clients.
- Relay connection limit, response timeout, duplicate reply, and replacement race.
- Packet capture on R proving content opacity.

## Packaging checks

Windows x64: build/signature, Defender scan, SmartScreen observation, per-user install/uninstall, service startup, sleep/resume, and upgrade from 1.5.2. Repeat the equivalent trust/notarization and lifecycle checks on macOS arm64 and supported Linux architectures.

## Pass rule

Attach raw redacted logs and hashes. Update `RELEASE_GATE.md` only from captured evidence. Any missing cross-OS direction, manual debugging required for the happy path, false receipt, content leak, authority violation, or unproven automatic traversal is a release NO-GO.
