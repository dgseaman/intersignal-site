# Braid Tendril v1.0.0 Release Verification Spec

This document details the standardized verification procedures required to confirm that a release candidate of the Braid Tendril client is "green" across all compilation and protocol conformance gates.

## Standardized Verification Sequence

To perform a complete verification check from a clean checkout, execute the following commands in order:

### 1. Frontend Production Compilation
Verify that the React/Vite web visualizer can be compiled without lockfile or dependency warnings:
```bash
npm ci
npm run build
```
*   **Success Criteria**: Both commands must exit with code `0`. A clean `dist/` directory must be generated.

### 2. Backend Rust Core Compilation & Verification
Verify that the Rust/Tauri core workspace compiles and passes formatting and type checks:
```bash
cd src-tauri
cargo check --workspace --all-targets
```
*   **Success Criteria**: Must compile without syntax, type, or import errors.

### 3. Backend Rust Core Unit Tests
Run the comprehensive cryptographic and protocol sanitization unit tests:
```bash
cargo test --workspace
```
*   **Success Criteria**: All unit tests must pass successfully (including `test_relayed_qint8_processing` and `test_preflight_packet_sanitizer_validation`).

### 4. Protocol Conformance Test
Verify that the local static fixtures conform to the IMTP-CBP v8 canonical layout and Ed25519 signature validation:
```bash
cd ..
python3 conformance_verify.py
cd conformance-fixtures && python3 conformance_verify.py && cd ..
```
*   **Success Criteria**: Must print `[SUCCESS] All Braid Pathfinder v0.9.0 protocol invariants verified successfully!`.

### 5. Loopback Socket Vector Transfer Demo
Verify that real, UDP socket-based loopback transmissions and dequantization reconstruction succeed:
```bash
# Test direct loopback f32 transmission
./braid demo vector-transfer --real-local --encoding raw-f32

# Test direct loopback qint8 quantized transmission
./braid demo vector-transfer --real-local --encoding qint8
```
*   **Success Criteria**:
    - For `raw-f32`: Must pass hash parity checks and exit with `[SUCCESS]`.
    - For `qint8`: Must satisfy RMSE reconstruction limits ($RMSE < 0.15$) and exit with `[SUCCESS]`.

### 6. Installer Checksum Verification
Validate that the binary installer script operates correctly and verifies artifact checksums:
```bash
sh verify-installer.sh
```
*   **Success Criteria**: Must print `Installer verification: PASS`.

---

## Expected Fail / Pass Meanings

- **PASS**: The release candidate successfully satisfies the strict cryptographic, size-boundary, and architectural constraints. It is safe to pack and distribute as a stable release.
- **FAIL**: Any non-zero exit code represents a gate failure. Distribution must be blocked until the root cause is resolved and re-verified.
