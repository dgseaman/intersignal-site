# Braid Tendril v1.0.0 NAT Traversal Guide

## Honest Traversal Capabilities & Boundaries

Braid Pathfinder v1.0.0 does not make overclaims about "fully decentralized automatic traversal." Direct UDP route establishment requires careful network configuration. There are no paid central TURN services or complex ICE protocol integrations bundled by default to avoid commercial dependencies. 

### How Direct UDP Can Work
Direct UDP path establishment requires that at least one of the nodes has a publicly reachable address or is behind a router that preserves port mappings (Cone NAT / Preserve-Port NAT) and has port forwarding or UPnP properly configured. Direct UDP route verification relies on explicit signed discovery probes exchanged over standard UDP sockets.

### When Port Forwarding Is Needed
If both nodes are behind private NAT routers (e.g., home networks), direct UDP punching might fail if the routers employ symmetric mapping or strict port restriction. In these scenarios, configuring a port forwarding rule on at least one router (binding the local UDP listen port to a public port) is required to allow incoming direct peer probes.

### When Relay Is Recommended
If port forwarding cannot be configured and both peers are behind restrictive or symmetric NAT, direct UDP punching is highly likely to fail. Under these conditions, the selection policy recommends using a verified Braid Relay Node.

## Scenario Matrix

| Scenario | Expected result | Recommended action |
| :--- | :--- | :--- |
| **Same Machine** | Works via local loopback | Use local loopback vector demo (`--real-local`). |
| **Same LAN** | Usually works directly | Add peer manually using the LAN IP and port. |
| **Public Server** | Works directly if port is open | Confirm firewall rules permit UDP on the local port. |
| **Home NAT with Port Forwarding** | Works via port mapping | Set up port forwarding for the Braid UDP port on the router. |
| **Home NAT without Port Forwarding** | May fail | Use Braid Relay Fallback or configure router port forwarding. |
| **Symmetric/Restrictive NAT** | Direct connection likely fails | Use a Braid Relay Node. |

## Under the Hood: No DHT or Global Discovery
Braid does not employ insecure public DHTs or blind internet range scanners. Discoveries are executed purely over user-configured seed endpoints or manual peers using cryptographically signed beacons, ensuring absolute control over network visibility and data leakage.
