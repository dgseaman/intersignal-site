use serde::{Serialize, Deserialize};
use sha2::{Sha256, Digest};

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AdapterType {
    TextProjection,
    LocalFileSummary,
    SemanticCacheSample,
    AgentMemoryDelta,
}

impl AdapterType {
    pub fn as_str(&self) -> &'static str {
        match self {
            AdapterType::TextProjection => "text_projection",
            AdapterType::LocalFileSummary => "local_file_summary",
            Self::SemanticCacheSample => "semantic_cache_sample",
            Self::AgentMemoryDelta => "agent_memory_delta",
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct AdapterDescriptor {
    pub id: String,
    pub name: String,
    pub description: String,
    pub supported: bool,
    pub honest_phrasing: String,
}

pub trait LatentAdapter: Send + Sync {
    fn name(&self) -> &str;
    fn description(&self) -> &str;
    fn honest_phrasing(&self) -> &str;
    fn is_supported(&self) -> bool;
    fn distill(&self, seed: &str) -> Result<Vec<f32>, String>;
}

pub struct TextProjectionAdapter;
impl LatentAdapter for TextProjectionAdapter {
    fn name(&self) -> &str {
        "Text Projection Latent Adapter"
    }
    fn description(&self) -> &str {
        "Generates a deterministic 384d state vector from the text input representing a simulated high-concept working-state summary."
    }
    fn honest_phrasing(&self) -> &str {
        "latent adapter / working-state summary"
    }
    fn is_supported(&self) -> bool {
        true
    }
    fn distill(&self, seed: &str) -> Result<Vec<f32>, String> {
        let mut hasher = Sha256::new();
        hasher.update(seed.as_bytes());
        let hash_res = hasher.finalize();
        let mut rng_seed = 0u64;
        for i in 0..8 {
            rng_seed = (rng_seed << 8) | hash_res[i] as u64;
        }
        let mut vector = Vec::with_capacity(384);
        let mut x = rng_seed;
        for _ in 0..384 {
            x = x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            let r = (x as f64) / (u64::MAX as f64);
            let val = (r * 2.0 - 1.0) as f32;
            vector.push(val);
        }
        Ok(vector)
    }
}

pub struct LocalFileSummaryAdapter;
impl LatentAdapter for LocalFileSummaryAdapter {
    fn name(&self) -> &str {
        "Local File Working-State Summary Adapter"
    }
    fn description(&self) -> &str {
        "Extracts and projects local workspace metadata (files, size, extensions) into a deterministic 384d state vector for transport testing."
    }
    fn honest_phrasing(&self) -> &str {
        "working-state summary / metadata-derived state vector"
    }
    fn is_supported(&self) -> bool {
        true
    }
    fn distill(&self, seed: &str) -> Result<Vec<f32>, String> {
        let root_dir = std::env::current_dir().map_err(|e| e.to_string())?;
        
        let mut file_count = 0;
        let mut dir_count = 0;
        let mut total_size = 0u64;
        let mut max_depth = 0;
        let mut rs_count = 0;
        let mut ts_count = 0;
        let mut tsx_count = 0;
        let mut json_count = 0;
        let mut md_count = 0;
        let mut other_count = 0;
        let mut recent_modified = 0;
        
        let now_ms = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64;

        fn walk_dir(
            dir: &std::path::Path,
            depth: usize,
            file_count: &mut usize,
            dir_count: &mut usize,
            total_size: &mut u64,
            max_depth: &mut usize,
            rs_count: &mut usize,
            ts_count: &mut usize,
            tsx_count: &mut usize,
            json_count: &mut usize,
            md_count: &mut usize,
            other_count: &mut usize,
            recent_modified: &mut usize,
            now_ms: u64,
        ) -> Result<(), String> {
            if depth > *max_depth {
                *max_depth = depth;
            }
            let entries = std::fs::read_dir(dir).map_err(|e| e.to_string())?;
            for entry in entries {
                if let Ok(entry) = entry {
                    let path = entry.path();
                    let name_str = path.file_name().unwrap_or_default().to_string_lossy();
                    
                    // Safe ignore list
                    if name_str == "node_modules"
                        || name_str == "target"
                        || name_str == "dist"
                        || name_str == ".git"
                        || name_str == ".DS_Store"
                        || name_str.starts_with('.')
                    {
                        continue;
                    }
                    
                    if path.is_dir() {
                        *dir_count += 1;
                        walk_dir(
                            &path,
                            depth + 1,
                            file_count,
                            dir_count,
                            total_size,
                            max_depth,
                            rs_count,
                            ts_count,
                            tsx_count,
                            json_count,
                            md_count,
                            other_count,
                            recent_modified,
                            now_ms,
                        )?;
                    } else if path.is_file() {
                        *file_count += 1;
                        if let Ok(metadata) = entry.metadata() {
                            let size = metadata.len();
                            *total_size += size;
                            
                            if let Ok(modified) = metadata.modified() {
                                if let Ok(elapsed) = modified.duration_since(std::time::UNIX_EPOCH) {
                                    let mod_ms = elapsed.as_millis() as u64;
                                    if now_ms.saturating_sub(mod_ms) < 24 * 3600 * 1000 {
                                        *recent_modified += 1;
                                    }
                                }
                            }
                        }
                        
                        if let Some(ext) = path.extension() {
                            let ext_str = ext.to_string_lossy().to_lowercase();
                            match ext_str.as_str() {
                                "rs" => *rs_count += 1,
                                "ts" => *ts_count += 1,
                                "tsx" => *tsx_count += 1,
                                "json" => *json_count += 1,
                                "md" => *md_count += 1,
                                _ => *other_count += 1,
                            }
                        } else {
                            *other_count += 1;
                        }
                    }
                }
            }
            Ok(())
        }
        
        walk_dir(
            &root_dir,
            1,
            &mut file_count,
            &mut dir_count,
            &mut total_size,
            &mut max_depth,
            &mut rs_count,
            &mut ts_count,
            &mut tsx_count,
            &mut json_count,
            &mut md_count,
            &mut other_count,
            &mut recent_modified,
            now_ms,
        )?;

        // Deterministic metadata summary packing
        let meta_summary = format!(
            "v0:{}:{}:{}:{}:{}:{}:{}:{}:{}:{}:{}:{}",
            root_dir.to_string_lossy(),
            file_count,
            dir_count,
            total_size,
            max_depth,
            rs_count,
            ts_count,
            tsx_count,
            json_count,
            md_count,
            recent_modified,
            seed
        );

        let mut hasher = Sha256::new();
        hasher.update(meta_summary.as_bytes());
        let digest = hasher.finalize();
        
        let mut rng_seed = 0u64;
        for i in 0..8 {
            rng_seed = (rng_seed << 8) | digest[i] as u64;
        }
        
        let mut vector = Vec::with_capacity(384);
        let mut x = rng_seed;
        for _ in 0..384 {
            x = x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            let r = (x as f64) / (u64::MAX as f64);
            let val = (r * 2.0 - 1.0) as f32;
            vector.push(val);
        }
        Ok(vector)
    }
}

pub struct SemanticCacheSampleAdapter;
impl LatentAdapter for SemanticCacheSampleAdapter {
    fn name(&self) -> &str {
        "Semantic Cache Sample Adapter"
    }
    fn description(&self) -> &str {
        "Encapsulates short-term semantic cache snapshots as coordinate drift matrices to prevent synchronization divergence (Future Phase)."
    }
    fn honest_phrasing(&self) -> &str {
        "semantic cache"
    }
    fn is_supported(&self) -> bool {
        false
    }
    fn distill(&self, _seed: &str) -> Result<Vec<f32>, String> {
        Err("Semantic Cache Sample adapter is not supported in this build. Upcoming in v0.9.".to_string())
    }
}

pub struct AgentMemoryDeltaAdapter;
impl LatentAdapter for AgentMemoryDeltaAdapter {
    fn name(&self) -> &str {
        "Agent Memory Delta Adapter"
    }
    fn description(&self) -> &str {
        "Compacts stateful memory delta increments into compact, cryptographic vector structures (Future Phase)."
    }
    fn honest_phrasing(&self) -> &str {
        "agent memory delta"
    }
    fn is_supported(&self) -> bool {
        false
    }
    fn distill(&self, _seed: &str) -> Result<Vec<f32>, String> {
        Err("Agent Memory Delta adapter is not supported in this build. Upcoming in v0.9.".to_string())
    }
}

pub struct AdapterManager {
    adapters: std::collections::HashMap<AdapterType, Box<dyn LatentAdapter>>,
}

impl AdapterManager {
    pub fn new() -> Self {
        let mut adapters = std::collections::HashMap::new();
        adapters.insert(AdapterType::TextProjection, Box::new(TextProjectionAdapter) as Box<dyn LatentAdapter>);
        adapters.insert(AdapterType::LocalFileSummary, Box::new(LocalFileSummaryAdapter) as Box<dyn LatentAdapter>);
        adapters.insert(AdapterType::SemanticCacheSample, Box::new(SemanticCacheSampleAdapter) as Box<dyn LatentAdapter>);
        adapters.insert(AdapterType::AgentMemoryDelta, Box::new(AgentMemoryDeltaAdapter) as Box<dyn LatentAdapter>);
        Self { adapters }
    }

    pub fn list(&self) -> Vec<AdapterDescriptor> {
        let mut list = Vec::new();
        for (k, v) in &self.adapters {
            list.push(AdapterDescriptor {
                id: k.as_str().to_string(),
                name: v.name().to_string(),
                description: v.description().to_string(),
                supported: v.is_supported(),
                honest_phrasing: v.honest_phrasing().to_string(),
            });
        }
        list.sort_by(|a, b| a.name.cmp(&b.name));
        list
    }

    pub fn get(&self, kind: AdapterType) -> Option<&dyn LatentAdapter> {
        self.adapters.get(&kind).map(|b| b.as_ref())
    }

    pub fn parse_kind(&self, kind_str: &str) -> Result<AdapterType, String> {
        match kind_str {
            "text_projection" => Ok(AdapterType::TextProjection),
            "local_file_summary" => Ok(AdapterType::LocalFileSummary),
            "semantic_cache_sample" => Ok(AdapterType::SemanticCacheSample),
            "agent_memory_delta" => Ok(AdapterType::AgentMemoryDelta),
            _ => Err(format!("Unknown adapter kind: {}", kind_str)),
        }
    }
}
