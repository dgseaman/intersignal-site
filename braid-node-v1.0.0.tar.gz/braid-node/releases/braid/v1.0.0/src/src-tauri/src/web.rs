use std::sync::Arc;
use tokio::net::TcpListener;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use crate::AppState;

// =====================================================================
// LOCALHOST WEB VISUALIZER VIEWPORT (Pillar 5)
// =====================================================================

pub async fn start_web_server(state: Arc<AppState>, web_port: u16) {
    let addr = format!("127.0.0.1:{}", web_port);
    let listener = match TcpListener::bind(&addr).await {
        Ok(l) => l,
        Err(_) => {
            TcpListener::bind("127.0.0.1:0").await.expect("Failed to bind web server to any port")
        }
    };

    let bound_addr = listener.local_addr().unwrap();
    println!("[WEB] Localhost Web Visualizer live at: http://{}", bound_addr);

    loop {
        match listener.accept().await {
            Ok((mut stream, _)) => {
                let state_clone = Arc::clone(&state);
                tokio::spawn(async move {
                    let mut buf = vec![0u8; 1024];
                    if let Ok(size) = stream.read(&mut buf).await {
                        let req_str = String::from_utf8_lossy(&buf[..size]);
                        
                        if req_str.starts_with("GET /api/state ") {
                            let node_id_hex = crate::format_hex(&state_clone.node_id);
                            
                            let peers_list = {
                                let table = state_clone.peer_table.lock().await;
                                table.values()
                                    .filter(|r| r.status != crate::main_status_stale())
                                    .map(|r| r.observed_addr.to_string())
                                    .collect::<Vec<String>>()
                            };

                            let latest_vec = {
                                let vec_guard = state_clone.latest_received_vector.lock().await;
                                vec_guard.clone()
                            };

                            let roster_list = {
                                let peer_table = state_clone.peer_table.lock().await;
                                let telemetry = state_clone.peer_telemetry.lock().await;
                                let now_ms = std::time::SystemTime::now()
                                    .duration_since(std::time::UNIX_EPOCH)
                                    .unwrap_or_default()
                                    .as_millis() as u64;

                                let mut roster = Vec::new();
                                for (node_id, record) in peer_table.iter() {
                                    let node_id_hex = crate::format_hex(node_id);
                                    let display_name = format!("Node-{}", &node_id_hex[0..8]);
                                    
                                    let elapsed = now_ms.saturating_sub(record.last_seen_ms);
                                    let presence_state = if elapsed >= crate::presence::PRESENCE_OFFLINE_AFTER_MS {
                                        "Offline".to_string()
                                    } else if elapsed >= crate::presence::PRESENCE_STALE_AFTER_MS {
                                        "Stale".to_string()
                                    } else {
                                        "Active".to_string()
                                    };

                                    let route_table = state_clone.route_table.lock().await;
                                    let route_state = if let Some(candidates) = route_table.get(node_id) {
                                        if candidates.iter().any(|c| c.state == crate::route::RouteState::Verified && matches!(c.endpoint, crate::route::RouteEndpoint::Udp(_))) {
                                            "direct".to_string()
                                        } else if candidates.iter().any(|c| c.state == crate::route::RouteState::Verified && matches!(c.endpoint, crate::route::RouteEndpoint::Relay { .. })) {
                                            "relay".to_string()
                                        } else if candidates.iter().any(|c| c.state == crate::route::RouteState::Probing) {
                                            "probing".to_string()
                                        } else {
                                            "failed".to_string()
                                        }
                                    } else {
                                        "unknown".to_string()
                                    };

                                    let (adapter, last_event) = telemetry.get(node_id)
                                        .cloned()
                                        .unwrap_or_else(|| ("text_projection".to_string(), None));

                                    roster.push(crate::presence::PresenceRosterView {
                                        node_id_hex,
                                        display_name,
                                        presence_state,
                                        route_state,
                                        nat_classification: "NAT-Restricted".to_string(),
                                        latency_ms: if record.round_trip_latency_ms > 0 { Some(record.round_trip_latency_ms) } else { None },
                                        last_seen_ms_ago: elapsed,
                                        active_adapter: adapter,
                                        last_payload_event: last_event,
                                    });
                                }
                                roster
                            };

                            let (vector_source, receipt_verified) = {
                                let last_obj_guard = state_clone.last_received_object.lock().await;
                                if let Some(ref obj) = *last_obj_guard {
                                    if obj.verified {
                                        ("peer_bound_verified", true)
                                    } else {
                                        ("daemon_state", false)
                                    }
                                } else {
                                    ("daemon_state", false)
                                }
                            };

                            let json_state = serde_json::json!({
                                "node_id": node_id_hex,
                                "local_address": format!("0.0.0.0:{}", state_clone.local_port),
                                "peers": peers_list,
                                "latest_vector": latest_vec,
                                "roster": roster_list,
                                "latest_vector_source": vector_source,
                                "last_receipt_verified": receipt_verified,
                            });

                            let body = serde_json::to_string(&json_state).unwrap_or_default();
                            let response = format!(
                                "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n{}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else if req_str.starts_with("GET /api/poke") {
                            let mut target_hex = String::new();
                            if let Some(pos) = req_str.find("target=") {
                                let query_part = &req_str[pos + 7..];
                                if let Some(end_pos) = query_part.find(' ') {
                                    target_hex = query_part[..end_pos].trim().to_string();
                                }
                            }

                            let mut status = "error";
                            let mut detail = "Node ID parse error".to_string();

                            if let Ok(target_bytes) = hex::decode(&target_hex) {
                                if target_bytes.len() == 32 {
                                    let mut target_node_id = [0u8; 32];
                                    target_node_id.copy_from_slice(&target_bytes);

                                    let peer_record_opt = {
                                        let table = state_clone.peer_table.lock().await;
                                        table.get(&target_node_id).cloned()
                                    };

                                    if let Some(record) = peer_record_opt {
                                        let seq = state_clone.sequence_counter.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                                        let now_ms = std::time::SystemTime::now()
                                            .duration_since(std::time::UNIX_EPOCH)
                                            .unwrap_or_default()
                                            .as_millis() as u64;

                                        let probe_payload = crate::protocol::BraidLinkProbe {
                                            ping_seq: 999,
                                            tx_timestamp_ms: now_ms,
                                        };

                                        if let Ok(serialized) = bincode::serialize(&probe_payload) {
                                            if let Ok(probe_env) = crate::protocol::BraidEnvelope::create(
                                                crate::protocol::MSG_LINK_PROBE,
                                                crate::protocol::VECTOR_ENCODING_RAW_F32,
                                                state_clone.session_id,
                                                seq,
                                                now_ms,
                                                serialized,
                                                state_clone.identity_provider.as_ref(),
                                            ) {
                                                if let Ok(ser_bytes) = bincode::serialize(&probe_env) {
                                                    let endpoint = crate::protocol::BraidEndpoint::Direct(record.observed_addr);
                                                    let res = state_clone.transport.send_to(&ser_bytes, endpoint).await;
                                                    if res.is_ok() {
                                                        status = "success";
                                                        detail = format!("Real UDP Link Probe dispatched to {}", record.observed_addr);
                                                    } else {
                                                        status = "error";
                                                        detail = format!("Transport IO error: {:?}", res.err());
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        detail = "Peer not active in local table".to_string();
                                    }
                                }
                            }

                            let json_res = serde_json::json!({
                                "status": status,
                                "detail": detail
                            });
                            let body = serde_json::to_string(&json_res).unwrap_or_default();
                            let response = format!(
                                "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n{}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else if req_str.starts_with("GET /api/scan") {
                            let seq = state_clone.sequence_counter.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                            let now_ms = std::time::SystemTime::now()
                                .duration_since(std::time::UNIX_EPOCH)
                                .unwrap_or_default()
                                .as_millis() as u64;

                            let discovery_payload = crate::protocol::BraidDiscoveryBeacon {
                                session_id: state_clone.session_id,
                                capabilities: crate::protocol::CAP_STATE_DRIFT | crate::protocol::CAP_DISCOVERY | crate::protocol::CAP_UDP_TRANSPORT | crate::protocol::CAP_VECTOR_384_F32 | crate::protocol::CAP_VECTOR_QINT8,
                                vector_dim: crate::EXPECTED_VECTOR_DIM as u16,
                                max_packet_size: crate::protocol::MAX_PACKET_SIZE as u16,
                                listen_port: state_clone.local_port,
                                ttl_ms: 15000,
                            };

                            let mut success = false;
                            if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                                if let Ok(envelope) = crate::protocol::BraidEnvelope::create(
                                    crate::protocol::MSG_DISCOVERY_BEACON,
                                    crate::protocol::VECTOR_ENCODING_RAW_F32,
                                    state_clone.session_id,
                                    seq,
                                    now_ms,
                                    serialized_beacon,
                                    state_clone.identity_provider.as_ref(),
                                ) {
                                    if let Ok(serialized_envelope) = bincode::serialize(&envelope) {
                                        let mut target_ports = vec![state_clone.local_port];
                                        for p in [12000, 12001, 12002, 12003, 12004] {
                                            if p != state_clone.local_port {
                                                target_ports.push(p);
                                            }
                                        }
                                        for p in target_ports {
                                            if let Ok(addr) = format!("255.255.255.255:{}", p).parse::<std::net::SocketAddr>() {
                                                let _ = state_clone.transport.send_to(
                                                    &serialized_envelope,
                                                    crate::protocol::BraidEndpoint::Direct(addr),
                                                ).await;
                                            }
                                        }
                                        success = true;
                                    }
                                }
                            }

                            let json_res = serde_json::json!({
                                "status": if success { "success" } else { "error" },
                                "detail": if success { "Subnet UDP beacons broadcast completed." } else { "Failed to serialize beacon." }
                            });
                            let body = serde_json::to_string(&json_res).unwrap_or_default();
                            let response = format!(
                                "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n{}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else if req_str.starts_with("GET / ") {
                            let html_body = include_str!("visualizer.html");
                            let response = format!(
                                "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                                html_body.len(),
                                html_body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else {
                            let body = "Not Found";
                            let response = format!(
                                "HTTP/1.1 404 Not Found\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        }
                        let _ = stream.flush().await;
                    }
                });
            }
            Err(_) => {
                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
            }
        }
    }
}
