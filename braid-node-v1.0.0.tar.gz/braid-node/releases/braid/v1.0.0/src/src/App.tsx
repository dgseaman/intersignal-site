import React, { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/tauri";
import { listen } from "@tauri-apps/api/event";

interface UdpPacketPayload {
  node_id: string;
  timestamp: number;
  sequence_id: number;
  latent_vector: number[];
  sender_address: string;
  byte_size: number;
}

interface NodeInfo {
  node_id: string;
  local_address: string;
  software_version: string;
  wire_version: number;
}

interface StreamResult {
  sent_count: number;
  failures: string[];
}

export default function App() {
  const [nodeInfo, setNodeInfo] = useState<NodeInfo | null>(null);
  const [peers, setPeers] = useState<string[]>([]);
  const [receivedPackets, setReceivedPackets] = useState<UdpPacketPayload[]>([]);
  const [vector, setVector] = useState<number[]>([]);
  const [vectorDim] = useState<number>(384);
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [lastBroadcastResult, setLastBroadcastResult] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"visualizer" | "raw">("visualizer");
  const [activeView, setActiveView] = useState<"dashboard" | "lab">("dashboard");

  // Connection Lab States
  const [networkStatus, setNetworkStatus] = useState<any>(null);
  const [routes, setRoutes] = useState<any[]>([]);
  const [sessions, setSessions] = useState<any[]>([]);
  const [receipts, setReceipts] = useState<any[]>([]);
  const [diagnosticsResult, setDiagnosticsResult] = useState<string | null>(null);

  // Manual peer form states
  const [manualLabel, setManualLabel] = useState("");
  const [manualEndpoint, setManualEndpoint] = useState("");
  const [manualNodeId, setManualNodeId] = useState("");
  const [manualTrustMode, setManualTrustMode] = useState("ManualTrusted");
  const [addPeerResult, setAddPeerResult] = useState<any>(null);

  // Probe form states
  
  const [probeResult, setProbeResult] = useState<any>(null);
  const [reachabilityReport, setReachabilityReport] = useState<any>(null);
  const [isCheckingReachability, setIsCheckingReachability] = useState<boolean>(false);
  const [recommendation, setRecommendation] = useState<any | null>(null);
  const [showWhyNote, setShowWhyNote] = useState<boolean>(false);
  const [showPortForwardHelp, setShowPortForwardHelp] = useState<boolean>(false);
  const [inviteResult, setInviteResult] = useState<string | null>(null);
  const [directUdpResult, setDirectUdpResult] = useState<any>(null);
  const [isDirectUdpAttempting, setIsDirectUdpAttempting] = useState<boolean>(false);

  // Send test vector states
  const [sendTargetNodeId, setSendTargetNodeId] = useState("");
  const [adapters, setAdapters] = useState<any[]>([]);
  const [selectedAdapterId, setSelectedAdapterId] = useState<string>("text_projection");
  const [recommendationUdpResult, setRecommendationUdpResult] = useState<any>(null);
  const [isRecUdpAttempting, setIsRecUdpAttempting] = useState<boolean>(false);

  const handleRecommendationUdpRetry = async () => {
    setIsRecUdpAttempting(true);
    setRecommendationUdpResult(null);
    const targetEndpoint = manualEndpoint || (peers.length > 0 ? peers[0] : "127.0.0.1:12000");
    try {
      const res = await invoke<any>("attempt_direct_udp_connect", {
        peerNodeId: manualNodeId ? manualNodeId : null,
        peerEndpoint: targetEndpoint,
        coordinationHint: null,
      });
      setRecommendationUdpResult(res);
      refreshLabState();
    } catch (err) {
      setRecommendationUdpResult({
        attempted: true,
        peer_endpoint: targetEndpoint,
        packets_sent: 0,
        response_received: false,
        route_verified: false,
        session_ready: false,
        elapsed_ms: 0,
        failure_reason: `${err}`,
        next_recommended_action: `Error: ${err}`,
      });
    } finally {
      setIsRecUdpAttempting(false);
    }
  };

  const [, setPresenceRoster] = useState<any[]>([]);
  const [, setLastReceivedObj] = useState<any>(null);
  const [sendEncoding, setSendEncoding] = useState("raw_f32");
  const [sendSeed, setSendSeed] = useState("");
  const [sendResult, setSendResult] = useState<any>(null);

  // Fetch initial info
  useEffect(() => {
    async function loadData() {
      try {
        const info = await invoke<NodeInfo>("get_node_info");
        setNodeInfo(info);
        const peerList = await invoke<string[]>("get_peers");
        setPeers(peerList);
        
        const list = await invoke<any[]>("list_adapters");
        setAdapters(list);
      } catch (err) {
        console.error("Failed to load node data:", err);
      }
    }
    loadData();
    generateRandomVector(vectorDim);
  }, []);

  // Poll for v0.9 Presence Roster and Last Verified Object in the background
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const roster = await invoke<any[]>("get_presence_roster");
        setPresenceRoster(roster);
      } catch (err) {
        console.error("Failed to load presence roster:", err);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const obj = await invoke<any>("get_last_received_object");
        setLastReceivedObj(obj);
      } catch (err) {
        console.error("Failed to load last received object:", err);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Poll for dynamically discovered peers in the background
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const peerList = await invoke<string[]>("get_peers");
        setPeers(peerList);
      } catch (err) {
        console.error("Failed to refresh peers:", err);
      }
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  // Listen for background UDP packets
  useEffect(() => {
    let unlistenFn: (() => void) | null = null;

    async function setupListener() {
      try {
        const unlisten = await listen<UdpPacketPayload>("udp-packet-received", (event) => {
          setReceivedPackets((prev) => {
            const updated = [event.payload, ...prev];
            return updated.slice(0, 100); // keep last 100 packets
          });
        });
        unlistenFn = unlisten;
      } catch (err) {
        console.error("Failed to bind Tauri event listener:", err);
      }
    }

    setupListener();

    return () => {
      if (unlistenFn) {
        unlistenFn();
      }
    };
  }, []);

  // Listen for vector-receipt event
  useEffect(() => {
    let unlistenFn: (() => void) | null = null;

    async function setupReceiptListener() {
      try {
        const unlisten = await listen<any>("vector-receipt", (event) => {
          setReceipts((prev) => {
            const updated = [event.payload, ...prev];
            return updated.slice(0, 50);
          });
        });
        unlistenFn = unlisten;
      } catch (err) {
        console.error("Failed to bind vector-receipt listener:", err);
      }
    }

    setupReceiptListener();

    return () => {
      if (unlistenFn) {
        unlistenFn();
      }
    };
  }, []);

  const refreshLabState = async () => {
    try {
      const rList = await invoke<any[]>("list_routes");
      setRoutes(rList);
      const sList = await invoke<any[]>("list_sessions");
      setSessions(sList);
      const net = await invoke<any>("get_network_status");
      setNetworkStatus(net);
    } catch (err) {
      console.error("Failed to refresh lab data:", err);
    }
  };

  useEffect(() => {
    if (activeView === "lab") {
      refreshLabState();
      const interval = setInterval(refreshLabState, 1500);
      return () => clearInterval(interval);
    }
  }, [activeView]);

  const generateRandomVector = (dim: number) => {
    const newVec = Array.from({ length: dim }, () => {
      return parseFloat((Math.random() * 2 - 1).toFixed(4));
    });
    setVector(newVec);
  };

  const handleStreamDrift = async () => {
    setIsBroadcasting(true);
    setLastBroadcastResult(null);
    try {
      const result = await invoke<StreamResult>("stream_state_drift", {
        latentVector: vector,
      });
      if (result.sent_count > 0) {
        setLastBroadcastResult(
          `Successfully broadcast state drift directly to ${result.sent_count} active peer(s).`
        );
      } else if (result.failures && result.failures.length > 0) {
        setLastBroadcastResult(
          `Broadcast failed: ${result.failures.join(", ")}`
        );
      } else {
        if (peers.length > 0) {
          setLastBroadcastResult(
            `Drift queued. Awaiting routebound session Ready commit...`
          );
        } else {
          setLastBroadcastResult(
            `No active peers or ready sessions. State drift broadcast skipped.`
          );
        }
      }
    } catch (err) {
      setLastBroadcastResult(`Broadcast failed: ${err}`);
    } finally {
      setIsBroadcasting(false);
    }
  };

  const handleAddManualPeer = async () => {
    setAddPeerResult(null);
    try {
      const res = await invoke<any>("add_manual_peer", {
        label: manualLabel,
        endpoint: manualEndpoint,
        nodeId: manualNodeId ? manualNodeId : null,
        trustMode: manualTrustMode,
      });
      setAddPeerResult(res);
      refreshLabState();
    } catch (err) {
      setAddPeerResult({ accepted: false, message: `Error: ${err}` });
    }
  };

  const handleProbePeer = async () => {
    setProbeResult(null);
    try {
      const res = await invoke<any>("probe_peer", {
        endpoint: manualEndpoint,
      });
      setProbeResult(res);
      refreshLabState();
    } catch (err) {
      setProbeResult({
        sent: false,
        packet_size: 0,
        elapsed_ms: null,
        response_received: false,
        error: `Error: ${err}`,
      });
    }
  };

  const handleSendTestVector = async () => {
    setSendResult(null);
    try {
      const res = await invoke<any>("send_test_vector", {
        targetNodeId: sendTargetNodeId ? sendTargetNodeId : null,
        encodingPreference: sendEncoding ? sendEncoding : null,
        seed: sendSeed ? sendSeed : null,
        adapterId: selectedAdapterId,
      });
      setSendResult(res);
      refreshLabState();
    } catch (err) {
      setSendResult({
        attempted: true,
        direct_attempted: false,
        relay_fallback_used: false,
        route_kind: "None",
        encoding: "None",
        vector_sha256: "",
        packet_size: 0,
        sent_count: 0,
        skipped: [],
        error: `Error: ${err}`,
        target_endpoint: "none",
      });
    }
  };

  const handleRunReachabilityTest = async () => {
    setIsCheckingReachability(true);
    setReachabilityReport(null);
    setRecommendation(null);
    try {
      const res = await invoke<any>("run_reachability_check");
      setReachabilityReport(res);
      // Derive connectivity recommendation
      const rec = await invoke<any>("derive_connectivity_recommendation", { report: res });
      setRecommendation(rec);
    } catch (err) {
      setReachabilityReport({ nat_status: "Error", warnings: [`${err}`], evidence: [] });
    } finally {
      setIsCheckingReachability(false);
    }
  };

  const copyPeerInvite = async () => {
    if (!recommendation) return;
    try {
      await navigator.clipboard.writeText(recommendation.json_invite);
      setInviteResult("Peer Invite (JSON) copied to clipboard!");
      setTimeout(() => setInviteResult(null), 3000);
    } catch (err) {
      setInviteResult(`Failed to copy: ${err}`);
      setTimeout(() => setInviteResult(null), 3000);
    }
  };

  const [relaySessionResult, setRelaySessionResult] = useState<string | null>(null);

  const handleStartRelaySession = async () => {
    setRelaySessionResult(null);
    try {
      // Step-by-step state progress is driven dynamically by the backend reaper
      const res = await invoke<string>("start_relay_session");
      setRelaySessionResult(res);
      refreshLabState();
    } catch (err) {
      setRelaySessionResult(`Error: ${err}`);
    }
  };

  const handleAttemptDirectUdp = async () => {
    setIsDirectUdpAttempting(true);
    setDirectUdpResult(null);
    try {
      const res = await invoke<any>("attempt_direct_udp_connect", {
        peerNodeId: manualNodeId ? manualNodeId : null,
        peerEndpoint: manualEndpoint,
        coordinationHint: null,
      });
      setDirectUdpResult(res);
      refreshLabState();
    } catch (err) {
      setDirectUdpResult({
        attempted: true,
        peer_endpoint: manualEndpoint,
        packets_sent: 0,
        response_received: false,
        route_verified: false,
        session_ready: false,
        elapsed_ms: 0,
        failure_reason: `${err}`,
        next_recommended_action: `Error: ${err}`,
      });
    } finally {
      setIsDirectUdpAttempting(false);
    }
  };

  const copyDiagnostics = async () => {
    try {
      const rList = await invoke<any[]>("list_routes");
      const sList = await invoke<any[]>("list_sessions");
      const net = await invoke<any>("get_network_status");
      const bundle = {
        version: "1.0.0",
        node_id: nodeInfo?.node_id || "",
        routes: rList,
        sessions: sList,
        last_send_result: sendResult,
        last_receipts: receipts,
        network_status: net,
      };
      await navigator.clipboard.writeText(JSON.stringify(bundle, null, 2));
      setDiagnosticsResult("Diagnostics copied to clipboard!");
      setTimeout(() => setDiagnosticsResult(null), 3000);
    } catch (err) {
      setDiagnosticsResult(`Failed to copy: ${err}`);
      setTimeout(() => setDiagnosticsResult(null), 3000);
    }
  };

  // Heatmap rendering utility for latent vector
  const renderHeatmap = (vec: number[], height: number = 80) => {
    if (vec.length === 0) return null;
    return (
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1px",
          background: "#161922",
          padding: "4px",
          borderRadius: "4px",
          maxHeight: `${height}px`,
          overflowY: "auto",
        }}
      >
        {vec.map((val, idx) => {
          const intensity = Math.min(Math.max((Math.abs(val)), 0), 1);
          const color =
            val >= 0
              ? `rgba(57, 219, 219, ${intensity})`  // Teal for positive
              : `rgba(235, 64, 52, ${intensity})`;   // Orange/Red for negative

          return (
            <div
              key={idx}
              title={`Index ${idx}: ${val.toFixed(4)}`}
              style={{
                width: "8px",
                height: "8px",
                backgroundColor: intensity < 0.05 ? "#242835" : color,
                borderRadius: "1px",
              }}
            />
          );
        })}
      </div>
    );
  };

  const getLatency = (timestamp: number): string => {
    const latencyMs = Date.now() - timestamp;
    if (!Number.isFinite(latencyMs)) return "unknown";
    if (latencyMs < 0) return "clock skew";
    if (latencyMs < 1000) {
      return `${latencyMs} ms`;
    }
    return `${(latencyMs / 1000).toFixed(1)} s`;
  };

  const activeUnicastPeers = peers.filter((p) => !p.includes("255.255"));
  const uniqueNodes = new Set(receivedPackets.map((p) => p.node_id));

  return (
    <div style={styles.container}>
      {/* HEADER */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.glowDot}></div>
          <h1 style={styles.title}>BRAID TENDRIL v1.0.0</h1>
          <span style={styles.version}>v1.0.0</span>
        </div>

        {/* View Toggles */}
        <div style={{ display: "flex", gap: "10px", margin: "0 20px" }}>
          <button
            onClick={() => setActiveView("dashboard")}
            style={activeView === "dashboard" ? styles.viewBtnActive : styles.viewBtn}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveView("lab")}
            style={activeView === "lab" ? styles.viewBtnActive : styles.viewBtn}
          >
            Connection Lab
          </button>
        </div>

        <div style={styles.headerRight}>
          {nodeInfo ? (
            <div style={styles.nodeMeta}>
              <span style={styles.label}>LOCAL PORT:</span>
              <code style={styles.code}>{nodeInfo.local_address.split(":").pop()}</code>
              <span style={{ ...styles.label, marginLeft: "15px" }}>NODE ID:</span>
              <code style={styles.code}>{nodeInfo.node_id.substring(0, 16)}...</code>
            </div>
          ) : (
            <span style={styles.connecting}>Initializing UDP Socket...</span>
          )}
        </div>
      </header>

      {/* DASHBOARD VIEW */}
      {activeView === "dashboard" && (
        <div style={styles.dashboard}>
          {/* LEFT COLUMN: Zero-Config Active Mesh Map */}
          <section style={styles.card}>
            <h2 style={styles.cardTitle}>Verified WAN Peer Sessions</h2>
            <div style={styles.cardContent}>
              <div style={styles.peerListHeader}>
                <span>Handshaked Peering Mesh ({activeUnicastPeers.length})</span>
              </div>
              
              <div style={styles.peerList}>
                {activeUnicastPeers.length === 0 ? (
                  <div style={styles.emptyMeshState}>
                    <div style={styles.radarRing}></div>
                    <div style={{ marginTop: "12px", color: "#8a94a6", fontWeight: "600" }}>
                      Awaiting handshaked sessions...
                    </div>
                    <div style={{ fontSize: "11px", color: "#56617a", padding: "0 10px", marginTop: "4px" }}>
                      Broadcasting rendezvous hello. Set trusted peer NodeId or use --open-dev flag to auto-verify.
                    </div>
                  </div>
                ) : (
                  activeUnicastPeers.map((peer, idx) => (
                    <div key={idx} style={peerRecordStyle}>
                      <div style={{ fontWeight: "bold" }}>Peer {idx + 1}</div>
                      <div style={{ fontSize: "11px", color: "#888" }}>Endpoint: {peer}</div>
                      <div style={{ fontSize: "11px", color: "#4ade80" }}>● READY FOR TRANSFER</div>
                    </div>
                  ))
                )}
              </div>

              <div style={styles.note}>
                <strong>WAN-Native Discovery:</strong> Braid Tendril v1.0.0 implements NodeId-first routing with signed-presence rendezvous. Sockets are completely abstracted; sessions are verified prior to exchanging state drift.
              </div>
            </div>
          </section>

          {/* MIDDLE COLUMN: State Generator */}
          <section style={styles.card}>
            <div style={styles.cardHeaderWithControls}>
              <h2 style={styles.cardTitle}>State Drift Generator</h2>
              <div style={styles.dimensionSelector}>
                <span style={styles.miniLabel}>DIM:</span>
                <select disabled style={styles.select}>
                  <option value="384">384 f32 (DeepBlend)</option>
                </select>
              </div>
            </div>

            <div style={styles.cardContent}>
              <div style={styles.tabHeader}>
                <button
                  style={activeTab === "visualizer" ? styles.tabActive : styles.tab}
                  onClick={() => setActiveTab("visualizer")}
                >
                  Latent Heatmap
                </button>
                <button
                  style={activeTab === "raw" ? styles.tabActive : styles.tab}
                  onClick={() => setActiveTab("raw")}
                >
                  Raw f32 Stream
                </button>
              </div>

              <div style={styles.vectorContainer}>
                {activeTab === "visualizer" ? (
                  <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                    <div style={styles.heatmapLabel}>
                      Each block represents a dimensional f32 coefficient [-1.0, 1.0]. Teal is positive, red is negative, slate is baseline (0.0).
                    </div>
                    {renderHeatmap(vector, 180)}
                  </div>
                ) : (
                  <textarea
                    readOnly
                    value={JSON.stringify(vector)}
                    style={styles.textarea}
                  />
                )}
              </div>

              <div style={styles.actionRow}>
                <button
                  onClick={() => generateRandomVector(vectorDim)}
                  style={styles.btnSecondary}
                >
                  Randomize State
                </button>
                <button
                  onClick={handleStreamDrift}
                  disabled={isBroadcasting}
                  style={styles.btnPrimary}
                >
                  {isBroadcasting ? "Broadcasting..." : "Stream State Drift"}
                </button>
              </div>

              {lastBroadcastResult && (
                <div
                  style={
                    lastBroadcastResult.includes("failed")
                      ? styles.statusError
                      : styles.statusSuccess
                  }
                >
                  {lastBroadcastResult}
                </div>
              )}
            </div>
          </section>

          {/* RIGHT COLUMN: Real-time Ingestion Feed */}
          <section style={styles.card}>
            <h2 style={styles.cardTitle}>Verified Ingestion Feed</h2>
            <div style={styles.cardContent}>
              <div style={styles.feedHeader}>
                <div style={styles.statMini}>
                  <span style={styles.statMiniValue}>{receivedPackets.length}</span>
                  <span style={styles.statMiniLabel}>Packets Received</span>
                </div>
                <div style={styles.statMini}>
                  <span style={styles.statMiniValue}>{uniqueNodes.size}</span>
                  <span style={styles.statMiniLabel}>Active Nodes</span>
                </div>
              </div>

              <div style={styles.feed}>
                {receivedPackets.length === 0 ? (
                  <div style={styles.feedEmpty}>
                    <div style={styles.radarGlow}></div>
                    <span>Awaiting cryptographically signed state drift...</span>
                  </div>
                ) : (
                  receivedPackets.map((packet, idx) => {
                    return (
                      <div key={idx} style={styles.feedItem}>
                        <div style={styles.feedItemHeader}>
                          <span style={styles.nodeIdBadge}>
                            Node: {packet.node_id.substring(0, 12)}
                          </span>
                          <span style={styles.latencyBadge}>
                            Latency: {getLatency(packet.timestamp)}
                          </span>
                        </div>

                        <div style={styles.packetDetails}>
                          <div>
                            <strong>From:</strong> <code>{packet.sender_address}</code>
                          </div>
                          <div style={{ color: "#39dbdb", fontWeight: "bold", fontSize: "10px", marginTop: "2px" }}>
                            🔒 CRYPTO SIGNATURE VERIFIED (ED25519)
                          </div>
                          <div style={{ color: "#39dbdb", fontWeight: "bold", fontSize: "10px", marginTop: "2px" }}>
                            📦 ROUTE-BOUND SECURE WAN SESSION
                          </div>
                        </div>

                        <div style={{ marginTop: "6px" }}>
                          {renderHeatmap(packet.latent_vector, 50)}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </section>
        </div>
      )}

      {/* CONNECTION LAB VIEW */}
      {activeView === "lab" && (
        <div style={styles.labContainer}>
          {/* LEFT FORM BLOCK */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px", overflowY: "auto", paddingRight: "8px" }}>
            
            {/* LOCAL NODE CARD */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Local Node Information</h3>
              <div style={styles.formContent}>
                {nodeInfo ? (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "8px", fontSize: "12px" }}>
                    <div><strong>Node ID:</strong> <code>{nodeInfo.node_id}</code></div>
                    <div><strong>Local UDP Bind Address:</strong> <code>{nodeInfo.local_address}</code></div>
                    <div><strong>Software Version:</strong> <code>{nodeInfo.software_version}</code></div>
                    <div><strong>Wire Protocol Version:</strong> <code>v{nodeInfo.wire_version}</code></div>
                  </div>
                ) : (
                  <div>Loading local node information...</div>
                )}
              </div>
            </section>

            {/* REACHABILITY CARD */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Reachability & NAT Traversal</h3>
              <div style={styles.formContent}>
                <button 
                  onClick={handleRunReachabilityTest} 
                  disabled={isCheckingReachability} 
                  style={styles.btnPrimary}
                >
                  {isCheckingReachability ? "Running Reachability Test..." : "Run Reachability Test"}
                </button>
                {reachabilityReport && (
                  <div style={{ marginTop: "12px", display: "flex", flexDirection: "column", gap: "12px", fontSize: "12px", borderTop: "1px solid #1c202d", paddingTop: "12px" }}>
                    <div><strong>Local Endpoint:</strong> <code>{reachabilityReport.local_endpoint}</code></div>
                    <div><strong>Public Endpoint:</strong> <code>{reachabilityReport.public_endpoint || "Undiscovered (timeout)"}</code></div>
                    
                    <div style={{ padding: "12px", backgroundColor: "#1c1e26", borderRadius: "6px", border: "1px solid #282b3d", marginTop: "4px" }}>
                      <div style={{ marginBottom: "8px" }}>
                        <strong style={{ color: "#39dbdb", textTransform: "uppercase", fontSize: "11px", letterSpacing: "0.5px" }}>NAT Classification:</strong>
                        <div style={{ fontSize: "14px", fontWeight: "bold", color: "#ffad47", marginTop: "2px" }}>
                          {reachabilityReport.nat_status}
                        </div>
                      </div>

                      <div style={{ marginBottom: "8px" }}>
                        <strong style={{ color: "#39dbdb", textTransform: "uppercase", fontSize: "11px", letterSpacing: "0.5px" }}>Direct UDP:</strong>
                        <div style={{ fontSize: "13px", fontWeight: "bold", color: reachabilityReport.direct_udp_likely ? "#4ade80" : "#ff6b6b", marginTop: "2px" }}>
                          {reachabilityReport.direct_udp_likely ? "Likely" : "Unlikely"}
                        </div>
                      </div>

                      {recommendation && (
                        <>
                          <div style={{ marginBottom: "8px", borderTop: "1px solid #282b3d", paddingTop: "8px" }}>
                            <strong style={{ color: "#39dbdb", textTransform: "uppercase", fontSize: "11px", letterSpacing: "0.5px" }}>Recommended Next Step:</strong>
                            <div style={{ fontSize: "13px", fontWeight: "bold", color: "#4ade80", marginTop: "2px" }}>
                              {recommendation.recommended_path === "RelayAssisted" ? "Use relay-assisted rendezvous" : 
                               recommendation.recommended_path === "DirectUdp" ? "Direct UDP peer connection" : 
                               recommendation.recommended_path === "PortForwardLikelyRequired" ? "Direct UDP Possible with router/NAT configuration" :
                               "Requires manual configuration or Relay fallback"}
                            </div>
                          </div>

                          <div style={{ marginBottom: "8px", fontSize: "11px", color: "#a5b4fc" }}>
                            {recommendation.recommended_path === "RelayAssisted" ? "Your router appears to rewrite UDP traffic in a way that may prevent direct peer punching. Braid can still connect through a relay path once relay configuration is available." : recommendation.guidance}
                          </div>

                          <div style={{ marginBottom: "8px" }}>
                            <strong style={{ color: "#8a94a6", fontSize: "11px" }}>Relay Status:</strong>
                            <div style={{ color: "#ffad47", fontSize: "11px", marginTop: "2px" }}>
                              {recommendation.relay_status_label}
                            </div>
                          </div>

                          {/* Collapsible Why Note */}
                          <div style={{ marginBottom: "8px" }}>
                            <button 
                              onClick={() => setShowWhyNote(!showWhyNote)} 
                              style={{ background: "none", border: "none", color: "#39dbdb", cursor: "pointer", fontSize: "11px", padding: 0, textDecoration: "underline" }}
                            >
                              {showWhyNote ? "Hide explanation [-]" : "Why? Collapsible Note [+]"}
                            </button>
                            {showWhyNote && (
                              <div style={{ color: "#8a94a6", fontSize: "11px", marginTop: "4px", backgroundColor: "#14161f", padding: "8px", borderRadius: "4px", lineHeight: "1.4" }}>
                                {recommendation.why_note}
                              </div>
                            )}
                          </div>

                          {/* Collapsible Port Forwarding Help */}
                          <div style={{ marginBottom: "8px" }}>
                            <button 
                              onClick={() => setShowPortForwardHelp(!showPortForwardHelp)} 
                              style={{ background: "none", border: "none", color: "#39dbdb", cursor: "pointer", fontSize: "11px", padding: 0, textDecoration: "underline" }}
                            >
                              {showPortForwardHelp ? "Hide Port Forward Help [-]" : "Manual Port Forwarding Help [+]"}
                            </button>
                            {showPortForwardHelp && (
                              <div style={{ color: "#8a94a6", fontSize: "11px", marginTop: "4px", backgroundColor: "#14161f", padding: "8px", borderRadius: "4px", lineHeight: "1.4" }}>
                                To ensure direct peer-to-peer connectivity under restrictive firewall policies:
                                <ol style={{ margin: "4px 0", paddingLeft: "16px" }}>
                                  <li>Log into your WAN router's administration portal.</li>
                                  <li>Locate the <strong>Port Forwarding</strong> or <strong>NAT Mapping</strong> settings.</li>
                                  <li>Create a new UDP rule mapping external port <code>{networkStatus?.local_udp_port || 12000}</code> directly to local port <code>12000</code> on your device's internal IP.</li>
                                  <li>Save configuration and retry the reachability check.</li>
                                </ol>
                              </div>
                            )}
                          </div>

                          {/* Action Buttons */}
                          <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", marginTop: "10px", borderTop: "1px solid #282b3d", paddingTop: "10px" }}>
                            <button onClick={copyDiagnostics} style={{ background: "transparent", border: "1px solid #282b3d", borderRadius: "4px", color: "#dcdfe6", cursor: "pointer", fontSize: "10px", padding: "4px 8px" }}>Copy Diagnostics</button>
                            <button onClick={copyPeerInvite} style={{ background: "transparent", border: "1px solid #282b3d", borderRadius: "4px", color: "#dcdfe6", cursor: "pointer", fontSize: "10px", padding: "4px 8px" }}>Copy Peer Invite</button>
                            <button onClick={handleRecommendationUdpRetry} style={{ background: "transparent", border: "1px solid #282b3d", borderRadius: "4px", color: "#dcdfe6", cursor: "pointer", fontSize: "10px", padding: "4px 8px" }}>{isRecUdpAttempting ? "Punching..." : "Retry Direct UDP"}</button>
                            <button 
                              onClick={handleStartRelaySession}
                              style={{ background: "transparent", border: "1px solid #282b3d", borderRadius: "4px", color: "#dcdfe6", cursor: "pointer", fontSize: "10px", padding: "4px 8px" }}
                            >
                              Start Relay Session
                            </button>
                          </div>
                          {relaySessionResult && (
                            <div style={{ color: "#39dbdb", fontSize: "11px", marginTop: "6px" }}>{relaySessionResult}</div>
                          )}
                          {recommendationUdpResult && (
                            <div style={{ ... (recommendationUdpResult.response_received ? styles.statusSuccess : styles.statusError), marginTop: "10px", fontSize: "11px" }}>
                              <div><strong>Punch Success:</strong> {recommendationUdpResult.response_received ? "Yes" : "No"}</div>
                              <div><strong>Endpoint:</strong> <code>{recommendationUdpResult.peer_endpoint}</code></div>
                              <div><strong>Route Verified:</strong> {recommendationUdpResult.route_verified ? "Yes" : "No"}</div>
                              <div><strong>Elapsed:</strong> {recommendationUdpResult.elapsed_ms} ms</div>
                              {recommendationUdpResult.failure_reason && <div style={{ color: "#ff6b6b" }}>Reason: {recommendationUdpResult.failure_reason}</div>}
                            </div>
                          )}
                          {inviteResult && (
                            <div style={{ color: "#39dbdb", fontSize: "11px", marginTop: "6px" }}>{inviteResult}</div>
                          )}
                          {diagnosticsResult && (
                            <div style={{ color: "#39dbdb", fontSize: "11px", marginTop: "6px" }}>{diagnosticsResult}</div>
                          )}
                        </>
                      )}
                    </div>

                    {/* Diagnostics Details (Collapsible) */}
                    <details style={{ marginTop: "6px", cursor: "pointer" }}>
                      <summary style={{ color: "#8a94a6", fontSize: "11px" }}>View Raw Diagnostic Evidence & Warnings</summary>
                      <div style={{ marginTop: "6px", display: "flex", flexDirection: "column", gap: "6px" }}>
                        {reachabilityReport.warnings.length > 0 && (
                          <div style={{ color: "#ff6b6b" }}>
                            <strong>Warnings:</strong>
                            <ul style={{ margin: "4px 0", paddingLeft: "16px" }}>
                              {reachabilityReport.warnings.map((w: string, i: number) => <li key={i}>{w}</li>)}
                            </ul>
                          </div>
                        )}
                        {reachabilityReport.evidence.length > 0 && (
                          <div>
                            <strong>Evidence Logs:</strong>
                            <ul style={{ margin: "4px 0", paddingLeft: "16px", color: "#8a94a6", fontSize: "10px" }}>
                              {reachabilityReport.evidence.map((e: string, i: number) => <li key={i}>{e}</li>)}
                            </ul>
                          </div>
                        )}
                      </div>
                    </details>
                  </div>
                )}
              </div>
            </section>

            {/* ADD MANUAL PEER */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Add & Probe Manual WAN Peer</h3>
              <div style={styles.formContent}>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Label:</label>
                  <input
                    type="text"
                    value={manualLabel}
                    onChange={(e) => setManualLabel(e.target.value)}
                    placeholder="e.g. Seed Node"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Endpoint (SocketAddr):</label>
                  <input
                    type="text"
                    value={manualEndpoint}
                    onChange={(e) => setManualEndpoint(e.target.value)}
                    placeholder="e.g. 127.0.0.1:12001"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Node ID (Optional Hex):</label>
                  <input
                    type="text"
                    value={manualNodeId}
                    onChange={(e) => setManualNodeId(e.target.value)}
                    placeholder="64-char hex target node id"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Trust Mode:</label>
                  <select
                    value={manualTrustMode}
                    onChange={(e) => setManualTrustMode(e.target.value)}
                    style={styles.selectField}
                  >
                    <option value="ManualTrusted">Manual Trusted</option>
                    <option value="PendingTrust">Pending Trust</option>
                    <option value="DiscoveryOnly">Discovery Only</option>
                  </select>
                </div>
                <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "10px" }}>
                  <button onClick={handleAddManualPeer} style={styles.btnPrimary}>
                    Add Peer
                  </button>
                  <button onClick={handleProbePeer} style={styles.btnSecondary}>
                    Probe Peer
                  </button>
                  <button onClick={handleAttemptDirectUdp} disabled={isDirectUdpAttempting} style={styles.btnSecondary}>
                    {isDirectUdpAttempting ? "Punching..." : "Attempt Direct UDP"}
                  </button>
                </div>
                
                {addPeerResult && (
                  <div style={{ ...styles.statusSuccess, marginTop: "10px" }}>
                    {addPeerResult.message || "Peer processed"}
                  </div>
                )}
                {probeResult && (
                  <div style={{ ... (probeResult.response_received ? styles.statusSuccess : styles.statusError), marginTop: "10px" }}>
                    <div><strong>Response Received:</strong> {probeResult.response_received ? "Yes" : "No"}</div>
                    <div><strong>Packet Size:</strong> {probeResult.packet_size} bytes</div>
                    <div><strong>Elapsed:</strong> {probeResult.elapsed_ms !== null ? `${probeResult.elapsed_ms} ms` : "timeout"}</div>
                    {probeResult.error && <div style={{ color: "#ff6b6b" }}>Error: {probeResult.error}</div>}
                  </div>
                )}
                {directUdpResult && (
                  <div style={{ ... (directUdpResult.response_received ? styles.statusSuccess : styles.statusError), marginTop: "10px" }}>
                    <div><strong>Punch Success:</strong> {directUdpResult.response_received ? "Yes" : "No"}</div>
                    <div><strong>Packets Sent:</strong> {directUdpResult.packets_sent}</div>
                    <div><strong>Route Verified:</strong> {directUdpResult.route_verified ? "Yes" : "No"}</div>
                    <div><strong>Session Ready:</strong> {directUdpResult.session_ready ? "Yes" : "No"}</div>
                    <div><strong>Elapsed:</strong> {directUdpResult.elapsed_ms} ms</div>
                    <div><strong>Next Step:</strong> {directUdpResult.next_recommended_action}</div>
                    {directUdpResult.failure_reason && <div style={{ color: "#ff6b6b" }}>Reason: {directUdpResult.failure_reason}</div>}
                  </div>
                )}
              </div>
            </section>

            {/* SEND TEST VECTOR */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Send Test 384d Vector</h3>
              <div style={styles.formContent}>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Target Peer Node ID:</label>
                  <input
                    type="text"
                    value={sendTargetNodeId}
                    onChange={(e) => setSendTargetNodeId(e.target.value)}
                    placeholder="Target Node ID (leave empty for first available)"
                    style={styles.input}
                  />
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Encoding Preference:</label>
                  <select
                    value={sendEncoding}
                    onChange={(e) => setSendEncoding(e.target.value)}
                    style={styles.selectField}
                  >
                    <option value="raw_f32">Raw F32</option>
                    <option value="qint8">QINT8 (8-bit Quantized)</option>
                  </select>
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Active Latent Adapter (v0.9.0):</label>
                  <select
                    value={selectedAdapterId}
                    onChange={(e) => setSelectedAdapterId(e.target.value)}
                    style={styles.selectField}
                  >
                    {adapters.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name} {!a.supported ? "(Upcoming)" : ""}
                      </option>
                    ))}
                  </select>
                  {adapters.find((a) => a.id === selectedAdapterId) && (
                    <div style={{ color: "#a5b4fc", fontSize: "10px", marginTop: "4px", lineHeight: "1.4" }}>
                      <strong>Active phrasing:</strong> <code>{adapters.find((a) => a.id === selectedAdapterId).honest_phrasing}</code><br/>
                      {adapters.find((a) => a.id === selectedAdapterId).description}
                      {selectedAdapterId === "local_file_summary" && (
                        <div style={{ marginTop: "6px", backgroundColor: "#1e2230", padding: "6px", borderRadius: "4px", border: "1px dashed #a5b4fc" }}>
                          <strong>Default Scan Target:</strong> <code>Current Workspace Root</code><br/>
                          <span style={{ color: "#ffad47" }}>⚠ Privacy Note: This adapter projects local metadata elements (such as file counts, directory depth, and file size distributions) into the 384d coordinate space. It does not ingest, read, or upload actual file contents.</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                <div style={styles.formRow}>
                  <label style={styles.formLabel}>Text Entry / Latent State Adapter:</label>
                  <input
                    type="text"
                    value={sendSeed}
                    onChange={(e) => setSendSeed(e.target.value)}
                    placeholder="Type a seed string to generate a deterministic 384d test vector"
                    style={styles.input}
                  />
                  <div style={{ color: "#8a94a6", fontSize: "10px", marginTop: "4px", lineHeight: "1.4" }}>
                    Type a string. The backend will use this string as a deterministic seed to generate a consistent, signed 384d test vector representing simulated working-state to stream across the network.
                  </div>
                </div>
                <button onClick={handleSendTestVector} style={styles.btnPrimary}>
                  {selectedAdapterId === "local_file_summary" ? "Scan Workspace & Send Vector" : "Send Test Vector"}
                </button>
                {sendResult && (
                  <div style={{ ... (sendResult.sent_count > 0 ? styles.statusSuccess : styles.statusError), marginTop: "12px" }}>
                    <div><strong>Direct Attempted:</strong> {sendResult.direct_attempted ? "Yes" : "No"}</div>
                    <div><strong>Relay Fallback Used:</strong> {sendResult.relay_fallback_used ? "Yes" : "No"}</div>
                    <div><strong>Transport Path Selected:</strong> {sendResult.route_kind}</div>
                    <div><strong>Target Endpoint:</strong> {sendResult.target_endpoint || "None"}</div>
                    <div><strong>Encoding used:</strong> {sendResult.encoding}</div>
                    <div><strong>Vector Hash:</strong> {sendResult.vector_sha256 ? `${sendResult.vector_sha256.substring(0, 16)}...` : "N/A"}</div>
                    <div><strong>Envelope Size:</strong> {sendResult.packet_size} bytes</div>
                    <div>
                      <strong>Transmission Status:</strong>{" "}
                      {sendResult.sent_count > 0 ? (
                        <span style={{ color: "#4ade80", fontWeight: "bold" }}>Success (vector successfully transmitted)</span>
                      ) : (
                        <span style={{ color: "#ff6b6b", fontWeight: "bold" }}>
                          Failed ({sendResult.skipped && sendResult.skipped.length > 0 ? sendResult.skipped[0].reason : sendResult.error || "Unknown error"})
                        </span>
                      )}
                    </div>
                    {sendResult.skipped && sendResult.skipped.length > 0 && (
                      <div style={{ color: "#ff6b6b", marginTop: "8px" }}>
                        <strong>Skipped Detail:</strong> {sendResult.skipped[0].reason} {sendResult.skipped[0].route_state ? `(route: ${sendResult.skipped[0].route_state})` : ""}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* RIGHT STATE TABLES AND MONITORS */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px", overflowY: "auto" }}>
            
            {/* NETWORK STATUS CARD */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Diagnostics & Privacy</h3>
              <div style={styles.formContent}>
                {networkStatus ? (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", fontSize: "12px" }}>
                    <div><strong>Bind Address:</strong> <code>{networkStatus.local_bind_addr}</code></div>
                    <div><strong>Local UDP Port:</strong> <code>{networkStatus.local_udp_port}</code></div>
                    <div><strong>NAT Status:</strong> <code style={{ color: "#ffad47" }}>{networkStatus.nat_status}</code></div>
                    <div><strong>Relay Connected:</strong> <code style={{ color: networkStatus.relay_available ? "#4ade80" : "#ff6b6b" }}>{networkStatus.relay_available ? "Yes" : "No"}</code></div>
                    <div style={{ gridColumn: "span 2" }}><strong>WAN Support Status:</strong> <div style={{ color: "#8a94a6", fontSize: "11px" }}>{networkStatus.direct_wan_supported}</div></div>
                  </div>
                ) : (
                  <div>Gathering network reachability stats...</div>
                )}
                
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginTop: "15px" }}>
                  <button onClick={copyDiagnostics} style={styles.btnSecondary}>Copy Diagnostics</button>
                  {diagnosticsResult && <span style={{ color: "#39dbdb", fontSize: "11px" }}>{diagnosticsResult}</span>}
                </div>
                
                <div style={{ fontSize: "11px", color: "#8a94a6", borderTop: "1px solid #1c202d", paddingTop: "8px", marginTop: "10px", backgroundColor: "#0b0c10", padding: "8px", borderRadius: "4px" }}>
                  <strong style={{ color: "#ffad47" }}>Privacy Copy & Disclosure:</strong><br />
                  Braid Tendril does not automatically share files, documents, chats, browser history, API keys, private keys, or personal data.<br /><br />
                  Network mode may share protocol-level data required for peer operation: node id, public signing key, UDP endpoint candidates, discovery probes, session handshakes, route metadata, signed protocol envelopes, relay headers, capabilities, timing metadata, and user-generated or app-generated 384-dimensional state vectors.<br /><br />
                  A 384d vector is not plain text, but it can still encode meaningful state. Treat vectors as sensitive unless you know exactly how they were generated. Braid does not make unsafe data safe merely by vectorizing it.
                </div>
              </div>
            </section>

            {/* ROUTE TABLE */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Active Routes Engine</h3>
              <div style={styles.formContent}>
                {routes.length === 0 ? (
                  <div style={{ color: "#56617a", fontSize: "12px" }}>No ready peers yet</div>
                ) : (
                  <table style={styles.table}>
                    <thead>
                      <tr>
                        <th style={styles.th}>Peer ID</th>
                        <th style={styles.th}>Endpoint</th>
                        <th style={styles.th}>Kind</th>
                        <th style={styles.th}>State</th>
                        <th style={styles.th}>Latency</th>
                        <th style={styles.th}>Encoding</th>
                      </tr>
                    </thead>
                    <tbody>
                      {routes.map((r, i) => (
                        <tr key={i} style={styles.tr}>
                          <td style={styles.td}><code>{r.peer_node_id.substring(0, 8)}...</code></td>
                          <td style={styles.td}><code>{r.endpoint}</code></td>
                          <td style={styles.itemBadge}>{r.route_kind}</td>
                          <td style={{ ...styles.td, color: r.verified ? "#4ade80" : "#ffad46" }}>{r.route_state}</td>
                          <td style={styles.td}>{r.latency_ms ? `${r.latency_ms}ms` : "N/A"}</td>
                          <td style={styles.td}>{r.preferred_vector_encoding}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </section>

            {/* SESSION TABLE */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Secure Session Handshakes</h3>
              <div style={styles.cardContent}>
                {sessions.length === 0 ? (
                  <div style={{ color: "#56617a", fontSize: "12px", padding: "10px 16px" }}>No sessions verified yet</div>
                ) : (
                  <table style={{ ...styles.table, width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={styles.th}>Peer ID</th>
                        <th style={styles.th}>Session ID</th>
                        <th style={styles.th}>State</th>
                        <th style={styles.th}>Capabilities</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sessions.map((s, i) => (
                        <tr key={i} style={styles.tr}>
                          <td style={styles.td}><code>{s.peer_node_id.substring(0, 8)}...</code></td>
                          <td style={styles.td}><code>{s.session_id.substring(0, 8)}...</code></td>
                          <td style={{ ...styles.td, color: s.ready_for_state_drift ? "#4ade80" : "#ffad46" }}>{s.state}</td>
                          <td style={styles.td}>{s.capabilities.join(", ")}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </section>

            {/* VECTOR RECEIPTS */}
            <section style={styles.formCard}>
              <h3 style={styles.formTitle}>Vector Receipt Logs</h3>
              <div style={styles.cardContent}>
                {receipts.length === 0 ? (
                  <div style={{ color: "#56617a", fontSize: "12px", padding: "10px 16px" }}>Awaiting first received 384d vector receipt...</div>
                ) : (
                  <div style={{ maxHeight: "250px", overflowY: "auto", padding: "0 16px" }}>
                    {receipts.map((rec, idx) => (
                      <details key={idx} style={receiptStyle}>
                        <summary style={{ cursor: "pointer", fontWeight: "bold", fontSize: "12px", color: "#39dbdb" }}>
                          📥 Receipt: {rec.from_node_id.substring(0, 12)}... ({rec.encoding}) - {getLatency(rec.received_at_ms)} ago
                        </summary>
                        <div style={{ padding: "8px 10px", fontSize: "11px", color: "#8a94a6", background: "#0a0b0f", marginTop: "4px", borderRadius: "4px" }}>
                          <div><strong>From:</strong> <code>{rec.from_node_id}</code></div>
                          <div><strong>Session:</strong> <code>{rec.session_id}</code></div>
                          <div><strong>Path:</strong> <code>{rec.route_kind} {rec.relay_used ? "(relayed)" : "(direct)"}</code></div>
                          <div><strong>Dimension:</strong> {rec.dimension}</div>
                          <div><strong>Packet Size:</strong> {rec.packet_size} bytes</div>
                          <div><strong>SHA-256:</strong> <code>{rec.vector_sha256}</code></div>
                        </div>
                      </details>
                    ))}
                  </div>
                )}
              </div>
            </section>
          </div>
        </div>
      )}{/* FOOTER STATS */}
      <footer style={styles.footer}>
        <div style={styles.footerBlock}>
          <span>PROTOCOL:</span>
          <strong>IMTP Wire Spec v8 (WAN Pathfinder Active)</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>CRYPTO:</span>
          <strong>Handshaked Session Keys</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>STATUS:</span>
          <span style={{ color: "#39dbdb" }}>● ROUTEBOUND PEER SESSIONS</span>
        </div>
      </footer>
    </div>
  );
}

const peerRecordStyle: React.CSSProperties = {
  backgroundColor: "#161922",
  border: "1px solid #202430",
  borderRadius: "6px",
  padding: "10px 12px",
  marginBottom: "8px",
};

const receiptStyle: React.CSSProperties = {
  backgroundColor: "#12151e",
  border: "1px solid #1c202d",
  borderRadius: "4px",
  padding: "8px",
  marginBottom: "8px",
};

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    width: "100%",
    boxSizing: "border-box",
    backgroundColor: "#0d0e12",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "16px 24px",
    borderBottom: "1px solid #1c202d",
    backgroundColor: "#10121a",
  },
  headerLeft: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  glowDot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
    backgroundColor: "#39dbdb",
    boxShadow: "0 0 10px #39dbdb",
  },
  title: {
    margin: 0,
    fontSize: "16px",
    fontWeight: "700",
    letterSpacing: "1px",
    color: "#ffffff",
  },
  version: {
    fontSize: "11px",
    padding: "2px 6px",
    borderRadius: "3px",
    backgroundColor: "#202430",
    color: "#8a94a6",
    fontWeight: "600",
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
  },
  nodeMeta: {
    display: "flex",
    alignItems: "center",
    fontSize: "12px",
    backgroundColor: "#08090d",
    padding: "6px 12px",
    borderRadius: "6px",
    border: "1px solid #202430",
  },
  label: {
    color: "#56617a",
    marginRight: "6px",
    fontWeight: "600",
  },
  code: {
    color: "#39dbdb",
    fontFamily: "Courier, monospace",
    fontWeight: "700",
  },
  connecting: {
    color: "#ffad47",
    fontWeight: "700",
  },

  viewBtn: {
    background: "#161922",
    border: "1px solid #202430",
    color: "#8a94a6",
    padding: "6px 16px",
    borderRadius: "4px",
    fontSize: "12px",
    fontWeight: "bold",
    cursor: "pointer",
  },
  viewBtnActive: {
    background: "#39dbdb",
    border: "1px solid #39dbdb",
    color: "#0d0e12",
    padding: "6px 16px",
    borderRadius: "4px",
    fontSize: "12px",
    fontWeight: "bold",
    cursor: "pointer",
  },
  dashboard: {
    display: "grid",
    gridTemplateColumns: "300px 1fr 340px",
    gap: "16px",
    padding: "16px",
    flex: 1,
    overflow: "hidden",
    boxSizing: "border-box",
  },
  labContainer: {
    display: "grid",
    gridTemplateColumns: "400px 1fr",
    gap: "16px",
    padding: "16px",
    flex: 1,
    overflow: "hidden",
    boxSizing: "border-box",
  },
  card: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: "#10121a",
    border: "1px solid #1c202d",
    borderRadius: "8px",
    overflow: "hidden",
  },
  formCard: {
    backgroundColor: "#10121a",
    border: "1px solid #1c202d",
    borderRadius: "8px",
    overflow: "hidden",
  },
  formTitle: {
    margin: 0,
    fontSize: "12px",
    fontWeight: "700",
    color: "#ffffff",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    padding: "10px 14px",
    background: "#161922",
    borderBottom: "1px solid #1c202d",
  },
  formContent: {
    padding: "14px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  formRow: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
  },
  formLabel: {
    fontSize: "11px",
    color: "#8a94a6",
    fontWeight: "bold",
  },
  input: {
    background: "#08090d",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#ffffff",
    padding: "8px",
    fontSize: "12px",
    fontFamily: "monospace",
  },
  selectField: {
    background: "#08090d",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#ffffff",
    padding: "8px",
    fontSize: "12px",
    cursor: "pointer",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    fontSize: "11px",
    textAlign: "left",
  },
  th: {
    background: "#161922",
    color: "#8a94a6",
    padding: "8px 10px",
    fontWeight: "bold",
    borderBottom: "1px solid #1c202d",
  },
  tr: {
    borderBottom: "1px solid #1c202d",
  },
  td: {
    padding: "8px 10px",
    color: "#ffffff",
  },
  itemBadge: {
    padding: "2px 6px",
    borderRadius: "3px",
    background: "#242835",
    color: "#39dbdb",
    fontSize: "10px",
    fontWeight: "bold",
  },
  cardHeaderWithControls: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 16px 8px 16px",
    borderBottom: "1px solid #1c202d",
  },
  cardTitle: {
    margin: 0,
    fontSize: "13px",
    fontWeight: "700",
    color: "#ffffff",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    padding: "12px 16px 8px 16px",
  },
  cardContent: {
    padding: "16px",
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflow: "hidden",
  },
  peerListHeader: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "12px",
    color: "#8a94a6",
    marginBottom: "12px",
    fontWeight: "600",
  },
  peerList: {
    flex: 1,
    overflowY: "auto",
    marginBottom: "12px",
  },
  emptyMeshState: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    textAlign: "center",
    color: "#56617a",
  },
  radarRing: {
    width: "40px",
    height: "40px",
    borderRadius: "50%",
    border: "2px solid #202430",
    position: "relative",
    animation: "radarPulse 2s infinite ease-out",
  },
  note: {
    fontSize: "11px",
    color: "#56617a",
    lineHeight: "1.4",
    backgroundColor: "#0c0d12",
    padding: "10px",
    borderRadius: "6px",
    border: "1px solid #1c202d",
  },
  dimensionSelector: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
  },
  miniLabel: {
    fontSize: "10px",
    color: "#56617a",
    fontWeight: "700",
  },
  select: {
    backgroundColor: "#161922",
    border: "1px solid #202430",
    color: "#ffffff",
    borderRadius: "4px",
    fontSize: "11px",
    padding: "4px 8px",
    fontWeight: "600",
  },
  tabHeader: {
    display: "flex",
    gap: "8px",
    borderBottom: "1px solid #1c202d",
    paddingBottom: "8px",
    marginBottom: "12px",
  },
  tab: {
    background: "none",
    border: "none",
    color: "#56617a",
    fontSize: "12px",
    fontWeight: "700",
    cursor: "pointer",
    padding: "4px 8px",
  },
  tabActive: {
    background: "none",
    border: "none",
    color: "#39dbdb",
    fontSize: "12px",
    fontWeight: "700",
    cursor: "pointer",
    padding: "4px 8px",
    borderBottom: "2px solid #39dbdb",
  },
  vectorContainer: {
    flex: 1,
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    marginBottom: "16px",
  },
  heatmapLabel: {
    fontSize: "11px",
    color: "#56617a",
    marginBottom: "8px",
    lineHeight: "1.3",
  },
  textarea: {
    width: "100%",
    height: "100%",
    minHeight: "150px",
    backgroundColor: "#08090d",
    border: "1px solid #202430",
    borderRadius: "6px",
    color: "#4ade80",
    fontFamily: "monospace",
    fontSize: "11px",
    padding: "8px",
    resize: "none",
    outline: "none",
  },
  actionRow: {
    display: "flex",
    gap: "10px",
    marginBottom: "12px",
  },
  btnPrimary: {
    flex: 1,
    backgroundColor: "#39dbdb",
    color: "#0d0e12",
    border: "none",
    borderRadius: "6px",
    padding: "10px 16px",
    fontSize: "12px",
    fontWeight: "700",
    cursor: "pointer",
    transition: "background-color 0.2s",
  },
  btnSecondary: {
    backgroundColor: "#202430",
    color: "#ffffff",
    border: "1px solid #2d3245",
    borderRadius: "6px",
    padding: "10px 16px",
    fontSize: "12px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "background-color 0.2s",
  },
  statusSuccess: {
    fontSize: "11px",
    color: "#4ade80",
    backgroundColor: "rgba(74, 222, 128, 0.05)",
    border: "1px solid rgba(74, 222, 128, 0.2)",
    padding: "10px",
    borderRadius: "6px",
    lineHeight: "1.4",
  },
  statusError: {
    fontSize: "11px",
    color: "#ff6b6b",
    backgroundColor: "rgba(255, 107, 107, 0.05)",
    border: "1px solid rgba(255, 107, 107, 0.2)",
    padding: "10px",
    borderRadius: "6px",
    lineHeight: "1.4",
  },
  feedHeader: {
    display: "flex",
    gap: "12px",
    borderBottom: "1px solid #1c202d",
    paddingBottom: "12px",
    marginBottom: "12px",
  },
  statMini: {
    display: "flex",
    flexDirection: "column",
    flex: 1,
    backgroundColor: "#161922",
    padding: "8px 12px",
    borderRadius: "6px",
    border: "1px solid #202430",
  },
  statMiniValue: {
    fontSize: "16px",
    fontWeight: "800",
    color: "#ffffff",
  },
  statMiniLabel: {
    fontSize: "10px",
    color: "#56617a",
    fontWeight: "600",
    textTransform: "uppercase",
  },
  feed: {
    flex: 1,
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  feedEmpty: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    color: "#56617a",
    textAlign: "center",
    fontSize: "12px",
    gap: "12px",
  },
  radarGlow: {
    width: "30px",
    height: "30px",
    borderRadius: "50%",
    backgroundColor: "#161922",
    border: "2px solid #202430",
  },
  feedItem: {
    backgroundColor: "#161922",
    border: "1px solid #202430",
    borderRadius: "6px",
    padding: "12px",
  },
  feedItemHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "8px",
  },
  nodeIdBadge: {
    fontSize: "10px",
    backgroundColor: "#242835",
    color: "#8a94a6",
    padding: "2px 6px",
    borderRadius: "3px",
    fontWeight: "700",
    fontFamily: "monospace",
  },
  latencyBadge: {
    fontSize: "10px",
    color: "#ffad47",
    fontWeight: "600",
  },
  packetDetails: {
    fontSize: "11px",
    color: "#8a94a6",
    lineHeight: "1.5",
    fontFamily: "monospace",
  },
  footer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 24px",
    borderTop: "1px solid #1c202d",
    backgroundColor: "#10121a",
    fontSize: "10px",
  },
  footerBlock: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    color: "#56617a",
  },
};
