#!/usr/bin/env bash
set -euo pipefail
rm -f "$HOME/.local/bin/braid" "$HOME/.local/bin/braid-client" "$HOME/.local/bin/braid-receiver" "$HOME/.local/bin/braid-client-launcher" "$HOME/.local/bin/braid-trust-export" "$HOME/.local/bin/braid-trust-import" "$HOME/.local/bin/braid-pair-export" "$HOME/.local/bin/braid-pair-import" "$HOME/.local/bin/braid-visualizer"
rm -f "$HOME/.local/share/applications/ai.intersignal.Braid.desktop" "$HOME/.local/share/applications/ai.intersignal.BraidVisualizer.desktop"
rm -f "$HOME/.local/share/icons/hicolor/512x512/apps/ai.intersignal.Braid.png"
rm -rf "$HOME/.local/share/braid/current"
echo "Braid application files removed. User workspace ~/.braid (including Braid Trust state) was intentionally preserved."
