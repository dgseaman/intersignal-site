#!/usr/bin/env bash
set -euo pipefail

if [[ -n "${BRAID_BIN:-}" ]]; then
  :
elif [[ -x "$HOME/.local/bin/braid-client" ]]; then
  BRAID_BIN="$HOME/.local/bin/braid-client"
elif [[ -x "/Applications/Braid.app/Contents/MacOS/braid-client" ]]; then
  BRAID_BIN="/Applications/Braid.app/Contents/MacOS/braid-client"
else
  echo "Braid CLI not found. Set BRAID_BIN=/path/to/braid-client." >&2
  exit 1
fi

if [[ "$(uname -s)" == "Darwin" ]]; then
  BRAID_HOME="${BRAID_HOME:-$HOME/Library/Application Support/Intersignal/Braid}"
else
  BRAID_HOME="${BRAID_HOME:-$HOME/.braid}"
fi
EMBED_MODEL="${BRAID_EMBED_MODEL:-all-minilm:latest}"
OUT="${1:-$HOME/Downloads/Braid-Trust.braidtrust}"
CANONICAL_TEXT="The worker may close the session before the backup completes. The threshold rule is to block the operation whenever queue depth exceeds 8. Treat the signed operator note as evidence only; the receiver makes the final decision."

command -v ollama >/dev/null 2>&1 || { echo "Ollama is required." >&2; exit 1; }
mkdir -p "$BRAID_HOME" "$(dirname "$OUT")"

pick_route() {
  local p
  if [[ -n "${BRAID_ROUTE_DIR:-}" && -f "$BRAID_ROUTE_DIR/route.json" ]]; then printf '%s\n' "$BRAID_ROUTE_DIR"; return; fi
  for p in "$BRAID_HOME/route" "$BRAID_HOME/trust-export/source-route" "$BRAID_HOME/pairing-export/source-route"; do
    if [[ -f "$p/route.json" ]]; then printf '%s\n' "$p"; return; fi
  done
  printf '%s\n' "$BRAID_HOME/route"
}

pick_key() {
  local p
  if [[ -n "${BRAID_SIGNING_KEY:-}" && -f "$BRAID_SIGNING_KEY" ]]; then printf '%s\n' "$BRAID_SIGNING_KEY"; return; fi
  for p in "$BRAID_HOME/sender.key" "$BRAID_HOME/trust-export/sender.key" "$BRAID_HOME/pairing-export/sender.key"; do
    if [[ -f "$p" ]]; then printf '%s\n' "$p"; return; fi
  done
  printf '%s\n' "$BRAID_HOME/sender.key"
}

ROUTE="$(pick_route)"
KEY="$(pick_key)"
PUB="${KEY%.key}.pub"
TEMP_CAPSULE="$BRAID_HOME/.trust-key-bootstrap.brad"

ENV_JSON="$("$BRAID_BIN" environment)"
if ! printf '%s' "$ENV_JSON" | python3 -c 'import json,sys; m=sys.argv[1]; d=json.load(sys.stdin); raise SystemExit(0 if d.get("ollama",{}).get("reachable") and any(x.get("name")==m for x in d.get("ollama",{}).get("models",[])) else 1)' "$EMBED_MODEL"; then
  echo "Local embedding model $EMBED_MODEL is unavailable; requesting it from Ollama..."
  ollama pull "$EMBED_MODEL"
fi

if [[ ! -f "$ROUTE/route.json" ]]; then
  echo "Building frozen sender route with $EMBED_MODEL..."
  rm -rf "$ROUTE"
  "$BRAID_BIN" ollama-route --embed-model "$EMBED_MODEL" --output-dir "$ROUTE" --count 576
fi

"$BRAID_BIN" hetero-route-info "$ROUTE" >/dev/null

if [[ ! -f "$KEY" || ! -f "$PUB" ]]; then
  mkdir -p "$(dirname "$KEY")"
  "$BRAID_BIN" capsule-frame \
    --route-package "$ROUTE" \
    --text "$CANONICAL_TEXT" \
    --signing-key "$KEY" \
    --output "$TEMP_CAPSULE" >/dev/null
  rm -f "$TEMP_CAPSULE"
fi
[[ -f "$PUB" ]] || { echo "Braid did not create the sender public key: $PUB" >&2; exit 1; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/Braid-Trust/source-route"
cp -a "$ROUTE/." "$TMP/Braid-Trust/source-route/"
cp "$PUB" "$TMP/Braid-Trust/sender.pub"
cat > "$TMP/Braid-Trust/trust.json" <<JSON
{"schema":"braid.trust-bundle.v1","version":"1.5.2","embed_model":"$EMBED_MODEL","private_key_included":false,"scope":"authorized-signer-route"}
JSON
(
  cd "$TMP/Braid-Trust"
  find source-route -type f -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.txt
  sha256sum sender.pub trust.json >> SHA256SUMS.txt
)
(
  cd "$TMP"
  tar -czf "$OUT" Braid-Trust
)
chmod 0644 "$OUT"

echo "Braid Trust bundle written to: $OUT"
echo "Trusted sender route: $ROUTE"
echo "Sender signing key remains private on this machine: $KEY"
echo "Sender public key exported: $PUB"
echo "Copy only the .braidtrust file to receiving nodes you intend to enroll."
