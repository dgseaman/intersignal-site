#!/usr/bin/env bash
set -euo pipefail
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$HERE"
sha256sum -c PACKAGE_SHA256SUMS.txt
for f in install-braid-linux.sh uninstall-braid-linux.sh braid-trust-export.sh helpers/braid-client-launcher helpers/braid-receiver helpers/braid-trust-export helpers/braid-trust-import helpers/braid-visualizer; do
  bash -n "$f"
done
python3 - <<'PY2'
import tarfile
with tarfile.open('payload/braid-source.tar', 'r:') as t:
    names=t.getnames()
    if not names: raise SystemExit('empty source payload')
    for n in names:
        if n.startswith('/') or '..' in n.split('/'):
            raise SystemExit(f'unsafe source payload member: {n}')
print('PASS: source payload paths are relative and traversal-free')
PY2
echo "PASS: Braid v1.5.2 Linux package hashes and shell syntax verified."
