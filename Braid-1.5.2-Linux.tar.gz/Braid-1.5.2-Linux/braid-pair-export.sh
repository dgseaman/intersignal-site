#!/usr/bin/env bash
exec "$(dirname "$0")/braid-trust-export.sh" "$@"
