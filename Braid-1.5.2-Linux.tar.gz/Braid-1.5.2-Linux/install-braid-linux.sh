#!/usr/bin/env bash
set -euo pipefail
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PAYLOAD="$HERE/payload/braid-source.tar"
PREFIX="$HOME/.local/share/braid/current"
VENV="$PREFIX/venv"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
ICONS="$HOME/.local/share/icons/hicolor/512x512/apps"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

command -v python3 >/dev/null 2>&1 || { echo "Python 3 is required." >&2; exit 1; }
python3 - <<'PY2'
import sys
if sys.version_info < (3,10):
    raise SystemExit("Braid requires Python 3.10+")
PY2
[[ -f "$PAYLOAD" ]] || { echo "Missing payload: $PAYLOAD" >&2; exit 1; }

VENV_PROBE="$WORK/venv-probe"
if ! python3 -m venv "$VENV_PROBE" >/dev/null 2>&1; then
  cat >&2 <<'TXT'
Braid could not create a Python virtual environment.
On Debian/Ubuntu systems install the matching venv package, for example:
  sudo apt install python3-venv
Then re-run this installer.
TXT
  exit 1
fi
rm -rf "$VENV_PROBE"

mkdir -p "$PREFIX" "$BIN" "$APPS" "$ICONS"
rm -rf "$VENV"
python3 -m venv "$VENV"
export PIP_DISABLE_PIP_VERSION_CHECK=1

tar -xf "$PAYLOAD" -C "$WORK"
SRC="$(find "$WORK" -mindepth 1 -maxdepth 1 -type d | head -1)"
[[ -n "$SRC" ]] || { echo "Unable to unpack Braid source payload." >&2; exit 1; }
"$VENV/bin/python" -m pip install "$SRC[full]"

ln -sfn "$VENV/bin/braid-client" "$BIN/braid-client"
ln -sfn "$VENV/bin/braid-client" "$BIN/braid"
install -m 0755 "$HERE/helpers/braid-receiver" "$BIN/braid-receiver"
install -m 0755 "$HERE/helpers/braid-client-launcher" "$BIN/braid-client-launcher"
install -m 0755 "$HERE/helpers/braid-trust-export" "$BIN/braid-trust-export"
install -m 0755 "$HERE/helpers/braid-trust-import" "$BIN/braid-trust-import"
# Compatibility aliases for RC1/hotfix users. New docs use Braid Trust terminology.
ln -sfn "$BIN/braid-trust-export" "$BIN/braid-pair-export"
ln -sfn "$BIN/braid-trust-import" "$BIN/braid-pair-import"
install -m 0755 "$HERE/helpers/braid-visualizer" "$BIN/braid-visualizer"
install -m 0644 "$HERE/assets/BraidIcon.png" "$ICONS/ai.intersignal.Braid.png"

cat > "$APPS/ai.intersignal.Braid.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Braid Client
Comment=Open Braid visualizer and start the trusted secure LAN receiver
Exec=$BIN/braid-client-launcher
Icon=ai.intersignal.Braid
Terminal=false
Categories=Development;Network;
StartupNotify=true
DESKTOP
chmod 0644 "$APPS/ai.intersignal.Braid.desktop"

cat > "$APPS/ai.intersignal.BraidVisualizer.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Braid Visualizer
Comment=Open the local Braid field UI
Exec=$BIN/braid-visualizer
Icon=ai.intersignal.Braid
Terminal=false
Categories=Development;Network;
StartupNotify=true
DESKTOP
chmod 0644 "$APPS/ai.intersignal.BraidVisualizer.desktop"

if command -v desktop-file-validate >/dev/null 2>&1; then
  desktop-file-validate "$APPS/ai.intersignal.Braid.desktop" "$APPS/ai.intersignal.BraidVisualizer.desktop" || true
fi
if command -v update-desktop-database >/dev/null 2>&1; then update-desktop-database "$APPS" >/dev/null 2>&1 || true; fi
if command -v gtk-update-icon-cache >/dev/null 2>&1; then gtk-update-icon-cache -f "$HOME/.local/share/icons/hicolor" >/dev/null 2>&1 || true; fi

add_path_line() {
  local rc="$1"
  [[ -f "$rc" ]] || return 0
  if ! grep -Fq 'export PATH="$HOME/.local/bin:$PATH"' "$rc"; then
    printf '\n# Intersignal Braid\nexport PATH="$HOME/.local/bin:$PATH"\n' >> "$rc"
  fi
}
add_path_line "$HOME/.bashrc"
add_path_line "$HOME/.zshrc"

"$BIN/braid-client" --version
"$BIN/braid-client" doctor
cat <<TXT

Braid v1.5.2 for Linux installed.

Desktop:
  Braid Client      -> visualizer + persistent secure receiver terminal
  Braid Visualizer  -> visualizer only

Braid Trust:
  Sender:   $BIN/braid-trust-export
  Receiver: copy Braid-Trust.braidtrust to ~/Downloads, then double-click Braid Client
  Note:     the private signing key never leaves the sender

CLI:
  $BIN/braid --help

If this current terminal cannot find 'braid' yet, run:
  export PATH="$HOME/.local/bin:\$PATH"
TXT
