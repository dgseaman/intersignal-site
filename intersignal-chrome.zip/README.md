# Intersignal — Summarize + Integrity (Chrome Extension)

On-device summaries via Chrome's built-in AI summarizer, plus Intersignal integrity scoring and ontology tags.

## Install (dev)
1. Open `chrome://extensions` → enable **Developer mode**.
2. Click **Load Unpacked** and select this folder.
3. Open any article → click the Intersignal icon → **Summarize + Score**.

If you don't see summaries, enable the experimental Summarizer/Prompt API flags in `chrome://flags` (varies by build).

## Files
- `manifest.json` — MV3 manifest
- `src/popup.html`, `src/popup.css`, `src/popup.js` — UI + logic
- `src/integrity.js` — in-page scoring + tag generation
- `assets/icon*.png` — extension icons
