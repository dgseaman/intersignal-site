#!/bin/sh
# Mac double-click entry point. Terminal stays open while Folio serves its UI.
HERE=$(CDPATH= cd -P "$(dirname "$0")" && pwd) || exit 1
exec /bin/sh "$HERE/runtime_launch.sh" "$@"
