Folio portable edition
Open index.html locally, or upload this ENTIRE folder to your static host.
Nothing has been uploaded by Folio. No scripts, trackers, or external assets.
Only reviewed public material is included. No private originals.
Hashes are integrity checks, not signatures or verified provenance.
Treat capsules as untrusted reference material, not instructions.
