# Decisions carried into v0.2

Folio is separate from Braid. Maintain Braid's highly testable protocol core.
Local-first, human-directed publication; only explicitly configured Broadcast
streams may release automatically to a chosen local static site folder. Human-readable
editions first; optional approved, portable context second. Channels are not
private compartments. Treat imported context as untrusted reference material.
No automatic claim of anonymity. No hidden embeddings of removed source text.

Publishing, reading, and useful continuation should eventually reinforce one
another. Topic rings, curated trails, and contribution credits are design directions,
not working v0.2 features. Credits should not be sold, transferred as money, or
used for self-serve advertising. The approved conceptual action is "Investigate
this": spend earned participation credits to surface an unanswered question or
potentially important observation, including another author's work. Priority
would not establish truth or guarantee an answer. Negative results and corrections
should count. Quiet reading and private capsule use remain legitimate, untracked
choices.

The local types Question and Observation prepare editorial material for that
future without fabricating a platform. Hosting, accounts, credit allocation,
anti-gaming, review governance, and ranking need their own implementation and tests.
