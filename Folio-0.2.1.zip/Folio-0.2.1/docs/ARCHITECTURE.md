# Architecture / v0.2.1

## Recurring stream layer

The original draft, approval hash, immutable edition, and Braid read-view
boundaries remain. Two new SQLite tables hold stream configurations and cycle
records; existing `drafts` and `exports` tables are not migrated. A recurring
dispatch is an ordinary Folio draft with private stream provenance and an
optional public `{id,name}` stream label in its v1 public body. Older manual
drafts and editions retain their shape.

Each stream explicitly records selected Braid Channel IDs, allowed source types,
an optional tag, cadence, template, and local privacy rules. `folio/dispatch.py`
collects only those read views, tracks opaque content fingerprints, selects
source-grounded salient excerpts, and creates a sanitized unapproved draft.
The sanitation audit reports field/category/replacement and retains private
originals for comparison; it does not store matched secrets in the audit.
No model endpoint or complete shared-field query is used.

The scheduler runs every 30 seconds while the Folio process is open. It never
reconnects to Braid silently. An unavailable Braid session records a blocked
cycle and retries after five minutes. A successful cycle schedules its next
run according to the stream's cadence. At most eight Channels, five recent
conversations per Channel, twenty recent turns per conversation, and Braid's
hundred-item note/object view are inspected in one cycle. These are explicit
sampling windows, not a complete timeline or a date-based cursor.

Review Queue is the default. The draft then uses the existing human edit,
preview, exact-content approval, and export boundary. Broadcast requires a
separate acknowledgement, a nonempty tag, all built-in privacy patterns
enabled, and an explicit existing destination folder. It creates a local edition
ZIP only when no residual literal privacy flags remain; otherwise it queues the
draft for review. This gate is heuristic and not an anonymity guarantee.
After release, Folio materializes a static stream site in a dedicated child
folder. A failed folder update is recorded and can be retried without repeating
the Braid observation. Released stream editions can also be bundled into a ZIP.
For Review Queue streams with a destination, the folder update happens after
the human approves and exports the draft.
Folio does not upload to a remote host; the user may serve or sync the chosen
folder through their own static host.

## Separate application boundary

Folio owns its HTTP service, private SQLite store, UI, export format, process,
launchers, session token, and profile. It has no production dependency on Braid's
Python package. No Braid patch or migration is provided. Braid remains the
existing local protocol client and inference interface.

The adapter uses exactly these Braid 1.9.1 local UI requests:

| Method | Route | Payload / purpose |
| --- | --- | --- |
| GET | /api/messenger/state | Explicit connection; version, CSRF, Channel list |
| POST | /api/messenger/channel | {"action":"view","id":"selected-channel"} |
| POST | /api/messenger/chat | {"action":"view","thread":"selected-thread"} |

POST here reflects the existing Braid API, not a new write operation. Folio has
an allowlist for these view actions. It does not call send, create, publish, turn,
field query/index, permission change, listener, or WAN endpoints. Braid's own
read handlers may perform their normal internal housekeeping; no claim is made
that every file byte in a running Braid profile remains static.

Folio permits an explicit numeric 127.0.0.1 UI address only. No proxy, redirect,
port scan, LAN bridge, or remote API endpoint is supported. Auto-detection reads
session.json in the standard messenger/messenger-a4 profiles, then checks the
reported profile. Failed explicit connection clears the earlier connection.
Restarting either app requires reconnecting; there is no silent inference retry.

Only selected visible text is normalized into Folio. Completed question/answer
pairs are used; raw result metadata, supplied context, keys, peer lists, Braid
identifiers, and model internals are not imported into publication data. There
is no complete shared-field export. The existing view's 100-item limits apply.

## Publication boundary

Private originals and editorial fields are separate. Export uses an explicit
public projection, never serialization of the draft object. Selected public
passages and explicit capsule fields are visible in the rendered review.
Excluding a passage also removes it from the capsule selection. Disabled capsule
fields remain private, even if they contain text. No embedding of original text
is attached.

Approval binds to SHA-256 of the public body. Public changes invalidate it;
server-side approval/export checks are independent of disabled UI buttons.
Changes affecting only private content need not invalidate an otherwise unchanged
public edition. This is an editorial review boundary, not de-identification proof,
consent verification, or protection against a user deliberately entering secrets.

Public HTML is escaped, script-free, and self-contained; preview is sandboxed.
Markdown treats source markup literally rather than executing embedded HTML.
ZIP names are fixed. Imported public JSON is bounded, hash checked and normalized
into a NEW unapproved draft. Imported content is never run or automatically sent
to a model. A model receiving copied context still needs its own trust boundaries.

## Private app security and persistence

Only loopback binding; exact Host and Origin checks; cross-site browser requests
rejected; random per-process token for data reads/writes; no CORS; no content or
request logging. The launch token is carried in a fragment then tab sessionStorage,
not query parameters or public exports. CSP and a sandboxed preview limit active
content. Browser extensions, a compromised user account, and same-user processes
are outside this isolation boundary. This is not an audited hardened multiuser
service. Do not expose it through a reverse proxy.

SQLite optimistic revisions stop stale edits. A profile lock prevents duplicate
processes; repeat launch reuses the session. A restart rotates the token. Atomic
file replacement protects export writes. Export archives are immutable per edition;
retrying the latest identical approved body reuses its archive. Private source
is plaintext, not encrypted; OS account protections and backups are necessary.

## Module map

- folio/core.py: bounded model, imports, public projection, review hashes, exports.
- folio/braid.py: loopback-only, fixed read-view adapter.
- folio/store.py: local drafts, concurrency, approval, immutable export storage.
- folio/server.py: private HTTP API and static assets.
- folio/static/: human editing interface. No framework, CDN, font download, analytics.
- start_folio.py: private profile, process lock, launch, reopen, quit.
- runtime_launch.sh and Start Folio.*: interpreter discovery, no installer.

The optional Mac bundle duplicates the same runtime source for movability. Release
verification checks these copies byte-for-byte. It is a shell launcher around the
browser app, not compiled native UI or an embedded interpreter.

## Next stages, not promises

First qualify the import/edit/export loop on the founder's actual Mac. Then refine
editorial UX and the published format with real examples. Hosting, rings, reader
continuations, and nonpurchasable contribution credits remain separate services.
A question or observation in a local edition is not yet a public investigation
request; there are no fabricated balances, paid boosts, or self-serve advertisements.
