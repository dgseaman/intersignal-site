# First physical test: Mac, then the optional other platforms

Start with non-sensitive material. Native operating-system checks below have NOT
been completed in the build environment.

1. Extract the whole package; start Braid 1.9.1 normally. Start Folio.command.
   Expect a separate local browser tab, not a new view inside Braid. Record Mac OS,
   Python version printed by the launcher, browser, and Braid version.
2. In Folio, Import from Braid > Connect > choose a Channel. Import a small,
   completed conversation. Check both question and answer against Braid. No new
   note, inference run, grant, or send should be initiated in Braid by Folio.
3. Give the draft a title. Change one speaker label and edit a passage. Add a
   harmless test sentinel such as PRIVATE-TEST-NOT-FOR-EXPORT to another passage
   and exclude that passage. Inspect Private source to confirm it is separate.
4. Leave the capsule OFF. Review and approve, then export. Extract the ZIP and
   open index.html. There should be no capsule.json/context.txt. Search ALL public
   files for the excluded sentinel; it must be absent. Do not use a real secret
   as a test value.
5. Return to the draft, turn the capsule ON, select one included passage, and
   write the question and limitations. Review everything again. Export a second
   edition. Its ZIP should contain capsule.json and context.txt, with the same
   capsule content visible in index.html.
6. Import that capsule.json back into Folio. Expect a new PRIVATE draft with
   visible parent lineage, not a write to Braid. Importing a capsule does not
   trigger a stream cycle or publication.
7. Quit Folio using its own button. Braid should remain available. Relaunch Folio;
   the library and exported editions should still be there. Use a command launcher
   to reopen the browser if the optional Finder launcher is already running.
8. Optional: host only the extracted public edition folder on a test static host.
   Enter its public URL and test the X/Facebook composer. No post should be sent
   without an action in the external service. Hosting and live social sign-in
   were not tested in this build.

Repeat 1-7 with Start Folio.cmd on Windows and sh "Start Folio.sh" on Linux when
convenient. Each machine has its own independent Folio library.

Useful failure report: exact action, visible message, OS/browser/Python/Braid
versions, whether the problem occurs with the built-in synthetic example, and
whether the capsule was enabled. A cropped screenshot is helpful. Do not send the
private SQLite database, profile/session.json, a launch URL fragment, or an
unreviewed conversation.
