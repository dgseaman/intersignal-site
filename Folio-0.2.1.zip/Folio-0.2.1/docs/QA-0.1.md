# Folio 0.1.0 - executed verification and remaining limits

Build date: 2026-09-21 UTC (2026-09-20 in South Florida).
Status: working local-first test build, not production platform certification.

## Completed checks

| Group | Result | What actually ran |
| --- | --- | --- |
| Unit, storage, adapter, security, HTTP suite | **77 tests passed** | Linux CPython 3.13.5; Python unittest; actual local Folio HTTP where applicable |
| Original Braid 1.9.1 integration | **15 checks passed** | Real unmodified MessengerService and HTTP handlers on loopback; synthetic stored conversations/notes; no inference |
| Production browser UI | **38 checks passed**, no unhandled JS errors | System Chromium rendering shipped HTML/CSS/JS, test bridge to real Folio HTTP; method limitation below |
| Launch/reopen/stop/persistence | **12 checks passed** | Actual Linux processes, isolated profiles, duplicate launch, restart and token rotation; POSIX Mac entry point exercised on Linux |
| Original Braid source preservation | **171 source files compared; 0 changed** | Byte comparison with every entry of the original nested source archive after integration testing |
| Syntax and packaging checks | Passed | node --check; Python AST/compilation through executed tests; POSIX sh -n; plist parsing; Mac bundle runtime probe on Linux |

No total is presented that conflates unittest test cases, browser assertions,
subtests, or manual observations. Machine-readable results and logs are under
verification/. Re-run from the final extracted package using the commands below.

## Specific properties exercised

Public projection omits private originals, excluded text, disabled capsules,
credentials, and Braid source IDs. The capsule references only included passages.
Original text cannot be overwritten through the public editor. Review binds to
the public-body digest; stale/unchecked approval and export attempts fail. Imports
validate hashes and normalize content to fresh private drafts. Edition retries
are idempotent. Source markup is escaped and script-free. File/draft limits,
duplicate JSON keys, nonfinite values, and nesting limits are enforced.

Storage tests include stale-update refusal, persistent reload, export versioning,
deletion of internal copies, path traversal rejection, and private Unix modes.
HTTP tests exercise token, Host, Origin, cross-site, content type, missing route,
and invalid JSON behavior. Braid operation allowlisting, URL restrictions, and
failed-reconnect clearing are tested. Braid's listener remained off and fixture
Channel/note/turn/object counts and Channel policy were unchanged by the adapter.

Browser checks cover importing text/JSON, editing/excluding passages, private
original inspection, capsule selection, rendered review, approval gating, actual
ZIP download through the bridge, public sentinel exclusion, clipboard fixture,
explicit social URL construction, local/session-URL rejection, approval
invalidation, edition/capsule reimport, and two-window optimistic conflict behavior.
Layouts at 1440, 1280, 1024, 800, and 390 pixels were captured; width overflow checks
passed at the latter four. Welcome, compose, capsule, review, and narrow layouts
were visually inspected. This is not a full accessibility audit.

## Browser method limitation

This environment blocks Chromium navigation to local HTTP URLs with
ERR_BLOCKED_BY_ADMINISTRATOR. The tests therefore render the original document
with test-only asset inlining and use an exposed transport bridge for window.fetch
to send real urllib HTTP requests to the actual Folio server. Session storage and
clipboard use explicit fixtures; social window.open is captured rather than sent
to external services. These transformations exist only in tests/browser_check.py,
not in the shipped application.

Actual HTTP and persistence checks are separate from this rendering method.
This is **not** certification of the complete native browser-to-server path,
OS clipboard, Safari behavior, Gatekeeper, or an actual X/Facebook posting session.

## Native platform and runtime limits

Only Linux CPython 3.13.5 was used to execute the app. The Mac command launcher and
optional bundle shell entry point were exercised as POSIX programs on Linux;
Finder, Apple Silicon/Intel hardware, native Safari, Gatekeeper, Windows cmd.exe,
Windows ACLs, and physical Windows execution were not run. The artifact is a
source-backed local application with launchers, not a bundled native runtime,
DMG, signed/notarized Mac binary, or Windows EXE/MSI.

Python 3.10+ with sqlite3/ssl is required. Other supported versions and browser
engines still need physical testing. No software installation or internet access
is needed once an appropriate runtime/browser is already installed. Folio can
reuse the interpreter used by Braid, but does not require importing Braid's
installed Python package to run.

## Scope not tested or implemented

No production profile, real user data, private keys, production relay, WAN peer,
model weights/inference, public hosting, live social posting, payment, credit
balance, account service, community ring, or public ranking was touched. No
full Braid regression suite is claimed for this release: Braid was not modified;
the dedicated compatibility fixture was run. Versions 1.8.x and 1.9.x pass the
adapter's compatibility gate, but only exact 1.9.1 was exercised here.

The scanner is literal-pattern assistance, not guaranteed anonymization. No
external security/privacy audit, signed identity, secure erasure, backup encryption,
or resistance to a compromised OS account is claimed. Context notices do not
make a downstream model immune to prompt injection. The app does not invoke a
model or automatically import context into Braid.

## Corrections during development

The first JSON-depth case showed that relying on interpreter recursion behavior
was insufficient. An explicit 64-level scan was added; the retained tests now
pass. A JavaScript closing-parenthesis syntax error in a Braid-view callback was
fixed before the final browser run. The initial browser harness timed out while
selecting the wrong draft for the two-window conflict check. The test now uses
the active draft's exact identifier; no concurrency safeguard was removed. The
initial timeout log is retained. Public import roundtrips now preserve opening
and closing notes and existing edited labels. Public URL sharing was tightened
for local aliases and accidentally pasted Folio session tokens. These fixes are
in the shipped source, not hidden test overrides.

## Reproduce

From the extracted Folio folder, with an existing Python runtime:

```
python3 verify_release.py
python3 -m unittest discover -s tests -v
python3 tests/launcher_check.py launcher-local.json
```

The launcher check uses POSIX paths and is a Linux/macOS development harness,
not a Windows cmd.exe harness. Windows users can run the standard unit tests;
Unix permission expectations in one case do not certify Windows ACL behavior.

Optional browser test (requires separately installed Playwright and Chromium;
not dependencies of the application):

```
python3 tests/browser_check.py browser-local
```

The default test browser executable is /usr/bin/chromium. Adjust the test harness
for another installed browser if needed; do not change production code to satisfy
it. Browser navigation limitations above apply to this build's executed evidence.

Optional Braid compatibility fixture, using the separate original 1.9.1 source
and its existing development dependencies:

```
python3 tests/check_braid191.py /path/to/Braid-Archangel-1.9.1-source braid-local.json
```

This test creates a temporary synthetic Braid profile. It never discovers or uses
the user's normal Braid profile. Do not point it at a live profile path. The path
argument is to the original SOURCE directory, not a data directory.

Original full Braid ZIP SHA-256:
`a13da581eec0a62700429ba7c76ab8cc84fbbea6fd768287d98236bb100d4a3d`

Package and publication hashes establish internal consistency, not authenticity.
