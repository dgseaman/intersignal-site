# Folio portable publication format / draft specification

Product version: 0.2.1. Wire format identifiers remain v1. These are proposed
Folio identifiers, not Braid protocol versions or an established public standard.

## Edition package

A publication ZIP has fixed names: index.html, publication.md, edition.json,
README.txt, SHA256SUMS.txt; plus capsule.json and context.txt ONLY when enabled.
The whole folder can be hosted as a static publication, or index.html read locally.
No JavaScript, external fonts, trackers, private originals, or runtime session
metadata are exported. SHA256SUMS.txt lists every OTHER file in the edition.

edition.json:

```json
{
  "format": "intersignal.folio.edition.v1",
  "edition_id": "32 lowercase hexadecimal characters",
  "edition_number": 1,
  "published_at": "UTC ISO-8601 timestamp of local export, not public hosting",
  "content_sha256": "SHA-256 of canonical body",
  "body": {
    "title": "Public title",
    "subtitle": "Optional public subtitle",
    "author": "Publisher's chosen public byline, or blank",
    "kind": "conversation",
    "introduction": "",
    "passages": [],
    "conclusion": "",
    "sources": ""
  }
}
```

kind is conversation, essay, question, or observation. A passage has id (a fresh
Folio-local 32-character hex identity), role (human/ai/note), speaker, text, and
edited (boolean). An imported edited passage remains labeled edited when reused.
The role/byline are publisher claims, not authenticated identity. Omitted passages
and original source text are absent. A public passage ID is not a Braid thread,
Channel, or model-internal ID.

Recurring dispatches may include `body.stream` with a Folio-generated stable
stream `id` and a publisher-selected public `name`. This optional field is
included in the content hash. Legacy editions without it remain valid. Importing
an edition does not subscribe to or grant access to its stream.

Optional body.continuation_of has title and content_sha256. It declares lineage;
it is not a verified author signature or backlink notification. No remote lookup
is performed.

Optional body.capsule has format="intersignal.folio.context.v1", a trust notice,
background, question, observations, attempted, constraints, uncertainty (strings),
and passages [{id,speaker,text}]. Each capsule passage refers to an INCLUDED public
passage with matching reviewed text. Every capsule field is also shown in the HTML.
This object is absent when the capsule is off, not merely hidden from the page.

## Standalone capsule

capsule.json carries format="intersignal.folio.capsule.v1", title,
parent_content_sha256, context (the public body.capsule), sources, and
capsule_sha256. Its digest covers the full object EXCEPT capsule_sha256.
context.txt is a readable version suitable for deliberate copying, with an
untrusted-reference notice. Neither representation has instruction authority,
permission to access tools, proof of truth, or a Braid field-write operation.

## Integrity rules

The reference canonicalization for this draft is:

```python
json.dumps(value, ensure_ascii=False, sort_keys=True,
           separators=(',', ':'), allow_nan=False).encode('utf-8')
```

Hash with SHA-256; use lowercase hexadecimal. No Unicode normalization is added.
The exported public body uses strings, booleans, lists, and objects, not floating
point quantities. Integers in outer edition metadata are not in its body digest.
This draft does NOT claim RFC 8785 canonicalization or author signatures. Independent
implementations should use the included fixture to test exact byte compatibility.

The content hash excludes outer edition timestamps/number/identity. The capsule
hash and archive file manifest cover their respective structures/files. An attacker
can change content and recompute unsigned hashes; they check consistency, not
publisher authenticity. An earlier public version remains public even after a
local correction or deletion. The app never promises revocation of distributed
capsules.

## Import semantics

Import edition.json or capsule.json, not an arbitrary ZIP. Verify the included
hash first, normalize accepted visible fields into new private passages, preserve
public sources and parent reference, and require a new review before export.
Capsules are OFF for the resulting new draft. Nothing is imported into Braid's
field automatically. Unknown metadata is not treated as executable instructions.

Also accepted: UTF-8 text/Markdown (literal), an array of plain-text messages or
{"messages":[{"role":"user","content":"..."}]}, and the exact Braid chat-view
turn shape. System/tool messages become note passages, never privileged roles.
Nested multimodal provider archives are not supported by this first importer.

4 MiB input/document limit; JSON nesting at most 64; no duplicate keys or nonfinite
numbers; at most 400 passages and 80,000 bytes per general text field. Most work
should be edited down well before reaching those bounds.

## Roadmap compatibility

The current edition does not contain credit balances, paid priority, anonymous
vector data, ring membership, or server-issued identities. Future circulation
services should refer to editions without retroactively changing their approved
content. Do not treat this prototype as a finalized public protocol commitment.
