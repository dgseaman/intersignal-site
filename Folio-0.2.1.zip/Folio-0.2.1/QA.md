# Folio 0.2.1 verification

## Checks completed for this iteration

- 81 standard-library core, storage, dispatch, stream workflow, and stream API
  route tests passed
  with Python 3.12. The tests include legacy-draft compatibility, selected
  Braid views, first and repeated cycles, sanitation, Broadcast gates, static
  site output, delivery failure, and retry. Route tests invoked the handlers
  directly without opening a socket.
- JavaScript syntax passed `node --check` and the shipped HTML has unique IDs.
- A simulated already-running 0.2.0 session confirmed that the 0.2.1 launcher
  names the older version instead of reopening it; stopping it still works.
- The capsule browser walkthrough now switches among its six topics, checks
  saved values and the summary, and checks that switching topics does not
  revoke approval. This browser walkthrough is not runnable in this sandbox.
- The complete package, Mac launcher source copies, and its regenerated SHA-256
  manifest are checked with `verify_release.py` before delivery.

The local execution sandbox denied binding an HTTP listener to 127.0.0.1, so
the existing HTTP integration class and live browser walkthrough could not run
here. The browser's URL policy also blocked opening the local QA page. The user
supplied Mac screenshots of Folio 0.2.0 connected to Braid 1.9.1, importing a
conversation, reviewing and exporting a ZIP, and opening the exported page in
Safari. The revised 0.2.1 capsule interaction still needs a live Mac pass.
The 0.1
baseline's earlier HTTP/browser results remain in `docs/QA-0.1.md` and
`verification/`; they are historical, not 0.2 evidence.

## Physical acceptance pass

On a computer that permits local app connections, start Folio with Python 3.10+
and Braid 1.9.1. Create a Review stream with one test Channel, a note scope,
and a daily cadence. Run now; check that a private dispatch appears, the
sanitation log names replacements, the original stays in Private source, and
the public preview excludes it. Approve and export. If a static parent folder
was set, check the dedicated stream child contains only public files.

Create a second test stream in Broadcast with a harmless `#share` note, all
built-in privacy checks on, a disposable existing destination folder, and
explicit acknowledgement. Run now; check that a released edition and static
site appear without a separate review click. Try a note containing an email
address and confirm that the public output contains only its replacement.
Stop Braid and run again; the queue should show a blocked cycle. Reconnect and
retry. Finally, quit and relaunch Folio; streams and drafts should persist,
while Braid requires an explicit reconnection.

Use synthetic material for the first pass. No Braid source, keys, grants, or
protocol files should change due to Folio's reads.
