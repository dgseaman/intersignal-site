"""Exercise stream HTTP handlers without binding a restricted local socket."""
import io
import json
import tempfile
import unittest
from email.message import Message
from pathlib import Path
from types import SimpleNamespace

from folio.server import Handler
from folio.store import Store
from tests.test_stream_workflow import FakeBridge, settings


class StreamRouteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        bridge = FakeBridge('We discovered a useful change.')
        bridge.base = 'http://127.0.0.1:4040'
        bridge.channels = [{'id': 'chosen-channel', 'name': 'Chosen Channel'}]
        self.server = SimpleNamespace(store=Store(Path(self.temp.name)), bridge=bridge,
                                      token='local-test-token', server_port=54321,
                                      origin='http://127.0.0.1:54321')

    def tearDown(self):
        self.temp.cleanup()

    def call(self, path, payload=None, token='local-test-token'):
        handler = Handler.__new__(Handler)
        handler.server = self.server
        handler.path = path
        raw = json.dumps(payload).encode() if payload is not None else b''
        headers = Message()
        headers['Host'] = '127.0.0.1:54321'
        headers['X-Folio-Token'] = token
        if payload is not None:
            headers['Content-Type'] = 'application/json'
            headers['Content-Length'] = str(len(raw))
        handler.headers = headers
        handler.rfile = io.BytesIO(raw)
        handler.wfile = io.BytesIO()
        handler.send_response = lambda status: setattr(handler, 'status', status)
        handler.send_header = lambda *args: None
        handler.end_headers = lambda: None
        if payload is None:
            handler.do_GET()
        else:
            handler.do_POST()
        return handler.status, json.loads(handler.wfile.getvalue())

    def test_stream_routes_create_observe_and_queue(self):
        status, listing = self.call('/api/streams')
        self.assertEqual(status, 200)
        self.assertEqual(listing['streams'], [])
        self.assertTrue(listing['connected'])
        status, stream = self.call('/api/streams/save', {'stream': settings()})
        self.assertEqual(status, 200)
        status, run = self.call('/api/streams/run', {'id': stream['id']})
        self.assertEqual(status, 200)
        self.assertEqual(run['status'], 'review')
        status, listing = self.call('/api/streams')
        self.assertEqual(status, 200)
        self.assertEqual(listing['queue'][0]['draft_id'], run['draft_id'])
        self.assertNotIn('seen', listing['streams'][0])

    def test_stream_routes_require_session_token(self):
        status, result = self.call('/api/streams', token='wrong')
        self.assertEqual(status, 401)
        self.assertIn('error', result)


if __name__ == '__main__':
    unittest.main()
