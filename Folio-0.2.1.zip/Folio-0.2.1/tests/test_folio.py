"""Run: python -m unittest discover -s tests -v (standard library only)."""
import copy
import hashlib
import http.client
import io
import json
import os
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from urllib import request,error

from folio.core import *
from folio.store import Store
from folio.server import Server
from folio.braid import BraidBridge,validate_base,NoRedirect

class CoreTests(unittest.TestCase):
    def draft(self):
        return new_draft('A useful question',[block('human','A useful question?'),block('ai','A considered answer.'),block('note','PRIVATE-OMITTED')],{'path':'/Users/private/secret','token':'PRIVATE-TOKEN'})
    def approved(self,d=None):
        d=d or self.draft();d['approved_digest']=review_digest(d);return d
    def test_default_capsule_off(self):self.assertFalse(self.draft()['capsule']['enabled'])
    def test_default_approval_none(self):self.assertIsNone(self.draft()['approved_digest'])
    def test_hash_stable(self):self.assertEqual(digest({'a':1,'b':2}),digest({'b':2,'a':1}))
    def test_private_metadata_does_not_change_public_hash(self):
        d=self.draft();h=review_digest(d);d['private_source']['token']='OTHER';self.assertEqual(h,review_digest(d))
    def test_originals_not_exported(self):
        d=self.draft();d['blocks'][0]['original']='PRIVATE-ORIGINAL';s=json.dumps(public_body(d));self.assertNotIn('PRIVATE-ORIGINAL',s);self.assertNotIn('PRIVATE-TOKEN',s)
    def test_exclusion_removes_capsule_reference(self):
        d=self.draft();d['capsule']['passage_ids']=[d['blocks'][2]['id']];candidate=copy.deepcopy(d);candidate['blocks'][2]['include']=False
        v=validate_draft(candidate,d);self.assertEqual(v['capsule']['passage_ids'],[])
    def test_excluded_text_never_in_export(self):
        d=self.draft();d['blocks'][2]['include']=False;d['capsule']['enabled']=True;d['capsule']['question']='What next?';d['capsule']['passage_ids']=[d['blocks'][2]['id']]
        e=make_edition(self.approved(d),1)
        with zipfile.ZipFile(io.BytesIO(export_zip(e))) as z:
            for n in z.namelist():
                raw=z.read(n);self.assertNotIn(b'PRIVATE-OMITTED',raw,n);self.assertNotIn(b'PRIVATE-TOKEN',raw,n)
    def test_disabled_capsule_fields_never_exported(self):
        d=self.draft();d['capsule']['background']='PRIVATE-CAPSULE';raw=export_zip(make_edition(self.approved(d),1))
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            self.assertNotIn('capsule.json',z.namelist())
            for n in z.namelist():self.assertNotIn(b'PRIVATE-CAPSULE',z.read(n))
    def test_original_cannot_be_forged_by_editor(self):
        d=self.draft();incoming=copy.deepcopy(d);incoming['blocks'][0]['original']='forged'
        self.assertEqual(validate_draft(incoming,d)['blocks'][0]['original'],d['blocks'][0]['original'])
    def test_public_text_edit_flag(self):
        d=self.draft();d['blocks'][0]['text']='Edited';self.assertTrue(public_body(d)['passages'][0]['edited'])
    def test_approval_required(self):
        with self.assertRaises(ConflictError):make_edition(self.draft(),1)
    def test_approval_bound_to_exact_text(self):
        d=self.approved();d['title']='changed'
        with self.assertRaises(ConflictError):make_edition(d,1)
    def test_empty_title_rejected(self):
        d=self.draft();d['title']=''
        with self.assertRaises(ValidationError):validate_publishable(d)
    def test_empty_publication_rejected(self):
        with self.assertRaises(ValidationError):validate_publishable(new_draft('Empty'))
    def test_empty_enabled_capsule_rejected(self):
        d=self.draft();d['capsule']['enabled']=True
        with self.assertRaises(ValidationError):validate_publishable(d)
    def test_html_escapes_untrusted_markup(self):
        d=self.draft();d['title']='</title><script>alert(1)</script>';d['blocks'][0]['text']='<img src="https://evil.invalid/pixel" onerror="alert(1)">'
        h=render_html(make_edition(self.approved(d),1));self.assertNotIn('<script>',h);self.assertNotIn('<img',h);self.assertIn('&lt;img',h)
    def test_export_has_no_script_or_remote_assets(self):
        h=render_html(make_edition(self.approved(),1));self.assertNotIn('<script',h);self.assertNotIn('<link',h);self.assertNotIn('<iframe',h)
    def test_md_escape_html_and_markdown_links(self):
        d=self.draft();d['introduction']='<script>x</script> [click](javascript:alert(1))'
        m=markdown(make_edition(self.approved(d),1));self.assertNotIn('<script>',m);self.assertIn('\\[click\\]',m)
    def test_archive_members_are_fixed_and_relative(self):
        with zipfile.ZipFile(io.BytesIO(export_zip(make_edition(self.approved(),1)))) as z:
            self.assertEqual(set(z.namelist()),{'index.html','publication.md','edition.json','README.txt','SHA256SUMS.txt'})
    def test_archive_hashes(self):
        with zipfile.ZipFile(io.BytesIO(export_zip(make_edition(self.approved(),1)))) as z:
            for line in z.read('SHA256SUMS.txt').decode().splitlines():
                sha,name=line.split('  ');self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(),sha)
    def test_archive_same_edition_is_reproducible(self):
        e=make_edition(self.approved(),1);self.assertEqual(export_zip(e),export_zip(e))
    def test_context_in_export_page_and_capsule(self):
        d=self.draft();d['capsule']['enabled']=True;d['capsule']['background']='Reviewable background';d['capsule']['passage_ids']=[d['blocks'][0]['id']]
        e=make_edition(self.approved(d),1);self.assertIn('Reviewable background',render_html(e));self.assertIn('A useful question?',context_text(e))
    def test_roundtrip_edition_is_unapproved_and_has_parent(self):
        e=make_edition(self.approved(),1);d=import_document(json.dumps(e),'edition.json');self.assertIsNone(d['approved_digest']);self.assertEqual(d['parent']['content_sha256'],e['content_sha256'])
    def test_roundtrip_preserves_intro_conclusion_and_edit_status(self):
        d=self.draft();d['introduction']='intro';d['conclusion']='conclusion';d['blocks'][0]['text']='EDITED';e=make_edition(self.approved(d),1)
        new=import_document(json.dumps(e),'edition.json');self.assertIn('intro',[b['text'] for b in new['blocks']]);self.assertIn('conclusion',[b['text'] for b in new['blocks']]);self.assertTrue(new['blocks'][1]['source_edited'])
    def test_tampered_edition_rejected(self):
        e=make_edition(self.approved(),1);e['body']['title']='Tampered'
        with self.assertRaises(ValidationError):import_document(json.dumps(e),'edition.json')
    def test_capsule_roundtrip_and_tamper(self):
        d=self.draft();d['capsule']['enabled']=True;d['capsule']['question']='Investigate this';e=make_edition(self.approved(d),1)
        with zipfile.ZipFile(io.BytesIO(export_zip(e))) as z:raw=z.read('capsule.json')
        new=import_document(raw,'capsule.json');self.assertFalse(new['capsule']['enabled']);self.assertIn('Investigate this',new['blocks'][0]['text'])
        obj=json.loads(raw);obj['title']='bad'
        with self.assertRaises(ValidationError):import_document(json.dumps(obj),'capsule.json')
    def test_messages_import(self):
        d=import_document('{"messages":[{"role":"user","content":"hi"},{"role":"assistant","content":"hello"}]}','x.json');self.assertEqual([b['role'] for b in d['blocks']],['human','ai'])
    def test_multimodal_message_rejected(self):
        with self.assertRaises(ValidationError):from_messages([{'role':'user','content':[{'type':'image'}]}])
    def test_unsupported_json_rejected(self):
        with self.assertRaises(ValidationError):import_document('{"unknown":1}','x.json')
    def test_text_import_literal(self):
        d=import_document('hello <script>bad</script>','x.txt');self.assertEqual(d['blocks'][0]['text'],'hello <script>bad</script>')
    def test_empty_import_rejected(self):
        with self.assertRaises(ValidationError):import_document('   ','x.txt')
    def test_import_bounds(self):
        with self.assertRaises(ValidationError):import_document('a'*(MAX_BYTES+1),'x.txt')
    def test_duplicate_json_rejected(self):
        with self.assertRaises(ValidationError):strict_json('{"a":1,"a":2}')
    def test_nonfinite_json_rejected(self):
        for raw in ['NaN','Infinity','-Infinity']:
            with self.subTest(raw=raw),self.assertRaises(ValidationError):strict_json(raw)
    def test_deep_json_rejected(self):
        with self.assertRaises(ValidationError):strict_json('['*2000+']'*2000)
    def test_controls_rejected(self):
        with self.assertRaises(ValidationError):text('abc\x00def')
    def test_unknown_kind_rejected(self):
        d=self.draft();bad=copy.deepcopy(d);bad['kind']='advertisement'
        with self.assertRaises(ValidationError):validate_draft(bad,d)
    def test_duplicate_passage_ids_rejected(self):
        d=self.draft();bad=copy.deepcopy(d);bad['blocks'][1]['id']=bad['blocks'][0]['id']
        with self.assertRaises(ValidationError):validate_draft(bad,d)
    def test_nonboolean_include_rejected(self):
        d=self.draft();bad=copy.deepcopy(d);bad['blocks'][0]['include']='false'
        with self.assertRaises(ValidationError):validate_draft(bad,d)
    def test_unknown_capsule_reference_rejected(self):
        d=self.draft();bad=copy.deepcopy(d);bad['capsule']['passage_ids']=['not-here']
        with self.assertRaises(ValidationError):validate_draft(bad,d)
    def test_privacy_scan_detects_public_patterns(self):
        d=self.draft();d['introduction']='alice@example.test /Users/alice/file 192.168.1.2 token=SECRET 954-555-1234';self.assertEqual(len(privacy_scan(d)),5)
    def test_privacy_scan_ignores_private_originals(self):
        d=self.draft();d['private_source']['secret']='alice@example.test';self.assertEqual(privacy_scan(d),[])
    def test_braid_completed_only(self):
        d=from_braid_thread({'title':'Actual shape','turns':[{'state':'done','question':'Q','payload':{'result':{'response':'A','supplied_notes':[{'text':'PRIVATE'}]}}},{'state':'error','question':'BAD','payload':{}}]})
        self.assertEqual(len(d['blocks']),2);self.assertNotIn('PRIVATE',json.dumps(d));self.assertEqual(d['private_source']['omitted_incomplete_turns'],1)
    def test_braid_no_completed_turns_rejected(self):
        with self.assertRaises(ValidationError):from_braid_thread({'turns':[]})
    def test_loopback_strict(self):
        self.assertEqual(validate_base('http://127.0.0.1:8745/'),'http://127.0.0.1:8745')
        for x in ['https://127.0.0.1:8745','http://localhost:8745','http://evil.invalid:8745','http://127.0.0.1:80','http://u:p@127.0.0.1:8745','http://127.0.0.1:8745/path','http://127.0.0.1:8745?x=1','http://127.0.0.1:8745/#token']:
            with self.subTest(url=x),self.assertRaises(ValidationError):validate_base(x)
    def test_braid_mutations_not_allowed_by_adapter(self):
        b=BraidBridge()
        for route,action in [('/api/messenger/chat','turn'),('/api/messenger/chat','new'),('/api/messenger/channel','publish'),('/api/messenger/channel','note'),('/api/messenger/channel','update')]:
            with self.subTest(action=action),self.assertRaises(ValidationError):b._read('http://127.0.0.1:8745',route,{'action':action})
    def test_braid_get_allowlist(self):
        with self.assertRaises(ValidationError):BraidBridge()._read('http://127.0.0.1:8745','/api/messenger/shutdown')
    def test_braid_bad_reconnect_clears_old_connection(self):
        b=BraidBridge();b.base='http://127.0.0.1:9000';b.csrf='old'
        with self.assertRaises(ValidationError):b.connect('http://evil.invalid:9000')
        self.assertIsNone(b.base);self.assertIsNone(b.csrf)
    def test_braid_redirect_denied(self):
        with self.assertRaises(ValidationError):NoRedirect().redirect_request(None,None,302,'',{},'http://evil.invalid')

class StoreTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.s=Store(Path(self.tmp.name)/'folio');self.d=self.s.insert(new_draft('Storage test',[block('note','Keep this')]))
    def tearDown(self):self.tmp.cleanup()
    def test_persistence(self):self.assertEqual(Store(self.s.home).get(self.d['id']),self.d)
    def test_save_revision(self):self.assertEqual(self.s.save(self.d['id'],self.d)['revision'],2)
    def test_stale_revision_conflict(self):
        self.s.save(self.d['id'],self.d)
        with self.assertRaises(ConflictError):self.s.save(self.d['id'],self.d)
    def test_approve_requires_confirm(self):
        with self.assertRaises(ValidationError):self.s.approve(self.d['id'],review_digest(self.d),False)
    def test_stale_preview_conflict(self):
        with self.assertRaises(ConflictError):self.s.approve(self.d['id'],'0'*64,True)
    def test_edit_invalidates_approval(self):
        d=self.s.approve(self.d['id'],review_digest(self.d),True);d['title']='new title';d=self.s.save(d['id'],d);self.assertIsNone(d['approved_digest'])
        with self.assertRaises(ConflictError):self.s.export(d['id'])
    def test_export_idempotency(self):
        self.s.approve(self.d['id'],review_digest(self.d),True);a=self.s.export(self.d['id']);b=self.s.export(self.d['id']);self.assertEqual(a,b);self.assertEqual(len(self.s.get(self.d['id'])['editions']),1)
    def test_new_edition_after_edit(self):
        self.s.approve(self.d['id'],review_digest(self.d),True);a=self.s.export(self.d['id']);d=self.s.get(self.d['id']);d['title']='Changed';d=self.s.save(d['id'],d);self.s.approve(d['id'],review_digest(d),True);b=self.s.export(d['id']);self.assertEqual(b['edition_number'],2);self.assertNotEqual(a['content_sha256'],b['content_sha256']);self.assertTrue(self.s.download(a['id'])[1])
    def test_delete_cleans_internal_exports(self):
        self.s.approve(self.d['id'],review_digest(self.d),True);e=self.s.export(self.d['id']);d=self.s.get(self.d['id']);self.s.delete(d['id'],d['revision']);self.assertEqual(self.s.list(),[]);self.assertFalse((self.s.exports/(e['id']+'.zip')).exists())
    def test_stale_delete_denied(self):
        with self.assertRaises(ConflictError):self.s.delete(self.d['id'],0)
    def test_download_traversal_denied(self):
        with self.assertRaises(ValidationError):self.s.download('../../secret')
    @unittest.skipIf(os.name=='nt','POSIX permissions only')
    def test_private_permissions(self):self.assertEqual(self.s.dbfile.stat().st_mode&0o777,0o600);self.assertEqual(self.s.home.stat().st_mode&0o777,0o700)

class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.s=Server(Path(cls.tmp.name));cls.t=threading.Thread(target=cls.s.serve_forever,daemon=True);cls.t.start()
    @classmethod
    def tearDownClass(cls):cls.s.shutdown();cls.s.server_close();cls.t.join(3);cls.tmp.cleanup()
    def req(self,path='/api/state',data=None,token=True,headers=None,raw=False):
        conn=http.client.HTTPConnection('127.0.0.1',self.s.server_port,timeout=5);h={'Content-Type':'application/json'}
        if token:h['X-Folio-Token']=self.s.token
        h.update(headers or {});body=data if raw else json.dumps(data).encode() if data is not None else None
        conn.request('POST' if data is not None else 'GET',path,body,h);r=conn.getresponse();out=(r.status,r.read(),dict(r.headers));conn.close();return out
    def test_state_auth(self):self.assertEqual(self.req()[0],200);self.assertEqual(self.req(token=False)[0],401)
    def test_bad_token(self):self.assertEqual(self.req(headers={'X-Folio-Token':'bad'})[0],401)
    def test_bad_host(self):self.assertEqual(self.req(headers={'Host':'evil.invalid'})[0],403)
    def test_cross_origin(self):self.assertEqual(self.req(headers={'Origin':'https://evil.invalid'})[0],403)
    def test_fetch_site(self):self.assertEqual(self.req(headers={'Sec-Fetch-Site':'cross-site'})[0],403)
    def test_no_cors(self):self.assertNotIn('Access-Control-Allow-Origin',self.req()[2])
    def test_security_headers(self):
        h=self.req()[2];self.assertEqual(h['X-Frame-Options'],'DENY');self.assertEqual(h['X-Content-Type-Options'],'nosniff');self.assertIn("script-src 'self'",h['Content-Security-Policy'])
    def test_static_assets(self):
        for p in ['/','/app.js','/style.css']:
            with self.subTest(path=p):self.assertEqual(self.req(p,token=False)[0],200)
    def test_path_traversal(self):self.assertEqual(self.req('/../../folio/core.py')[0],404)
    def test_unknown_operation(self):self.assertEqual(self.req('/api/write-braid',{})[0],404)
    def test_bad_json(self):self.assertEqual(self.req('/api/new',b'{',raw=True)[0],400)
    def test_duplicate_keys(self):self.assertEqual(self.req('/api/new',b'{"a":1,"a":2}',raw=True)[0],400)
    def test_bad_content_type(self):self.assertEqual(self.req('/api/new',{},headers={'Content-Type':'text/plain'})[0],400)
    def test_new_export_requires_review(self):
        d=json.loads(self.req('/api/sample',{})[1]);self.assertEqual(self.req('/api/export',{'id':d['id']})[0],409)
    def test_full_http_publish_lifecycle(self):
        d=json.loads(self.req('/api/sample',{})[1]);p=json.loads(self.req('/api/preview',{'id':d['id']})[1]);self.assertIn('public_json',p)
        self.assertEqual(self.req('/api/approve',{'id':d['id'],'digest':p['digest'],'confirmed':True})[0],200)
        e=json.loads(self.req('/api/export',{'id':d['id']})[1]);r=self.req('/api/download?id='+e['id']);self.assertEqual(r[0],200);self.assertTrue(r[1].startswith(b'PK'))
    def test_session_token_never_in_state_or_page(self):
        self.assertNotIn(self.s.token.encode(),self.req()[1]);self.assertNotIn(self.s.token.encode(),self.req('/')[1])

if __name__=='__main__':unittest.main()
