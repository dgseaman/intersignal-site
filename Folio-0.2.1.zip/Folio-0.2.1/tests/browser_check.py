"""Production UI in offline Chromium, bridged to real local Folio HTTP.
The environment blocks Chromium navigation to loopback. Only the test harness
inlines assets and substitutes fetch/sessionStorage/clipboard. The shipped app
is unchanged. This is not a native browser-to-server integration certification.
Requires Playwright and Chromium; not needed to run Folio itself.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import base64,json,tempfile,threading,io,zipfile
from urllib import request,error
from playwright.sync_api import sync_playwright
from folio.server import Server,STATIC

out=Path(sys.argv[1] if len(sys.argv)>1 else 'browser-results');out.mkdir(parents=True,exist_ok=True)
checks=[];js_errors=[]
def check(name,value):
    if not value:raise AssertionError(name)
    checks.append({'name':name,'passed':True});print('PASS '+name,flush=True)

with tempfile.TemporaryDirectory() as temp:
    server=Server(Path(temp)/'profile');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    opener=request.build_opener(request.ProxyHandler({}))
    def pyfetch(route,opts):
        assert route.startswith('/api/'),'Test transport only handles local API calls'
        req=request.Request(server.origin+route,data=opts.get('body','').encode() if opts.get('method')=='POST' else None,headers=opts.get('headers',{}),method=opts.get('method','GET'))
        try:r=opener.open(req,timeout=15)
        except error.HTTPError as e:r=e
        with r:return {'status':r.status,'headers':dict(r.headers),'body':base64.b64encode(r.read()).decode()}
    html=(STATIC/'index.html').read_text().replace('<link rel="stylesheet" href="/style.css">','<style>'+(STATIC/'style.css').read_text()+'</style>').replace('<script src="/app.js" defer></script>','')
    js=(STATIC/'app.js').read_text()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':1440,'height':1000},accept_downloads=True);context.set_default_timeout(8000)
        def make_page():
            page=context.new_page();page.on('pageerror',lambda e:js_errors.append(str(e)));page.on('dialog',lambda d:d.accept())
            page.expose_function('pyfetch',pyfetch);page.set_content(html)
            page.evaluate('''token => {
              const values={'folio-token':token};Object.defineProperty(window,'sessionStorage',{value:{getItem:k=>values[k]??null,setItem:(k,v)=>values[k]=v}});
              window.fetch=async(route,opts={})=>{const r=await window.pyfetch(route,opts);const bytes=Uint8Array.from(atob(r.body),c=>c.charCodeAt(0));return new Response(bytes,{status:r.status,headers:r.headers});};
              Object.defineProperty(navigator,'clipboard',{value:{writeText:async text=>window.copiedText=text}});
              if(!crypto.randomUUID)crypto.randomUUID=()=>Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b=>b.toString(16).padStart(2,'0')).join('');
              window.open=(url)=>{window.openedURL=url;return null;};
            }''',server.token)
            page.add_script_tag(content=js);page.wait_for_timeout(200);return page
        def saved(page):page.wait_for_function("document.getElementById('save-state').textContent==='Saved on this computer'")
        try:
            page=make_page()
            check('Welcome visible',page.locator('#welcome').is_visible())
            check('Initial library empty',page.locator('#count').inner_text()=='0')
            page.screenshot(path=str(out/'01-welcome.png'),full_page=True)
            page.locator('#sample').click();page.locator('#f-title').wait_for();saved(page)
            check('Sample clearly marked synthetic','synthetic' in page.locator('#f-subtitle').input_value())
            page.locator('#import-open').click()
            raw=json.dumps({'messages':[{'role':'user','content':'PRIVATE_ORIGINAL alice@example.test 192.168.2.3 <script>alert(7)</script>'},{'role':'assistant','content':'A context capsule can make a useful conversation easier to continue.'},{'role':'note','content':'EXCLUDED_PRIVATE_SENTINEL'}]})
            page.locator('#paste-input').fill(raw);page.locator('#paste-import').click();page.locator('#import-dialog').wait_for(state='hidden');saved(page)
            check('Imported three passages',page.locator('.passage-card').count()==3)
            page.locator('#f-title').fill('A starting point, not a transcript')
            page.locator('#f-subtitle').fill('A deliberately edited conversation, with context the reader can choose to carry.')
            page.locator('#f-author').fill('An independent publisher')
            page.locator('#f-introduction').fill('The worthwhile part of a conversation is sometimes the question it leaves open. This edition gives the next reader a place to begin.')
            saved(page)
            page.locator('[data-view="review"]').click();page.locator('#preview-frame').wait_for()
            check('Privacy flags displayed for public content',page.locator('.finding').count()>=2)
            page.locator('[data-view="compose"]').click();page.locator('[data-text]').first.fill('What should a reader be able to take from a useful conversation?')
            page.locator('[data-include]').nth(2).uncheck();saved(page)
            check('Excluded passage is visually marked',page.locator('.passage-card.excluded').count()==1)
            page.locator('#source').click();check('Private original still available','PRIVATE_ORIGINAL' in page.locator('#source-contents').inner_text());page.locator('#source-dialog .close').click()
            page.screenshot(path=str(out/'02-compose.png'),full_page=True)
            page.locator('[data-view="capsule"]').click();page.locator('#capsule-enabled').check()
            check('Only one context input is shown',page.locator('[data-capsule]').count()==1)
            page.locator('#capsule-text').fill('The publisher is exploring how human-edited work can become a useful starting point for another reader.')
            page.locator('#capsule-field').select_option('question')
            page.locator('#capsule-text').fill('Does portable context improve the quality of a reader\'s next contribution?')
            page.locator('#capsule-field').select_option('uncertainty')
            page.locator('#capsule-text').fill('This is a design hypothesis. No usage study has been conducted.')
            check('Three context topics summarized','3 of 6 added' in page.locator('#capsule-count').inner_text())
            page.locator('#capsule-field').select_option('background')
            check('Switching topics preserves context','The publisher is exploring' in page.locator('#capsule-text').input_value())
            page.locator('[data-capsule-passage]').nth(1).check();saved(page)
            check('Only included passages selectable for capsule',page.locator('[data-capsule-passage]').count()==2)
            page.screenshot(path=str(out/'03-capsule.png'),full_page=True)
            page.locator('[data-view="review"]').click();page.locator('#preview-frame').wait_for()
            check('Export disabled before approval',page.locator('#export').is_disabled())
            check('No leaked excluded text in preview','EXCLUDED_PRIVATE_SENTINEL' not in page.locator('#editor').inner_text())
            check('Redacted original not in public JSON','PRIVATE_ORIGINAL' not in page.locator('.review-json').first.inner_text())
            frame=page.frame_locator('#preview-frame');check('Actual preview renders title',frame.locator('h1').inner_text()=='A starting point, not a transcript')
            check('Capsule appears in rendered page','Continue the investigation' in frame.locator('body').inner_text())
            check('No imported scripts executed',page.evaluate('typeof window.attackRan')=='undefined')
            page.screenshot(path=str(out/'04-review.png'),full_page=True)
            page.locator('#approve').click();page.wait_for_timeout(200)
            check('Unchecked review blocks approval',page.locator('#error').is_visible() and page.locator('#export').is_disabled())
            page.locator('#review-confirm').check();page.locator('#approve').click();page.locator('#export').wait_for();page.wait_for_function("!document.getElementById('export').disabled")
            check('Approval enables export',page.locator('#export').is_enabled())
            page.locator('[data-view="capsule"]').click();page.locator('#capsule-field').select_option('question')
            page.locator('[data-view="review"]').click();page.wait_for_function("!document.getElementById('export').disabled")
            check('Navigating context topics preserves approval',page.locator('#export').is_enabled())
            with page.expect_download() as download_info:page.locator('#export').click()
            download=download_info.value;export_path=out/'ui-export.zip';download.save_as(export_path);page.wait_for_timeout(250)
            with zipfile.ZipFile(export_path) as z:
                check('UI download includes capsule','capsule.json' in z.namelist());check('UI export contains no private sentinels',all(b'PRIVATE_ORIGINAL' not in z.read(n) and b'EXCLUDED_PRIVATE_SENTINEL' not in z.read(n) for n in z.namelist()))
                edition=z.read('edition.json');capsule=z.read('capsule.json')
            check('Export recorded as edition 1','1 exported edition' in page.locator('#edition-pill').inner_text())
            page.locator('summary').filter(has_text='Readable context capsule').click();page.locator('#copy-context').click();page.wait_for_timeout(150)
            check('Approved context copy works','A context capsule' in page.evaluate('window.copiedText'))
            page.locator('#hosted-url').fill('http://127.0.0.1:9000/');page.locator('#share-x').click();page.wait_for_timeout(120)
            check('Local address blocked from social sharing',page.locator('#error').is_visible())
            for local in ('http://127.0.0.2:9000/','http://machine.local/','http://[fd00::1]/'):
                page.locator('#hosted-url').fill(local);page.locator('#share-x').click();page.wait_for_timeout(50)
                check('Reject nonpublic share target '+local,page.locator('#error').is_visible())
            page.locator('#hosted-url').fill('https://publisher.example/#session='+server.token);page.locator('#share-x').click();page.wait_for_timeout(50)
            check('Pasted current token is rejected even on a public host',page.locator('#error').is_visible())
            page.locator('#hosted-url').fill('https://publisher.example/folio/');page.locator('#share-x').click();page.wait_for_timeout(100)
            check('X composer is deliberate and contains approved URL','twitter.com/intent/tweet' in page.evaluate('window.openedURL') and 'publisher.example' in page.evaluate('window.openedURL'))
            check('Social URL has no session token',server.token not in page.evaluate('window.openedURL'))
            page.locator('[data-view="compose"]').click();page.locator('#f-title').fill('Changed after approval');saved(page);page.locator('[data-view="review"]').click();page.locator('#export').wait_for()
            check('Editing revokes export approval',page.locator('#export').is_disabled())
            page.locator('#import-open').click();page.locator('#file-input').set_input_files({'name':'edition.json','mimeType':'application/json','buffer':edition});page.locator('#import-dialog').wait_for(state='hidden');saved(page)
            check('Edition reimport shows lineage','Continuation of' in page.locator('#editor').inner_text())
            check('Edition reimport remains private',page.locator('#workspace-label').inner_text()=='PRIVATE DRAFT')
            page.locator('#import-open').click();page.locator('#file-input').set_input_files({'name':'capsule.json','mimeType':'application/json','buffer':capsule});page.locator('#import-dialog').wait_for(state='hidden');saved(page)
            check('Capsule reimport creates inspectable passages',page.locator('.passage-card').count()>=3)
            for width,height in [(1280,800),(1024,768),(800,900),(390,844)]:
                page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(100)
                check('No horizontal overflow at '+str(width),page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
                page.screenshot(path=str(out/('layout-'+str(width)+'.png')),full_page=True)
            page.set_viewport_size({'width':1440,'height':1000})
            # Real optimistic-concurrency behavior from two production UI instances.
            ident=page.locator('.library-item.active').get_attribute('data-id');page2=make_page();page2.locator('[data-id="'+ident+'"]').click();page2.locator('#f-title').wait_for()
            page.locator('#f-title').fill('Window one wins');saved(page)
            page2.locator('#f-title').fill('Window two unsaved text');page2.wait_for_function("document.getElementById('error').hidden===false")
            check('Concurrent stale save fails visibly','another window' in page2.locator('#error').inner_text())
            check('Concurrent stale text retained on screen',page2.locator('#f-title').input_value()=='Window two unsaved text')
            check('No unhandled JS errors',not js_errors)
            page2.close();page.close()
        finally:browser.close();server.shutdown();server.server_close();worker.join(3)
result={'method':__doc__,'passed':len(checks),'checks':checks,'javascript_errors':js_errors}
(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
