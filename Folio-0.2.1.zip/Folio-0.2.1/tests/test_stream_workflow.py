"""End-to-end storage boundaries for recurring streams (stdlib only)."""
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from folio.core import new_draft, block, public_body, review_digest
from folio.store import Store


class FakeBridge:
    def __init__(self, text):
        self.text = text

    def channel(self, ident):
        if ident != 'chosen-channel':
            raise AssertionError('An unselected Channel was inspected.')
        return {'notes': [{'id': 'note-one', 'kind': 'note', 'title': 'Lab update',
                           'text': self.text}], 'threads': []}

    def view(self, kind, ident):
        raise AssertionError('Conversation views were not selected.')


def settings(mode='review', tag='', redact_emails=True, rules=None, site_directory=''):
    return {'name': 'Intersignal Lab', 'mode': mode, 'cadence_hours': 24,
            'template': 'daily', 'broadcast_ack': mode == 'broadcast',
            'site_directory': site_directory,
            'scope': {'channels': ['chosen-channel'], 'notes': True,
                      'objects': False, 'conversations': False, 'tag': tag},
            'privacy': {'rules': rules or [], 'redact_emails': redact_emails,
                        'redact_phones': True, 'redact_addresses': True,
                        'redact_credentials': True, 'redact_paths': True,
                        'redact_ip': True, 'redact_financial': True}}


class StreamWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name))

    def tearDown(self):
        self.temp.cleanup()

    def test_legacy_draft_survives_new_stream_tables(self):
        draft = self.store.insert(new_draft('Legacy conversation',
                                           [block('human', 'A publishable question?')]))
        reopened = Store(Path(self.temp.name))
        self.assertEqual(reopened.get(draft['id'])['title'], 'Legacy conversation')
        self.assertEqual(reopened.streams(), [])

    def test_review_queue_is_private_and_deltas_are_not_repeated(self):
        stream = self.store.save_stream(settings(rules=[{'category': 'name',
            'find': 'Avery', 'replace': 'a colleague'}]))
        run = self.store.run_stream(stream['id'], FakeBridge('We discovered Avery fixed the failed test. Contact avery@example.test.'))
        self.assertEqual(run['status'], 'review')
        self.assertGreater(run['privacy_changes_count'], 0)
        draft = self.store.get(run['draft_id'])
        public = json.dumps(public_body(draft))
        self.assertNotIn('Avery', public)
        self.assertNotIn('avery@example.test', public)
        self.assertIn('Avery', draft['blocks'][0]['original'])
        self.assertIsNone(draft['approved_digest'])
        self.assertEqual(draft['editions'], [])
        self.assertEqual(self.store.run_stream(stream['id'], FakeBridge('We discovered Avery fixed the failed test. Contact avery@example.test.'))['status'], 'no_change')

    def test_broadcast_releases_only_when_tagged_and_scan_clear(self):
        stream = self.store.save_stream(settings(mode='broadcast', tag='share', site_directory=self.temp.name))
        run = self.store.run_stream(stream['id'], FakeBridge('#share We validated the revised measurement with avery@example.test.'))
        self.assertEqual(run['status'], 'released')
        record, archive = self.store.download(run['edition_id'])
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            raw = z.read('edition.json')
            self.assertNotIn(b'avery@example.test', raw)
            self.assertIn(b'email address removed', raw)
        _, site = self.store.stream_site(stream['id'])
        with zipfile.ZipFile(io.BytesIO(site)) as z:
            self.assertIn('index.html', z.namelist())
            self.assertTrue(any(name.endswith('/edition.json') for name in z.namelist()))
            self.assertFalse(any(b'avery@example.test' in z.read(name) for name in z.namelist()))
        public_folder = Path(self.temp.name)/('folio-stream-'+stream['id'])
        self.assertTrue((public_folder/'index.html').is_file())
        self.assertNotIn('avery@example.test', (public_folder/'index.html').read_text())

    def test_broadcast_falls_back_to_review_for_residual_private_pattern(self):
        stream = self.store.save_stream(settings(mode='broadcast', tag='share', site_directory=self.temp.name))
        with patch('folio.store.privacy_scan', return_value=[{'kind': 'Potential private detail'}]):
            run = self.store.run_stream(stream['id'], FakeBridge('#share We learned to revise the method.'))
        self.assertEqual(run['status'], 'needs_review')
        self.assertNotIn('edition_id', run)
        self.assertEqual(self.store.get(run['draft_id'])['editions'], [])

    def test_failed_static_destination_is_visible_and_retryable(self):
        site_root = Path(self.temp.name)/'site-root'
        stream = self.store.save_stream(settings(mode='broadcast', tag='share', site_directory=str(site_root)))
        run = self.store.run_stream(stream['id'], FakeBridge('#share We confirmed the change worked.'))
        self.assertEqual(run['status'], 'delivery_failed')
        self.assertIn('edition_id', run)
        site_root.mkdir()
        result = self.store.retry_stream_site(stream['id'])
        self.assertEqual(result['recovered_runs'], 1)
        self.assertEqual(self.store.runs()[0]['status'], 'released')
        self.assertTrue((site_root/('folio-stream-'+stream['id'])/'index.html').is_file())

    def test_review_export_updates_chosen_site_only_after_approval(self):
        stream = self.store.save_stream(settings(site_directory=self.temp.name))
        run = self.store.run_stream(stream['id'], FakeBridge('We discovered a useful change.'))
        folder = Path(self.temp.name)/('folio-stream-'+stream['id'])
        self.assertFalse(folder.exists())
        draft = self.store.get(run['draft_id'])
        self.store.approve(draft['id'], review_digest(draft), True)
        record = self.store.export(draft['id'])
        self.assertNotIn('site_error', record)
        self.assertEqual(self.store.runs()[0]['status'], 'released')
        self.assertTrue((folder/'index.html').is_file())


if __name__ == '__main__':
    unittest.main()
