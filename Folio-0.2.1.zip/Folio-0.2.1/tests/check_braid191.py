"""Optional integration test against real, unmodified Braid 1.9.1 source.
Usage: python tests/check_braid191.py /path/to/Braid-Archangel-1.9.1-source output.json
Uses synthetic stored conversations and notes; no model inference or user profile.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
import json, tempfile, threading, time, uuid, hashlib, os
from cryptography.hazmat.primitives.asymmetric import ed25519
from braid_client.messenger import MessengerService
from braid_client.messenger_http import MessengerHTTPServer,MessengerHandler
from folio.braid import BraidBridge
from folio.core import new_draft,public_body,block,review_digest,make_edition,export_zip

checks=[]
def check(name,value):
    if not value:raise AssertionError(name)
    checks.append({'name':name,'passed':True})

with tempfile.TemporaryDirectory() as temp:
    root=Path(temp)
    desk=MessengerService(ed25519.Ed25519PrivateKey.generate(),root/'braid'/'inbox',root/'braid')
    ch=desk.create_channel('Folio integration','Synthetic test channel')
    thread=desk.new_thread(ch['id'],'A real Braid view, synthetic content')
    nid=desk.new_note(ch['id'],'Selected source material.','A deliberate note')['id']
    with desk._db() as db:
        payload={'result':{'response':'A synthetic stored answer.','completion_model':'fixture-not-invoked','supplied_notes':[{'text':'SECRET_HIDDEN_EVIDENCE','source':'PRIVATE_SOURCE'}]},'model':'fixture'}
        db.execute('INSERT INTO c6_turns VALUES (?,?,?,?,?,?)',(uuid.uuid4().hex,thread['id'],'A synthetic stored question.','done',time.time(),json.dumps(payload)))
        db.execute('INSERT INTO c6_turns VALUES (?,?,?,?,?,?)',(uuid.uuid4().hex,thread['id'],'Never export this incomplete question.','error',time.time()+1,json.dumps({'error':'fixture interruption'})))
    before=desk.channel(ch['id'])
    counts_before={}
    with desk._db() as db:
        for table in ('c6_channels','c6_notes','c6_threads','c6_turns','c6_objects'):
            counts_before[table]=db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]
    http=MessengerHTTPServer(('127.0.0.1',0),MessengerHandler);http.messenger=desk
    worker=threading.Thread(target=http.serve_forever,daemon=True);worker.start()
    try:
        bridge=BraidBridge();connected=bridge.connect('http://127.0.0.1:'+str(http.server_port))
        check('Actual Braid version 1.9.1',connected['version']=='1.9.1')
        check('Channel name returned',connected['channels'][0]['name']=='Folio integration')
        check('Full state and CSRF stripped',not any(k in connected for k in ('csrf','peers','inbox_path','settings','fingerprint')))
        v=bridge.channel(ch['id']);check('Actual channel view includes thread',any(t['id']==thread['id'] for t in v['threads']))
        check('Actual channel view includes note',any(n['id']==nid for n in v['notes']))
        d=bridge.import_thread(thread['id'])
        check('Completed question and answer normalized',len(d['blocks'])==2 and d['blocks'][1]['text']=='A synthetic stored answer.')
        check('Incomplete exchange excluded',d['private_source']['omitted_incomplete_turns']==1)
        check('Hidden supplied atoms not copied', 'SECRET_HIDDEN_EVIDENCE' not in json.dumps(d))
        check('Source IDs and model metadata not made public',all(x not in json.dumps(public_body(d)) for x in (thread['id'],ch['id'],'fixture-not-invoked')))
        n=bridge.import_note(ch['id'],nid,'note');check('Selected material imports literally',n['blocks'][0]['text']=='Selected source material.')
        check('Braid policy unchanged',desk.channel(ch['id'])==before)
        with desk._db() as db:
            after={table:db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in counts_before}
        check('No Channel/turn/note/object rows added by adapter',after==counts_before)
        check('No listener started',desk.listener is None)
        d['capsule']['enabled']=True;d['capsule']['passage_ids']=[d['blocks'][1]['id']];d['approved_digest']=review_digest(d)
        import io,zipfile
        with zipfile.ZipFile(io.BytesIO(export_zip(make_edition(d,1)))) as z:
            check('Integrated export omits Braid token',all(desk.csrf.encode() not in z.read(n) for n in z.namelist()))
            check('Integrated export contains optional capsule','capsule.json' in z.namelist())
    finally:http.shutdown();http.server_close();worker.join(3);desk.close()

result={'baseline':'Braid 1.9.1 original source, unchanged','method':'Real MessengerService and HTTP handlers over loopback; synthetic persisted turns and notes; no model inference or physical Mac execution','checks':checks,'passed':len(checks)}
Path(sys.argv[2]).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
