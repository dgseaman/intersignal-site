"""Focused checks for the local recurring dispatch boundary."""
import json
import tempfile
import unittest

from folio.core import ValidationError, public_body
from folio.dispatch import collect, prepare, validate_stream


def stream(**overrides):
    value = {
        'name': 'Intersignal Lab', 'cadence_hours': 168,
        'scope': {'channels': ['allowed'], 'notes': True, 'objects': True,
                  'conversations': True, 'tag': ''},
        'privacy': {'rules': [{'category': 'Person', 'find': 'Alice',
                              'replace': 'a researcher'}]},
        'template': 'weekly',
    }
    value.update(overrides)
    return validate_stream(value)


class Bridge:
    def __init__(self, channels=None, chats=None):
        self.channels = channels or {}
        self.chats = chats or {}
        self.calls = []

    def channel(self, ident):
        self.calls.append(('channel', ident))
        if ident not in self.channels:
            raise ValueError('missing')
        return self.channels[ident]

    def view(self, kind, ident):
        self.calls.append((kind, ident))
        if kind != 'chat':
            raise AssertionError('unexpected Braid operation')
        return self.chats[ident]


class DispatchTests(unittest.TestCase):
    def test_defaults_and_stream_scope(self):
        s = stream()
        self.assertEqual(s['mode'], 'review')
        self.assertEqual(s['scope']['channels'], ['allowed'])
        self.assertEqual(s['cadence_hours'], 168)
        self.assertTrue(s['privacy']['redact_credentials'])

    def test_invalid_scope_and_cadence(self):
        for candidate in (
            {'scope': {'channels': [], 'notes': True}},
            {'scope': {'channels': ['allowed'], 'notes': False,
                       'objects': False, 'conversations': False}},
            {'cadence_hours': 0}, {'cadence_hours': True},
            {'scope': {'channels': [str(i) for i in range(9)], 'notes': True}},
        ):
            with self.subTest(candidate=candidate), self.assertRaises(ValidationError):
                stream(**candidate)

    def test_broadcast_needs_ack_and_tag(self):
        with self.assertRaises(ValidationError):
            stream(mode='broadcast')
        with self.assertRaises(ValidationError):
            stream(mode='broadcast', broadcast_ack=True)
        with self.assertRaises(ValidationError):
            stream(mode='broadcast', broadcast_ack=True,
                   scope={'channels': ['allowed'], 'notes': True,
                          'objects': False, 'conversations': False, 'tag': '#public'})
        s = stream(mode='broadcast', broadcast_ack=True,
                   site_directory=tempfile.gettempdir(),
                   scope={'channels': ['allowed'], 'notes': True,
                          'objects': False, 'conversations': False, 'tag': '#public'})
        self.assertEqual(s['scope']['tag'], 'public')
        self.assertEqual(s['site_directory'], tempfile.gettempdir())

    def test_broadcast_requires_all_built_in_redactions(self):
        scope = {'channels': ['allowed'], 'notes': True, 'objects': False,
                 'conversations': False, 'tag': '#public'}
        for switch in ('redact_emails', 'redact_phones', 'redact_addresses',
                       'redact_credentials', 'redact_paths', 'redact_ip',
                       'redact_financial'):
            with self.subTest(switch=switch), self.assertRaises(ValidationError):
                stream(mode='broadcast', broadcast_ack=True, scope=scope,
                       site_directory=tempfile.gettempdir(),
                       privacy={'rules': [], switch: False})
        self.assertEqual(stream(mode='broadcast', broadcast_ack=True,
                                site_directory=tempfile.gettempdir(),
                                scope=scope)['mode'], 'broadcast')

    def test_site_directory_must_be_native_absolute_path(self):
        self.assertEqual(stream()['site_directory'], '')
        with self.assertRaises(ValidationError):
            stream(site_directory='relative/output')
        with self.assertRaises(ValidationError):
            stream(site_directory='x' * 1025)
        self.assertEqual(stream(site_directory=tempfile.gettempdir())['site_directory'],
                         tempfile.gettempdir())

    def test_collection_is_selected_and_content_fingerprinted(self):
        view = {
            'notes': [
                {'id': 'n1', 'kind': 'note', 'title': 'A note', 'text': 'Alice decided to test this.'},
                {'id': 'o1', 'kind': 'object', 'title': 'A field item', 'text': 'Found a result.'},
            ],
            'threads': [{'id': 't1', 'title': 'Experiment'}],
        }
        chats = {'t1': {'turns': [
            {'id': 'x', 'state': 'done', 'question': 'What changed?',
             'payload': {'result': {'response': 'We changed the design.'}}},
            {'id': 'y', 'state': 'error', 'question': 'secret', 'payload': {}},
        ]}}
        b = Bridge({'allowed': view, 'not-allowed': view}, chats)
        s = stream()
        items, warnings = collect(b, s)
        self.assertEqual(len(items), 3)
        self.assertEqual(warnings, [])
        self.assertEqual(b.calls, [('channel', 'allowed'), ('chat', 't1')])
        self.assertNotIn('secret', json.dumps(items))
        original = items[0]['key']
        view['notes'][0]['text'] = 'Alice decided to test something else.'
        changed, _ = collect(b, s)
        self.assertNotEqual(changed[0]['key'], original)

    def test_tag_filter_and_source_type(self):
        b = Bridge({'allowed': {'notes': [
            {'id': 'n1', 'kind': 'note', 'title': 'Private', 'text': 'No tag.'},
            {'id': 'n2', 'kind': 'note', 'title': 'Public #dispatch', 'text': 'We learned this.'},
            {'id': 'o1', 'kind': 'object', 'title': '#dispatch', 'text': 'Do not read objects.'},
        ], 'threads': [{'id': 't1', 'title': '#dispatch'}]}})
        s = stream(scope={'channels': ['allowed'], 'notes': True, 'objects': False,
                          'conversations': False, 'tag': 'dispatch'})
        items, _ = collect(b, s)
        self.assertEqual([item['source'] for item in items], ['note'])
        self.assertEqual(b.calls, [('channel', 'allowed')])

    def test_newest_five_conversations_only(self):
        threads = [{'id': 't' + str(i), 'title': 'Conversation'} for i in range(25)]
        b = Bridge({'allowed': {'notes': [], 'threads': threads}},
                   {t['id']: {'turns': []} for t in threads})
        _, warnings = collect(b, stream())
        self.assertEqual(len([x for x in b.calls if x[0] == 'chat']), 5)
        self.assertIn('Only the newest 5 conversations', ' '.join(warnings))

    def test_all_channels_offline_blocks_cycle(self):
        with self.assertRaises(ValidationError):
            collect(Bridge(), stream())

    def test_partial_channel_failure_does_not_create_watermark(self):
        s = stream(scope={'channels': ['allowed', 'offline'], 'notes': True,
                          'objects': False, 'conversations': False, 'tag': ''})
        b = Bridge({'allowed': {'notes': [{'id': 'n1', 'kind': 'note',
                                           'title': 'Decision', 'text': 'We decided to publish.'}],
                                 'threads': []}})
        items, warnings = collect(b, s)
        draft, seen, audit = prepare(s, items, [])
        self.assertIsNotNone(draft)
        self.assertEqual(seen, [items[0]['key']])
        self.assertTrue(warnings)
        self.assertEqual(audit['new_count'], 1)

    def test_public_projection_sanitized_audit_contains_no_source_values(self):
        s = stream(name='Alice Field Notes')
        source = ('Alice decided at 123 Main Street to spend $1,200 and call '
                  '954-555-1234; contact alice@example.test; token=supersecret '
                  'at /Users/alice/private or 192.168.1.2.')
        b = Bridge({'allowed': {'notes': [{'id': 'n1', 'kind': 'note',
                                           'title': 'Alice decision', 'text': source}],
                                 'threads': []}})
        items, _ = collect(b, s)
        draft, seen, audit = prepare(s, items, [])
        public = json.dumps(public_body(draft))
        for secret in ('Alice', '123 Main Street', '$1,200', '954-555-1234',
                       'alice@example.test', 'supersecret', '/Users/alice/private',
                       '192.168.1.2'):
            with self.subTest(secret=secret):
                self.assertNotIn(secret, public)
                self.assertNotIn(secret, json.dumps(audit))
        self.assertIn('Alice', draft['blocks'][0]['original'])
        self.assertEqual(draft['stream_public_name'], 'a researcher Field Notes')
        self.assertIsNone(draft['approved_digest'])
        self.assertEqual(audit['selected_count'], 1)
        self.assertGreaterEqual(audit['sanitized_occurrences'], 8)
        self.assertEqual(seen, [items[0]['key']])

    def test_seen_prevents_repeat_and_changed_source_returns(self):
        s = stream()
        b = Bridge({'allowed': {'notes': [{'id': 'n1', 'kind': 'note',
                                           'title': 'Update', 'text': 'We learned one thing.'}],
                                 'threads': []}})
        items, _ = collect(b, s)
        draft, seen, _ = prepare(s, items, [])
        self.assertIsNotNone(draft)
        repeated, next_seen, audit = prepare(s, items, seen)
        self.assertIsNone(repeated)
        self.assertEqual(next_seen, seen)
        self.assertEqual(audit['new_count'], 0)
        b.channels['allowed']['notes'][0]['text'] = 'We learned a different thing.'
        changed, _ = collect(b, s)
        later, newer_seen, _ = prepare(s, changed, seen)
        self.assertIsNotNone(later)
        self.assertEqual(len(newer_seen), 2)


if __name__ == '__main__':
    unittest.main()
