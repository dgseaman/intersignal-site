# Folio 0.2.1
## Local publishing studio / Intersignal / private test build

A separate app for turning selected Braid conversations and recurring permitted
Channel observations into readable publications, with an optional, inspectable
context capsule. Braid's source,
protocol, identities, policies, and installed package do not need to change.

**Start on Mac:** extract the entire download, then double-click
**Start Folio.command**. A terminal and your default browser open. Leave the
terminal open until you choose **Quit Folio**. The optional **Folio.app** Finder
launcher starts the same browser-based app without a terminal; the command
launcher is the better first-test path because startup errors are visible.

This is a working local web application, not a screenshot mock-up. It is also
**not a signed/notarized native application or a bundled Python runtime**.
It needs an existing Python 3.10+ installation with standard-library sqlite3 and
ssl. It can reuse the interpreter already used by Braid. No pip dependencies,
model downloads, administrative permissions, or online installation are needed.
The user's Mac screenshots show a live Braid 1.9.1 import, review, ZIP export,
and the exported page opening in Safari. Automated Mac launcher checks have not
run here; see QA.md for the exact evidence.

### Platform entry points

| Platform | Launch |
| --- | --- |
| macOS, Apple Silicon or Intel | Start Folio.command; optional Folio.app |
| Windows | Extract first, then Start Folio.cmd |
| Linux | `sh "Start Folio.sh"` in the extracted directory |
| Any supported Python installation | `python3 -I start_folio.py` |

The runtime must match your OS/architecture. Native Mac and Windows launches
remain to be tested. The Mac app bundle contains the same source as the root
folder, so it can be moved on its own; it still requires Python. For reopening
an already-running session, use Start Folio.command, especially if Finder does
not open a new browser window. No login item, updater, or background installation
is registered.

## Your first publication

Start Braid normally. In Folio, choose **Import from Braid > Connect**. Leave the
address blank for standard-profile discovery, or enter the precise local Braid
UI address, `http://127.0.0.1:PORT`. This is the browser UI port, not a relay,
receiver, LM Studio, or Ollama port. LAN addresses and intersignal.local are not
accepted by this first adapter.

Choose a Channel, then import a conversation or a specific note/visible indexed
item. Only completed question/answer pairs are imported from conversations. The
Braid view limit is 100 turns/items per view; the importer does not silently
retrieve older history or hidden supplied context. A Channel is not a privacy
boundary. Imported text is initially INCLUDED in the private draft: review and
exclude anything you do not intend to publish.

**Compose:** edit the title, public byline, introduction, passages, speaker labels,
sources, and closing note. Exclude or reorder passages. Imported originals stay
private in Folio's own database for comparison. Exclusion does not erase them.
The types Conversation, Essay, Unanswered question, and Observation are supported.
No credits, public priority, community review, or investigation is implied by
choosing a type.

**Context capsule:** off by default. Enable it only deliberately. Choose one
topic from the dropdown and write what matters; add more topics only if useful.
Existing entries appear in a short summary and can be reopened or cleared.
Background, unanswered questions, observations, attempted approaches, scope,
and uncertainty remain separate in the exported format. Select any PUBLIC
passages you want to carry. Excluded passages
cannot be included through stale capsule selections. This is a textual reference
packet, NOT a Braid .brad packet, an embedding, instructions, or a shared-field
write. No model is invoked to summarize or anonymize your text.

**Review & export:** inspect the rendered edition, the complete public JSON, and
the readable capsule. Pattern flags are hints, not a certificate of anonymity.
Confirm that you reviewed the material and have the right to share it. Approve
that exact content, then export the ZIP. Any public content change requires a
new review. Repeating the same export retrieves the same immutable edition.

Extract the publication ZIP and open **index.html**. To publish, upload the ENTIRE
extracted publication folder to a static host you control. Folio does not
supply hosting. Never upload the application folder, profile, or SQLite database.
After hosting, open the published edition and enter that exact page URL to copy
sharing text or open an
explicit X/Facebook sharing window. No posting is automatic; these external
services require internet access and may require your sign-in. Folio cannot
verify that the URL resolves to the edition; inspect the link preview before
posting.

A reader can import the extracted **edition.json** or **capsule.json** into Folio
to start a fresh private continuation. The parent title/content hash is visible.
Importing a capsule does NOT send it to Braid or grant it authority. The reviewed
context can be copied for deliberate use in an existing model interface.

## Recurring streams

Choose **Streams** in the sidebar, connect to Braid, then create a stream. Give it
a **public stream name** and choose specific Channels, source types (notes,
indexed field material, completed conversations), an optional `#tag`, a cadence
in hours, and a dispatch format. The default is **Review queue**. Folio checks
for new or edited source content and creates a private, unapproved dispatch.
The first scheduled cycle occurs after the chosen cadence; use **Run now** for
an immediate first dispatch.
Open it from the queue to compare private originals, inspect the sanitation log,
edit the selected passages, and use the existing exact-content approval/export
flow. A cycle with no changed material creates no draft.

Privacy rules run locally before a dispatch is prepared. Built-in patterns cover
email addresses, phone numbers, street addresses, credentials, local paths, IP
addresses, and formatted financial amounts. Add literal replacement rules for
names, locations, relationships, confidential projects, or other sensitive
phrases. The private source view retains original excerpts and shows what kinds
of replacements occurred. These rules cannot identify every sensitive fact or
combination. Review the complete public page and JSON before sharing.

**Broadcast** is optional. It requires a nonempty explicit `#tag` scope, all
built-in privacy patterns enabled, a separate acknowledgement, and an existing
local destination folder. It automatically approves and exports an edition only
when no residual pattern flags remain; otherwise the draft goes to review.
It then updates a dedicated `folio-stream-<id>` child folder inside your chosen
destination with an index and released editions. Serve or sync that folder
through a static host you control to make the recurring output public. Folio
does not upload to a host or post to social services itself. A failed folder
update is visible and retryable; the local edition ZIP is retained.
**Download stream site** also produces a portable static bundle. Review mode
can use the same destination: Folio updates it only after you approve and
export the dispatch. Existing manual Folios still work as before.

Cadence runs only while the Folio process is running (the browser tab may be
closed). Braid must be running and explicitly
connected in that Folio session; Folio does not silently reconnect after a
restart. A failed observation appears as a blocked run and retries after five
minutes. **Run now** is available at any time. The Braid adapter still uses only
its existing read views and never changes Braid. A cycle observes at most the
newest five conversations per selected Channel, twenty turns per conversation,
and Braid's hundred-item note/object view. The queue warns when a view is
truncated. Dispatches are source-grounded excerpts chosen by local salience
rules, not model-written summaries or claims of exhaustive coverage.

## Data and connection boundaries

Folio binds only to numeric IPv4 loopback, using an automatically selected port.
It is not a LAN service. Data APIs require a random per-session token. The token
arrives in a local URL fragment, is removed from the address bar, and is retained
in that browser tab's session storage. Do not share a launch URL or the private
session file. A bookmark without its token will not open an authenticated session;
relaunch Folio instead. Closing the browser does not stop the process.

On explicit connection, the adapter uses Braid's existing state and read-view
operations. It never opens Braid's database directly, uses its signing keys,
changes permissions, joins peers, sends notes, runs inference, or changes the wire
protocol. It reads standard Braid session files only to find the existing port.
The Braid CSRF value stays in process memory; it is not exported or persisted.

Local Folio profiles:
- Mac: `~/Library/Application Support/Intersignal/Folio`
- Windows: `%LOCALAPPDATA%\Intersignal\Folio`
- Linux: `$XDG_DATA_HOME/intersignal/folio`, normally `~/.local/share/intersignal/folio`

The profile contains **plaintext private originals**, drafts, local exported
copies, and a private session file. Folio does not provide encryption at rest.
Unix permissions are restrictive; Windows relies on the user's profile ACLs.
Protect your account and backups. Back up the Folio profile while Folio is closed.
Deleting a draft removes its internal export copies but not files already
saved elsewhere, public copies, backups, or recoverable storage remnants.

## Troubleshooting

- **Missing Python:** use the interpreter already used by Braid. On Mac/Linux,
  `FOLIO_PYTHON="/full/path/to/python3" sh "Start Folio.command"`. On Windows,
  set `FOLIO_PYTHON` to the full python.exe path before running the launcher.
  An invalid explicit choice fails without falling back. The launchers never
  install Python or change your global environment.
- **Mac blocks an unknown developer:** this build is unsigned and not notarized.
  Inspect the included code/test report before choosing to run it. Apple's
  per-application Privacy & Security process is documented at
  https://support.apple.com/guide/mac-help/mh40616/mac . Do not disable Gatekeeper
  systemwide. No quarantine-removal or global security-bypass command is supplied.
- **Command file permission lost by extraction:** from its folder,
  `sh "Start Folio.command"` uses the same launcher without changing global policy.
- **Finder startup failure:** use Start Folio.command to see the error. The optional
  app writes startup output, not conversations, to
  `~/Library/Logs/Intersignal/Folio/launcher.log`.
- **Folio already running:** rerun a command launcher to reopen its browser session.
  Quit the current 0.2.0 session before launching 0.2.1; the new launcher will
  tell you when an older version still holds the same private profile. To stop
  it, use Quit Folio or `python3 -I start_folio.py --stop`.
- **Stale browser tab after restarting:** relaunch to receive a new session token.
- **Braid connection fails:** start Braid first and check its exact loopback UI URL.
  Reconnect after Braid restarts. Custom profiles need an explicit address. A failed
  connection clears the previously selected connection rather than silently
  retaining it.
- **Save conflict:** a second window changed the draft. Unsaved text remains on
  screen. Copy it somewhere private BEFORE reloading. The app does not silently
  overwrite another window's version. For this test build, edit a draft in one tab.
- **Bounds:** 4 MiB request/document limit, 400 passages, 80,000 UTF-8 bytes per
  general text field; title/byline 300 bytes, subtitle 2,000 bytes. Plain text or
  JSON only. No images, attachments, raw HTML rendering, ZIP import, or arbitrary
  provider-specific chat archives. Extract public JSON before importing it.

## Included and deferred

Working: private library, Braid read adapter, text/JSON imports, passage editing,
optional capsule, privacy hints, content-bound approval, numbered immutable
exports, continuation imports, explicit social sharing, local persistence,
recurring streams, local sanitation, review queue, and opt-in local Broadcast.

Deferred pending demand: built-in remote hosting. Also deferred: rings, accounts,
paid plans, credits, ranking,
public investigation requests, Braid writes, semantic/vector
exports, model-assisted editing, and native runtime bundling/signing. Nothing is
mocked up as a working community service.

See docs/TEST_TOMORROW.md, docs/FORMAT.md, docs/ARCHITECTURE.md, and QA.md.
The full source and test harnesses are included. The example edition is synthetic.
