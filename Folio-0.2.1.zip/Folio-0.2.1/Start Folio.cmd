@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0start_folio.py" (
  echo Keep this launcher inside the complete extracted Folio folder.
  exit /b 1
)
if defined FOLIO_PYTHON (
  set "PY_EXE=%FOLIO_PYTHON%"
  set "PY_ARG="
  call :probe
  if errorlevel 1 goto explicit_failed
  goto launch
)
set "PY_EXE=py"
for %%V in (-3 -3.14 -3.13 -3.12 -3.11 -3.10) do (
  set "PY_ARG=%%V"
  call :probe
  if not errorlevel 1 goto launch
)
set "PY_ARG="
for %%P in (python python3) do (
  set "PY_EXE=%%P"
  call :probe
  if not errorlevel 1 goto launch
)
echo No usable Python 3.10+ was found. Folio can reuse the Python installation used by Braid.
echo Set FOLIO_PYTHON to that executable. No installation or download was attempted.
goto failed
:explicit_failed
echo FOLIO_PYTHON did not select a usable Python 3.10+ runtime with sqlite3 and ssl.
echo No fallback was attempted.
goto failed
:probe
"%PY_EXE%" %PY_ARG% -I -c "import sys,sqlite3,ssl;sys.exit(0 if sys.version_info.__ge__((3,10)) else 2)" >nul 2>&1
exit /b %errorlevel%
:launch
if "%~1"=="--runtime-info" (
  "%PY_EXE%" %PY_ARG% -I -c "import sys;print(sys.version);print(sys.executable)"
  exit /b %errorlevel%
)
"%PY_EXE%" %PY_ARG% -I "%~dp0start_folio.py" %*
set "RESULT=%errorlevel%"
if not "%RESULT%"=="0" goto failed
exit /b 0
:failed
if not defined FOLIO_NO_PAUSE pause
exit /b 1
