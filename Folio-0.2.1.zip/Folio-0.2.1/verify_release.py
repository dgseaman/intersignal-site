#!/usr/bin/env python3
"""Verify package consistency, not publisher authenticity. Python standard library only."""
from pathlib import Path
import hashlib, json, plistlib, ast, sys
root=Path(__file__).resolve().parent
errors=[];count=0
manifest=root/'SHA256SUMS.txt'
if not manifest.exists():raise SystemExit('SHA256SUMS.txt is missing.')
for line in manifest.read_text().splitlines():
    expected,relative=line.split('  ',1);p=root/relative
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:errors.append(relative)
    count+=1
app=root/'Folio.app'/'Contents'
try:
    info=plistlib.loads((app/'Info.plist').read_bytes())
    assert info['CFBundleShortVersionString']=='0.2.1'
    for f in [root/'start_folio.py',root/'runtime_launch.sh',*(root/'folio').rglob('*')]:
        if f.is_file() and '__pycache__' not in f.parts:
            copy=app/'Resources'/'app'/f.relative_to(root)
            if not copy.is_file() or copy.read_bytes()!=f.read_bytes():errors.append('Mac bundle copy: '+str(f.relative_to(root)))
    for p in root.rglob('*.py'):ast.parse(p.read_text(),filename=str(p))
except Exception as e:errors.append(str(e))
print(json.dumps({'verified_files':count,'errors':errors,'note':'Hashes check consistency, not signing, provenance, or native platform execution.'},indent=2))
raise SystemExit(1 if errors else 0)
