#!/bin/sh
# Linux / POSIX entry point.
HERE=$(CDPATH= cd -P "$(dirname "$0")" && pwd) || exit 1
exec /bin/sh "$HERE/runtime_launch.sh" "$@"
