# Build notice

Folio 0.2.1 is an Intersignal development/test artifact, supplied with complete
source for the project's inspection, testing, and further work. No new public
open-source license, third-party endorsement, privacy certification, or production
release authorization is established by this package.

The running application uses Python's standard library and the user's existing
browser/interpreter. No third-party Python or JavaScript libraries, runtimes,
models, font files, private Braid code, or user data are bundled. The optional
verification tools name development dependencies (Playwright/Chromium and Braid's
own test prerequisites); they are not application dependencies and are not bundled.

Braid is a separate app and is not installed, patched, or relicensed by this build.
Exported publication content remains the publisher's responsibility. Folio does
not silently assign a content license or verify rights to conversations involving
other people. The included examples are explicitly synthetic.
