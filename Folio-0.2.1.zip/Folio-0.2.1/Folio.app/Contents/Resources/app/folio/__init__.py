"""Folio: local, human-directed publishing beside Braid."""
__version__ = '0.2.1'
