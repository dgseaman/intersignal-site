"""Local, bounded preparation of recurring Folio dispatches.

The Braid bridge is the only source adapter. This module makes no network or
model calls of its own, and its audit never includes matched private text.
"""
from __future__ import annotations

import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from .core import ValidationError, block, digest, new_draft, text, uid


TEMPLATES = {
    'daily': 'Daily Dispatch', 'weekly': 'Weekly Field Notes',
    'research': 'Research Log', 'build': 'Build Diary',
    'experiment': 'Experiment Log', 'conversation': 'AI Conversation Digest',
    'market': 'Market Observations', 'telescope': 'Observational Log',
    'custom': 'Field Notes',
}
SOURCE_TYPES = ('notes', 'objects', 'conversations')
PRIVACY_SWITCHES = ('redact_emails', 'redact_phones', 'redact_addresses',
                    'redact_credentials', 'redact_paths', 'redact_ip',
                    'redact_financial')
MAX_CHANNELS = 8
MAX_RULES = 40
MAX_CONVERSATIONS_PER_CHANNEL = 5
MAX_TURNS_PER_CONVERSATION = 20
MAX_ITEMS = 300
MAX_ITEM_BYTES = 6000
MAX_DISPATCH_ITEMS = 12
MAX_SEEN = 10000
MAX_AUDIT_CHANGES = 300


def _string(value, limit, label):
    if not isinstance(value, str):
        raise ValidationError(label + ' must be text.')
    return text(value, limit).strip()


def _bool(value, label):
    if type(value) is not bool:
        raise ValidationError(label + ' must be on or off.')
    return value


def validate_stream(incoming, existing=None):
    """Return a strict private stream configuration, ready for persistence."""
    if not isinstance(incoming, dict):
        raise ValidationError('Expected a stream object.')
    if existing is not None and not isinstance(existing, dict):
        raise ValidationError('Invalid existing stream.')
    prior = existing or {}
    ident = prior.get('id') or incoming.get('id') or uid()
    if not isinstance(ident, str) or not re.fullmatch(r'[a-f0-9]{32}', ident):
        raise ValidationError('Invalid stream identity.')
    if prior and incoming.get('id', ident) != ident:
        raise ValidationError('A stream identity cannot change.')

    name = _string(incoming.get('name', prior.get('name', '')), 300, 'Stream name')
    if not name:
        raise ValidationError('Name this stream.')
    mode = incoming.get('mode', prior.get('mode', 'review'))
    if mode not in ('review', 'broadcast'):
        raise ValidationError('Choose Review Queue or Broadcast.')
    cadence = incoming.get('cadence_hours', prior.get('cadence_hours', 168))
    if type(cadence) is not int or not 1 <= cadence <= 720:
        raise ValidationError('Cadence must be 1 to 720 whole hours.')
    template = incoming.get('template', prior.get('template', 'weekly'))
    if template not in TEMPLATES:
        raise ValidationError('Unknown dispatch template.')
    site_directory = _string(incoming.get('site_directory', prior.get('site_directory', '')),
                             1024, 'Site directory')
    if site_directory and not Path(site_directory).is_absolute():
        raise ValidationError('Site directory must be an absolute path on this computer.')
    if mode == 'broadcast' and not site_directory:
        raise ValidationError('Broadcast requires a local site directory.')

    scope = incoming.get('scope', prior.get('scope', {}))
    if not isinstance(scope, dict):
        raise ValidationError('Invalid source scope.')
    channels = scope.get('channels', [])
    if not isinstance(channels, list) or not 1 <= len(channels) <= MAX_CHANNELS:
        raise ValidationError('Choose 1 to 8 Braid Channels.')
    cleaned_channels = []
    for channel in channels:
        ident_channel = _string(channel, 128, 'Channel identity')
        if not ident_channel:
            raise ValidationError('A Channel identity is empty.')
        if ident_channel not in cleaned_channels:
            cleaned_channels.append(ident_channel)
    source_choices = {key: _bool(scope.get(key, False), key) for key in SOURCE_TYPES}
    if not any(source_choices.values()):
        raise ValidationError('Choose at least one source type.')
    tag = _string(scope.get('tag', ''), 48, 'Tag').lstrip('#')
    if tag and not re.fullmatch(r'[\w-]+', tag, flags=re.UNICODE):
        raise ValidationError('A tag may contain letters, numbers, underscores, or hyphens.')
    if mode == 'broadcast' and not tag:
        raise ValidationError('Broadcast requires an explicit source tag.')

    privacy = incoming.get('privacy', prior.get('privacy', {}))
    if not isinstance(privacy, dict):
        raise ValidationError('Invalid privacy policy.')
    rules = privacy.get('rules', [])
    if not isinstance(rules, list) or len(rules) > MAX_RULES:
        raise ValidationError('Use no more than 40 privacy rules.')
    cleaned_rules = []
    for rule in rules:
        if not isinstance(rule, dict):
            raise ValidationError('Invalid privacy rule.')
        category = _string(rule.get('category', ''), 60, 'Rule category')
        find = _string(rule.get('find', ''), 200, 'Rule text')
        replace = _string(rule.get('replace', ''), 200, 'Rule replacement')
        if not category or not find:
            raise ValidationError('Privacy rules need a category and text to find.')
        if not replace:
            replace = '[sensitive detail removed]'
        cleaned_rules.append({'category': category, 'find': find, 'replace': replace})
    switches = {key: _bool(privacy.get(key, True), key) for key in PRIVACY_SWITCHES}
    if mode == 'broadcast' and not all(switches.values()):
        raise ValidationError('Broadcast requires every built-in privacy redaction to be on.')

    ack = incoming.get('broadcast_ack', prior.get('broadcast_ack', False))
    _bool(ack, 'Broadcast acknowledgement')
    if mode == 'broadcast' and ack is not True:
        raise ValidationError('Broadcast requires explicit acknowledgement.')
    return {
        'id': ident, 'name': name, 'mode': mode, 'cadence_hours': cadence,
        'scope': {'channels': cleaned_channels, **source_choices, 'tag': tag},
        'privacy': {'rules': cleaned_rules, **switches},
        'template': template, 'broadcast_ack': ack if mode == 'broadcast' else False,
        'site_directory': site_directory,
    }


def _clip(value, limit=MAX_ITEM_BYTES):
    """Bound untrusted Braid text without splitting a UTF-8 character."""
    if not isinstance(value, str):
        return ''
    value = value.replace('\r\n', '\n').replace('\r', '\n')
    value = ''.join(ch for ch in value if ord(ch) >= 32 or ch in '\n\t')
    raw = value.encode('utf-8')
    return value if len(raw) <= limit else raw[:limit - 3].decode('utf-8', 'ignore').rstrip() + '…'


def _tagged(tag, title, body):
    if not tag:
        return True
    marker = re.compile(r'(?<![\w#])#' + re.escape(tag) + r'(?![\w-])', re.IGNORECASE)
    return bool(marker.search(title) or marker.search(body))


def _item(channel, source, source_id, title, body):
    title = _clip(title, 300) or 'Untitled source'
    body = _clip(body)
    if not body.strip():
        return None
    # The fingerprint changes if a source is edited; private Braid IDs stay out
    # of public text and out of the persisted seen state.
    key = digest([channel, source, str(source_id), title, body])
    return {'key': key, 'title': title, 'text': body, 'source': source, 'channel': channel}


def collect(bridge, stream):
    """Read only chosen channel views and at most five chats per channel."""
    stream = validate_stream(stream, stream)
    scope = stream['scope']
    items, warnings = [], []
    read_failures = 0
    channels_read = 0
    for channel in scope['channels']:
        try:
            view = bridge.channel(channel)
        except Exception:
            read_failures += 1
            continue
        if not isinstance(view, dict):
            read_failures += 1
            continue
        channels_read += 1
        notes = view.get('notes', [])
        if not isinstance(notes, list):
            notes = []
        for kind, enabled in (('note', scope['notes']), ('object', scope['objects'])):
            if not enabled:
                continue
            matching = [note for note in notes if isinstance(note, dict) and note.get('kind') == kind]
            if len(matching) > 100:
                warnings.append('A Channel view exceeded its 100-item source window.')
            for note in matching[:100]:
                candidate = _item(channel, kind, note.get('id', ''), note.get('title', ''), note.get('text', ''))
                if candidate and _tagged(scope['tag'], candidate['title'], candidate['text']):
                    items.append(candidate)
                if len(items) >= MAX_ITEMS:
                    warnings.append('The observation limit was reached; narrow the stream scope.')
                    return items, warnings
        if not scope['conversations']:
            continue
        threads = view.get('threads', [])
        if not isinstance(threads, list):
            continue
        if len(threads) > MAX_CONVERSATIONS_PER_CHANNEL:
            warnings.append('Only the newest 5 conversations in a selected Channel were checked.')
        for thread in threads[:MAX_CONVERSATIONS_PER_CHANNEL]:
            if not isinstance(thread, dict) or not isinstance(thread.get('id'), str):
                continue
            try:
                chat = bridge.view('chat', thread['id'])
            except Exception:
                read_failures += 1
                continue
            turns = chat.get('turns', []) if isinstance(chat, dict) else []
            if not isinstance(turns, list):
                continue
            if len(turns) > MAX_TURNS_PER_CONVERSATION:
                warnings.append('Only the newest 20 turns in a selected conversation were checked.')
            for turn in turns[-MAX_TURNS_PER_CONVERSATION:]:
                if not isinstance(turn, dict) or turn.get('state') != 'done':
                    continue
                payload = turn.get('payload', {})
                result = payload.get('result', {}) if isinstance(payload, dict) else {}
                answer = result.get('response') if isinstance(result, dict) else None
                question = turn.get('question')
                if not isinstance(question, str) or not isinstance(answer, str):
                    continue
                body = 'Question: ' + _clip(question, 2000) + '\nAnswer: ' + _clip(answer, 4000)
                candidate = _item(channel, 'conversation', turn.get('id', ''), thread.get('title', ''), body)
                if candidate and _tagged(scope['tag'], candidate['title'], candidate['text']):
                    items.append(candidate)
                if len(items) >= MAX_ITEMS:
                    warnings.append('The observation limit was reached; narrow the stream scope.')
                    return items, warnings
    if channels_read == 0:
        raise ValidationError('No selected Braid Channel could be read. Reconnect and retry this cycle.')
    if read_failures:
        warnings.append('Some selected Braid views could not be read; reconnect and retry if material is missing.')
    if items:
        items = list({item['key']: item for item in items}.values())
    return items, list(dict.fromkeys(warnings))


PATTERNS = (
    ('redact_emails', 'Email address', re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b')),
    ('redact_phones', 'Phone number', re.compile(r'(?<!\w)(?:\+\d{1,3}[ .-]?)?\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4}\b')),
    ('redact_addresses', 'Street address', re.compile(r'\b\d{1,6}\s+(?:[A-Za-z0-9.\-]+\s+){1,5}(?:Street|St\.?|Road|Rd\.?|Avenue|Ave\.?|Boulevard|Blvd\.?|Lane|Ln\.?|Drive|Dr\.?|Court|Ct\.?)\b', re.IGNORECASE)),
    ('redact_credentials', 'Credential', re.compile(r'\bsk-[A-Za-z0-9_-]{12,}\b|\b(?:api[_ -]?key|access[_ -]?key|token|password|secret)\s*[:=]\s*[^\s,;]+', re.IGNORECASE)),
    ('redact_paths', 'Local path', re.compile(r'(?:/Users/|/home/|[A-Za-z]:\\Users\\)[^\s,;]+')),
    ('redact_ip', 'IP address', re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')),
    ('redact_financial', 'Financial amount', re.compile(r'(?<!\w)(?:[$€£]\s?\d[\d,]*(?:\.\d{1,2})?|\b(?:USD|EUR|GBP)\s?\d[\d,]*(?:\.\d{1,2})?)\b', re.IGNORECASE)),
)


def _sanitize(value, field, privacy, changes, totals):
    value = _clip(value, 12000)
    def apply(pattern, category, replacement):
        nonlocal value
        def replace(match):
            totals['sanitized_occurrences'] += 1
            if len(changes) < MAX_AUDIT_CHANGES:
                changes.append({'field': field, 'category': category, 'replacement': replacement})
            return replacement
        value = pattern.sub(replace, value)
        value = _clip(value, 12000)
    # Detect structured secrets before literal name rules can split an email or
    # credential into text that no longer matches its safety pattern.
    for switch, category, pattern in PATTERNS:
        if privacy[switch]:
            apply(pattern, category, '[' + category.lower() + ' removed]')
    for rule in privacy['rules']:
        apply(re.compile(re.escape(rule['find']), re.IGNORECASE), rule['category'], rule['replace'])
    # A user-supplied generalization can itself contain a structured value.
    for switch, category, pattern in PATTERNS:
        if privacy[switch]:
            apply(pattern, category, '[' + category.lower() + ' removed]')
    return _clip(value, 12000)


CUES = (
    ('Decision', re.compile(r'\b(?:decid(?:ed|e)|chose|agreed|will adopt|switched to|changed (?:our|my) mind)\b', re.I), 7),
    ('Failed experiment', re.compile(r'\b(?:failed|did not work|didn.t work|regression|unsuccessful|blocked)\b', re.I), 6),
    ('Successful experiment', re.compile(r'\b(?:succeeded|successful|worked|validated|confirmed|passed)\b', re.I), 6),
    ('Finding', re.compile(r'\b(?:found|discovered|learned|observed|measured|showed|revealed)\b', re.I), 5),
    ('Change', re.compile(r'\b(?:changed|updated|revised|replaced|removed|added|built|implemented)\b', re.I), 4),
    ('Open question', re.compile(r'\?|\b(?:uncertain|unknown|open question|next test|need to test)\b', re.I), 3),
)

TEMPLATE_BOOSTS = {
    'research': {'Finding': 3, 'Open question': 2},
    'build': {'Change': 3, 'Decision': 2},
    'experiment': {'Failed experiment': 3, 'Successful experiment': 3},
    'conversation': {'Open question': 2, 'Decision': 1},
    'market': {'Finding': 2, 'Change': 2},
    'telescope': {'Finding': 3, 'Observation': 2},
}


def _salience(item):
    content = item['text']
    labels = [(score, label) for label, pattern, score in CUES if pattern.search(content)]
    score, label = max(labels, default=(1, 'Observation'))
    # Specificity helps a concrete observation beat a one-word note.
    score += min(len(content.split()) // 25, 3)
    return score, label


def _excerpt(item):
    """Select a source-grounded span instead of inventing a summary."""
    body = item['text'].strip()
    if item['source'] == 'conversation' and '\nAnswer: ' in body:
        question, answer = body.split('\nAnswer: ', 1)
        body = answer.strip() or question
    pieces = re.split(r'(?<=[.!?])\s+', body)
    salient = [(score, index, piece) for index, piece in enumerate(pieces[:30])
               for score, _ in [_salience({'text': piece})]]
    if salient:
        score, index, piece = max(salient, key=lambda x: (x[0], -x[1]))
        if score > 1:
            return _clip(piece, 1400)
    return _clip(body, 1400)


def _title(stream):
    now = datetime.now(timezone.utc)
    if stream['template'] == 'weekly':
        stamp = f'{now.isocalendar().year}-W{now.isocalendar().week:02d}'
    else:
        stamp = now.date().isoformat()
    return f"{stream['name']} · {TEMPLATES[stream['template']]} · {stamp}"


def prepare(stream, items, seen):
    """Select new salient deltas and return an unapproved legacy Folio draft.

    `next_seen` is an ordered list of opaque content fingerprints. Even material
    not selected for the dispatch is marked seen, so each cycle moves forward.
    """
    stream = validate_stream(stream, stream)
    if not isinstance(items, list) or len(items) > MAX_ITEMS:
        raise ValidationError('Too many observed items.')
    if not isinstance(seen, (list, tuple, set)) or len(seen) > MAX_SEEN:
        raise ValidationError('Invalid seen state.')
    prior = [x for x in seen if isinstance(x, str) and re.fullmatch(r'[a-f0-9]{64}', x)]
    seen_set = set(prior)
    fresh = []
    next_seen = list(dict.fromkeys(prior))
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get('key'), str) or not re.fullmatch(r'[a-f0-9]{64}', item['key']):
            raise ValidationError('Invalid observed item.')
        if item['key'] in seen_set:
            continue
        source_switch = {'note': 'notes', 'object': 'objects', 'conversation': 'conversations'}
        if (item.get('source') not in source_switch
            or not stream['scope'][source_switch[item['source']]]
            or item.get('channel') not in stream['scope']['channels']):
            raise ValidationError('An item is outside this stream scope.')
        if not isinstance(item.get('title'), str) or not isinstance(item.get('text'), str):
            raise ValidationError('Invalid observed text.')
        fresh.append(item)
        seen_set.add(item['key'])
        next_seen.append(item['key'])
    next_seen = next_seen[-MAX_SEEN:]
    audit = {'observed_count': len(items), 'new_count': len(fresh), 'selected_count': 0,
             'sanitized_occurrences': 0, 'changes': [], 'warnings': []}
    if not fresh:
        return None, next_seen, audit
    boosts = TEMPLATE_BOOSTS.get(stream['template'], {})
    ranked = sorted(enumerate(fresh), key=lambda pair: (
        -(_salience(pair[1])[0] + boosts.get(_salience(pair[1])[1], 0)
          + (3 if stream['template']=='conversation' and pair[1]['source']=='conversation' else 0)),
        pair[0]))
    selected = [item for _, item in ranked[:MAX_DISPATCH_ITEMS]]
    if len(fresh) > len(selected):
        audit['warnings'].append('Some new material was not selected for this dispatch.')
    audit['warnings'].append('Local pattern rules cannot reliably identify every name, location, or confidential detail. Review the draft before sharing.')
    changes = audit['changes']
    privacy = stream['privacy']
    public_stream_name = _clip(_sanitize(stream['name'], 'Stream name', privacy, changes, audit), 300)
    title = _clip(_sanitize(_clip(_title(stream), 300), 'Title', privacy, changes, audit), 300)
    categories = Counter(_salience(item)[1] for item in selected)
    category_line = ', '.join(str(count)+' '+label.lower()+('s' if count!=1 else '')
                              for label,count in categories.most_common())
    phase = 'Initial observation' if not prior else 'Changes since the previous cycle'
    intro = _sanitize(f'{phase}: {len(fresh)} new or changed source items observed. '
                      f'This {TEMPLATES[stream["template"]].lower()} preserves {category_line}.',
                      'Introduction', privacy, changes, audit)
    blocks = []
    for index, item in enumerate(selected, 1):
        _, label = _salience(item)
        heading = _clip(_sanitize(label, f'Passage {index} heading', privacy, changes, audit), 300)
        source_title = _sanitize(item['title'], f'Passage {index} source title', privacy, changes, audit)
        excerpt = _excerpt(item)
        public = source_title + '\n' + _sanitize(excerpt, f'Passage {index} text', privacy, changes, audit)
        # The original is available only in the private editor's source view.
        blocks.append(block('note', public, heading, original=item['title'] + '\n' + excerpt))
    draft = new_draft(title, blocks, {
        'kind': 'Recurring dispatch', 'stream_id': stream['id'],
        'observed_count': len(items), 'selected_count': len(selected),
        'source_fingerprints': [item['key'] for item in selected],
    })
    draft['kind'] = 'observation'
    draft['subtitle'] = _sanitize(TEMPLATES[stream['template']], 'Subtitle', privacy, changes, audit)
    draft['introduction'] = intro
    draft['stream_public_name'] = public_stream_name
    audit['selected_count'] = len(selected)
    if audit['sanitized_occurrences'] > len(changes):
        audit['warnings'].append('Additional sanitation changes were made beyond the audit display limit.')
    return draft, next_seen, audit
