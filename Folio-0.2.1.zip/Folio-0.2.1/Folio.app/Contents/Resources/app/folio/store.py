"""Folio-only private storage with optimistic concurrency and immutable exports."""
from __future__ import annotations
import json
import html
import io
import os
import sqlite3
import threading
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from .core import (ValidationError, ConflictError, uid, now, validate_draft, review_digest,
                   make_edition, export_zip, strict_json, privacy_scan)
from .dispatch import validate_stream, collect, prepare

def private_dir(path):
    path=Path(path);path.mkdir(parents=True,exist_ok=True,mode=0o700)
    if os.name!='nt':path.chmod(0o700)
    return path

def private_write(path,data):
    path=Path(path);temp=path.with_name(path.name+'.tmp-'+uid())
    fd=os.open(str(temp),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if temp.exists():temp.unlink()

class Store:
    def __init__(self,path):
        self.home=private_dir(path);self.exports=private_dir(self.home/'exports');self.lock=threading.RLock();self.running=set()
        self.dbfile=self.home/'folio.sqlite3'
        if not self.dbfile.exists():
            fd=os.open(str(self.dbfile),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
        with self.db() as db:
            db.executescript('CREATE TABLE IF NOT EXISTS drafts (id TEXT PRIMARY KEY, data TEXT NOT NULL); CREATE TABLE IF NOT EXISTS exports (id TEXT PRIMARY KEY, draft TEXT NOT NULL, data TEXT NOT NULL); CREATE TABLE IF NOT EXISTS streams (id TEXT PRIMARY KEY, data TEXT NOT NULL); CREATE TABLE IF NOT EXISTS stream_runs (id TEXT PRIMARY KEY, stream TEXT NOT NULL, data TEXT NOT NULL);')
    def db(self):
        c=sqlite3.connect(self.dbfile,timeout=10);c.row_factory=sqlite3.Row;return c
    def list(self):
        with self.db() as db:items=[json.loads(r['data']) for r in db.execute('SELECT data FROM drafts')]
        return sorted([dict(id=d['id'],title=d['title'],kind=d['kind'],updated_at=d['updated_at'],
            approved=d.get('approved_digest')==review_digest(d),editions=len(d.get('editions',[]))) for d in items],key=lambda d:d['updated_at'],reverse=True)
    def get(self,ident):
        with self.db() as db:r=db.execute('SELECT data FROM drafts WHERE id=?',(ident,)).fetchone()
        if r is None:raise ValidationError('Folio not found. It may have been deleted in another window.')
        return json.loads(r['data'])
    def insert(self,d):
        d=validate_draft(d,d)
        with self.lock,self.db() as db:
            d['revision']=1;d['updated_at']=now()
            db.execute('INSERT INTO drafts VALUES (?,?)',(d['id'],json.dumps(d,ensure_ascii=False)))
        return d
    def save(self,ident,incoming):
        with self.lock,self.db() as db:
            old=self.get(ident)
            if type(incoming.get('revision')) is not int or incoming['revision']!=old['revision']:
                raise ConflictError('This draft changed in another window. Your unsaved text is still on screen. Copy it before reloading the draft.')
            d=validate_draft(incoming,old)
            if review_digest(d)!=review_digest(old):d['approved_digest']=None
            d['revision']=old['revision']+1;d['updated_at']=now()
            db.execute('UPDATE drafts SET data=? WHERE id=?',(json.dumps(d,ensure_ascii=False),ident))
            return d
    def approve(self,ident,expected_digest,confirmed):
        from .core import validate_publishable
        with self.lock,self.db() as db:
            d=self.get(ident);validate_publishable(d)
            if confirmed is not True:raise ValidationError('Explicit approval is required.')
            actual=review_digest(d)
            if actual!=expected_digest:raise ConflictError('The publication changed after preview. Review the current version.')
            d['approved_digest']=actual;d['revision']+=1;d['updated_at']=now()
            db.execute('UPDATE drafts SET data=? WHERE id=?',(json.dumps(d,ensure_ascii=False),ident))
            return d
    def export(self,ident):
        with self.lock:
            linked=[]
            with self.db() as db:
                d=self.get(ident)
                if d.get('approved_digest')!=review_digest(d):
                    raise ConflictError('Review and approve the current publication before exporting.')
                # Retrying the same approved body reuses its immutable archive.
                if d['editions'] and d['editions'][-1]['content_sha256']==review_digest(d):
                    record=d['editions'][-1]
                else:
                    e=make_edition(d,len(d['editions'])+1);raw=export_zip(e)
                    record={'id':e['edition_id'],'edition_number':e['edition_number'],'content_sha256':e['content_sha256'],
                            'published_at':e['published_at'],'filename':'Folio-'+e['edition_id'][:8]+'-edition-'+str(e['edition_number'])+'.zip'}
                    private_write(self.exports/(record['id']+'.zip'),raw)
                    db.execute('INSERT INTO exports VALUES (?,?,?)',(record['id'],ident,json.dumps(record)))
                    d['editions'].append(record);d['revision']+=1
                    db.execute('UPDATE drafts SET data=? WHERE id=?',(json.dumps(d,ensure_ascii=False),ident))
                for row in db.execute('SELECT id,data FROM stream_runs').fetchall():
                    run=json.loads(row['data'])
                    if run.get('draft_id')==ident and run.get('status') in ('review','needs_review','released','delivery_failed'):
                        linked.append(run['id'])
                        run['status']='released';run['edition_id']=record['id'];run.pop('error',None)
                        db.execute('UPDATE stream_runs SET data=? WHERE id=?',(json.dumps(run,ensure_ascii=False),row['id']))
            if linked and d.get('stream_id'):
                try:stream=self._get_stream(d['stream_id'])
                except ValidationError:stream=None  # Deleted stream; the draft remains exportable.
                try:
                    if stream and stream.get('site_directory'):
                        self.write_stream_site(d['stream_id'])
                except Exception:
                    message='The edition was exported, but Folio could not update the selected static site folder. Check it and use Retry site update.'
                    with self.db() as db:
                        for run_id in linked:
                            row=db.execute('SELECT data FROM stream_runs WHERE id=?',(run_id,)).fetchone()
                            if row:
                                run=json.loads(row['data']);run['status']='delivery_failed';run['error']=message
                                db.execute('UPDATE stream_runs SET data=? WHERE id=?',(json.dumps(run,ensure_ascii=False),run_id))
                    return {**record,'site_error':message}
            return record
    def download(self,ident):
        with self.db() as db:r=db.execute('SELECT data FROM exports WHERE id=?',(ident,)).fetchone()
        if r is None:raise ValidationError('Export not found.')
        return json.loads(r['data']),(self.exports/(ident+'.zip')).read_bytes()
    def delete(self,ident,revision):
        with self.lock,self.db() as db:
            d=self.get(ident)
            if revision!=d['revision']:raise ConflictError('Draft changed; reload before deleting.')
            for r in db.execute('SELECT id FROM exports WHERE draft=?',(ident,)).fetchall():
                (self.exports/(r['id']+'.zip')).unlink(missing_ok=True)
            db.execute('DELETE FROM exports WHERE draft=?',(ident,));db.execute('DELETE FROM drafts WHERE id=?',(ident,))
            for row in db.execute('SELECT id,data FROM stream_runs').fetchall():
                run=json.loads(row['data'])
                if run.get('draft_id')==ident:
                    run['status']='dismissed';run['draft_id']=None
                    db.execute('UPDATE stream_runs SET data=? WHERE id=?',(json.dumps(run,ensure_ascii=False),row['id']))
        return {'deleted':True}

    def _get_stream(self,ident):
        with self.db() as db:r=db.execute('SELECT data FROM streams WHERE id=?',(ident,)).fetchone()
        if r is None:raise ValidationError('Stream not found.')
        return json.loads(r['data'])

    def _public_stream(self,stream):
        return {k:v for k,v in stream.items() if k!='seen'}

    def streams(self):
        with self.db() as db:rows=db.execute('SELECT data FROM streams').fetchall()
        return sorted([self._public_stream(json.loads(r['data'])) for r in rows],key=lambda s:s.get('updated_at',''),reverse=True)

    def runs(self):
        with self.db() as db:rows=db.execute('SELECT data FROM stream_runs').fetchall()
        return sorted([json.loads(r['data']) for r in rows],key=lambda r:r['created_at'],reverse=True)[:200]

    def save_stream(self,incoming):
        if not isinstance(incoming,dict):raise ValidationError('Expected stream settings.')
        with self.lock:
            ident=incoming.get('id')
            old=self._get_stream(ident) if ident else None
            if old and incoming.get('revision')!=old['revision']:
                raise ConflictError('This stream changed in another window. Reload before saving.')
            value=validate_stream(incoming,old)
            value['revision']=(old['revision']+1 if old else 1)
            value['created_at']=old['created_at'] if old else now()
            value['updated_at']=now()
            value['seen']=old.get('seen',[]) if old else []
            value['last_run_at']=old.get('last_run_at') if old else None
            value['last_status']=old.get('last_status') if old else None
            value['next_due_at']=(datetime.now(timezone.utc)+timedelta(hours=value['cadence_hours'])).isoformat(timespec='seconds').replace('+00:00','Z')
            with self.db() as db:
                db.execute('INSERT OR REPLACE INTO streams VALUES (?,?)',(value['id'],json.dumps(value,ensure_ascii=False)))
            return self._public_stream(value)

    def delete_stream(self,ident,revision):
        with self.lock:
            old=self._get_stream(ident)
            if revision!=old['revision']:raise ConflictError('This stream changed in another window. Reload before deleting.')
            with self.db() as db:db.execute('DELETE FROM streams WHERE id=?',(ident,))
            return {'deleted':True}

    def due_stream_ids(self):
        current=now()
        with self.db() as db:rows=db.execute('SELECT data FROM streams').fetchall()
        return [s['id'] for s in (json.loads(r['data']) for r in rows)
                if s['id'] not in self.running and s.get('next_due_at','')<=current]

    def record_cycle_error(self,ident):
        """Make unexpected scheduler failures visible without exposing source text."""
        with self.lock:
            stream=self._get_stream(ident)
            run={'id':uid(),'stream_id':ident,'draft_id':None,'status':'blocked',
                 'created_at':now(),'change_count':0,'warnings':[],
                 'privacy_changes_count':0,
                 'error':'This cycle failed before a dispatch was prepared. Check the local app and retry.'}
            stream['last_run_at']=now();stream['last_status']='blocked'
            stream['next_due_at']=(datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat(timespec='seconds').replace('+00:00','Z')
            with self.db() as db:
                db.execute('UPDATE streams SET data=? WHERE id=?',(json.dumps(stream,ensure_ascii=False),ident))
                db.execute('INSERT INTO stream_runs VALUES (?,?,?)',(run['id'],ident,json.dumps(run,ensure_ascii=False)))
            return run

    def run_stream(self,ident,bridge):
        with self.lock:
            if ident in self.running:raise ConflictError('This stream is already observing its selected sources.')
            stream=self._get_stream(ident)
            self.running.add(ident)
        try:
            try:
                items,warnings=collect(bridge,stream)
                draft,next_seen,audit=prepare(stream,items,stream.get('seen',{}))
                error=None
            except (ValidationError,OSError) as exc:
                draft=None;next_seen=stream.get('seen',[]);audit={};warnings=[];error=str(exc)[:500]
            with self.lock:
                current=self._get_stream(ident)
                if current['revision']!=stream['revision']:
                    raise ConflictError('The stream settings changed during observation. Run it again.')
                run={'id':uid(),'stream_id':ident,'draft_id':None,'status':'blocked' if error else 'no_change',
                     'created_at':now(),'change_count':0,'warnings':(warnings+audit.get('warnings',[]))[:20],
                     'privacy_changes_count':0}
                if error:run['error']=error
                if draft:
                    draft['private_source']['privacy_audit']={
                        'sanitized_occurrences':int(audit.get('sanitized_occurrences',0)),
                        'changes':audit.get('changes',[])[:300],
                        'warnings':audit.get('warnings',[])[:20],
                    }
                    draft['stream']={'id':stream['id'],'name':draft.pop('stream_public_name',stream['name'])}
                    draft['stream_id']=stream['id']
                    saved=self.insert(draft)
                    run['draft_id']=saved['id']
                    run['change_count']=int(audit.get('new_count',len(saved['blocks'])))
                    run['selected_count']=len(saved['blocks'])
                    run['privacy_changes_count']=int(audit.get('sanitized_occurrences',0))
                    run['privacy_changes']=audit.get('changes',[])[:50]
                    run['status']='review'
                    if stream['mode']=='broadcast' and stream.get('broadcast_ack'):
                        findings=privacy_scan(saved)
                        if findings:
                            run['status']='needs_review'
                            run['warnings'].append('Automatic release paused: possible private information remains in the public draft.')
                        else:
                            approved=self.approve(saved['id'],review_digest(saved),True)
                            record=self.export(approved['id'])
                            run['status']='released';run['edition_id']=record['id']
                current['seen']=next_seen
                current['last_run_at']=now();current['last_status']=run['status']
                wait_minutes=5 if error else current['cadence_hours']*60
                current['next_due_at']=(datetime.now(timezone.utc)+timedelta(minutes=wait_minutes)).isoformat(timespec='seconds').replace('+00:00','Z')
                with self.db() as db:
                    db.execute('UPDATE streams SET data=? WHERE id=?',(json.dumps(current,ensure_ascii=False),ident))
                    db.execute('INSERT INTO stream_runs VALUES (?,?,?)',(run['id'],ident,json.dumps(run,ensure_ascii=False)))
                if run['status']=='released' and stream.get('site_directory'):
                    try:
                        self.write_stream_site(ident)
                        run['site_updated']=True
                    except Exception:
                        run['status']='delivery_failed'
                        run['error']='The local edition was exported, but Folio could not update the selected static site folder. Check that the folder exists and is writable, then retry.'
                        current['last_status']=run['status']
                    with self.db() as db:
                        db.execute('UPDATE stream_runs SET data=? WHERE id=?',(json.dumps(run,ensure_ascii=False),run['id']))
                        db.execute('UPDATE streams SET data=? WHERE id=?',(json.dumps(current,ensure_ascii=False),ident))
                return run
        finally:
            with self.lock:self.running.discard(ident)

    def stream_site(self,ident):
        stream=self._get_stream(ident)
        with self.db() as db:rows=db.execute('SELECT data FROM stream_runs WHERE stream=? ORDER BY rowid',(ident,)).fetchall()
        releases=[r for r in (json.loads(row['data']) for row in rows) if r['status'] in ('released','delivery_failed') and r.get('edition_id')]
        pages=[];files={};public_name='Folio stream'
        for run in releases:
            record,archive=self.download(run['edition_id'])
            with zipfile.ZipFile(io.BytesIO(archive)) as source:
                edition=strict_json(source.read('edition.json'))
                public_name=edition['body'].get('stream',{}).get('name',public_name)
                folder='editions/'+record['id']+'/'
                for name in source.namelist():
                    if name in ('index.html','publication.md','edition.json','README.txt','SHA256SUMS.txt','capsule.json','context.txt'):
                        files[folder+name]=source.read(name)
            pages.append((folder+'index.html',edition['body']['title'],edition['body']['subtitle'],edition['published_at']))
        esc=html.escape
        listing=''.join('<article><time>'+esc(date)+'</time><h2><a href="'+esc(path,quote=True)+'">'+esc(title)+'</a></h2><p>'+esc(subtitle)+'</p></article>' for path,title,subtitle,date in reversed(pages))
        page='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><title>'+esc(public_name)+' / Folio</title><style>body{margin:0;background:#f7f5ef;color:#242d29;font:18px/1.6 system-ui,sans-serif}main{max-width:760px;margin:auto;padding:50px 28px}h1,h2{font-family:Georgia,serif;font-weight:normal}article{border-top:1px solid #cfd5cb;padding:22px 0}a{color:#37694e}time{font:13px ui-monospace,monospace;color:#607068}</style><main><p>FOLIO / INTERSIGNAL</p><h1>'+esc(public_name)+'</h1>'+ (listing or '<p>No released dispatches yet.</p>')+'</main></html>'
        files['index.html']=page.encode('utf-8')
        files['README.txt']=b'Folio stream site bundle. Upload the entire extracted folder to a static host you control. Folio has not uploaded it. Only released public editions are included.\n'
        output=io.BytesIO()
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as target:
            for name,value in sorted(files.items()):
                info=zipfile.ZipInfo(name,(2026,9,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
                target.writestr(info,value)
        return 'Folio-stream-'+ident[:8]+'.zip',output.getvalue()

    def write_stream_site(self,ident):
        """Materialize public files into a dedicated child of an opted-in root."""
        stream=self._get_stream(ident)
        chosen=stream.get('site_directory','')
        if not chosen:raise ValidationError('Choose a static site destination for this stream.')
        root=Path(chosen).expanduser()
        if not root.is_dir() or root.is_symlink():
            raise ValidationError('The selected destination must be an existing, ordinary folder.')
        destination=root/('folio-stream-'+ident)
        marker=destination/'.folio-stream-id'
        if destination.exists():
            if destination.is_symlink() or not destination.is_dir() or not marker.is_file() or marker.read_text()!=ident:
                raise ValidationError('The dedicated stream folder exists but was not created by this stream.')
        else:
            destination.mkdir(mode=0o755)
            private_write(marker,ident.encode())
        _,archive=self.stream_site(ident)
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            for name in z.namelist():
                path=Path(name)
                if path.is_absolute() or '..' in path.parts or name.startswith('/'):
                    raise ValidationError('Invalid stream site member.')
                target=destination/path
                for parent in target.parents:
                    if parent==destination.parent:break
                    if parent.is_symlink():raise ValidationError('A link inside the stream site prevents safe updates.')
                target.parent.mkdir(parents=True,exist_ok=True,mode=0o755)
                if target.is_symlink():raise ValidationError('A linked stream site file prevents safe updates.')
                private_write(target,z.read(name))
                if os.name!='nt':target.chmod(0o644)
        if os.name!='nt':
            destination.chmod(0o755)
            for folder in destination.rglob('*'):
                if folder.is_dir() and not folder.is_symlink():folder.chmod(0o755)
        return {'folder':str(destination)}

    def retry_stream_site(self,ident):
        with self.lock:
            self.write_stream_site(ident)
            with self.db() as db:
                rows=db.execute('SELECT id,data FROM stream_runs WHERE stream=?',(ident,)).fetchall()
                updated=0
                for row in rows:
                    run=json.loads(row['data'])
                    if run.get('status')=='delivery_failed':
                        run['status']='released';run.pop('error',None);run['site_updated']=True
                        db.execute('UPDATE stream_runs SET data=? WHERE id=?',(json.dumps(run,ensure_ascii=False),row['id']))
                        updated+=1
                stream=self._get_stream(ident)
                stream['last_status']='released'
                db.execute('UPDATE streams SET data=? WHERE id=?',(json.dumps(stream,ensure_ascii=False),ident))
            return {'site_updated':True,'recovered_runs':updated}
