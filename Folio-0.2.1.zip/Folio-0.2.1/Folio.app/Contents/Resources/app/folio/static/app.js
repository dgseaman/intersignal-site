'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const E = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const uid = () => crypto.randomUUID().replace(/-/g,'');
  const S = {draft:null, view:'compose', section:'welcome', seq:0, dirty:false, saving:null, saveError:null, timer:null, preview:null, braid:null, channel:'', channelSeq:0, streams:null, streamEdit:null, capsuleField:null};
  const params = new URLSearchParams(location.hash.slice(1));
  let token = params.get('session');
  if(token){sessionStorage.setItem('folio-token',token); history.replaceState(null,'',location.pathname);}
  else token = sessionStorage.getItem('folio-token');
  async function api(route,data=null){
    const response=await fetch('/api/'+route,{method:data===null?'GET':'POST',headers:{'X-Folio-Token':token||'',...(data===null?{}:{'Content-Type':'application/json'})},body:data===null?undefined:JSON.stringify(data),cache:'no-store'});
    const value=await response.json();if(!response.ok)throw new Error(value.error||'The operation did not complete.');return value;
  }
  function error(err){$('error').hidden=false;$('error').textContent=err.message||String(err);}
  function clearError(){$('error').hidden=true;$('error').textContent='';}
  function toast(message){$('toast').textContent=message;$('toast').hidden=false;setTimeout(()=>$('toast').hidden=true,4000);}
  async function safely(fn){try{clearError();return await fn();}catch(e){error(e);return null;}}
  async function busy(button,fn){if(button.disabled)return;button.disabled=true;const original=button.textContent;button.textContent='Working...';try{return await fn();}finally{button.disabled=false;button.textContent=original;}}
  function modal(id){const el=$(id);el.querySelector('.dialog-error')?.replaceChildren();if(!el.open)el.showModal();}
  async function inDialog(dialog,fn){try{dialog.querySelector('.dialog-error').textContent='';await fn();}catch(e){dialog.querySelector('.dialog-error').textContent=e.message||String(e);}}
  function displaySave(){ $('save-state').textContent=S.saveError?'Not saved - resolve the error':S.dirty?'Saving locally...':S.draft?'Saved on this computer':'Local-first. Human-edited.'; }
  function mark(){S.seq++;S.dirty=true;S.preview=null;S.draft.approved_digest=null;clearTimeout(S.timer);displaySave();S.timer=setTimeout(()=>saveNow().catch(error),600);updateHeading();}
  async function saveNow(){
    clearTimeout(S.timer);
    if(S.saveError)throw S.saveError;
    if(S.saving)await S.saving;
    if(!S.dirty||!S.draft)return;
    S.saving=(async()=>{
      while(S.dirty){
        const sequence=S.seq, snapshot=structuredClone(S.draft), ident=S.draft.id;
        try{
          const result=await api('save',{id:ident,draft:snapshot});
          if(S.draft?.id!==ident)throw new Error('Draft switched before save completed.');
          S.draft.revision=result.revision;S.draft.updated_at=result.updated_at;S.draft.editions=result.editions;
          if(sequence===S.seq){S.dirty=false;S.draft.approved_digest=result.approved_digest;}
        }catch(e){S.saveError=e;displaySave();throw e;}
      }
      displaySave();await refreshLibrary();
    })();
    try{await S.saving;}finally{S.saving=null;}
  }
  async function refreshLibrary(){
    const state=await api('state');$('count').textContent=state.drafts.length;
    $('library').innerHTML=state.drafts.length?state.drafts.map(d=>`<button class="library-item ${d.id===S.draft?.id?'active':''}" data-id="${E(d.id)}"><strong>${E(d.title||'Untitled folio')}</strong><small>${E(d.kind)} &middot; ${d.editions?d.editions+' edition'+(d.editions===1?'':'s'):'private draft'}</small></button>`).join(''):'<p class="empty-library">Your publications start here.<br>Private until you export.</p>';
  }
  async function setDraft(d){await saveNow();S.draft=d;S.dirty=false;S.saveError=null;S.seq=0;S.view='compose';S.section='draft';S.preview=null;S.capsuleField=null;$('welcome').hidden=true;$('streams-view').hidden=true;$('workspace').hidden=false;$('source').hidden=false;$('delete').hidden=false;displaySave();updateHeading();render();await refreshLibrary();}
  async function openDraft(id){await saveNow();await setDraft(await api('draft?id='+encodeURIComponent(id)));}
  const streamTemplates=[
    ['daily','Daily Dispatch'],['weekly','Weekly Field Notes'],['research','Research Log'],
    ['build','Build Diary'],['experiment','Experiment Log'],['conversation','AI Conversation Digest'],
    ['market','Market Observations'],['telescope','Telescope Log'],['custom','Custom dispatch']
  ];
  const privacyFlags=[
    ['redact_emails','Email addresses'],['redact_phones','Phone numbers'],
    ['redact_addresses','Street addresses'],['redact_credentials','Credentials and secrets'],
    ['redact_paths','Local paths'],['redact_ip','IP addresses'],['redact_financial','Financial details']
  ];
  const ruleCategories=[
    ['name','Personal name'],['location','Address or location'],['financial','Financial detail'],
    ['relationship','Private relationship'],['secret','Credential or secret'],
    ['project','Confidential project detail'],['custom','Other sensitive detail']
  ];
  const streamDefaults=()=>({
    name:'',mode:'review',cadence_hours:24,
    scope:{channels:[],notes:true,objects:false,conversations:true,tag:''},
    privacy:{rules:[],...Object.fromEntries(privacyFlags.map(([key])=>[key,true]))},
    template:'daily',broadcast_ack:false,site_directory:''
  });
  const streamDate=value=>{const d=new Date(value);return value&&!Number.isNaN(d.getTime())?d.toLocaleString():'Not yet';};
  const streamWarnings=value=>Array.isArray(value)?value.filter(x=>typeof x==='string'):typeof value==='string'&&value?[value]:[];
  const absoluteLocalPath=value=>/^\/(?!\/)/.test(value)||/^[A-Za-z]:[\\/]/.test(value);
  const isAwaiting=q=>q.draft_id&&!['released','delivery_failed','exported','broadcast','published','dismissed'].includes(q.status);
  async function refreshStreams(){
    S.streams=await api('streams');
    renderStreams();
  }
  async function openStreams(){
    await saveNow();
    await refreshStreams();
    S.section='streams';$('welcome').hidden=true;$('workspace').hidden=true;$('streams-view').hidden=false;
    $('source').hidden=true;$('delete').hidden=true;$('crumb').textContent='/ Streams';
    displaySave();
  }
  function renderStreams(){
    if(!S.streams)return;
    const streams=Array.isArray(S.streams.streams)?S.streams.streams:[];
    const queue=Array.isArray(S.streams.queue)?S.streams.queue:[];
    const awaiting=queue.filter(isAwaiting).length;
    $('queue-count').textContent=awaiting;
    $('queue-count').hidden=!awaiting;
    $('queue-summary').textContent=awaiting+' awaiting review';
    $('stream-list').innerHTML=streams.length?streams.map(s=>{
      const last=queue.find(q=>q.stream_id===s.id);
      const released=queue.some(q=>q.stream_id===s.id&&q.edition_id);
      const next=s.next_due_at||s.next_run_at;
      return `<article class="stream-card"><div class="stream-card-heading"><h3>${E(s.name)}</h3><span class="pill">${s.mode==='broadcast'?'Broadcast':'Review queue'}</span></div>
        <p>${E(streamTemplates.find(([key])=>key===s.template)?.[1]||'Custom dispatch')} · Every ${E(s.cadence_hours)} hours · ${E(s.scope?.channels?.length||0)} Channel${s.scope?.channels?.length===1?'':'s'}</p>
        <p class="stream-muted">Next cycle: ${E(streamDate(next))}${last?' · Latest: '+E(last.status||'prepared'):''}</p>
        <div class="stream-card-actions"><button class="secondary" data-stream-edit="${E(s.id)}">Settings</button><button class="secondary" data-stream-run="${E(s.id)}">Run now</button>${released?`<button class="secondary" data-stream-site="${E(s.id)}">Download stream site</button>`:''}</div></article>`;
    }).join(''):'<div class="stream-empty"><h3>No streams yet.</h3><p>Create one to turn permitted Braid material into a recurring private dispatch draft.</p></div>';
    $('stream-queue').innerHTML=queue.length?queue.map(q=>{
      const stream=streams.find(s=>s.id===q.stream_id);
      const warnings=streamWarnings(q.warnings);
      const changes=Array.isArray(q.privacy_changes)?q.privacy_changes:[];
      const status=q.status||'prepared';
      return `<article class="queue-card"><div class="queue-card-top"><strong>${E(stream?.name||'Stream dispatch')}</strong><span class="pill">${E(status.replaceAll('_',' '))}</span></div>
        <p>${E(streamDate(q.created_at))} · ${E(q.change_count||0)} new item${q.change_count===1?'':'s'}${q.selected_count!=null?' · '+E(q.selected_count)+' selected':''} · ${E(q.privacy_changes_count||0)} privacy change${q.privacy_changes_count===1?'':'s'}</p>
        ${q.error?`<p class="form-warning">${E(q.error)}</p>`:''}
        ${changes.length?`<details><summary>Inspect privacy changes</summary><ul>${changes.map(change=>`<li>${E(change.category||'Private detail')} in ${E(change.field||'dispatch')} → ${E(change.replacement||'[redacted]')}</li>`).join('')}</ul>${q.privacy_changes_count>changes.length?`<p>Showing the first ${changes.length} of ${E(q.privacy_changes_count)} changes.</p>`:''}</details>`:''}
        ${warnings.length?`<details><summary>${warnings.length} observation warning${warnings.length===1?'':'s'}</summary><ul>${warnings.map(w=>`<li>${E(w)}</li>`).join('')}</ul></details>`:''}
        <div class="stream-card-actions">${q.draft_id?`<button class="secondary" data-queue-draft="${E(q.draft_id)}">${isAwaiting(q)?'Review dispatch':'Open edition'}</button>`:''}${status==='delivery_failed'?`<button class="secondary" data-queue-retry="${E(q.stream_id)}">Retry site update</button>`:''}</div></article>`;
    }).join(''):'<div class="stream-empty"><h3>Queue is clear.</h3><p>Run a stream now, or keep Folio and Braid running for its next cycle.</p></div>';
  }
  function showStreamEditor(stream=null){
    S.streamEdit=structuredClone(stream||streamDefaults());
    $('stream-editor').hidden=false;
    renderStreamEditor();
    $('stream-editor').scrollIntoView({behavior:'smooth',block:'start'});
  }
  function renderStreamEditor(){
    const s=S.streamEdit;if(!s)return;
    const scope=s.scope||{},privacy=s.privacy||{},selected=new Set(scope.channels||[]);
    const connectedChannels=Array.isArray(S.streams?.channels)?S.streams.channels:[];
    const channels=[...connectedChannels,...[...selected].filter(id=>!connectedChannels.some(c=>c.id===id)).map(id=>({id,name:'Saved Channel '+id.slice(0,8)}))];
    $('stream-editor').innerHTML=`<div class="stream-editor-head"><div><span class="eyebrow">STREAM SETTINGS</span><h2>${s.id?'Edit stream':'New stream'}</h2></div><button id="stream-cancel" class="ghost">Close</button></div>
      <form id="stream-form"><div class="field"><label for="s-name">Public stream name</label><input id="s-name" maxlength="300" required value="${E(s.name||'')}" placeholder="Intersignal Lab"><small>This label appears in dispatch titles and the exported stream site.</small></div>
      <div class="stream-form-grid"><div class="field"><label for="s-template">Dispatch format</label><select id="s-template">${streamTemplates.map(([key,label])=>`<option value="${key}" ${s.template===key?'selected':''}>${E(label)}</option>`).join('')}</select></div>
      <div class="field"><label for="s-cadence">Cadence in hours</label><input id="s-cadence" type="number" min="1" max="720" step="1" required value="${E(s.cadence_hours||24)}"><small>24 = daily · 168 = weekly. The next cycle follows this interval; use Run now to start sooner. Folio and Braid must be running.</small></div></div>
      <div class="stream-subsection"><h3>Observe</h3><p>Select up to eight Braid Channels and the material types this stream may read. Each cycle checks up to five conversations per Channel. Braid returns a full visible Channel view; Folio builds dispatches only from the selected material types and discards the rest.</p>
      <div class="stream-channel-list">${channels.length?channels.map(c=>`<label class="stream-check"><input type="checkbox" data-channel-id="${E(c.id)}" ${selected.has(c.id)?'checked':''}><span>${E(c.name||c.id)}</span></label>`).join(''):'<p class="small-note">Connect to Braid to choose Channels.</p>'}</div>
      <button type="button" id="streams-connect" class="text-button">${S.streams?.connected?'Reconnect or change Braid session':'Connect to Braid'}</button>
      <div class="stream-check-grid"><label class="stream-check"><input id="s-notes" type="checkbox" ${scope.notes?'checked':''}><span>Channel notes</span></label><label class="stream-check"><input id="s-objects" type="checkbox" ${scope.objects?'checked':''}><span>Indexed field material</span></label><label class="stream-check"><input id="s-conversations" type="checkbox" ${scope.conversations?'checked':''}><span>Completed conversations</span></label></div>
      <div class="field"><label for="s-tag">Exact source tag <span class="optional">required for Broadcast</span></label><input id="s-tag" maxlength="48" value="${E(scope.tag||'')}" placeholder="For example: public-field-note"><small>Broadcast requires a tag. Only material with this #tag can be released automatically. Folio never searches outside the selected Channels.</small></div></div>
      <div class="stream-subsection"><h3>Sanitize</h3><p>Folio applies these local rules before a dispatch is prepared. Review the generated text and its privacy changes before sharing.</p>
      <div class="stream-check-grid">${privacyFlags.map(([key,label])=>`<label class="stream-check"><input type="checkbox" data-privacy-flag="${key}" ${privacy[key]!==false?'checked':''}><span>${E(label)}</span></label>`).join('')}</div>
      <div class="streams-section-heading"><h4>Your literal replacement rules</h4><button id="stream-add-rule" type="button" class="text-button">+ Add rule</button></div>
      <div id="stream-rules">${(privacy.rules||[]).map(renderRule).join('')}</div><p class="small-note">For example, replace a private name with “a collaborator.” Rules match the exact phrase you enter. Folio treats the replacement as plain text.</p></div>
      <div class="stream-subsection"><h3>Release</h3><div class="field"><label for="s-mode">Publishing mode</label><select id="s-mode"><option value="review" ${s.mode!=='broadcast'?'selected':''}>Review queue · approval required</option><option value="broadcast" ${s.mode==='broadcast'?'selected':''}>Broadcast · automatic local site update</option></select></div>
      <div class="field"><label for="s-site-directory">Static site parent folder <span class="optional">required for Broadcast</span></label><input id="s-site-directory" value="${E(s.site_directory||'')}" placeholder="/Users/you/Sites/folio"><small>Choose an existing absolute local folder. Folio writes only inside its dedicated folio-stream-&lt;full-stream-id&gt; child folder there. Review may leave this blank; when set, approved exports update that folder. If another service serves or syncs it, new pages may become public as soon as they are written.</small></div>
      <div id="broadcast-choice" ${s.mode==='broadcast'?'':'hidden'}><div class="info">Broadcast automatically exports an edition and updates the local static stream site after privacy checks. Folio itself does not upload to a remote host; a host or sync service watching your chosen folder may publish it. All built-in privacy checks must stay on. Add literal rules for names and general locations. These checks can still miss sensitive facts and identifying combinations.</div><p id="broadcast-tag-warning" class="form-warning" ${scope.tag?'hidden':''}>Enter a source tag above. Untagged material cannot be released automatically.</p><label class="stream-check"><input id="s-broadcast-ack" type="checkbox"><span>I explicitly enable automatic writes to the chosen site folder and understand that each edition is released without human review. I must reconfirm this whenever I save Broadcast settings.</span></label></div></div>
      <div class="stream-editor-actions"><button class="primary" type="submit">Save stream</button>${s.id?'<button id="stream-delete" type="button" class="ghost">Delete stream</button>':''}<span>Default: private review queue. Existing folios stay as they are.</span></div></form>`;
    $('stream-form').onsubmit=e=>{e.preventDefault();safely(saveStream);};
    $('stream-cancel').onclick=()=>{$('stream-editor').hidden=true;S.streamEdit=null;};
    $('s-mode').onchange=e=>{if(e.target.value==='broadcast'){$('s-broadcast-ack').checked=false;}$('broadcast-choice').hidden=e.target.value!=='broadcast';$('broadcast-tag-warning').hidden=!!$('s-tag').value.trim();};
    $('s-tag').oninput=()=>{$('broadcast-tag-warning').hidden=!!$('s-tag').value.trim();};
    $('stream-add-rule').onclick=()=>{$('stream-rules').insertAdjacentHTML('beforeend',renderRule({category:'custom',find:'',replace:'[redacted]'}));};
    $('stream-rules').onclick=e=>{const button=e.target.closest('[data-remove-rule]');if(button)button.closest('.stream-rule').remove();};
    $('streams-connect').onclick=()=>modal('braid-dialog');
    if(s.id)$('stream-delete').onclick=()=>safely(deleteStream);
  }
  function renderRule(rule){
    return `<div class="stream-rule"><div class="field"><label>Category<select data-rule-category>${ruleCategories.map(([key,label])=>`<option value="${key}" ${rule.category===key?'selected':''}>${E(label)}</option>`).join('')}</select></label></div><div class="field"><label>Exact private phrase<input data-rule-find value="${E(rule.find||'')}" placeholder="Private phrase"></label></div><div class="field"><label>Public replacement<input data-rule-replace value="${E(rule.replace??'[redacted]')}" placeholder="[redacted]"></label></div><button type="button" class="ghost" data-remove-rule aria-label="Remove replacement rule">Remove</button></div>`;
  }
  function readStreamForm(){
    const base=S.streamEdit||streamDefaults();
    return {...base,name:$('s-name').value.trim(),template:$('s-template').value,site_directory:$('s-site-directory').value.trim(),
      cadence_hours:Number($('s-cadence').value),mode:$('s-mode').value,
      broadcast_ack:$('s-mode').value==='broadcast'&&$('s-broadcast-ack').checked,
      scope:{channels:[...document.querySelectorAll('#stream-form [data-channel-id]:checked')].map(el=>el.dataset.channelId),
        notes:$('s-notes').checked,objects:$('s-objects').checked,conversations:$('s-conversations').checked,tag:$('s-tag').value.trim()},
      privacy:{...Object.fromEntries([...document.querySelectorAll('#stream-form [data-privacy-flag]')].map(el=>[el.dataset.privacyFlag,el.checked])),
        rules:[...document.querySelectorAll('#stream-rules .stream-rule')].map(row=>({
          category:row.querySelector('[data-rule-category]').value,
          find:row.querySelector('[data-rule-find]').value,
          replace:row.querySelector('[data-rule-replace]').value
        }))}};
  }
  async function saveStream(){
    const stream=readStreamForm();
    if(!stream.name)throw new Error('Give this stream a name.');
    if(!Number.isInteger(stream.cadence_hours)||stream.cadence_hours<1||stream.cadence_hours>720)throw new Error('Enter a cadence between 1 and 720 hours.');
    if(!stream.scope.channels.length||stream.scope.channels.length>8)throw new Error('Choose between one and eight Braid Channels.');
    if(![stream.scope.notes,stream.scope.objects,stream.scope.conversations].some(Boolean))throw new Error('Choose at least one source type.');
    if(stream.privacy.rules.some(rule=>!rule.find.trim()||!rule.replace.trim()))throw new Error('Each replacement rule needs a private phrase and public replacement.');
    if(stream.site_directory&&!absoluteLocalPath(stream.site_directory))throw new Error('Choose an absolute local folder path for the static site parent folder.');
    if(stream.mode==='broadcast'&&!stream.scope.tag)throw new Error('Broadcast requires an explicit source tag. Only tagged material can be released automatically.');
    if(stream.mode==='broadcast'&&!stream.site_directory)throw new Error('Broadcast requires a static site parent folder.');
    if(stream.mode==='broadcast'&&privacyFlags.some(([key])=>!stream.privacy[key]))throw new Error('Keep all built-in privacy checks on for Broadcast. Add literal rules for names and general locations.');
    if(stream.mode==='broadcast'&&!stream.broadcast_ack)throw new Error('Explicitly acknowledge automatic local site updates before enabling Broadcast.');
    await api('streams/save',{stream});
    $('stream-editor').hidden=true;S.streamEdit=null;await refreshStreams();toast('Stream saved.');
  }
  async function deleteStream(){
    const stream=readStreamForm();
    if(!confirm('Delete this stream and stop its future cycles? Existing drafts and exported editions remain in your library.'))return;
    await api('streams/delete',{id:stream.id,revision:stream.revision});
    $('stream-editor').hidden=true;S.streamEdit=null;await refreshStreams();toast('Stream deleted.');
  }
  async function runStream(id){
    const result=await api('streams/run',{id});
    await Promise.all([refreshStreams(),refreshLibrary()]);
    const warnings=streamWarnings(result.warnings);
    const message=result.status==='blocked'?'Cycle paused: '+(result.error||'The selected sources could not be read.'):
      result.status==='no_change'?'No new qualifying material was found in the selected scope.':
      result.status==='released'?'A new edition and local stream site were updated. Folio did not upload them.':
      result.status==='delivery_failed'?'The edition was exported, but the local stream site could not be updated. Use Retry site update.':
      result.status==='needs_review'?'Automatic export paused. Review the draft and privacy findings.':
      'A dispatch draft is ready in the review queue.';
    $('stream-notice').textContent=message+(warnings.length?' '+warnings.length+' warning(s) are recorded in the queue.':'');
    $('stream-notice').hidden=false;
  }
  async function retryStreamSite(id){
    const result=await api('streams/publish',{id});
    await refreshStreams();
    const latest=S.streams.queue.find(q=>q.stream_id===id&&q.edition_id);
    $('stream-notice').textContent=(result.status==='delivery_failed'||latest?.status==='delivery_failed')?'The site update still needs attention. Check the queue error.':'The local stream site was updated. Folio did not upload it.';
    $('stream-notice').hidden=false;
  }
  async function downloadStreamSite(id){
    const r=await fetch('/api/streams/site?id='+encodeURIComponent(id),{headers:{'X-Folio-Token':token||''},cache:'no-store'});
    if(!r.ok){const x=await r.json();throw new Error(x.error||'Stream site download failed.');}
    const name=/filename="([^"]+)"/.exec(r.headers.get('Content-Disposition')||'')?.[1]||'Folio-stream-site.zip';
    const url=URL.createObjectURL(await r.blob()),a=document.createElement('a');a.href=url;a.download=name;a.click();
    setTimeout(()=>URL.revokeObjectURL(url),30000);
    toast('Static stream site downloaded. Folio did not upload this ZIP.');
  }
  function updateHeading(){
    if(!S.draft)return;
    $('crumb').textContent='/ '+S.draft.title.slice(0,36);
    $('workspace-label').textContent=S.draft.approved_digest?'REVIEWED LOCAL EDITION':'PRIVATE DRAFT';
    $('edition-pill').textContent=S.draft.editions.length?S.draft.editions.length+' exported edition'+(S.draft.editions.length===1?'':'s'):'Not exported';
    $('capsule-dot').className=S.draft.capsule.enabled?'on':'';
    document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===S.view));
  }
  function field(name,label,value,placeholder='',rows=3){return `<div class="field"><label for="f-${name}">${E(label)}</label><textarea id="f-${name}" data-field="${E(name)}" rows="${rows}" placeholder="${E(placeholder)}">${E(value)}</textarea></div>`;}
  function compose(){
    const d=S.draft;
    $('editor').innerHTML=`<label class="form-label" for="f-title">PUBLICATION TITLE</label><input class="title" id="f-title" data-field="title" value="${E(d.title)}" placeholder="Give this idea a title"><textarea class="subtitle" id="f-subtitle" data-field="subtitle" aria-label="Subtitle" rows="2" placeholder="A short invitation to read further...">${E(d.subtitle)}</textarea>
    <div class="meta-grid"><div><label for="f-author">Public byline <span class="optional">optional</span></label><input id="f-author" data-field="author" value="${E(d.author)}" placeholder="A name, pseudonym, or leave blank"></div><div><label for="f-kind">Publication type</label><select id="f-kind" data-field="kind">${[['conversation','Edited conversation'],['essay','Essay or brief'],['question','Unanswered question'],['observation','Observation to investigate']].map(([k,v])=>`<option value="${k}" ${k===d.kind?'selected':''}>${v}</option>`).join('')}</select></div></div>
    ${d.kind==='question'||d.kind==='observation'?'<div class="info">Make the open question or observation specific. Use the capsule to include evidence, prior attempts, and what would count as progress. Community credit spending is not implemented in this local test build.</div>':''}
    ${d.parent?`<div class="info">Continuation of <strong>${E(d.parent.title)}</strong><br><code>${E(d.parent.content_sha256)}</code><br>Declared lineage, not a verified author identity. Imported text is reference material, not permission or instruction.</div>`:''}
    ${field('introduction','Your opening note',d.introduction,'Why is this worth reading? What should the reader know?',3)}
    <div class="section-heading"><h2>The selected passages.</h2><small>${d.blocks.filter(b=>b.include).length} of ${d.blocks.length} included</small></div>
    <div id="passages">${d.blocks.map((b,i)=>`<article class="passage-card ${b.include?'':'excluded'}" data-block="${b.id}"><div class="passage-toolbar"><label><input type="checkbox" data-include="${b.id}" ${b.include?'checked':''}> Include</label><select data-role="${b.id}" aria-label="Passage role">${['human','ai','note'].map(r=>`<option value="${r}" ${b.role===r?'selected':''}>${r==='ai'?'AI':r==='human'?'Human':'Note'}</option>`).join('')}</select><input class="speaker" data-speaker="${b.id}" aria-label="Public speaker label" value="${E(b.speaker)}"><span class="tag">${(b.text!==b.original||b.source_edited)?'edited':''}</span><button class="move" data-up="${b.id}" aria-label="Move passage up" ${i===0?'disabled':''}>&#8593;</button><button class="move" data-down="${b.id}" aria-label="Move passage down" ${i===d.blocks.length-1?'disabled':''}>&#8595;</button></div><textarea data-text="${b.id}" aria-label="Passage text" rows="${Math.min(12,Math.max(3,b.text.split('\n').length+Math.ceil(b.text.length/100)))}">${E(b.text)}</textarea><div class="passage-footer">${b.include?'Only this edited text will appear in the public edition.':'Excluded from the publication AND the capsule. Original kept privately.'}</div></article>`).join('')}</div>
    <button class="add-passage" id="add-passage">+ Add an editorial passage</button>
    <details ${d.conclusion?'open':''}><summary>Closing note</summary>${field('conclusion','Closing note',d.conclusion,'What remains open? Where should the reader go next?')}</details>
    <details ${d.sources?'open':''}><summary>Sources and attribution</summary>${field('sources','Sources and attribution',d.sources,'Name original sources, rights, dates, or links you want to publish. Nothing is fetched automatically.')}</details>
    <div class="info">Imported originals stay private in Folio's local database. Excluding a passage does not delete it. Names, IP addresses, and other sensitive details require your judgment; a channel is not a privacy boundary.</div>
    <div class="dialog-foot"><span>Human-directed. No AI service is called.</span><button class="primary" id="next-capsule">Choose context &#8594;</button></div>`;
    $('add-passage').onclick=()=>{S.draft.blocks.push({id:uid(),role:'note',speaker:'Editorial note',text:'',original:'',include:true});mark();render();};
    $('next-capsule').onclick=()=>safely(()=>switchView('capsule'));
  }
  const capsuleLabels={background:'Background worth carrying',question:'The question to investigate',observations:'Evidence and observations',attempted:'What has already been tried',constraints:'Scope and constraints',uncertainty:'Uncertainty and limitations'};
  const capsulePlaceholders={background:'Definitions and background the next reader will need.',question:'What remains unanswered? What would count as progress?',observations:'What was actually observed? Separate evidence from interpretation.',attempted:'Results, failed attempts, and approaches already ruled out.',constraints:'Boundaries, assumptions, versions, or conditions.',uncertainty:'What might be wrong? What has not been verified?'};
  const capsuleKeys=Object.keys(capsuleLabels);
  function capsuleOverview(){
    const c=S.draft.capsule, filled=capsuleKeys.filter(k=>String(c[k]||'').trim());
    $('capsule-count').textContent=filled.length+' of '+capsuleKeys.length+' added';
    $('capsule-summary').innerHTML=filled.length?filled.map(k=>`<li class="capsule-summary-row"><div><strong>${E(capsuleLabels[k])}</strong><span>${E(String(c[k]).replace(/\s+/g,' ').trim().slice(0,140))}${String(c[k]).trim().length>140?'…':''}</span></div><button type="button" class="text-button" data-capsule-edit="${k}" aria-label="Edit ${E(capsuleLabels[k])}">Edit</button></li>`).join(''):'<li class="capsule-summary-empty">No context added yet. Choose a topic and write only what the reader needs.</li>';
    $('capsule-add').disabled=filled.length===capsuleKeys.length;
    $('capsule-clear').disabled=!c[S.capsuleField];
    $('capsule-field').querySelectorAll('option').forEach(option=>{option.textContent=capsuleLabels[option.value]+(filled.includes(option.value)?' · added':'');});
  }
  function capsule(){
    const c=S.draft.capsule, included=S.draft.blocks.filter(b=>b.include);
    if(!capsuleKeys.includes(S.capsuleField))S.capsuleField=capsuleKeys.find(k=>String(c[k]||'').trim())||capsuleKeys[0];
    const active=S.capsuleField;
    $('editor').innerHTML=`<div class="capsule-heading"><div><span class="eyebrow">OPTIONAL / EXPLICIT / INSPECTABLE</span><h2 style="margin-top:9px">Give the reader a starting point.</h2></div><label class="toggle-label"><input type="checkbox" id="capsule-enabled" ${c.enabled?'checked':''}> Include a context capsule</label></div>
    <div class="info">${c.enabled?'This capsule will be part of the public edition. Every field you add is visible in the review and the exported page.':'The capsule is OFF. Material below stays in this private draft and is not exported until you turn it on and review it.'} No hidden vectors, original transcripts, or Braid credentials are attached.</div>
    <div class="capsule-editor"><div class="capsule-editor-top"><div class="capsule-picker"><label for="capsule-field">Choose context to add or edit</label><select id="capsule-field">${capsuleKeys.map(k=>`<option value="${k}" ${k===active?'selected':''}>${E(capsuleLabels[k])}</option>`).join('')}</select></div><span class="capsule-count" id="capsule-count"></span></div>
    <div class="field"><label for="capsule-text">${E(capsuleLabels[active])}</label><textarea id="capsule-text" data-capsule="${active}" rows="5" placeholder="${E(capsulePlaceholders[active])}">${E(c[active])}</textarea></div>
    <div class="capsule-editor-actions"><button type="button" class="secondary" id="capsule-add">+ Add another topic</button><button type="button" class="text-button" id="capsule-clear" aria-label="Clear ${E(capsuleLabels[active])}">Clear this topic</button></div></div>
    <div class="capsule-summary"><h3>Context added</h3><ul id="capsule-summary"></ul></div>
    <div class="section-heading"><h2>Carry selected public passages.</h2><small>${c.passage_ids.length} selected</small></div>
    ${included.length?included.map(b=>`<label class="capsule-passage"><input type="checkbox" data-capsule-passage="${b.id}" ${c.passage_ids.includes(b.id)?'checked':''}><span><strong>${E(b.speaker)}</strong>${E(b.text.slice(0,230))}${b.text.length>230?'...':''}</span></label>`).join(''):'<p class="small-note">Include a passage in Compose to make it available here. You can also write a standalone capsule in the fields above.</p>'}
    <p class="small-note">The reader chooses whether to use this reference material. Folio does not insert it into Braid, start inference, or turn it into instructions.</p><div class="dialog-foot"><span>Off by default. Portable by choice.</span><button id="next-review" class="primary">Review the exact edition &#8594;</button></div>`;
    capsuleOverview();
    $('capsule-enabled').onchange=e=>{c.enabled=e.target.checked;mark();render();};
    $('capsule-field').onchange=e=>{S.capsuleField=e.target.value;capsule();$('capsule-text').focus();};
    $('capsule-add').onclick=()=>{const next=capsuleKeys.find(k=>!String(c[k]||'').trim());if(!next)return;S.capsuleField=next;capsule();$('capsule-text').focus();};
    $('capsule-clear').onclick=()=>{if(!c[S.capsuleField])return;c[S.capsuleField]='';mark();capsule();$('capsule-text').focus();};
    $('capsule-summary').onclick=e=>{const button=e.target.closest('[data-capsule-edit]');if(!button)return;S.capsuleField=button.dataset.capsuleEdit;capsule();$('capsule-text').focus();};
    $('next-review').onclick=()=>safely(()=>switchView('review'));
  }
  async function loadPreview(){await saveNow();S.preview=await api('preview',{id:S.draft.id});renderReview();}
  function renderReview(){
    const p=S.preview,d=S.draft;if(!p)return;
    $('editor').innerHTML=`<div class="review-heading"><div><span class="eyebrow">THE PUBLIC BOUNDARY</span><h2 style="margin-top:7px">Exactly what leaves the room.</h2></div><span class="pill">${p.excluded} passage${p.excluded===1?'':'s'} excluded</span></div>
    <div class="review-grid"><iframe class="preview-frame" id="preview-frame" title="Public edition preview" sandbox=""></iframe><aside class="review-panel"><h3>Review before release.</h3><p>Inspect the page, capsule, and public data below. Exporting writes local files. If a stream site folder is served or synced by your host, its approved page may become public.</p><div class="status-line">${p.findings.length?p.findings.length+' possible privacy issue'+(p.findings.length===1?'':'s'):'No literal-pattern flags found.'}</div>
    ${p.findings.slice(0,12).map(f=>`<div class="finding"><strong>${E(f.kind)} / ${E(f.field)}</strong>${E(f.excerpt)}</div>`).join('')}${p.findings.length>12?'<p>More findings are listed below.</p>':''}
    <p>This scan can miss names, secrets, and identifying combinations. It is not an anonymity guarantee.</p>
    <label class="checkbox-label"><input id="review-confirm" type="checkbox" ${p.approved?'checked':''}><span>I reviewed all public text and capsule contents, removed what should remain private, and have the right to share this edition.</span></label>
    <button class="secondary" id="approve" ${p.approved?'disabled':''}>${p.approved?'This edition is approved':'Approve this exact edition'}</button>
    <button class="primary" id="export" ${p.approved?'':'disabled'}>Export publication ZIP &#8595;</button>
    <p id="export-status">${d.editions.length?'Your exported editions remain available below.':'Nothing has been exported yet.'}</p><p class="hash">Content SHA-256<br>${E(p.digest)}</p><p>Any public edit invalidates approval. Hashes establish content consistency, not verified authorship.</p></aside></div>
    <details><summary>Inspect exact public JSON (plus edition metadata on export)</summary><pre class="review-json">${E(p.public_json)}</pre></details>
    ${p.findings.length?`<details><summary>All privacy scan findings</summary><pre class="review-json">${E(JSON.stringify(p.findings,null,2))}</pre></details>`:''}
    ${p.context_text?`<details><summary>Readable context capsule / copy for deliberate use</summary><pre class="review-json">${E(p.context_text)}</pre><button class="secondary" id="copy-context">Copy reviewed context text</button><p class="small-note">Reference text only. Paste deliberately; Folio does not grant it authority or send it anywhere.</p></details>`:''}
    ${d.editions.length?`<div class="share-box"><h3>Your exported editions.</h3>${d.editions.map(e=>`<div class="edition-row"><span>Edition ${e.edition_number} &middot; ${E(new Date(e.published_at).toLocaleString())}</span><button class="secondary" data-download="${E(e.id)}">Save ZIP again</button></div>`).join('')}</div>`:''}
    <div class="share-box"><h3>Publish anywhere. Keep the work yours.</h3><p>For manual editions, upload the extracted folder to your chosen host. A stream in either mode can update its configured local site folder after release; a host serving or syncing that folder may publish it. Folio itself does not upload or post to social networks. Once it is live, open this edition's public page and paste that page's exact URL below.</p><label for="hosted-url">Exact public page URL of this Folio edition</label><input id="hosted-url" placeholder="https://your-site.example/your-folio-edition/" ${p.approved?'':'disabled'}><div class="share-actions"><button class="secondary" id="share-copy" ${p.approved?'':'disabled'}>Copy sharing text</button><button class="secondary" id="share-x" ${p.approved?'':'disabled'}>Open X composer</button><button class="secondary" id="share-facebook" ${p.approved?'':'disabled'}>Open Facebook share</button></div><p class="small-note">Only the title, subtitle, and URL you provide are included. Folio cannot verify that the URL points to this edition; check the link preview before posting. Known local addresses and the current Folio token are rejected.</p></div>`;
    $('preview-frame').srcdoc=p.html;
    $('approve').onclick=()=>safely(()=>busy($('approve'),async()=>{
      if(!$('review-confirm').checked)throw new Error('Check the review confirmation after inspecting the complete edition.');
      S.draft=await api('approve',{id:d.id,digest:p.digest,confirmed:true});await loadPreview();updateHeading();toast('Approved. Public edits will require a fresh review.');
    }));
    $('export').onclick=()=>safely(()=>busy($('export'),async()=>{
      const record=await api('export',{id:d.id});await download(record.id);S.draft=await api('draft?id='+d.id);await refreshLibrary();updateHeading();await loadPreview();if(record.site_error){toast('Edition exported, but the local stream site update failed. Open Streams to retry.');error(new Error('Local stream site update failed: '+record.site_error));}
      else toast('Edition exported locally. Folio did not upload it.');
    }));
    if($('copy-context'))$('copy-context').onclick=()=>safely(async()=>{if(!p.approved)throw new Error('Approve this exact edition before copying its capsule for use elsewhere.');await navigator.clipboard.writeText(p.context_text);toast('Context copied. No message sent to Braid.');});
    document.querySelectorAll('[data-download]').forEach(b=>b.onclick=()=>safely(()=>download(b.dataset.download)));
    function shareData(){
      const raw=$('hosted-url').value.trim();let u;
      try{u=new URL(raw);}catch{throw new Error('Enter the exact public page URL of this edition first. Folio has not uploaded it.');}
      const host=u.hostname.toLowerCase();
      if(!['http:','https:'].includes(u.protocol)||u.username||u.password||host==='localhost'||host.endsWith('.localhost')||host.endsWith('.local')||host.endsWith('.internal')||(!host.includes('.')&&!host.includes(':'))||/^\[(::|::1|f[cd][0-9a-f]|fe[89ab])/.test(host)||/^(0\.|127\.|169\.254\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host)||(token&&raw.includes(token)))throw new Error('Use a public http(s) page URL, not a local app address, a Folio session URL, or embedded credentials.');
      const b=JSON.parse(p.public_json);return {url:u.href,text:b.title+(b.subtitle?'\n'+b.subtitle:'')};
    }
    $('share-copy').onclick=()=>safely(async()=>{const s=shareData();await navigator.clipboard.writeText(s.text+'\n'+s.url);toast('Sharing text copied.');});
    $('share-x').onclick=()=>safely(()=>{const s=shareData();window.open('https://twitter.com/intent/tweet?text='+encodeURIComponent(s.text)+'&url='+encodeURIComponent(s.url),'_blank','noopener,noreferrer');});
    $('share-facebook').onclick=()=>safely(()=>{const s=shareData();window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(s.url),'_blank','noopener,noreferrer');});
  }
  async function download(id){
    const r=await fetch('/api/download?id='+encodeURIComponent(id),{headers:{'X-Folio-Token':token},cache:'no-store'});
    if(!r.ok){const x=await r.json();throw new Error(x.error||'Download failed.');}
    const name=/filename="([^"]+)"/.exec(r.headers.get('Content-Disposition')||'')?.[1]||'Folio-edition.zip';
    const url=URL.createObjectURL(await r.blob());const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
  }
  function render(){updateHeading();if(S.view==='compose')compose();else if(S.view==='capsule')capsule();else if(S.preview)renderReview();}
  async function switchView(view){await saveNow();S.view=view;updateHeading();if(view==='review')await loadPreview();else render();}
  $('editor').addEventListener('input',event=>{
    const el=event.target;if(!S.draft)return;
    if(el.dataset.field){S.draft[el.dataset.field]=el.value;mark();}
    if(el.dataset.text){const b=S.draft.blocks.find(b=>b.id===el.dataset.text);b.text=el.value;mark();el.closest('.passage-card').querySelector('.tag').textContent=(b.text!==b.original||b.source_edited)?'edited':'';}
    if(el.dataset.speaker){S.draft.blocks.find(b=>b.id===el.dataset.speaker).speaker=el.value;mark();}
    if(el.dataset.capsule){S.draft.capsule[el.dataset.capsule]=el.value;mark();capsuleOverview();}
  });
  $('editor').addEventListener('change',event=>{
    const el=event.target;if(!S.draft)return;
    if(el.dataset.include){const b=S.draft.blocks.find(b=>b.id===el.dataset.include);b.include=el.checked;if(!b.include)S.draft.capsule.passage_ids=S.draft.capsule.passage_ids.filter(id=>id!==b.id);mark();render();}
    if(el.dataset.role){S.draft.blocks.find(b=>b.id===el.dataset.role).role=el.value;mark();}
    if(el.dataset.field==='kind'){S.draft.kind=el.value;mark();render();}
    if(el.dataset.capsulePassage){const ids=new Set(S.draft.capsule.passage_ids);el.checked?ids.add(el.dataset.capsulePassage):ids.delete(el.dataset.capsulePassage);S.draft.capsule.passage_ids=[...ids];mark();render();}
  });
  $('editor').addEventListener('click',event=>{const el=event.target.closest('[data-up],[data-down]');if(!el)return;const id=el.dataset.up||el.dataset.down,i=S.draft.blocks.findIndex(b=>b.id===id),j=i+(el.dataset.up?-1:1);if(j<0||j>=S.draft.blocks.length)return;[S.draft.blocks[i],S.draft.blocks[j]]=[S.draft.blocks[j],S.draft.blocks[i]];mark();render();});
  document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>safely(()=>switchView(b.dataset.view)));
  $('library').onclick=e=>{const b=e.target.closest('[data-id]');if(b)safely(()=>openDraft(b.dataset.id));};
  $('streams-open').onclick=()=>safely(openStreams);
  $('welcome-streams').onclick=()=>safely(openStreams);
  $('stream-new').onclick=()=>showStreamEditor();
  $('streams-refresh').onclick=()=>safely(async()=>{await refreshStreams();toast('Stream status refreshed.');});
  $('stream-list').onclick=e=>{
    const edit=e.target.closest('[data-stream-edit]'),run=e.target.closest('[data-stream-run]'),site=e.target.closest('[data-stream-site]');
    if(edit){const stream=S.streams.streams.find(s=>s.id===edit.dataset.streamEdit);if(stream)showStreamEditor(stream);}
    else if(run)safely(()=>busy(run,()=>runStream(run.dataset.streamRun)));
    else if(site)safely(()=>busy(site,()=>downloadStreamSite(site.dataset.streamSite)));
  };
  $('stream-queue').onclick=e=>{
    const draft=e.target.closest('[data-queue-draft]'),retry=e.target.closest('[data-queue-retry]');
    if(draft)safely(async()=>{await openDraft(draft.dataset.queueDraft);await switchView('review');});
    else if(retry)safely(()=>busy(retry,()=>retryStreamSite(retry.dataset.queueRetry)));
  };
  const create=()=>safely(async()=>{await saveNow();await setDraft(await api('new',{}));$('f-title').focus();$('f-title').select();});
  $('new').onclick=create;$('welcome-new').onclick=create;
  $('sample').onclick=()=>safely(async()=>{await saveNow();await setDraft(await api('sample',{}));});
  $('help').onclick=()=>modal('help-dialog');
  $('import-open').onclick=()=>modal('import-dialog');
  $('braid-open').onclick=()=>modal('braid-dialog');$('welcome-braid').onclick=()=>modal('braid-dialog');
  document.querySelectorAll('.close').forEach(b=>b.onclick=()=>b.closest('dialog').close());
  $('paste-import').onclick=()=>inDialog($('import-dialog'),()=>busy($('paste-import'),async()=>{await saveNow();await setDraft(await api('import',{content:$('paste-input').value,filename:'pasted.txt'}));$('paste-input').value='';$('import-dialog').close();}));
  $('file-input').onchange=()=>inDialog($('import-dialog'),async()=>{
    const f=$('file-input').files[0];if(!f)return;
    try{if(f.size>4*1024*1024)throw new Error('The file limit is 4 MiB.');if(!/\.(json|txt|md)$/i.test(f.name))throw new Error('Extract edition.json or capsule.json from the publication ZIP first.');const content=await f.text();await saveNow();await setDraft(await api('import',{content,filename:f.name}));$('import-dialog').close();}finally{$('file-input').value='';}
  });
  $('source').onclick=()=>{
    const d=S.draft,audit=d.private_source?.privacy_audit;
    const changes=Array.isArray(audit?.changes)?audit.changes:[];
    const warnings=streamWarnings(audit?.warnings);
    const auditHtml=audit?`<div class="source-audit"><strong>Stream sanitation</strong><p>${E(audit.sanitized_occurrences||0)} replacement${audit.sanitized_occurrences===1?'':'s'} made before this draft was prepared. The log names the category, location, and public replacement without repeating the private match.</p>
      ${changes.length?`<details><summary>Inspect ${changes.length} logged change${changes.length===1?'':'s'}</summary><ul>${changes.map(change=>`<li>${E(change.category||'Private detail')} in ${E(change.field||'dispatch')} → ${E(change.replacement||'[redacted]')}</li>`).join('')}</ul></details>`:''}
      ${warnings.length?`<details><summary>Observation warnings</summary><ul>${warnings.map(w=>`<li>${E(w)}</li>`).join('')}</ul></details>`:''}</div>`:'';
    $('source-contents').innerHTML=`<p class="small-note">${E(d.private_source.kind||'Authored in Folio')}${d.private_source.omitted_incomplete_turns?' / '+d.private_source.omitted_incomplete_turns+' incomplete turn(s) omitted':''}</p>`+auditHtml+d.blocks.map((b,i)=>`<div class="source-item"><strong>Original passage ${i+1}</strong><small> &middot; ${b.include?'included in edited form':'excluded'}</small><pre>${E(b.original)}</pre></div>`).join('');
    modal('source-dialog');
  };
  $('delete').onclick=()=>safely(async()=>{await saveNow();if(!confirm('Delete this private folio and its export copies held by Folio? Files you already downloaded or published elsewhere will remain. This is not secure disk erasure.'))return;await api('delete',{id:S.draft.id,revision:S.draft.revision,confirmed:true});S.draft=null;S.preview=null;S.dirty=false;$('workspace').hidden=true;$('welcome').hidden=false;$('source').hidden=true;$('delete').hidden=true;$('crumb').textContent='';displaySave();await refreshLibrary();});
  $('braid-connect').onclick=()=>inDialog($('braid-dialog'),()=>busy($('braid-connect'),async()=>{
    S.braid=null;S.channel='';S.channelSeq++;$('braid-contents').replaceChildren();$('braid-status').textContent='Connecting to the existing Braid session...';
    try{
      S.braid=await api('braid/connect',{address:$('braid-address').value.trim()});$('braid-status').textContent='Connected to Braid '+S.braid.version+' - read views only.';
      $('braid-contents').innerHTML=`<div class="braid-channel"><label for="braid-channel">Choose a Channel</label><select id="braid-channel"><option value="">Select a Channel...</option>${S.braid.channels.map(c=>`<option value="${E(c.id)}">${E(c.name)}</option>`).join('')}</select></div><div id="braid-items"></div>`;
      if(S.section==='streams'){
        if(S.streamEdit)S.streamEdit=readStreamForm();
        await refreshStreams();
        if(S.streamEdit)renderStreamEditor();
      }
      if(!S.braid.channels.length)$('braid-items').textContent='No Channels are present in this Braid profile. You can still import pasted text into Folio.';
      $('braid-channel').onchange=()=>inDialog($('braid-dialog'),async()=>{
        const id=$('braid-channel').value;S.channel=id;const seq=++S.channelSeq;$('braid-items').textContent=id?'Reading the selected Channel...':'';if(!id)return;
        const v=await api('braid/channel',{id});if(seq!==S.channelSeq)return;
        $('braid-items').innerHTML=`<h3>Conversations</h3>${v.threads.length?v.threads.map(t=>`<div class="import-row"><div><strong>${E(t.title)}</strong><small>Completed exchanges only / up to 100 turns</small></div><button class="secondary" data-thread="${E(t.id)}">Import</button></div>`).join(''):'<p>No conversations in this view.</p>'}<h3>Selected notes and field material</h3>${v.notes.map(n=>`<details><summary>${E(n.title)} / ${E(n.state)}</summary><pre class="note-material">${E(n.text)}</pre><button class="secondary" data-note="${E(n.id)}" data-kind="${E(n.kind)}">Import this material</button></details>`).join('')||'<p>No notes in this view.</p>'}<p class="small-note">${E(v.notice)}</p>`;
        document.querySelectorAll('[data-thread]').forEach(b=>b.onclick=()=>inDialog($('braid-dialog'),()=>busy(b,async()=>{await saveNow();const d=await api('braid/import-thread',{id:b.dataset.thread});await setDraft(d);$('braid-dialog').close();toast('Conversation imported privately. No Braid state was published or sent.');})));
        document.querySelectorAll('[data-note]').forEach(b=>b.onclick=()=>inDialog($('braid-dialog'),()=>busy(b,async()=>{await saveNow();const d=await api('braid/import-note',{id:b.dataset.note,kind:b.dataset.kind,channel:id});await setDraft(d);$('braid-dialog').close();})));
      });
    }catch(e){$('braid-status').textContent='Not connected.';throw e;}
  }));
  $('quit').onclick=()=>safely(async()=>{await saveNow();if(!confirm('Quit Folio? Your local drafts are saved. Braid will keep running independently.'))return;await api('quit',{});document.body.innerHTML='<main style="padding:70px"><h1>Folio is closed.</h1><p>Your library is saved on this computer. You can close this tab.</p></main>';});
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();safely(async()=>{await saveNow();toast('Saved on this computer.');});}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='n'){e.preventDefault();create();}});
  window.addEventListener('beforeunload',e=>{if(S.dirty){e.preventDefault();e.returnValue='';}});
  safely(async()=>{if(!token)throw new Error('Launch Folio using its app or launcher. Opening an old localhost bookmark does not grant access to your library.');await refreshLibrary();await refreshStreams();});
  setInterval(()=>{if(token)Promise.all([refreshStreams(),refreshLibrary()]).catch(()=>{});},60000);
})();
