#!/usr/bin/env python3
"""Zero-third-party-dependency Folio launcher; does not start or stop Braid."""
from __future__ import annotations
import argparse
import json
import os
import platform
import signal
import sys
import time
import webbrowser
from pathlib import Path
from urllib import request

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from folio.server import Server
from folio import __version__
from folio.store import private_dir, private_write
from folio.core import strict_json
from folio.braid import NoRedirect

def default_home():
    if sys.platform=='darwin':return Path.home()/'Library'/'Application Support'/'Intersignal'/'Folio'
    if os.name=='nt':return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData'/'Local')))/'Intersignal'/'Folio'
    return Path(os.environ.get('XDG_DATA_HOME',str(Path.home()/'.local'/'share')))/'intersignal'/'folio'

def lock_profile(path):
    handle=path.open('a+b');handle.seek(0)
    if not handle.read(1):handle.write(b'0');handle.flush()
    handle.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        return handle
    except OSError:handle.close();return None

def existing(home,stop=False,no_browser=False):
    try:
        s=strict_json((home/'session.json').read_bytes());port=int(s['port'])
        if not 1024<=port<=65535:return False
        origin='http://127.0.0.1:'+str(port)
        headers={'X-Folio-Token':s['token']};data=None;url=origin+'/api/state'
        if stop:headers['Content-Type']='application/json';data=b'{}';url=origin+'/api/quit'
        opener=request.build_opener(request.ProxyHandler({}), NoRedirect())
        with opener.open(request.Request(url,data=data,headers=headers),timeout=2) as r:result=json.load(r)
        if not stop and result.get('app')!='intersignal.folio':return False
        if not stop and result.get('version')!=__version__:
            raise RuntimeError('Folio '+str(result.get('version') or 'an unknown version')+' is already running with this profile. Quit it before starting Folio '+__version__+'.')
        if not stop and not no_browser:webbrowser.open(origin+'/#session='+s['token'])
        print('Folio '+('stopped.' if stop else 'is already running: '+origin),flush=True);return True
    except (OSError,KeyError,ValueError):return False

def main():
    if sys.version_info<(3,10):raise RuntimeError('Folio requires Python 3.10 or newer with sqlite3 and ssl.')
    parser=argparse.ArgumentParser(description='Folio 0.2.1 local publishing studio')
    parser.add_argument('--profile',type=Path,default=default_home());parser.add_argument('--port',type=int,default=0)
    parser.add_argument('--no-browser',action='store_true');parser.add_argument('--stop',action='store_true')
    args=parser.parse_args()
    if args.port and not 1024<=args.port<=65535:raise RuntimeError('Use port 0 (automatic) or 1024-65535.')
    if os.name!='nt':os.umask(0o077)
    home=private_dir(args.profile.expanduser().resolve())
    if args.stop:
        if not existing(home,stop=True):raise RuntimeError('No responsive Folio session found. Braid was not touched.')
        return
    lock=lock_profile(home/'session.lock')
    if lock is None:
        for _ in range(12):
            if existing(home,no_browser=args.no_browser):return
            time.sleep(.25)
        raise RuntimeError('Folio holds this profile, but has not responded. Close its terminal/process before reopening. No second server was started.')
    server=Server(home,args.port)
    private_write(home/'session.json',json.dumps({'port':server.server_port,'token':server.token,'pid':os.getpid(),'version':__version__}).encode())
    print('\nFolio '+__version__+' / private local publishing\n'+server.origin+'\nLibrary: '+str(home)+'\nUse Quit Folio in the app to stop. Braid remains independent.\n',flush=True)
    if not args.no_browser:webbrowser.open(server.origin+'/#session='+server.token)
    try:server.serve_forever(poll_interval=.25)
    except KeyboardInterrupt:pass
    finally:
        server.server_close();(home/'session.json').unlink(missing_ok=True);lock.close()

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('Folio could not start: '+str(e),file=sys.stderr);sys.exit(1)
