// src/popup.js
const btn = document.getElementById('run');
const statusEl = document.getElementById('status');
const summaryEl = document.getElementById('summary');
const integrityEl = document.getElementById('integrity');
const scoreValEl = document.getElementById('score-val');
const tagsContainer = document.getElementById('tags');
function setStatus(msg = '') { statusEl.textContent = msg; }
function renderTags(tags) { tagsContainer.innerHTML = ''; (tags||[]).forEach(tag => { const el = document.createElement('span'); el.className = `tag ${tag.type}`; el.textContent = tag.label; tagsContainer.appendChild(el); }); }
async function getActiveTab() { const [tab] = await chrome.tabs.query({active:true,currentWindow:true}); if(!tab) throw new Error('No active tab found.'); return tab; }
async function collectPageText(tabId) { const [{ result }] = await chrome.scripting.executeScript({target:{tabId}, func:()=>{ const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT); let out=''; while(walker.nextNode()){ const t=walker.currentNode.nodeValue; if(t && t.trim().length>0) out+=' '+t; } return out.replace(/\s+/g,' ').trim().slice(0,120000); }}); return result||''; }
async function summarizeViaDomInjection(tabId, text) {
 await chrome.scripting.executeScript({target:{tabId}, world:'MAIN', args:[text], func:(pageText)=>{
   const prior=document.getElementById('__isig_runner'); if(prior) prior.remove();
   const s=document.createElement('script'); s.id='__isig_runner';
   s.textContent=`(async()=>{ try{ const api=window?.ai?.summarizer; if(!api){window.__ISIG_SUMMARY={error:'Summarizer API not available (model not loaded yet?).'};return;} const h=await api.create({type:'key-points',format:'markdown',length:'medium'}); const out=await h.summarize(${JSON.stringify(text)}); window.__ISIG_SUMMARY={summary:out?.summary||''}; }catch(e){window.__ISIG_SUMMARY={error:e?.message||String(e)};} window.dispatchEvent(new CustomEvent('ISIG_SUMMARY_READY')); })();`;
   document.documentElement.appendChild(s); s.remove();
 }});
 const maxTries=160, interval=250;
 for(let i=0;i<maxTries;i++){ const [{result}] = await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:()=>window.__ISIG_SUMMARY||null}); if(result) return result; await new Promise(r=>setTimeout(r,interval)); }
 return { error:'Timed out waiting for summary (model may still be downloading).' };
}
async function injectIntegrity(tabId) { await chrome.scripting.executeScript({target:{tabId}, files:['src/integrity.js']}); }
async function pollIntegrity(tabId, attempts=50, intervalMs=120) {
 let tries=0; return new Promise((resolve)=>{ const iv=setInterval(async()=>{ tries++; const [{result}] = await chrome.scripting.executeScript({target:{tabId},func:()=>window.__ISIG_RESULT||null}); if(result || tries>attempts){ clearInterval(iv); resolve(result||null);} }, intervalMs); });
}
async function exec(){
 try{
   setStatus('Collecting page text…'); const tab=await getActiveTab(); const text=await collectPageText(tab.id);
   setStatus('Summarizing on-device…'); const sumRes=await summarizeViaDomInjection(tab.id,text);
   if(sumRes?.error){ summaryEl.textContent='Summarization failed: '+sumRes.error; } else { summaryEl.textContent=sumRes?.summary||'(no summary)'; }
   setStatus('Scoring integrity…'); await injectIntegrity(tab.id); const res=await pollIntegrity(tab.id);
   if(res && typeof res.integrityScore==='number'){ integrityEl.textContent=JSON.stringify(res.diagnostics,null,2); scoreValEl.textContent=String(res.integrityScore); renderTags(res.tags); setStatus('Done.'); } else { integrityEl.textContent='No integrity result.'; setStatus(''); }
 } catch(err){ setStatus(''); summaryEl.textContent=''; integrityEl.textContent=''; scoreValEl.textContent='--'; tagsContainer.innerHTML=''; alert('Intersignal error: '+err.message); }
}
btn.addEventListener('click', exec);