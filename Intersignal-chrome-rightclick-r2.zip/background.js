chrome.runtime.onInstalled.addListener(()=>{
  chrome.contextMenus.create({id:'intersignal_summarize', title:'Intersignal: Summarize + Score This Page', contexts:['page']});
});
chrome.contextMenus.onClicked.addListener(async(info,tab)=>{
  if(info.menuItemId!=='intersignal_summarize'||!tab?.id) return;
  chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>alert('Right-click summarization would run here.')});
});