
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "intersignalScan",
    title: "Scan with Intersignal AI",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "intersignalScan") {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => {
        alert("Intersignal AI: This selection would be scored here.");
      }
    });
  }
});
