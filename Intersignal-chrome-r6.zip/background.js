function buildMenu(){
  chrome.contextMenus.removeAll(()=>{
    chrome.contextMenus.create({ id:'isig_summarize', title:'Intersignal: Summarize + Score This Page', contexts:['page'] });
  });
}
chrome.runtime.onInstalled.addListener(buildMenu);
chrome.runtime.onStartup.addListener(buildMenu);

async function getText(tabId){
  const [{result}] = await chrome.scripting.executeScript({ target:{tabId}, func:()=> (document.body.innerText||'').replace(/\s+/g,' ').trim().slice(0,120000) });
  return result||'';
}
chrome.contextMenus.onClicked.addListener(async(info, tab)=>{
  if(info.menuItemId!=='isig_summarize' || !tab?.id) return;
  try{
    const text = await getText(tab.id);
    const sum = await chrome.tabs.sendMessage(tab.id, { type:'ISIG_SUMMARIZE', text });
    await chrome.scripting.executeScript({ target:{tabId:tab.id}, files:['src/integrity.js'] });
    const [{result: integ}] = await chrome.scripting.executeScript({ target:{tabId:tab.id}, func:()=>window.__ISIG_RESULT||null });
    const score = (integ && typeof integ.integrityScore==='number') ? integ.integrityScore : 0;
    const short = (sum?.summary || sum?.error || '').slice(0,180).replace(/\s+/g,' ');
    chrome.notifications.create({ type:'basic', iconUrl:'assets/icon128.png', title:'Intersignal', message:(sum?.error?'Error: ':'Score: '+score+' — ')+short+(short.length>=180?'…':''), priority:1 });
    if (chrome.action?.openPopup) { try{ await chrome.action.openPopup(); } catch(e){} }
  }catch(e){
    chrome.notifications.create({ type:'basic', iconUrl:'assets/icon128.png', title:'Intersignal — Error', message:e.message||String(e), priority:2 });
  }
});
