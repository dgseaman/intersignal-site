// bridge.js — content-script bridge with retry
function delay(ms){ return new Promise(r=>setTimeout(r,ms)); }

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'ISIG_SUMMARIZE') return;
  (async () => {
    const pageText = (msg.text || (document.body.innerText||'')).replace(/\s+/g,' ').trim().slice(0,120000);

    // Retry for up to ~60s waiting for window.ai.summarizer
    let api = window?.ai?.summarizer;
    let waited = 0;
    while (!api && waited < 60000) {
      await delay(500);
      waited += 500;
      api = window?.ai?.summarizer;
    }
    if (!api) { sendResponse({ error: 'Model not ready yet (no summarizer in page context).' }); return; }

    try {
      const h = await api.create({ type:'key-points', format:'markdown', length:'medium' });
      const out = await h.summarize(pageText);
      sendResponse({ summary: out?.summary || '' });
    } catch (e) {
      sendResponse({ error: e?.message || String(e) });
    }
  })();
  return true; // keep channel open
});
