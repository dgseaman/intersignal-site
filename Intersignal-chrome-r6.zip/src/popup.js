// popup.js — R6
const btn=document.getElementById('run');
const banner=document.getElementById('banner');
const statusEl=document.getElementById('status');
const summaryEl=document.getElementById('summary');
const integrityEl=document.getElementById('integrity');
const scoreValEl=document.getElementById('score-val');
const tagsContainer=document.getElementById('tags');

function setStatus(m=''){ statusEl.textContent=m; console.log('[ISIG]',m); }
function showBanner(text){ banner.hidden=false; banner.textContent=text; }
function hideBanner(){ banner.hidden=true; banner.textContent=''; }
function renderTags(tags){ tagsContainer.innerHTML=''; (tags||[]).forEach(t=>{ const el=document.createElement('span'); el.className=`tag ${t.type}`; el.textContent=t.label; tagsContainer.appendChild(el); }); }

async function getActiveTab(){ const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); return tab; }
async function collectText(tabId){ const [{result}] = await chrome.scripting.executeScript({target:{tabId}, func:()=> (document.body.innerText||'').replace(/\s+/g,' ').trim().slice(0,120000)}); return result||''; }

async function summarize(tabId, text){
  setStatus('Waiting for local model… (up to 60s)');
  hideBanner();
  const res = await chrome.tabs.sendMessage(tabId, { type:'ISIG_SUMMARIZE', text });
  if (res?.error && /not ready|no summarizer/i.test(res.error)) {
    showBanner('Local summarizer model is still downloading or not exposed yet. Leave Chrome open and retry.');
  }
  return res;
}

async function runIntegrity(tabId){
  await chrome.scripting.executeScript({ target:{tabId}, files:['src/integrity.js'] });
  const [{result}] = await chrome.scripting.executeScript({ target:{tabId}, func:()=>window.__ISIG_RESULT||null });
  return result;
}

btn.addEventListener('click', async()=>{
  try{
    setStatus('Collecting page text…');
    const tab=await getActiveTab();
    const text=await collectText(tab.id);

    setStatus('Summarizing on-device…');
    const sum=await summarize(tab.id, text);
    if(sum?.error){ summaryEl.textContent='Summarization failed: '+sum.error; } else { summaryEl.textContent=sum?.summary||'(no summary)'; }

    setStatus('Scoring integrity…');
    const res=await runIntegrity(tab.id);
    if(res){ integrityEl.textContent=JSON.stringify(res.diagnostics,null,2); scoreValEl.textContent=String(res.integrityScore||'--'); renderTags(res.tags||[]); }
    setStatus('Done.');
  }catch(e){ console.error(e); setStatus('Error: '+(e?.message||String(e))); }
});
