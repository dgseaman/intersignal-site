(function () {
  function textOf(root) {
    return (root.innerText || '').replace(/\s+/g, ' ').trim();
  }
  function getShadowAnchors(root) {
    const anchors = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    while (walker.nextNode()) {
      const el = walker.currentNode;
      if (el.shadowRoot) anchors.push(...el.shadowRoot.querySelectorAll('a[href]'));
    }
    return anchors;
  }
  function uniq(a) { return [...new Set(a)]; }
  const txt = textOf(document.body);
  const links = Array.from(document.querySelectorAll('a[href]'));
  const shadowLinks = getShadowAnchors(document.documentElement);
  const metaCanonical = document.querySelector('link[rel=canonical]')?.href || '';
  const metaOg = document.querySelector('meta[property="og:url"]')?.content || '';
  const candidates = links.concat(shadowLinks).map(a=>a.href).concat([metaCanonical, metaOg]).filter(Boolean);
  const hosts = uniq(candidates.map(h=>{ try{ return new URL(h, location.href).host }catch{return null} }).filter(Boolean));

  const hedges=(txt.match(/\b(might|could|may|reportedly|alleged|unconfirmed|sources say|appears|suggests)\b/gi)||[]).length;
  const quotes=(txt.match(/[“"][^”"]+[”"]/g)||[]).length;
  const title=(document.title||'').toLowerCase();
  const toWords = s => (s.toLowerCase().match(/\b[a-z]{4,}\b/g) || []);
  const titleTerms = uniq(toWords(title));
  const bodyTerms = uniq(toWords(txt));
  const overlap = titleTerms.filter(w => bodyTerms.includes(w));
  const overlapScore = Math.min(1, overlap.length/8);
  const sourceClarity = Math.min(1, (hosts.length + Math.min(quotes,5))/8);
  const recency = /\b(20\d{2}|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(txt) ? 0.2 : 0;
  const score = Math.round(100*(0.55*sourceClarity + 0.35*overlapScore + 0.10*recency));

  const topics = [
    ['AI/ML', /\b(ai|artificial intelligence|machine learning|model|neural|summarizer|openai|anthropic|google)\b/i],
    ['Crypto', /\b(crypto|bitcoin|ethereum|eth|btc|blockchain|defi|staking|l2)\b/i],
    ['Markets', /\b(stocks?|equities|etf|yield|basis|funding|futures|oi|open interest|treasury|bond|dow|nasdaq|s&p)\b/i],
    ['Metals', /\b(silver|gold|bullion|comex|spot|miners?|slv|gld)\b/i],
    ['Science', /\b(physics|biology|biotech|vaccine|trial|peer-reviewed|preprint|study)\b/i],
    ['Politics', /\b(president|congress|senate|election|policy|regulation|bill|court)\b/i],
    ['Tech', /\b(software|chrome|extension|api|github|kernel|browser|device)\b/i],
    ['Space', /\b(space|nasa|jwst|comet|asteroid|probe|interstellar)\b/i]
  ];
  const detected = topics.filter(t=>t[1].test(txt)).map(t=>t[0]).slice(0,4).map(l=>({type:'topic',label:l}));
  const bias = hedges>8?{type:'bias',label:'Heavy Hedging'}:hedges>3?{type:'bias',label:'Some Hedging'}:{type:'bias',label:'Low Hedging'};
  const source = hosts.length>=5?{type:'source',label:'Multi-source'}:hosts.length>=2?{type:'source',label:'Some Sources'}:{type:'source',label:'Thin Sourcing'};
  const drift = overlapScore>=0.75?{type:'neutral',label:'Strong Title Alignment'}:overlapScore>=0.40?{type:'neutral',label:'Moderate Alignment'}:{type:'neutral',label:'Possible Drift'};

  window.__ISIG_RESULT = {
    integrityScore: score,
    diagnostics: { distinctHosts: hosts.length, hosts: hosts.slice(0,12), quotes, hedges, titleOverlapTerms: overlap.slice(0,12) },
    tags: [source, bias, drift, ...detected]
  };
})();