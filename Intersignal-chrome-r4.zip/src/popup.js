// popup.js — uses content-script bridge messaging
const btn = document.getElementById('run');
const statusEl = document.getElementById('status');
const summaryEl = document.getElementById('summary');
const integrityEl = document.getElementById('integrity');
const scoreValEl = document.getElementById('score-val');
const tagsContainer = document.getElementById('tags');

function setStatus(m=''){ statusEl.textContent=m; }
function tagRender(tags){ tagsContainer.innerHTML=''; (tags||[]).forEach(t=>{ const el=document.createElement('span'); el.className=`tag ${t.type}`; el.textContent=t.label; tagsContainer.appendChild(el); }); }

async function getActiveTab(){ const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); return tab; }

async function collectText(tabId){
  const [{result}] = await chrome.scripting.executeScript({target:{tabId}, func:()=>{ const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT); let out=''; while(w.nextNode()){ const t=w.currentNode.nodeValue; if(t && t.trim()) out+=' '+t; } return out.replace(/\s+/g,' ').trim().slice(0,120000); }});
  return result||'';
}

async function summarizeViaBridge(tabId, text){
  return await chrome.tabs.sendMessage(tabId, { type:'ISIG_SUMMARIZE', text });
}

async function injectIntegrity(tabId){
  await chrome.scripting.executeScript({ target:{tabId}, files:['src/integrity.js'] });
  const [{result}] = await chrome.scripting.executeScript({ target:{tabId}, func:()=>window.__ISIG_RESULT||null });
  return result;
}

btn.addEventListener('click', async ()=>{
  try{
    setStatus('Collecting page text…');
    const tab = await getActiveTab();
    const text = await collectText(tab.id);
    setStatus('Summarizing on-device…');
    const sum = await summarizeViaBridge(tab.id, text);
    summaryEl.textContent = sum?.error ? ('Summarization failed: ' + sum.error) : (sum?.summary || '(no summary)');
    setStatus('Scoring integrity…');
    await injectIntegrity(tab.id);
    const [{result}] = await chrome.scripting.executeScript({ target:{tab.id}, func:()=>window.__ISIG_RESULT||null });
    const res = result;
    if(res){
      integrityEl.textContent = JSON.stringify(res.diagnostics, null, 2);
      scoreValEl.textContent = String(res.integrityScore || '--');
      tagRender(res.tags || []);
    }
    setStatus('Done.');
  }catch(e){ setStatus(''); summaryEl.textContent=''; integrityEl.textContent=''; scoreValEl.textContent='--'; tagsContainer.innerHTML=''; alert('Intersignal error: ' + (e?.message||String(e))); }
});
