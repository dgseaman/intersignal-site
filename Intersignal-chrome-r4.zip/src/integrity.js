(function(){ const text=(document.body.innerText||'').replace(/\s+/g,' ').trim();
const hosts=[...new Set(Array.from(document.links||[]).map(a=>{try{return new URL(a.href,location.href).host}catch{return null}}).filter(Boolean))];
const hedges=(text.match(/\b(might|could|may|reportedly|alleged|unconfirmed|sources say|appears|suggests)\b/gi)||[]).length;
const quotes=(text.match(/[“"][^”\"]+[”\"]/g)||[]).length;
const title=(document.title||'').toLowerCase(); const body=(text.toLowerCase().match(/\b[a-z]{4,}\b/g)||[]);
const overlap=[...new Set((title.match(/\b[a-z]{4,}\b/g)||[]))].filter(w=>body.includes(w)); const oScore=Math.min(1,overlap.length/8);
const sClarity=Math.min(1,(hosts.length+Math.min(quotes,5))/8); const hasDates=/\b(20\d{2}|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(text)?0.2:0;
const score=Math.round(100*(0.55*sClarity+0.35*oScore+0.10*hasDates));
const topics=[['AI/ML',/\b(ai|artificial intelligence|machine learning|model|neural|summarizer|openai|anthropic|google)\b/i],
['Crypto',/\b(crypto|bitcoin|ethereum|eth|btc|blockchain|defi|staking|l2)\b/i],
['Markets',/\b(stocks?|equities|etf|yield|basis|funding|futures|oi|open interest|treasury|bond|dow|nasdaq|s&p)\b/i],
['Metals',/\b(silver|gold|bullion|comex|spot|miners?|slv|gld)\b/i]];
const det=topics.filter(t=>t[1].test(text)).map(t=>t[0]).slice(0,4).map(l=>({type:'topic',label:l}));
const bias=hedges>8?{type:'bias',label:'Heavy Hedging'}:hedges>3?{type:'bias',label:'Some Hedging'}:{type:'bias',label:'Low Hedging'};
const source=hosts.length>=5?{type:'source',label:'Multi-source'}:hosts.length>=2?{type:'source',label:'Some Sources'}:{type:'source',label:'Thin Sourcing'};
const drift=oScore>=0.75?{type:'neutral',label:'Strong Title Alignment'}:oScore>=0.40?{type:'neutral',label:'Moderate Alignment'}:{type:'neutral',label:'Possible Drift'};
window.__ISIG_RESULT={ integrityScore:score, diagnostics:{distinctHosts:hosts.length,hosts:hosts.slice(0,10),quotes,hedges,titleOverlapTerms:overlap.slice(0,12)}, tags:[source,bias,drift,...det] };})();