// bridge.js — runs in page context to help access window.ai.summarizer via DOM injection
(function(){
  // Listen for messages from extension
  chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
    if (msg && msg.type === 'ISIG_SUMMARIZE') {
      const pageText = msg.text || (document.body.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 120000);
      try {
        // Use a <script> injection to ensure MAIN world access
        const id = '__isig_bridge_runner';
        const prior = document.getElementById(id);
        if (prior) prior.remove();
        const s = document.createElement('script');
        s.id = id;
        s.textContent = `
          (async () => {
            try {
              const api = window?.ai?.summarizer;
              if (!api) { window.__ISIG_SUMMARY = { error: 'Summarizer API not available in page context.' }; }
              else {
                const h = await api.create({ type:'key-points', format:'markdown', length:'medium' });
                const out = await h.summarize(${JSON.stringify("")} + ${JSON.stringify("")}); // placeholder; actual call below
              }
            } catch (e) { /* no-op */ }
          })();
        `;
        document.documentElement.appendChild(s); s.remove();
        // Now call API directly from content script (after warm-up) if available
        const api = window?.ai?.summarizer;
        if (!api) {
          sendResponse({ error: 'Summarizer API not available in page context.' });
          return true;
        }
        const h = await api.create({ type:'key-points', format:'markdown', length:'medium' });
        const out = await h.summarize(pageText);
        sendResponse({ summary: out?.summary || '' });
      } catch (e) {
        sendResponse({ error: e?.message || String(e) });
      }
      return true; // keep channel open for async
    }
  });
})();