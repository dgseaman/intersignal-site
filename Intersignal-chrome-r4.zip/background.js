chrome.runtime.onInstalled.addListener(()=>{
  chrome.contextMenus.create({ id:'intersignal_summarize', title:'Intersignal: Summarize + Score This Page', contexts:['page'] });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'intersignal_summarize' || !tab?.id) return;
  try {
    const text = await chrome.scripting.executeScript({ target:{tabId:tab.id}, func:()=> (document.body.innerText||'').replace(/\s+/g,' ').trim().slice(0,120000) });
    const pageText = text[0].result || '';
    const sum = await chrome.tabs.sendMessage(tab.id, { type:'ISIG_SUMMARIZE', text: pageText });
    await chrome.scripting.executeScript({ target:{tabId:tab.id}, files:['src/integrity.js'] });
    const [{result: integ}] = await chrome.scripting.executeScript({ target:{tabId:tab.id}, func:()=>window.__ISIG_RESULT||null });
    const score = (integ && typeof integ.integrityScore==='number') ? integ.integrityScore : 0;
    const short = (sum?.summary || sum?.error || '').slice(0,180).replace(/\s+/g,' ');
    chrome.notifications.create({ type:'basic', iconUrl:'assets/icon128.png', title:'Intersignal', message:(sum?.error?'Error: ':'Score: '+score+' — ')+short+(short.length>=180?'…':''), priority:1 });
  } catch(e){
    chrome.notifications.create({ type:'basic', iconUrl:'assets/icon128.png', title:'Intersignal — Error', message:e.message || String(e), priority:2 });
  }
});