// bridge.js
chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
  if (msg && msg.type === 'ISIG_SUMMARIZE') {
    try {
      const pageText = msg.text || (document.body.innerText||'').replace(/\s+/g,' ').trim().slice(0,120000);
      const api = window?.ai?.summarizer;
      if (!api) {
        sendResponse({ error: 'Summarizer API not available in page context.' });
        return true;
      }
      const h = await api.create({ type:'key-points', format:'markdown', length:'medium' });
      const out = await h.summarize(pageText);
      sendResponse({ summary: out?.summary || '' });
    } catch(e) {
      sendResponse({ error: e?.message || String(e) });
    }
    return true;
  }
});