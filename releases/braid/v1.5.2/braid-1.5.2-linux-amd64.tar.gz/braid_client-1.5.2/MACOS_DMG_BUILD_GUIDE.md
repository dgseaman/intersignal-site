# Braid v1.5.2 — Native macOS DMG Build Guide

This is the last-mile builder for the hobbyist-facing Braid release. PyInstaller is not a cross-compiler, so the actual Mach-O `Braid.app`, `hdiutil` disk image, Developer ID signature, and Apple notarization must be produced on macOS.

## What the finished DMG does

- drag `Braid.app` to Applications;
- launch from Finder with no Python/Ollama prerequisite;
- automatically open the loopback-only Braid visualizer;
- make **Generate state -> Commit locally** work immediately without Ollama;
- detect local machine/LAN/Ollama/camera/BLE state;
- expose a CLI from the exact same frozen runtime at `Braid.app/Contents/MacOS/braid-client`;
- prepopulate copyable commands using the installed app's actual path;
- retain build dependency hashes, runtime lock, Python/architecture/minimum-macOS evidence, and third-party notices inside the app.

## Easiest local build

From Finder, double-click:

`packaging/macos/Build Braid 1.5.2.command`

For frozen public-release bytes the builder requires **CPython 3.12.10**. Without Developer ID/notary environment variables it creates an **ad-hoc signed local-UAT DMG**. That image is functional for our physical testing but is not the public Gatekeeper/notarized release.

## Public signed + notarized build

Use a `Developer ID Application` certificate and a `notarytool` keychain profile, then run:

```sh
export PYTHON=/path/to/python3.12.10
export BRAID_CODESIGN_IDENTITY='Developer ID Application: YOUR NAME (TEAMID)'
export BRAID_NOTARY_PROFILE='intersignal-notary'
export BRAID_PUBLIC_RELEASE=1
./packaging/macos/build_release_macos.sh
```

The pipeline:

1. resolves pinned third-party wheels to a local wheelhouse and hashes the exact bytes;
2. freezes one standalone `Braid.app` runtime;
3. makes `braid-client` a relative symlink to that same frozen executable, avoiding a duplicated Python runtime;
4. sets the final Info.plist, icon, usage descriptions, and Mach-O-derived minimum macOS version **before signing**;
5. signs nested Mach-O code inside-out, then seals the outer app;
6. creates a Finder-arranged drag-to-Applications DMG with the Braid background and Quick Start;
7. signs the DMG, submits it with `notarytool`, saves submission/log evidence, staples and validates the ticket;
8. mounts the final DMG, simulates a drag-install to a fresh temporary path, runs `doctor` and `environment`, verifies path self-discovery, and performs LaunchServices/Gatekeeper checks;
9. emits the DMG SHA-256 next to the image and retains native evidence under `dist/release-gate-evidence/`.

## Local UAT with another Python 3.12 patch

Only for physical pre-release testing, never the public release claim:

```sh
BRAID_ALLOW_PYTHON_PATCH_DRIFT=1 \
PYTHON=/path/to/python3.12 \
./packaging/macos/build_release_macos.sh
```

The verifier records that Python version in the app and evidence. Rebuild with exact 3.12.10 before public freeze.

## Final physical gate

A successful DMG build does **not** by itself close the release gate. Run the final image through:

- `FINAL_MACOS_RELEASE_GATE_v1.5.2.md`
- `BRAID_V1_5_2_2NODE_SEMANTIC_UAT.md`
- `PHYSICAL_CAMERA_UAT.md`

on the real MacBook Air + MacBook Pro before publishing v1.5.2.
