# Braid Light Client v1.5.2 Release Notes

Release status: **external-review candidate pending Chef/Nemotron/Glimmer review, native macOS build verification, and physical two-node/Ollama/camera UAT**.

## Flag-plant feature: signed Semantic Capsule

v1.5.2 adds `braid.semantic-capsule.v1`, a bounded signed manifest extension for explicit semantic material and source embedding provenance.

The receiver now has a strict two-path semantic decision:

- identical source/receiver embedding model digest -> `exact_space_fast_path` using the signed 384D route-space vector;
- different digest -> `semantic_capsule_local_reembed` using explicit capsule material and the receiver's local embedding model at its native dimension.

If heterogeneous semantic ingestion is configured and the capsule is absent, the receiver rejects before Phase B. There is no opaque-vector-to-text fallback.

## Capsule integrity and authority

The capsule is bound to:

- its own RFC 8785/JCS digest;
- the signed frame's exact FP16 wire payload digest;
- the frozen route source model name and exact model digest;
- the signed Legend digest/content view for `legend_ref` capsules.

Receiver-created semantic vectors and optional completion responses remain receiver-local artifacts. The sender signature does not cover them. Completion responses are explicitly marked `generative_output: true`; `bridge_semantic_invention: false` refers only to Braid's bridge not fabricating missing source semantics.

## Atomic receiver semantic lineage

The semantic vector and its lineage are now published as one private atomic directory bundle so a partial filesystem failure cannot expose an unlineaged semantic vector.

## Front door / hobbyist UX

New `braid-client environment` performs bounded local-only autodetection for:

- machine/architecture/Python;
- private LAN addresses;
- the exact CLI invocation belonging to the current installation;
- loopback Ollama and model capabilities reported by the API;
- explicit cloud names plus Ollama `remote_model` / `remote_host` markers, which fail closed;
- Ollama cloud-disable configuration evidence without pretending to attest the server process;
- camera/browser-QR/OpenCV and BLE capability;
- default Braid workspace/route/key presence;
- prepopulated copyable CLI commands using valid detected values.

New `braid-client demo` opens the loopback visualizer automatically. A fresh app can produce a signed, verified, Phase-B-committed synthetic object with **Generate state -> Commit locally** before Ollama is installed.

The standalone `Braid.app` now exposes `Contents/MacOS/braid-client` as a relative symlink to the same frozen Braid executable used by Finder. Commands shown by the visualizer point back to that same-runtime path, closing the previous DMG/CLI split without duplicating a second embedded Python runtime. The visualizer retains Braid's sparse field aesthetic, scan background, and reduced-motion behavior.

## macOS application / DMG build

`packaging/macos/` now contains:

- native app entry point;
- standalone PyInstaller `Braid.app` builder plus same-runtime CLI symlink;
- exact CPython 3.12.10 release-build requirement and pinned direct dependencies;
- pre-download dependency wheelhouse + SHA-256 manifest + resolved runtime/pip-inspect evidence embedded in the app;
- intentional packaged OpenCV camera fallback and BLE stack;
- minimum macOS declaration derived from the actual Mach-O deployment targets in the frozen app;
- explicit inside-out nested-code signing path (ad-hoc for local UAT or Developer ID for public distribution), with `--deep` reserved for recursive verification;
- HFS+ UDZO DMG builder using `hdiutil`, a sparse scan-style background, Quick Start, and Applications symlink;
- `notarytool` JSON/log evidence, stapling, DMG checksum emission, drag-install simulation, LaunchServices smoke, and Gatekeeper assessment;
- lightweight network-assisted developer bootstrap app template.

The actual standalone DMG is intentionally built and verified on macOS; the Linux release-build environment does not fabricate a `.dmg` file.

## CLI additions

- `capsule-frame`
- `environment`
- `demo`
- `receive-file --semantic-embed-model ... [--semantic-completion-model ...]`
- `receive --semantic-embed-model ... [--semantic-completion-model ...]`
- `serve --open`

Existing signed Legend and heterogeneous calibration commands remain available.

## Compatibility and invariants

The 1.4.x finality, replay, canonicalization, QR, LAN, transport-policy, and lineage suites remain intact. Existing v1.5.0 Ollama/Legend and calibrated-route behavior is retained.

Phase B remains the only receiver acceptance boundary. Post-commit semantic/model failures degrade delivery but cannot rewrite committed finality. Exact-space receivers may optionally enable `--semantic-verify-fast-path` to recompute capsule/vector coherence before Phase B.

## Test status

The current source passes **129/129 unique automated tests** in the review-hardening split regression/conformance run: 33 legacy group A + 52 legacy group B + 17 v1.5.0 heterogeneous/Ollama/Legend + 27 v1.5.2 front-door/Semantic-Capsule/hobbyist-gate tests. See `BRAID_CLIENT_V1_5_2_TEST_EVIDENCE.txt` in the release bundle.

Physical two-node macOS/Ollama/camera validation is explicitly not claimed by this evidence and remains the next UAT gate.

The release bundle now carries `FINAL_MACOS_RELEASE_GATE_v1.5.2.md` and `packaging/macos/verify_release_macos.sh`. External adversarial review is intentionally sequenced before native packaging/physical UAT; any executable change after review reopens the affected gate.

## External-review hardening

The review candidate received an additional boundary pass before the native Mac gate:

- unified Ollama digest lookup with full local-model inspection;
- removed verification-key fallback into private-key parsing;
- hardened private-key file reads against symlink/permission races;
- added browser Fetch Metadata defense for origin-less cross-site requests;
- made receiver-local derived-artifact authority explicit in the visualizer.

