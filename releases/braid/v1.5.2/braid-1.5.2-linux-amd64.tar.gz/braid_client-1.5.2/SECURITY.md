# Braid Light Client v1.5.2 Security Notes

## Receiver sovereignty

Only successful receiver-owned Phase B commit means accepted. Transport arrival, Phase A validation, external validator output, semantic re-embedding, and language-model output do not possess acceptance authority.

## Semantic Capsule threat boundary

A Semantic Capsule is signed sender evidence, not truth and not authority.

The receiver validates the closed capsule schema, capsule digest, signed wire-payload binding, frozen route/source-model binding, and (for `legend_ref`) the signed Legend digest/content binding before Phase B.

A capsule never authorizes the receiver to infer missing semantics. When source and receiver embedding-model digests differ, heterogeneous semantic ingestion requires explicit capsule material.

## Derived local state

Receiver-created semantic embeddings and completion responses:

- do not inherit the sender signature;
- are labelled receiver-local output/evidence;
- carry explicit source/capsule/model lineage;
- are stored with private permissions;
- cannot rewrite Phase B finality if post-commit processing fails.

The semantic vector and lineage are published together as an atomic private directory bundle.

## Prompt injection / model output

Signed semantic content can still contain hostile instructions or false claims. Signature validity only establishes integrity/provenance from an authorized signer.

Optional local completion handoff places capsule material below a receiver-owned system instruction and labels it as data/evidence. This is not a formal sandbox. Generated model text is untrusted and must not directly authorize tools, shell commands, credentials, network access, or other privileged actions.

## Ollama boundary

The built-in Ollama clients accept loopback URLs only and reject redirects away from loopback. Semantic Capsules do not contain receiver-fetch URLs.

Loopback by itself is not treated as proof of local inference. Braid rejects model names that explicitly denote Ollama cloud execution, rejects locally listed/show metadata carrying non-empty `remote_model` or `remote_host` markers, and checks generation responses for those remote markers before accepting model output. Capability eligibility comes from Ollama-reported capabilities rather than model-name heuristics.

The receiver resolves model digests independently through its loopback Ollama instance. Sender claims cannot choose an inference endpoint. `~/.ollama/server.json` cloud-disable state is reported as local configuration evidence only; Braid does not claim cryptographic attestation of an already-running Ollama server process.

## Local UI/autodetect

The Field UI remains loopback-only and enforces local browser Host/Origin constraints. `/api/environment` performs local read-only detection and probes only loopback Ollama. Private LAN addresses are displayed to the local operator but are not uploaded by Braid.

## Network exposure

- LAN binding requires explicit `--allow-lan`.
- Public exposure requires explicit public policy and TLS safeguards as defined by the transport layer.
- Discovery/BLE sensing are untrusted hints and do not enter the acceptance authority chain.

## Cryptographic/integrity controls

Braid retains Ed25519 signatures, payload digests, RFC 8785/JCS canonicalization, scoped replay/session ledger state, bounded parsing, and receiver-owned finality.

## Distribution

The source/wheel/sdist release should be accompanied by SHA-256 hashes. The standalone macOS application and DMG must be built/verified on macOS. The v1.5.2 release builder pins CPython 3.12.10 and direct third-party versions, downloads release wheels into a local wheelhouse, records SHA-256 for the exact dependency bytes, installs from that wheelhouse, and embeds the resolved runtime lock/evidence in `Braid.app`. Production public distribution should use a Developer ID signature and notarization rather than the ad-hoc signing path intended for lab testing.

## Reporting

Experimental developer software. Inspect and test before deployment into sensitive environments.
## Review-driven boundary hardening in v1.5.2

- Ollama model-digest lookup is a locality-sensitive operation and therefore uses the same local-tags plus `/api/show` remote-marker inspection as inference paths.
- Verification-key loading accepts only public-key encodings and never falls back to parsing private-key material.
- Private-key loading rejects symlink indirection where the platform supports no-follow opens, operates on the opened inode, and verifies repaired `0600` permissions before reading key bytes.
- The loopback Field UI rejects browser requests marked `Sec-Fetch-Site: cross-site` even when an `Origin` header is absent; non-browser local API clients that omit browser Fetch Metadata remain supported.
- Receiver-created vectors, lineage, and completion artifacts are receiver-local evidence/output. The visualizer labels derived artifacts as **not sender-signed**.

