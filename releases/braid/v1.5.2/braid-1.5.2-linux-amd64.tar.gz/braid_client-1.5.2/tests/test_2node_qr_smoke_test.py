"""
Automated 2-Node Optical QR Transport Smoke Test Suite
"""

import unittest
import sys
from pathlib import Path

# Ensure package root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from braid_client.cli import run_2node_smoke_test


class Test2NodeQRSmokeTest(unittest.TestCase):

    def test_2node_optical_qr_smoke_test_pass(self):
        """Verifies full end-to-end 2-node optical QR transport, reassembly, and validation."""
        success = run_2node_smoke_test(verbose=False)
        self.assertTrue(success)


if __name__ == "__main__":
    unittest.main()
