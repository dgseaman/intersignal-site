import copy
import hashlib
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock

import numpy as np

from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.legend import (
    attach_legend_extension,
    extract_legend_extension,
    finalize_legend,
    legend_digest,
    legend_embedding_text,
    validate_legend,
)
from braid_client.mcp_core.protocol import BraidFrame
from braid_client.ollama_adapter import (
    OllamaClient,
    OllamaHandoffConfig,
    extract_ollama_extension,
    generate_legend,
    ollama_doctor,
)
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
from braid_client.semantic_transfer import (
    build_conformance_corpus,
    build_frame_from_legend,
    calibrate_ollama_route,
    calibrate_route,
    create_validator_from_route_package,
)


MISTRAL = "mistral:latest"
EMBED = "all-minilm:latest"
MISTRAL_DIGEST = "1" * 64
EMBED_DIGEST = "2" * 64


def deterministic_embedding(model: str, text: str) -> np.ndarray:
    seed_bytes = hashlib.sha256((model + "\0" + text).encode("utf-8")).digest()[:8]
    seed = int.from_bytes(seed_bytes, "big")
    vec = np.random.default_rng(seed).normal(size=384)
    vec /= np.linalg.norm(vec)
    return vec.astype(np.float64)


MODEL_LEGEND = {
    "objective": "Continue the Braid two-node local AI handoff.",
    "active_intent": "Preserve receiver-owned finality while continuing the task on Node B.",
    "constraints": [
        {"kind": "technical", "text": "Braid Phase B remains the only acceptance boundary.", "critical": True},
        {"kind": "policy", "text": "Legend context cannot grant receiver authority.", "critical": True},
    ],
    "branch_conditions": [
        {"if": "receiver finality is not committed", "then": "do not invoke the receiver model", "critical": True}
    ],
    "provenance_facts": [
        {
            "statement": "The supplied source text asks for a Braid Ollama handoff.",
            "provenance": "source_text_explicit",
            "confidence": "asserted",
            "critical": False,
        }
    ],
    "temporal_salience": [
        {"statement": "This handoff is active for the current session.", "horizon": "session", "expires_at": None}
    ],
    "significance": [
        {"concept": "receiver finality", "weight": 5, "reason": "Acceptance must remain receiver-owned."}
    ],
    "must_preserve": ["receiver-owned finality", "Legend is context, not authority"],
    "archive_refs": [],
}


class FakeOllamaHandler(BaseHTTPRequestHandler):
    server_version = "FakeOllama/1.0"

    def log_message(self, _format, *_args):
        return

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        if self.path == "/api/tags":
            if getattr(self.server, "redirect_tags", False):
                self.send_response(302)
                self.send_header("Location", "http://example.com/api/tags")
                self.end_headers()
                return
            self._json(200, {"models": [
                {"name": MISTRAL, "model": MISTRAL, "digest": MISTRAL_DIGEST},
                {"name": EMBED, "model": EMBED, "digest": EMBED_DIGEST},
            ]})
            return
        self._json(404, {"error": "not found"})

    def do_POST(self):
        data = self._body()
        if self.path == "/api/show":
            model = data.get("model")
            if model == MISTRAL:
                self._json(200, {"capabilities": ["completion"], "details": {"family": "mistral"}})
            elif model == EMBED:
                self._json(200, {"capabilities": ["embedding"], "details": {"family": "bert"}})
            else:
                self._json(404, {"error": "model not found"})
            return

        if self.path == "/api/embed":
            model = data.get("model")
            texts = data.get("input")
            if model != EMBED or not isinstance(texts, list) or data.get("dimensions") != 384:
                self._json(400, {"error": "bad embed request"})
                return
            vectors = [deterministic_embedding(model, text).tolist() for text in texts]
            self._json(200, {"model": model, "embeddings": vectors})
            return

        if self.path == "/api/chat":
            model = data.get("model")
            messages = data.get("messages") or []
            if model != MISTRAL:
                self._json(400, {"error": "bad chat model"})
                return
            joined = "\n".join(str(item.get("content", "")) for item in messages if isinstance(item, dict))
            if data.get("format") is not None:
                self._json(200, {"message": {"role": "assistant", "content": json.dumps(MODEL_LEGEND)}})
                return
            if "Reply with exactly BRAID_OLLAMA_READY" in joined:
                self._json(200, {"message": {"role": "assistant", "content": "BRAID_OLLAMA_READY"}})
                return
            if getattr(self.server, "fail_receiver_chat", False) and "Braid receiver finality is committed" in joined:
                self._json(500, {"error": "simulated receiver model failure"})
                return
            self._json(200, {"message": {"role": "assistant", "content": "Receiver continued from the committed signed Legend."}})
            return

        self._json(404, {"error": "not found"})


class FakeOllama:
    def __init__(self) -> None:
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), FakeOllamaHandler)
        self.server.fail_receiver_chat = False
        self.server.redirect_tags = False
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"

    def close(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)


class OllamaLegendV150Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name)
        cls.fake = FakeOllama()

        cls.rows = build_conformance_corpus(768)
        texts = [row["text"] for row in cls.rows]
        vectors = np.vstack([deterministic_embedding(EMBED, text) for text in texts])
        cls.route_dir = cls.root / "same-space-route"
        cls.route_report = calibrate_route(
            rows=cls.rows,
            source_raw=vectors,
            target_raw=vectors.copy(),
            source_model=EMBED,
            target_model=EMBED,
            source_model_digest=EMBED_DIGEST,
            target_model_digest=EMBED_DIGEST,
            same_space_identity=True,
            output_dir=cls.route_dir,
            corpus_sha256="a" * 64,
        )
        if not cls.route_report["promotion"]["passed"]:
            raise AssertionError(cls.route_report)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.fake.close()
        cls.tmp.cleanup()

    def _legend(self, text: str = "Continue the two-node Braid demo with receiver-owned finality.") -> dict:
        return generate_legend(text, completion_model=MISTRAL, client=OllamaClient(self.fake.url), created_at=1_800_000_000)

    def _receiver(self, sk, directory: Path, *, min_alignment=None) -> AutomatedReceiver:
        vk = sk.public_key()
        validator, registry, ledger, _ = create_validator_from_route_package(
            self.route_dir,
            get_raw_public_bytes(vk).hex(),
            directory / "ledger.db",
        )
        return AutomatedReceiver(
            validator=validator,
            registry=registry,
            ledger=ledger,
            verification_key=vk,
            config=ReceiverAutomationConfig(
                storage_dir=directory / "inbox",
                ollama_handoff=OllamaHandoffConfig(
                    completion_model=MISTRAL,
                    embedding_model=EMBED,
                    base_url=self.fake.url,
                    min_alignment=min_alignment,
                ),
            ),
        )

    def test_legend_is_bounded_digest_bound_and_sender_context_only(self) -> None:
        legend = self._legend()
        normalized = validate_legend(legend)
        self.assertEqual(normalized["schema"], "braid.legend.v1")
        self.assertEqual(normalized["generator"]["model"], MISTRAL)
        self.assertEqual(normalized["generator"]["model_digest"], MISTRAL_DIGEST)
        self.assertEqual(normalized["provenance_facts"][0]["provenance"], "source_text_explicit")

        manifest = {"extensions": {}}
        attach_legend_extension(manifest, legend)
        recovered, evidence = extract_legend_extension(manifest, required=True)
        self.assertEqual(recovered, normalized)
        self.assertEqual(evidence["digest"], legend_digest(legend))
        self.assertEqual(evidence["authority"], "signed_sender_context_only")

        tampered = copy.deepcopy(manifest)
        tampered["extensions"]["braid_legend"]["objective"] = "tampered"
        with self.assertRaisesRegex(ValueError, "ERR_LEGEND_DIGEST"):
            extract_legend_extension(tampered, required=True)

    def test_ollama_client_is_strictly_loopback(self) -> None:
        with self.assertRaisesRegex(ValueError, "ERR_OLLAMA_LOOPBACK_REQUIRED"):
            OllamaClient("http://example.com:11434")
        with self.assertRaisesRegex(ValueError, "ERR_OLLAMA_LOOPBACK_REQUIRED"):
            OllamaClient("http://localhost.evil.example:11434")

    def test_ollama_client_rejects_redirects_off_loopback(self) -> None:
        self.fake.server.redirect_tags = True
        try:
            with self.assertRaisesRegex(RuntimeError, "ERR_OLLAMA_HTTP:302"):
                OllamaClient(self.fake.url).tags()
        finally:
            self.fake.server.redirect_tags = False

    def test_ollama_doctor_checks_real_api_shapes(self) -> None:
        report = ollama_doctor(
            completion_model=MISTRAL,
            embedding_model=EMBED,
            base_url=self.fake.url,
            timeout_seconds=5,
        )
        self.assertTrue(report["ready"], report)
        self.assertEqual(report["completion_model_digest"], MISTRAL_DIGEST)
        self.assertEqual(report["embedding_model_digest"], EMBED_DIGEST)
        self.assertTrue(report["embedding_384"])
        self.assertTrue(report["embedding_unit_norm"])

    def test_same_space_route_is_exact_digest_bound_identity(self) -> None:
        self.assertEqual(self.route_report["status"], "empirically_promotable")
        self.assertEqual(self.route_report["route_kind"], "same_space_identity")
        self.assertTrue(self.route_report["claims"]["same_space_identity_verified"])
        self.assertFalse(self.route_report["claims"]["generative_soft_prefix_expansion"])
        self.assertEqual(self.route_report["source_model_digest"], EMBED_DIGEST)
        self.assertEqual(self.route_report["target_model_digest"], EMBED_DIGEST)

    def test_calibrate_ollama_same_model_binds_digest_and_reuses_identical_embeddings(self) -> None:
        captured = {}

        def fake_calibrate_route(**kwargs):
            captured.update(kwargs)
            return {"promotion": {"passed": True}, "status": "empirically_promotable"}

        out = self.root / "ollama-calibration-fast"
        with mock.patch("braid_client.semantic_transfer.calibrate_route", side_effect=fake_calibrate_route):
            report = calibrate_ollama_route(
                source_model=EMBED,
                target_model=EMBED,
                output_dir=out,
                ollama_url=self.fake.url,
                count=576,
            )
        self.assertTrue(captured["same_space_identity"])
        self.assertEqual(captured["source_model_digest"], EMBED_DIGEST)
        self.assertEqual(captured["target_model_digest"], EMBED_DIGEST)
        self.assertTrue(np.array_equal(captured["source_raw"], captured["target_raw"]))
        self.assertEqual(report["ollama_model_binding"]["source_model_digest"], EMBED_DIGEST)
        self.assertGreater(report["ollama_model_binding"]["determinism_cosine"], 0.999999)

    def test_full_legend_frame_phase_b_and_builtin_ollama_handoff(self) -> None:
        root = self.root / "full-path"
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        legend = self._legend()
        frame, raw, source_vector, _ = build_frame_from_legend(
            self.route_dir,
            legend,
            sk,
            source_completion_model=MISTRAL,
            ollama_url=self.fake.url,
            session_id="legend-full-path",
        )
        self.assertEqual(source_vector.shape, (384,))
        adapter_meta = extract_ollama_extension(frame.manifest)
        self.assertEqual(adapter_meta["source_completion_model_digest"], MISTRAL_DIGEST)
        self.assertFalse(adapter_meta["generative_vector_injection"])

        receiver = self._receiver(sk, root)
        report = receiver.process_bytes(raw, source_transport="network", source_name="legend.brad", peer="192.168.1.108")
        self.assertTrue(report["accepted"], report)
        self.assertEqual(report["finality"], "committed")
        self.assertTrue(report["phase_b_committed"])
        self.assertTrue(report["post_commit_complete"])
        self.assertIn("legend_verify", report["pipeline"])
        self.assertIn("ollama_route_bind", report["pipeline"])
        self.assertTrue(report["ollama_adapter"]["route_bound"])
        self.assertIn("phase_b_commit", report["pipeline"])
        self.assertIn("ollama_handoff", report["pipeline"])
        self.assertTrue(report["handoff"]["accepted"], report["handoff"])
        self.assertAlmostEqual(report["handoff"]["legend_alignment_cosine"], 1.0, places=4)

        artifact = json.loads(Path(report["handoff"]["artifact_path"]).read_text(encoding="utf-8"))
        self.assertEqual(artifact["finality"], "committed")
        self.assertTrue(artifact["phase_b_committed"])
        self.assertFalse(artifact["generative_vector_injection"])
        self.assertEqual(artifact["legend_digest"], legend_digest(legend))
        self.assertEqual(artifact["response"], "Receiver continued from the committed signed Legend.")

    def test_ollama_failure_after_phase_b_degrades_but_cannot_rewrite_finality(self) -> None:
        root = self.root / "handoff-failure"
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        legend = self._legend()
        _, raw, _, _ = build_frame_from_legend(
            self.route_dir,
            legend,
            sk,
            source_completion_model=MISTRAL,
            ollama_url=self.fake.url,
            session_id="legend-handoff-failure",
        )
        receiver = self._receiver(sk, root)
        self.fake.server.fail_receiver_chat = True
        try:
            report = receiver.process_bytes(raw, source_transport="network", source_name="legend.brad")
        finally:
            self.fake.server.fail_receiver_chat = False
        self.assertTrue(report["accepted"], report)
        self.assertEqual(report["finality"], "committed")
        self.assertTrue(report["phase_b_committed"])
        self.assertFalse(report["post_commit_complete"])
        self.assertEqual(report["reason"], "RECEIVER_COMMITTED_HANDOFF_DEGRADED")
        self.assertFalse(report["handoff"]["accepted"])

    def test_signed_but_self_inconsistent_legend_digest_rejects_before_phase_b(self) -> None:
        root = self.root / "legend-tamper"
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        legend = self._legend()
        frame, _, source_vector, _ = build_frame_from_legend(
            self.route_dir,
            legend,
            sk,
            source_completion_model=MISTRAL,
            ollama_url=self.fake.url,
            session_id="legend-tamper",
        )
        manifest = copy.deepcopy(frame.manifest)
        manifest["extensions"]["braid_legend_digest"] = "f" * 64
        tampered_but_signed = BraidFrame(manifest, source_vector, signer_private_key=sk).to_bytes()
        receiver = self._receiver(sk, root)
        report = receiver.process_bytes(tampered_but_signed, source_transport="network", source_name="tampered.brad")
        self.assertFalse(report["accepted"], report)
        self.assertFalse(report["phase_b_committed"])
        self.assertEqual(report["finality"], "rejected")
        self.assertIn("ERR_LEGEND_DIGEST", report["reason"])

    def test_signed_ollama_metadata_must_match_receiver_authorized_route_before_phase_b(self) -> None:
        root = self.root / "adapter-route-tamper"
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        legend = self._legend()
        frame, _, source_vector, _ = build_frame_from_legend(
            self.route_dir,
            legend,
            sk,
            source_completion_model=MISTRAL,
            ollama_url=self.fake.url,
            session_id="adapter-route-tamper",
        )
        manifest = copy.deepcopy(frame.manifest)
        manifest["extensions"]["ollama_adapter"]["target_embedding_model_digest"] = "e" * 64
        inconsistent_but_signed = BraidFrame(manifest, source_vector, signer_private_key=sk).to_bytes()
        receiver = self._receiver(sk, root)
        report = receiver.process_bytes(inconsistent_but_signed, source_transport="network", source_name="adapter-tamper.brad")
        self.assertFalse(report["accepted"], report)
        self.assertFalse(report["phase_b_committed"])
        self.assertEqual(report["finality"], "rejected")
        self.assertIn("ERR_OLLAMA_ROUTE_TARGET_DIGEST", report["reason"])

    def test_completion_model_provenance_must_match_legend_generator(self) -> None:
        root = self.root / "generator-mismatch"
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        legend = self._legend()
        with self.assertRaisesRegex(ValueError, "ERR_OLLAMA_COMPLETION_MODEL_PROVENANCE"):
            build_frame_from_legend(
                self.route_dir,
                legend,
                sk,
                source_completion_model="other-model:latest",
                ollama_url=self.fake.url,
            )

    def test_shell_handoff_and_builtin_ollama_handoff_are_mutually_exclusive(self) -> None:
        root = self.root / "handoff-conflict"
        sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
        vk = sk.public_key()
        validator, registry, ledger, _ = create_validator_from_route_package(
            self.route_dir,
            get_raw_public_bytes(vk).hex(),
            root / "ledger.db",
        )
        with self.assertRaisesRegex(ValueError, "ERR_HANDOFF_MODE_CONFLICT"):
            AutomatedReceiver(
                validator=validator,
                registry=registry,
                ledger=ledger,
                verification_key=vk,
                config=ReceiverAutomationConfig(
                    storage_dir=root / "inbox",
                    handoff_command="true",
                    ollama_handoff=OllamaHandoffConfig(base_url=self.fake.url),
                ),
            )


if __name__ == "__main__":
    unittest.main()
