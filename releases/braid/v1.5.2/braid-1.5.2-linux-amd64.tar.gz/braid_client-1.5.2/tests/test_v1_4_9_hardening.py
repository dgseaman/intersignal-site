from __future__ import annotations

import hashlib
import json
import multiprocessing
import sqlite3
import struct
import sys
import tempfile
import time
import unittest
from pathlib import Path

from braid_client import __version__
from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.mcp_core.canonical import jcs_serialize
from braid_client.mcp_core.protocol import ReplayLedger
from braid_client.mcp_core.server import McpServer
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
from braid_client.sensing import ProximityField
from braid_client.server import create_authoritative_validator, generate_frame_object
from braid_client.transport.client import send_frame
from braid_client.transport.errors import PolicyError, ProtocolError
from braid_client.transport.server import ReceiverConfig, TransportServer


def _commit_worker(db_path: str, start_event, queue) -> None:
    ledger = ReplayLedger(db_path)
    start_event.wait(5)
    now = int(time.time())
    result = ledger.commit_atomic_transaction(
        receiver_node_id="receiver-a",
        signer_key_id="signer-a",
        route_id="route-a",
        session_id="shared-race-session",
        sequence_num=1,
        issued_at=now,
        expires_at=now + 300,
        predecessor_object_digest="0" * 64,
        current_object_digest="a" * 64,
        object_id="race-object",
        nonce="race-nonce",
    )
    queue.put(result)


class TransportFinalityV149Tests(unittest.TestCase):
    def _frame(self, root: Path) -> Path:
        path = root / "sample.brad"
        path.write_bytes(b"BRAD" + b"x" * 128)
        return path

    def test_external_validator_success_is_non_authoritative(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = self._frame(root)
            validator = f'{sys.executable} -c "import sys; sys.exit(0)" {{file}}'
            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox", validator_command=validator)
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertTrue(result.ack.stored)
            self.assertTrue(result.ack.validated)
            self.assertFalse(result.ack.accepted)
            self.assertEqual(result.ack.reason, "VALIDATED_NOT_COMMITTED")
            self.assertEqual(result.ack.destination, "quarantine")
            self.assertTrue(list((root / "inbox" / "quarantine").glob("*.brad")))
            self.assertFalse((root / "inbox" / "accepted").exists())

    def test_callback_cannot_claim_acceptance_without_phase_b(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = self._frame(root)

            def bad_callback(*_args, **_kwargs):
                return {
                    "stored": True,
                    "accepted": True,
                    "phase_b_committed": False,
                    "finality": "quarantined",
                    "reason": "SHOULD_NOT_ESCAPE",
                }

            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox", receiver_callback=bad_callback)
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertFalse(result.ack.accepted)
            self.assertEqual(result.ack.reason, "ERR_FINALITY_INVARIANT")

    def test_callback_acceptance_requires_committed_finality(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = self._frame(root)

            def committed_callback(*_args, **_kwargs):
                return {
                    "stored": True,
                    "accepted": True,
                    "phase_b_committed": True,
                    "finality": "committed",
                    "reason": "RECEIVER_COMMITTED",
                }

            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox", receiver_callback=committed_callback)
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertTrue(result.ack.accepted)
            self.assertEqual(result.ack.destination, "accepted")

    def test_callback_and_legacy_validator_are_mutually_exclusive(self) -> None:
        with self.assertRaisesRegex(PolicyError, "ERR_RECEIVER_CALLBACK_VALIDATOR_CONFLICT"):
            TransportServer(
                ReceiverConfig(
                    receiver_callback=lambda *_a, **_k: {},
                    validator_command="true {file}",
                )
            )

    def test_sender_rejects_oversize_before_network_io(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            frame = Path(temp_dir) / "oversize.brad"
            frame.write_bytes(b"x" * 4097)
            with self.assertRaisesRegex(ProtocolError, "ERR_FRAME_TOO_LARGE"):
                send_frame(frame, "127.0.0.1", 9, max_frame_bytes=4096)


class ReplayLedgerV149Tests(unittest.TestCase):
    def _commit(self, ledger: ReplayLedger, *, signer: str, route: str, session: str, sequence: int, predecessor: str, current: str):
        now = int(time.time())
        return ledger.commit_atomic_transaction(
            receiver_node_id="receiver-a",
            signer_key_id=signer,
            route_id=route,
            session_id=session,
            sequence_num=sequence,
            issued_at=now,
            expires_at=now + 300,
            predecessor_object_digest=predecessor,
            current_object_digest=current,
            object_id=f"{session}-{sequence}",
            nonce=f"nonce-{sequence}",
        )

    def test_session_heads_are_scoped_by_receiver_signer_route(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            ledger = ReplayLedger(str(Path(temp_dir) / "ledger.db"))
            session = "same-session-id"
            a1 = self._commit(ledger, signer="signer-a", route="route-a", session=session, sequence=1, predecessor="0" * 64, current="a" * 64)
            b1 = self._commit(ledger, signer="signer-b", route="route-b", session=session, sequence=1, predecessor="0" * 64, current="b" * 64)
            self.assertTrue(a1[0], a1)
            self.assertTrue(b1[0], b1)
            a2 = self._commit(ledger, signer="signer-a", route="route-a", session=session, sequence=2, predecessor="a" * 64, current="c" * 64)
            b2 = self._commit(ledger, signer="signer-b", route="route-b", session=session, sequence=2, predecessor="b" * 64, current="d" * 64)
            self.assertTrue(a2[0], a2)
            self.assertTrue(b2[0], b2)

    def test_unambiguous_v148_session_head_migrates_to_scoped_v4(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            db_path = str(Path(temp_dir) / "legacy.db")
            conn = sqlite3.connect(db_path)
            conn.execute("""CREATE TABLE replay_ledger_v3 (receiver_node_id TEXT NOT NULL, signer_key_id TEXT NOT NULL, route_id TEXT NOT NULL, session_id TEXT NOT NULL, sequence_num INTEGER NOT NULL, object_id TEXT NOT NULL, nonce TEXT NOT NULL, expiry INTEGER NOT NULL, PRIMARY KEY (receiver_node_id, signer_key_id, route_id, session_id, sequence_num))""")
            conn.execute("""CREATE TABLE session_state_ledger_v3 (session_id TEXT PRIMARY KEY, last_sequence_num INTEGER NOT NULL, last_object_digest TEXT NOT NULL, last_vector_blob BLOB, updated_at INTEGER NOT NULL)""")
            conn.execute("INSERT INTO replay_ledger_v3 VALUES (?, ?, ?, ?, ?, ?, ?, ?)", ("receiver-a", "signer-a", "route-a", "legacy-session", 1, "legacy-session-1", "n", int(time.time()) + 300))
            conn.execute("INSERT INTO session_state_ledger_v3 VALUES (?, ?, ?, ?, ?)", ("legacy-session", 1, "a" * 64, None, int(time.time())))
            conn.commit()
            conn.close()
            ledger = ReplayLedger(db_path)
            result = self._commit(ledger, signer="signer-a", route="route-a", session="legacy-session", sequence=2, predecessor="a" * 64, current="b" * 64)
            self.assertTrue(result[0], result)

    def test_simultaneous_duplicate_commit_has_single_winner(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            db_path = str(Path(temp_dir) / "ledger.db")
            ReplayLedger(db_path)
            ctx = multiprocessing.get_context("spawn")
            start = ctx.Event()
            queue = ctx.Queue()
            workers = [ctx.Process(target=_commit_worker, args=(db_path, start, queue)) for _ in range(2)]
            for worker in workers:
                worker.start()
            start.set()
            results = [queue.get(timeout=10) for _ in workers]
            for worker in workers:
                worker.join(timeout=10)
                self.assertEqual(worker.exitcode, 0)
            successes = [result for result in results if result[0]]
            failures = [result for result in results if not result[0]]
            self.assertEqual(len(successes), 1, results)
            self.assertEqual(len(failures), 1, results)
            self.assertTrue("ERR_SEQUENCE" in failures[0][1] or "ERR_REPLAY_CONFLICT" in failures[0][1], failures[0])


class CanonicalizationV149Tests(unittest.TestCase):
    def test_rfc8785_utf16_property_sorting_regression(self) -> None:
        value = {
            "€": "Euro Sign",
            "\r": "Carriage Return",
            "דּ": "Hebrew Letter Dalet With Dagesh",
            "1": "One",
            "😀": "Emoji: Grinning Face",
            "\u0080": "Control",
            "ö": "Latin Small Letter O With Diaeresis",
        }
        expected = '{"\\r":"Carriage Return","1":"One","\u0080":"Control","ö":"Latin Small Letter O With Diaeresis","€":"Euro Sign","😀":"Emoji: Grinning Face","דּ":"Hebrew Letter Dalet With Dagesh"}'.encode("utf-8")
        self.assertEqual(jcs_serialize(value), expected)

    def test_rfc8785_number_examples_regression(self) -> None:
        value = {"numbers": [333333333.33333329, 1e30, 4.50, 2e-3, 1e-27]}
        self.assertEqual(jcs_serialize(value), b'{"numbers":[333333333.3333333,1e+30,4.5,0.002,1e-27]}')

    def test_rfc8785_appendix_b_ieee754_vectors(self) -> None:
        samples = [
            ("0000000000000000", "0"),
            ("8000000000000000", "0"),
            ("0000000000000001", "5e-324"),
            ("8000000000000001", "-5e-324"),
            ("7fefffffffffffff", "1.7976931348623157e+308"),
            ("ffefffffffffffff", "-1.7976931348623157e+308"),
            ("4340000000000000", "9007199254740992"),
            ("c340000000000000", "-9007199254740992"),
            ("4430000000000000", "295147905179352830000"),
            ("44b52d02c7e14af5", "9.999999999999997e+22"),
            ("44b52d02c7e14af6", "1e+23"),
            ("44b52d02c7e14af7", "1.0000000000000001e+23"),
            ("444b1ae4d6e2ef4e", "999999999999999700000"),
            ("444b1ae4d6e2ef4f", "999999999999999900000"),
            ("444b1ae4d6e2ef50", "1e+21"),
            ("3eb0c6f7a0b5ed8c", "9.999999999999997e-7"),
            ("3eb0c6f7a0b5ed8d", "0.000001"),
            ("41b3de4355555553", "333333333.3333332"),
            ("41b3de4355555554", "333333333.33333325"),
            ("41b3de4355555555", "333333333.3333333"),
            ("41b3de4355555556", "333333333.3333334"),
            ("41b3de4355555557", "333333333.33333343"),
            ("becbf647612f3696", "-0.0000033333333333333333"),
            ("43143ff3c1cb0959", "1424953923781206.2"),
        ]
        for ieee_hex, expected in samples:
            value = struct.unpack(">d", bytes.fromhex(ieee_hex))[0]
            self.assertEqual(jcs_serialize(value).decode("utf-8"), expected, ieee_hex)

        for nonfinite in (float("nan"), float("inf"), float("-inf")):
            with self.assertRaises(ValueError):
                jcs_serialize(nonfinite)


class DerivedStateLineageV149Tests(unittest.TestCase):
    def test_receiver_local_vector_has_explicit_source_lineage(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            sk, _, _ = load_or_create_signing_key(str(root / "sender.key"))
            vk = sk.public_key()
            validator, registry, ledger = create_authoritative_validator(
                get_raw_public_bytes(vk).hex(), ledger_path=root / "ledger.db"
            )
            receiver = AutomatedReceiver(
                validator=validator,
                registry=registry,
                ledger=ledger,
                verification_key=vk,
                config=ReceiverAutomationConfig(storage_dir=root / "inbox"),
            )
            _, raw, _ = generate_frame_object(signing_key=sk)
            report = receiver.process_bytes(raw, source_transport="file", source_name="lineage.brad")
            self.assertTrue(report["accepted"], report)
            lineage_path = Path(report["lineage_path"])
            lineage = json.loads(lineage_path.read_text())
            vector_bytes = Path(report["vector_path"]).read_bytes()
            self.assertEqual(lineage["source_object_digest"], report["object_digest"])
            self.assertEqual(lineage["source_transport_sha256"], report["transport_sha256"])
            self.assertEqual(lineage["derived_artifact_sha256"], hashlib.sha256(vector_bytes).hexdigest())
            self.assertFalse(lineage["sender_signature_covers_derived_artifact"])
            self.assertEqual(lineage["authority"], "receiver_local_evidence_only")
            self.assertTrue(lineage["phase_b_committed"])


class MetadataAndSensingV149Tests(unittest.TestCase):
    def test_mcp_server_version_comes_from_package_version(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            ledger = ReplayLedger(str(Path(temp_dir) / "ledger.db"))
            server = McpServer(registry=object(), ledger=ledger)  # initialize does not touch registry
            response = json.loads(server.handle_message('{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}'))
            self.assertEqual(__version__, "1.5.2")
            self.assertEqual(response["result"]["serverInfo"]["version"], __version__)

    def test_sensing_text_is_bounded_and_control_cleaned(self) -> None:
        field = ProximityField(max_tracks=4, max_key_chars=8, max_label_chars=12)
        record = field.observe("K" * 20 + "\x00\n", -55, label="BRAID\x00\nLABEL" + "X" * 40)
        self.assertLessEqual(len(record["key"]), 8)
        self.assertLessEqual(len(record["label"]), 12)
        self.assertNotIn("\x00", record["label"])
        self.assertNotIn("\n", record["label"])

    def test_sensing_track_count_is_bounded(self) -> None:
        field = ProximityField(max_tracks=3)
        for index in range(10):
            field.observe(f"node-{index}", -60 + (index % 3), label=f"BRAID {index}")
        self.assertLessEqual(len(field._tracks), 3)


if __name__ == "__main__":
    unittest.main()
