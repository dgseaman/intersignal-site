from __future__ import annotations

import json
import tempfile
import threading
import unittest
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest import mock

from braid_client import __version__
from braid_client.environment import detect_environment
from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig
from braid_client.server import HardenedBraidHTTPHandler, create_authoritative_validator


class FrontDoorV152Tests(unittest.TestCase):
    def test_environment_is_local_only_and_never_promises_semantic_invention(self):
        with mock.patch("braid_client.environment._private_ipv4_candidates", return_value=["192.168.50.7"]), \
             mock.patch("braid_client.environment._ollama_snapshot", return_value={
                 "endpoint": "http://127.0.0.1:11434",
                 "reachable": True,
                 "models": [{"name": "nomic-embed-text:latest", "digest": "1" * 64}],
                 "embedding_candidates": ["nomic-embed-text:latest"],
                 "completion_candidates": ["mistral:latest"],
             }):
            env = detect_environment()
        self.assertEqual(env["version"], __version__)
        self.assertTrue(env["autodetect_is_local_only"])
        self.assertFalse(env["bridge_semantic_invention"])
        self.assertEqual(env["semantic_rule"], "heterogeneous_reembedding_requires_signed_semantic_capsule")
        self.assertEqual(env["lan"]["preferred"], "192.168.50.7")
        commands = "\n".join(row["command"] for row in env["commands"])
        self.assertIn("capsule-frame", commands)
        self.assertIn("--semantic-embed-model", commands)
        self.assertIn("--allow-lan", commands)

    def test_visualizer_contains_autodetect_and_capsule_pipeline(self):
        html = (Path(__file__).parents[1] / "braid_client" / "static" / "braid_visualizer.html").read_text(encoding="utf-8")
        self.assertIn("Local node autodetect", html)
        self.assertIn("Semantic Capsule", html)
        self.assertIn("No capsule", html)
        self.assertIn("/api/environment", html)
        self.assertIn("ambient-scan", html)
        self.assertIn("prefers-reduced-motion", html)


class FrontDoorHTTPV152Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.sk, _, _ = load_or_create_signing_key(str(Path(cls.tmp.name) / "sender.key"))
        cls.vk = cls.sk.public_key()
        cls.validator, cls.registry, cls.ledger = create_authoritative_validator(get_raw_public_bytes(cls.vk).hex())
        Handler = HardenedBraidHTTPHandler
        Handler.signing_key = cls.sk
        Handler.verification_key = cls.vk
        Handler.validator = cls.validator
        Handler.registry = cls.registry
        Handler.ledger = cls.ledger
        Handler.receiver_automation = AutomatedReceiver(
            validator=cls.validator,
            registry=cls.registry,
            ledger=cls.ledger,
            verification_key=cls.vk,
            config=ReceiverAutomationConfig(storage_dir=Path(cls.tmp.name) / "field-inbox"),
        )
        Handler.last_receiver_report = {}
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=3)
        cls.tmp.cleanup()

    def test_environment_endpoint_exposes_only_local_detection_facts(self):
        with urllib.request.urlopen(self.base + "/api/environment", timeout=5) as response:
            self.assertEqual(response.status, 200)
            body = json.loads(response.read())
        self.assertEqual(body["version"], __version__)
        self.assertTrue(body["autodetect_is_local_only"])
        self.assertFalse(body["bridge_semantic_invention"])
        self.assertEqual(body["ollama"]["endpoint"], "http://127.0.0.1:11434")

    def test_health_advertises_capsule_rule_without_overclaim(self):
        with urllib.request.urlopen(self.base + "/api/health", timeout=5) as response:
            body = json.loads(response.read())
        self.assertTrue(body["semantic_capsule"])
        self.assertTrue(body["exact_space_fast_path"])
        self.assertEqual(body["semantic_rule"], "heterogeneous_reembedding_requires_signed_semantic_capsule")


if __name__ == "__main__":
    unittest.main()
