"""
Braid Client v1.4.2 Conformance and Security Test Suite
"""

import unittest
import os
import sys
import json
import tempfile
import numpy as np
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import ed25519

# Ensure local braid_client package is imported
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from braid_client.keys import load_or_create_signing_key, load_verification_key, save_keypair
from braid_client.server import generate_frame_object, evaluate_normative_receiver_gates, analyze_vector_stats
from braid_client.qr_engine import chunk_binary_frame, OpticalChunkCollector
from braid_client.mcp_core.protocol import BraidFrame


class TestBraidClientV142(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.key_path = str(Path(self.tmp_dir.name) / "test_sender.key")
        self.sk, self.priv_p, self.pub_p = load_or_create_signing_key(self.key_path)
        self.vk = self.sk.public_key()

    def tearDown(self):
        self.tmp_dir.cleanup()

    def test_key_persistence_and_cross_process_verification(self):
        """P0-2 Fix Verification: Ensures signing and verification keys persist across processes."""
        frame, raw_bytes, _ = generate_frame_object(signing_key=self.sk)
        
        # Load verification key from saved .pub file
        loaded_vk = load_verification_key(self.pub_p)
        
        # Evaluate receiver gates
        gates = evaluate_normative_receiver_gates(frame, trusted_vk=loaded_vk)
        self.assertTrue(gates["overall_accepted"])
        self.assertTrue(gates["gate1_signature"]["passed"])
        self.assertTrue(gates["gate2_representation"]["passed"])
        self.assertTrue(gates["gate3_anomaly"]["passed"])

    def test_wrong_signature_rejection(self):
        """Verifies Gate 1 fails when checked against an untrusted/wrong public key."""
        frame, _, _ = generate_frame_object(signing_key=self.sk)
        wrong_sk = ed25519.Ed25519PrivateKey.generate()
        wrong_vk = wrong_sk.public_key()

        gates = evaluate_normative_receiver_gates(frame, trusted_vk=wrong_vk)
        self.assertFalse(gates["overall_accepted"])
        self.assertFalse(gates["gate1_signature"]["passed"])
        self.assertIn("ERR_BAD_SIGNATURE", gates["rejection_reason"])

    def test_non_unit_norm_rejection(self):
        """Verifies Gate 2 fails when vector L2 norm is outside [0.99, 1.01]."""
        manifest = frame_obj = generate_frame_object(signing_key=self.sk)[0].manifest
        non_unit_vec = np.ones(384, dtype=np.float32) * 2.0  # L2 norm = sqrt(384 * 4) = 39.19
        
        bad_frame = BraidFrame(manifest, non_unit_vec.tolist(), signer_private_key=self.sk)
        gates = evaluate_normative_receiver_gates(bad_frame, trusted_vk=self.vk)
        
        self.assertFalse(gates["overall_accepted"])
        self.assertFalse(gates["gate2_representation"]["passed"])
        self.assertIn("ERR_VECTOR_NORM", gates["rejection_reason"])

    def test_adversarial_noise_gate3_rejection(self):
        """Verifies Gate 3 fails when adversarial noise triggers Mahalanobis/Residual OOD anomaly."""
        # Generate frame with large adversarial noise std dev = 0.5
        noisy_frame, _, _ = generate_frame_object(noise_std=0.5, signing_key=self.sk)
        gates = evaluate_normative_receiver_gates(noisy_frame, trusted_vk=self.vk)
        
        self.assertFalse(gates["overall_accepted"])
        self.assertFalse(gates["gate3_anomaly"]["passed"])

    def test_optical_chunk_collector_reassembly(self):
        """Verifies chunk streaming, CRC32 checks, duplicate and reordered chunk handling."""
        frame, raw_bytes, _ = generate_frame_object(signing_key=self.sk)
        chunks = chunk_binary_frame(raw_bytes, max_chunk_size=120)

        collector = OpticalChunkCollector()
        
        # Ingest chunks out of order
        for c in reversed(chunks):
            res = collector.ingest_chunk_string(c["chunk_str"])
            self.assertEqual(res["status"], "success")

        self.assertTrue(res["is_complete"])
        self.assertEqual(res["reassembled_bytes"], raw_bytes)

        # Ingest duplicate chunk (should be handled gracefully)
        dup_res = collector.ingest_chunk_string(chunks[0]["chunk_str"])
        self.assertEqual(dup_res["status"], "success")

    def test_effective_authority_derivation(self):
        """Verifies receiver-derived effective authority P_effective = P_local intersect P_requested."""
        frame, _, _ = generate_frame_object(sender_requested_max_action="refund_max_75", signing_key=self.sk)
        gates = evaluate_normative_receiver_gates(frame, trusted_vk=self.vk)
        
        effective = gates["effective_authority"]
        self.assertEqual(effective["refund_max"], 50.0)  # Receiver local policy limit ($50) narrows $75 request


if __name__ == "__main__":
    unittest.main()
