"""
Braid Client v1.4.3 Authoritative Conformance and Security Test Suite
Executes real subprocess CLI calls and validates mandatory rejection matrix.
"""

import unittest
import os
import sys
import json
import time
import tempfile
import subprocess
import numpy as np
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

# Ensure local braid_client package is imported
CLIENT_PKG_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CLIENT_PKG_DIR))

from braid_client.keys import load_or_create_signing_key, load_verification_key, get_raw_public_bytes
from braid_client.server import create_authoritative_validator, create_sample_manifest, generate_frame_object
from braid_client.qr_engine import chunk_binary_frame, OpticalChunkCollector, StandardQRCodeEncoder
from braid_client.mcp_core.protocol import BraidFrame
from braid_client.mcp_core.canonical import serialize_fp16_payload, compute_payload_digest


class TestBraidClientV143Subprocess(unittest.TestCase):

    def setUp(self):
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.tmp_path = Path(self.tmp_dir.name)
        self.key_path = str(self.tmp_path / "sender.key")
        self.pub_path = str(self.tmp_path / "sender.pub")
        self.frame_path = str(self.tmp_path / "state.brad")

        self.sk, _, _ = load_or_create_signing_key(self.key_path)
        self.vk = self.sk.public_key()
        self.vk_hex = get_raw_public_bytes(self.vk).hex()

        self.env = dict(os.environ)
        self.env["PYTHONPATH"] = str(CLIENT_PKG_DIR) + ":" + os.environ.get("PYTHONPATH", "")

    def tearDown(self):
        self.tmp_dir.cleanup()

    def run_cli_generate(self, signing_key_path: str, output_path: str, preset="llama3_gemma2_soft_prefix", noise=0.0):
        cmd = [
            sys.executable, "-m", "braid_client.cli", "generate",
            "--signing-key", signing_key_path,
            "--output", output_path,
            "--preset", preset,
            "--noise", str(noise)
        ]
        return subprocess.run(cmd, env=self.env, capture_output=True, text=True)

    def run_cli_inspect(self, trusted_key_path: str, frame_path: str):
        cmd = [
            sys.executable, "-m", "braid_client.cli", "inspect",
            "--trusted-key", trusted_key_path,
            frame_path
        ]
        return subprocess.run(cmd, env=self.env, capture_output=True, text=True)

    def test_subprocess_generate_and_inspect_success(self):
        """Verifies real subprocess CLI generation in Process A and inspection in Process B."""
        gen_res = self.run_cli_generate(self.key_path, self.frame_path)
        self.assertEqual(gen_res.returncode, 0, f"Generate failed: {gen_res.stderr}")

        insp_res = self.run_cli_inspect(self.pub_path, self.frame_path)
        self.assertEqual(insp_res.returncode, 0, f"Inspect failed: {insp_res.stderr}")
        self.assertIn("PHASE A VALIDATED: True", insp_res.stdout)

    def test_p0_2_payload_tamper_rejection(self):
        """P0-2 Mandatory Test: Altered payload with unchanged manifest/signature is rejected with ERR_PAYLOAD_DIGEST."""
        self.run_cli_generate(self.key_path, self.frame_path)

        with open(self.frame_path, "rb") as f:
            valid_bytes = f.read()

        frame = BraidFrame.from_bytes(valid_bytes)
        alt_vec = np.random.randn(384).astype(np.float32)
        alt_vec /= np.linalg.norm(alt_vec)
        tampered_payload = serialize_fp16_payload(alt_vec)

        m_len = frame.manifest_len
        tampered_bytes = valid_bytes[:12 + m_len + 64] + tampered_payload

        tampered_path = str(self.tmp_path / "tampered.brad")
        with open(tampered_path, "wb") as f:
            f.write(tampered_bytes)

        insp_res = self.run_cli_inspect(self.pub_path, tampered_path)
        self.assertNotEqual(insp_res.returncode, 0)
        self.assertIn("ERR_PAYLOAD_DIGEST", insp_res.stdout)

    def test_manifest_tamper_signature_rejection(self):
        """Altered manifest JCS bytes fail Ed25519 signature verification."""
        self.run_cli_generate(self.key_path, self.frame_path)

        with open(self.frame_path, "rb") as f:
            valid_bytes = f.read()

        frame = BraidFrame.from_bytes(valid_bytes)
        manifest_tampered = dict(frame.manifest)
        manifest_tampered["sequence_num"] = 99
        tampered_frame = BraidFrame(manifest_tampered, frame.vector, signer_private_key=self.sk)

        tampered_path = str(self.tmp_path / "manifest_tampered.brad")
        with open(tampered_path, "wb") as f:
            f.write(tampered_frame.to_bytes())

        # Inspect using wrong key
        wrong_sk = ed25519.Ed25519PrivateKey.generate()
        wrong_pub_path = str(self.tmp_path / "wrong.pub")
        with open(wrong_pub_path, "wb") as f:
            f.write(wrong_sk.public_key().public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            ))

        insp_res = self.run_cli_inspect(wrong_pub_path, tampered_path)
        self.assertNotEqual(insp_res.returncode, 0)
        self.assertIn("ERR_BAD_SIGNATURE", insp_res.stdout)

    def test_expired_envelope_rejection(self):
        """Expired envelope (expires_at < now) fails ReplayCheckGate."""
        now = int(time.time())
        manifest = create_sample_manifest()
        manifest["issued_at"] = now - 600
        manifest["expires_at"] = now - 300  # Expired

        vec = generate_frame_object(signing_key=self.sk)[0].vector
        expired_frame = BraidFrame(manifest, vec, signer_private_key=self.sk)

        validator, _, _ = create_authoritative_validator(self.vk_hex)
        val_res = validator.validate_frame_phase_a(expired_frame.to_bytes())

        self.assertFalse(val_res.is_valid)
        self.assertTrue("ERR_EXPIRED" in val_res.message or "ERR_STALE" in val_res.message)

    def test_wrong_audience_rejection(self):
        """Envelope target mismatch (receiver_node_id != local_node_id) fails with ERR_WRONG_AUDIENCE."""
        manifest = create_sample_manifest()
        manifest["receiver_node_id"] = "node:untrusted:attacker"

        vec = generate_frame_object(signing_key=self.sk)[0].vector
        frame = BraidFrame(manifest, vec, signer_private_key=self.sk)

        validator, _, _ = create_authoritative_validator(self.vk_hex)
        val_res = validator.validate_frame_phase_a(frame.to_bytes())

        self.assertFalse(val_res.is_valid)
        self.assertIn("ERR_WRONG_AUDIENCE", val_res.message)

    def test_p0_3_adversarial_ood_residual_rejection(self):
        """P0-3 Test: Out-of-subspace adversarial vector fails SubspaceResidualGate."""
        noisy_frame, _, _ = generate_frame_object(noise_std=1.5, signing_key=self.sk)

        validator, _, _ = create_authoritative_validator(self.vk_hex)
        val_res = validator.validate_frame_phase_a(noisy_frame.to_bytes())

        self.assertFalse(val_res.is_valid)
        self.assertIn("SubspaceResidualGate", val_res.gate_name)

    def test_optical_chunk_bounded_collector(self):
        """P1 Test: Bounded OpticalChunkCollector schema validation, duplicate equality, and CRC32 checks."""
        frame, raw_bytes, _ = generate_frame_object(signing_key=self.sk)
        chunks = chunk_binary_frame(raw_bytes, max_chunk_size=100)

        collector = OpticalChunkCollector()

        # Ingest chunks out of order
        for c in reversed(chunks):
            res = collector.ingest_chunk_string(c["chunk_str"])
            self.assertEqual(res["status"], "success")

        self.assertTrue(res["is_complete"])
        self.assertEqual(res["reassembled_bytes"], raw_bytes)

        # Ingest bad CRC chunk
        parts = chunks[0]["chunk_str"].split(":")
        parts[4] = "00000000"  # Deliberately invalid CRC32
        bad_crc_chunk = ":".join(parts)
        bad_res = collector.ingest_chunk_string(bad_crc_chunk)
        self.assertEqual(bad_res["status"], "error")
        self.assertIn("ERR_CRC32_MISMATCH", bad_res["error"])


if __name__ == "__main__":
    unittest.main()
