from __future__ import annotations

import json
import os
import stat
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from braid_client import __version__
from braid_client.cli import run_doctor
from braid_client.keys import get_raw_public_bytes, load_or_create_signing_key
from braid_client.receiver import AutomatedReceiver, ReceiverAutomationConfig, RECEIPT_SCHEMA
from braid_client.server import HardenedBraidHTTPHandler, create_authoritative_validator, generate_frame_object
from braid_client.transport.validator import run_validator


class ReceiverPolishV148Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.sk, _, _ = load_or_create_signing_key(str(self.root / "sender.key"))
        self.vk = self.sk.public_key()
        self.validator, self.registry, self.ledger = create_authoritative_validator(get_raw_public_bytes(self.vk).hex())

    def tearDown(self):
        self.tmp.cleanup()

    def receiver(self, **overrides) -> AutomatedReceiver:
        config = ReceiverAutomationConfig(storage_dir=self.root / "inbox", **overrides)
        return AutomatedReceiver(
            validator=self.validator,
            registry=self.registry,
            ledger=self.ledger,
            verification_key=self.vk,
            config=config,
        )

    def test_committed_finality_is_unambiguous_and_storage_is_private(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        report = self.receiver().process_bytes(raw, source_transport="file", source_name="state.brad", peer="local")
        self.assertTrue(report["accepted"], report)
        self.assertEqual(report["finality"], "committed")
        self.assertTrue(report["phase_b_committed"])
        self.assertTrue(report["post_commit_complete"])
        self.assertEqual(report["schema"], RECEIPT_SCHEMA)
        self.assertEqual(report["accepted"], report["finality"] == "committed")
        self.assertTrue(Path(report["receipt_path"]).is_file())
        for bucket in ("quarantine", "accepted", "state", "receipts"):
            mode = stat.S_IMODE(os.stat(self.root / "inbox" / bucket).st_mode)
            self.assertEqual(mode, 0o700, (bucket, oct(mode)))

    def test_rejected_intake_gets_durable_receipt_and_rejected_finality(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        tampered = bytearray(raw)
        tampered[-1] ^= 0x01
        report = self.receiver().process_bytes(bytes(tampered), source_transport="file", source_name="tampered.brad")
        self.assertFalse(report["accepted"], report)
        self.assertEqual(report["finality"], "rejected")
        self.assertFalse(report["phase_b_committed"])
        self.assertTrue(Path(report["receipt_path"]).is_file())
        receipt = json.loads(Path(report["receipt_path"]).read_text())
        self.assertEqual(receipt["transfer_id"], report["transfer_id"])
        self.assertEqual(receipt["finality"], "rejected")

    def test_source_metadata_is_bounded_before_receipt_and_audit(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        report = self.receiver().process_bytes(
            raw,
            source_transport="T" * 1000 + "\n",
            source_name="state.brad",
            peer="P" * 1000 + "\x00\n",
        )
        self.assertLessEqual(len(report["source_transport"]), 64)
        self.assertLessEqual(len(report["source_peer"]), 160)
        self.assertNotIn("\n", report["source_transport"])
        self.assertNotIn("\x00", report["source_peer"])

    def test_missing_handoff_executable_cannot_rewrite_commit_finality(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        report = self.receiver(handoff_command="/definitely/missing/braid-adapter {frame}").process_bytes(
            raw, source_transport="file", source_name="handoff.brad"
        )
        self.assertTrue(report["accepted"], report)
        self.assertEqual(report["finality"], "committed")
        self.assertTrue(report["phase_b_committed"])
        self.assertFalse(report["post_commit_complete"])
        self.assertEqual(report["handoff"]["reason"], "ERR_HANDOFF_EXEC")
        self.assertEqual(report["reason"], "RECEIVER_COMMITTED_HANDOFF_DEGRADED")

    def test_external_transport_validator_fails_closed_on_bad_command(self):
        frame = self.root / "frame.brad"
        frame.write_bytes(b"test")
        missing = run_validator("/definitely/missing/braid-validator {file}", frame, 1.0)
        malformed = run_validator("'unterminated", frame, 1.0)
        self.assertFalse(missing.accepted)
        self.assertFalse(missing.ran)
        self.assertEqual(missing.reason, "ERR_VALIDATOR_EXEC")
        self.assertFalse(malformed.accepted)
        self.assertFalse(malformed.ran)
        self.assertEqual(malformed.reason, "ERR_VALIDATOR_PARSE")

    def test_doctor_is_ready_without_optional_ble(self):
        report = run_doctor()
        self.assertTrue(report["ready"], report)
        self.assertTrue(report["receiver_roundtrip"])
        self.assertTrue(report["finality_invariant"])
        self.assertEqual(report["version"], __version__)


class FieldHTTPV148Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.sk, _, _ = load_or_create_signing_key(str(Path(cls.tmp.name) / "sender.key"))
        cls.vk = cls.sk.public_key()
        cls.validator, cls.registry, cls.ledger = create_authoritative_validator(get_raw_public_bytes(cls.vk).hex())
        Handler = HardenedBraidHTTPHandler
        Handler.signing_key = cls.sk
        Handler.verification_key = cls.vk
        Handler.validator = cls.validator
        Handler.registry = cls.registry
        Handler.ledger = cls.ledger
        Handler.receiver_automation = AutomatedReceiver(
            validator=cls.validator,
            registry=cls.registry,
            ledger=cls.ledger,
            verification_key=cls.vk,
            config=ReceiverAutomationConfig(storage_dir=Path(cls.tmp.name) / "field-inbox"),
        )
        Handler.last_receiver_report = {}
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=3)
        cls.tmp.cleanup()

    def test_health_is_minimal_and_security_headers_are_hardened(self):
        with urllib.request.urlopen(self.base + "/api/health", timeout=5) as response:
            body = json.loads(response.read())
            self.assertEqual(body["status"], "ready")
            self.assertEqual(body["version"], __version__)
            self.assertEqual(body["field"], "loopback_only")
            self.assertEqual(response.headers["Referrer-Policy"], "no-referrer")
            self.assertEqual(response.headers["Cross-Origin-Opener-Policy"], "same-origin")
            self.assertIn("object-src 'none'", response.headers["Content-Security-Policy"])

    def test_http_inspect_reports_phase_a_without_claiming_acceptance(self):
        _, raw, _ = generate_frame_object(signing_key=self.sk)
        req = urllib.request.Request(
            self.base + "/api/inspect",
            data=json.dumps({"raw_frame_hex": raw.hex()}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            self.assertEqual(response.status, 200)
            body = json.loads(response.read())
        self.assertEqual(body["status"], "phase_a_validated")
        self.assertFalse(body["accepted"])
        self.assertEqual(body["finality"], "not_committed")
        self.assertEqual(body["phase"], "A_non_locking")
        self.assertTrue(body["gates"]["overall_accepted"])

    def test_post_rejects_non_object_and_nonfinite_json(self):
        for payload in (b"[]", b'{"noise_std":NaN}'):
            req = urllib.request.Request(
                self.base + "/api/generate",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with self.assertRaises(urllib.error.HTTPError) as ctx:
                urllib.request.urlopen(req, timeout=5)
            self.assertEqual(ctx.exception.code, 400)
            body = json.loads(ctx.exception.read())
            self.assertEqual(body["error"], "ERR_JSON_OBJECT_REQUIRED")

    def test_field_ui_contains_livestream_readiness_and_finality_language(self):
        with urllib.request.urlopen(self.base + "/", timeout=5) as response:
            html = response.read().decode("utf-8")
        self.assertIn("One field.<br>Any path.", html)
        self.assertIn("FIELD READY", html)
        self.assertIn("finality", html)
        self.assertIn("Commit locally", html)


if __name__ == "__main__":
    unittest.main()
