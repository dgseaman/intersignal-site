from __future__ import annotations

import json
import socket
import struct
import subprocess
import sys
import time
import tempfile
import unittest
from pathlib import Path

from braid_client.transport.client import send_frame
from braid_client.transport.discovery import decode_advertisement, encode_advertisement
from braid_client.transport.errors import PolicyError, ProtocolError
from braid_client.transport.policy import BindScope, classify_bind_scope, enforce_bind_policy
from braid_client.transport.protocol import HEADER, MAGIC, WIRE_VERSION, decode_transfer_from_socket, encode_transfer, sanitize_filename, sha256_bytes
from braid_client.transport.server import ReceiverConfig, TransportServer


class FakeSocket:
    def __init__(self, data: bytes):
        self._data = bytearray(data)

    def recv(self, length: int) -> bytes:
        if not self._data:
            return b""
        chunk = bytes(self._data[:length])
        del self._data[:length]
        return chunk


class ProtocolTests(unittest.TestCase):
    def test_round_trip(self) -> None:
        payload = b"BRAD" + bytes(range(64))
        encoded = encode_transfer(payload, "state.brad")
        metadata, recovered = decode_transfer_from_socket(FakeSocket(encoded))  # type: ignore[arg-type]
        self.assertEqual(recovered, payload)
        self.assertEqual(metadata.transport_sha256, sha256_bytes(payload))
        self.assertEqual(metadata.filename, "state.brad")

    def test_digest_mismatch_rejects(self) -> None:
        payload = b"BRAD-payload"
        encoded = bytearray(encode_transfer(payload, "state.brad"))
        encoded[-1] ^= 0x01
        with self.assertRaisesRegex(ProtocolError, "ERR_DIGEST_MISMATCH"):
            decode_transfer_from_socket(FakeSocket(bytes(encoded)))  # type: ignore[arg-type]

    def test_oversize_rejects(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "ERR_FRAME_TOO_LARGE"):
            encode_transfer(b"x" * 11, "x.brad", max_frame_bytes=10)

    def test_filename_sanitization(self) -> None:
        self.assertEqual(sanitize_filename("../../hello world"), "helloworld.brad")

    def test_unknown_flags_reject(self) -> None:
        packet = bytearray(encode_transfer(b"hello", "x.brad"))
        magic, version, _flags, metadata_len, payload_len = HEADER.unpack(packet[: HEADER.size])
        packet[: HEADER.size] = HEADER.pack(magic, version, 1, metadata_len, payload_len)
        with self.assertRaisesRegex(ProtocolError, "ERR_FLAGS"):
            decode_transfer_from_socket(FakeSocket(bytes(packet)))  # type: ignore[arg-type]


class PolicyTests(unittest.TestCase):
    def test_loopback_default(self) -> None:
        decision = enforce_bind_policy("127.0.0.1", allow_lan=False, allow_public=False, tls_enabled=False, insecure_public=False)
        self.assertEqual(decision.scope, BindScope.LOOPBACK)

    def test_lan_requires_opt_in(self) -> None:
        with self.assertRaisesRegex(PolicyError, "ERR_LAN_BIND_REQUIRES_ALLOW_LAN"):
            enforce_bind_policy("192.168.1.5", allow_lan=False, allow_public=False, tls_enabled=False, insecure_public=False)
        decision = enforce_bind_policy("192.168.1.5", allow_lan=True, allow_public=False, tls_enabled=False, insecure_public=False)
        self.assertEqual(decision.scope, BindScope.LAN)

    def test_public_requires_opt_in_and_tls(self) -> None:
        with self.assertRaisesRegex(PolicyError, "ERR_PUBLIC_BIND_REQUIRES_ALLOW_PUBLIC"):
            enforce_bind_policy("8.8.8.8", allow_lan=False, allow_public=False, tls_enabled=False, insecure_public=False)
        with self.assertRaisesRegex(PolicyError, "ERR_PUBLIC_BIND_REQUIRES_TLS_OR_INSECURE_OVERRIDE"):
            enforce_bind_policy("8.8.8.8", allow_lan=False, allow_public=True, tls_enabled=False, insecure_public=False)
        decision = enforce_bind_policy("8.8.8.8", allow_lan=False, allow_public=True, tls_enabled=True, insecure_public=False)
        self.assertEqual(decision.scope, BindScope.PUBLIC)

    def test_public_send_requires_tls_or_override(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            frame = Path(temp_dir) / "sample.brad"
            frame.write_bytes(b"BRAD-data")
            with self.assertRaisesRegex(PolicyError, "ERR_PUBLIC_SEND_REQUIRES_TLS_OR_PLAINTEXT_OVERRIDE"):
                send_frame(frame, "8.8.8.8", 8745)

    def test_wildcard_is_public_policy(self) -> None:
        self.assertEqual(classify_bind_scope("0.0.0.0").scope, BindScope.WILDCARD)


class DiscoveryTests(unittest.TestCase):
    def test_advertisement_round_trip(self) -> None:
        encoded = encode_advertisement("node-b", 8745, True)
        record = decode_advertisement(encoded, "192.168.1.5")
        self.assertEqual(record.node_id, "node-b")
        self.assertEqual(record.transport_port, 8745)
        self.assertTrue(record.tls)

    def test_advertisement_schema_is_closed(self) -> None:
        obj = json.loads(encode_advertisement("node-b", 8745, False))
        obj["trusted"] = True
        with self.assertRaisesRegex(ValueError, "ERR_DISCOVERY_SCHEMA"):
            decode_advertisement(json.dumps(obj).encode(), "127.0.0.1")


class IntegrationTests(unittest.TestCase):
    def test_unvalidated_transfer_is_quarantined_not_accepted(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = root / "sample.brad"
            frame.write_bytes(b"BRAD" + b"x" * 128)
            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox")
            with TransportServer(config) as server:
                host, port = server.address
                result = send_frame(frame, host, port)
            self.assertTrue(result.ack.stored)
            self.assertFalse(result.ack.validated)
            self.assertFalse(result.ack.accepted)
            self.assertEqual(result.ack.reason, "STORED_UNVALIDATED")
            self.assertTrue(list((root / "inbox" / "quarantine").glob("*.brad")))

    def test_validator_pass_remains_quarantined_without_phase_b(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = root / "sample.brad"
            frame.write_bytes(b"BRAD" + b"a" * 128)
            validator = f'{sys.executable} -c "import pathlib,sys; sys.exit(0 if pathlib.Path(sys.argv[1]).read_bytes().startswith(b\'BRAD\') else 3)" {{file}}'
            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox", validator_command=validator)
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertTrue(result.ack.validated)
            self.assertFalse(result.ack.accepted)
            self.assertEqual(result.ack.reason, "VALIDATED_NOT_COMMITTED")
            self.assertTrue(list((root / "inbox" / "quarantine").glob("*.brad")))
            self.assertFalse((root / "inbox" / "accepted").exists())

    def test_validator_failure_moves_to_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = root / "sample.brad"
            frame.write_bytes(b"BRAD" + b"b" * 128)
            validator = f'{sys.executable} -c "import sys; sys.exit(9)" {{file}}'
            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox", validator_command=validator)
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertTrue(result.ack.validated)
            self.assertFalse(result.ack.accepted)
            self.assertIn("ERR_VALIDATOR_REJECTED:9", result.ack.reason)
            self.assertTrue(list((root / "inbox" / "rejected").glob("*.brad")))

    def test_validator_timeout_is_rejection(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = root / "sample.brad"
            frame.write_bytes(b"BRAD" + b"t" * 128)
            validator = f'{sys.executable} -c "import time; time.sleep(1)" {{file}}'
            config = ReceiverConfig(
                bind="127.0.0.1",
                port=0,
                output_dir=root / "inbox",
                validator_command=validator,
                validator_timeout_seconds=0.05,
            )
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address)
            self.assertTrue(result.ack.validated)
            self.assertFalse(result.ack.accepted)
            self.assertEqual(result.ack.reason, "ERR_VALIDATOR_TIMEOUT")

    def test_audit_log_has_no_frame_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            frame = root / "sample.brad"
            frame.write_bytes(b"BRAD" + b"sensitive-marker" * 8)
            audit = root / "audit.jsonl"
            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox", audit_log=audit)
            with TransportServer(config) as server:
                send_frame(frame, *server.address)
            text = audit.read_text()
            self.assertIn("STORED_UNVALIDATED", text)
            self.assertNotIn("sensitive-marker", text)

    @unittest.skipUnless(subprocess.run(["sh", "-c", "command -v openssl"], capture_output=True).returncode == 0, "openssl unavailable")
    def test_tls_loopback_transfer(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            cert = root / "cert.pem"
            key = root / "key.pem"
            subprocess.run(
                [
                    "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                    "-keyout", str(key), "-out", str(cert), "-days", "1",
                    "-subj", "/CN=localhost",
                ],
                check=True,
                capture_output=True,
            )
            frame = root / "sample.brad"
            frame.write_bytes(b"BRAD" + b"tls" * 64)
            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox", tls_cert=cert, tls_key=key)
            with TransportServer(config) as server:
                result = send_frame(frame, *server.address, use_tls=True, insecure_tls=True)
            self.assertTrue(result.ack.stored)
            self.assertEqual(result.ack.destination, "quarantine")

    def test_bad_digest_gets_negative_ack(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            config = ReceiverConfig(bind="127.0.0.1", port=0, output_dir=root / "inbox")
            with TransportServer(config) as server:
                packet = bytearray(encode_transfer(b"BRAD-data", "bad.brad"))
                packet[-1] ^= 1
                with socket.create_connection(server.address, timeout=2) as sock:
                    sock.sendall(packet)
                    raw = sock.recv(4096)
            self.assertIn(b"ERR_DIGEST_MISMATCH", raw)


if __name__ == "__main__":
    unittest.main()
