# Heterogeneous Semantic Transfer in Braid v1.5.2

Braid now distinguishes **semantic interoperability** from **coordinate projection**.

## Preferred interoperability path: Semantic Capsule

For two local AI systems using different embedding models, the preferred v1.5.2 flow is:

```text
explicit semantic state
        |
        v
source local embedding -> Braid 384D signed route state
        |                         + signed Semantic Capsule
        v
transport (QR/LAN/explicit Internet)
        |
        v
receiver Phase A + capsule/route binding
        |
        +-- same model digest --> exact-space 384D fast path
        |
        +-- different digest --> receiver-local native re-embedding
                                  from explicit capsule material
        |
        v
receiver-owned Phase B finality + lineage
```

The receiver never interprets an unrelated source vector as though it were already in its own embedding coordinate system.

## Historical/experimental calibrated projection route

The v1.5.0 `hetero-calibrate` machinery remains in v1.5.2 because it is useful for controlled experiments:

- deterministic semantic corpus;
- train/held-out split;
- source and target embeddings;
- learned/validated route transform;
- frozen package digests;
- held-out promotion thresholds;
- receiver-local mapped 384D evidence.

A promoted calibration demonstrates measured behavior for the tested model pair/corpus/route. It does not establish a universal translation between arbitrary model spaces, and it does not reconstruct missing semantic source material.

For that reason, v1.5.2 does not use calibrated projection as a fallback when a Semantic Capsule is absent.

## Why both exist

The two mechanisms answer different research/product questions:

- **calibrated route:** can a measured transform preserve useful geometry between a particular source/target route under held-out tests?
- **Semantic Capsule:** can heterogeneous receivers exchange explicit authenticated meaning while allowing each receiver to own its local representation?

The second is the interoperable product path. The first remains a transparent experiment.

## No invention rule

Braid rejects the following inference:

```text
"this signed 384D vector probably means X, so I will embed X locally"
```

unless `X` is actually present in the signed capsule/Legend semantic material. A model may later reason about explicit capsule content, but Braid itself does not hallucinate a semantic bridge.
