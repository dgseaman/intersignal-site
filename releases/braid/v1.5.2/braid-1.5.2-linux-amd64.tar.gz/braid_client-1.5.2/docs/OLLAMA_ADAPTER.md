# Built-in Ollama Adapter - Braid v1.5.2

## Architecture

The built-in adapter deliberately separates three roles:

1. **Source completion model** - a local Ollama completion model (default `mistral:latest`) distills source context into a strict `braid.legend.v1` structured object.
2. **384D embedding model** - a local Ollama embedding model (default `all-minilm:latest`) encodes the canonical Legend semantic view into Braid's 384D state.
3. **Receiver completion model** - after receiver Phase B finality, a local Ollama completion model consumes the committed signed Legend as data and produces a receiver-local continuation artifact.

No Ollama response can create Braid acceptance. There is no claimed hidden-state, weight, KV-cache, or native activation injection.

## Exposure boundary

The adapter accepts only loopback Ollama URLs whose host is exactly `127.0.0.1`, `localhost`, or `::1`. Remote Ollama URLs are rejected, and HTTP redirects are not followed so a loopback endpoint cannot redirect Braid off-host. Braid never auto-pulls a model. Model installation remains an explicit operator action.

Loopback is not treated as sufficient proof of local inference. The built-in adapter also fails closed when:

- a model name explicitly denotes cloud execution;
- `/api/tags` or `/api/show` reports a non-empty `remote_model` or `remote_host`;
- a model response reports a non-empty remote marker.

Model role classification uses Ollama-reported `capabilities` (`embedding`, `completion`) rather than guessing from the model name. `braid-client environment` reports Ollama cloud-disable configuration evidence separately; this is useful operator evidence but not cryptographic process attestation.

The adapter records exact eligible model digests from Ollama's loopback model inventory:

- Legend generator completion-model digest is signed inside the Legend;
- source/target embedding-model digests are route-bound and signed in `extensions.ollama_adapter`;
- receiver completion-model digest is recorded in the post-commit handoff artifact.

## Readiness

```bash
braid-client ollama-doctor \
  --model mistral:latest \
  --embed-model all-minilm:latest
```

The check requires:

- the completion model to be locally addressable and completion-capable;
- an exact deterministic readiness response;
- the embedding model to be locally present;
- an exact model digest;
- a finite 384D embedding with unit norm.

## Build a same-space Ollama route

When both nodes use the exact same embedding model tag and model digest, use:

```bash
braid-client ollama-route \
  --embed-model all-minilm:latest \
  --output-dir routes/all-minilm-identity \
  --count 576
```

The route is promoted only when exact model identity is proven and the held-out same-space route checks pass. The generated route package remains digest-bound receiver configuration.

For a receiver using a **different** embedding model digest, v1.5.2 prefers the Semantic Capsule path. Build/sign the frame from the source route, then configure the receiver's own model independently:

```bash
braid-client capsule-frame \
  --route-package routes/all-minilm-identity \
  --text 'explicit semantic material' \
  --signing-key sender.key \
  --output state.brad

braid-client receive \
  --route-package routes/all-minilm-identity \
  --trusted-key sender.pub \
  --bind 0.0.0.0 --allow-lan \
  --semantic-embed-model '<RECEIVER_LOCAL_MODEL>'
```

If the receiver model digest differs, the adapter re-embeds the signed capsule material locally at the receiver model's native dimension. If the capsule is absent, heterogeneous semantic ingestion rejects before Phase B.

The earlier `hetero-calibrate` path remains available for measured coordinate-projection experiments, but it is not a fallback for missing semantics and is not the preferred interoperability path.

## Create a model-conditioned Braid frame

```bash
braid-client ollama-frame \
  --route-package routes/all-minilm-identity \
  --model mistral:latest \
  --text 'Continue the current task while preserving the critical constraints.' \
  --signing-key sender.key \
  --legend-output state.legend.json \
  --output state.brad
```

This command:

1. calls the local completion model with a strict JSON schema;
2. normalizes and bounds the returned Legend;
3. binds the exact completion-model digest and source-text digest;
4. embeds the canonical Legend semantic view with the route source embedding model;
5. verifies the local embedding model digest matches the calibrated route;
6. inserts the Legend and Ollama adapter metadata into the signed manifest;
7. writes the signed `.brad` object.

## Receiver-side Ollama continuation

File intake:

```bash
braid-client receive-file \
  --route-package routes/all-minilm-identity \
  --trusted-key sender.pub \
  --output-dir braid-inbox \
  --ollama-model mistral:latest \
  --ollama-embed-model all-minilm:latest \
  state.brad
```

LAN receiver:

```bash
braid-client receive \
  --route-package routes/all-minilm-identity \
  --trusted-key sender.pub \
  --bind 192.168.1.50 \
  --allow-lan \
  --output-dir braid-inbox \
  --ollama-model mistral:latest \
  --ollama-embed-model all-minilm:latest
```

The built-in adapter runs only after Phase B. A successful continuation writes:

`handoff/<object_digest>.ollama.json`

The artifact binds the object digest, Legend digest, receiver-side Legend/vector alignment, local completion and embedding model digests, model response digest, and `generative_vector_injection: false`.

## Optional receiver-local alignment policy

A receiver may set a post-commit handoff threshold:

```bash
--ollama-min-alignment 0.80
```

If the target Legend/vector cosine is lower than the configured threshold, Braid does not invoke the receiver completion model. The Braid receipt remains `finality: committed`; only the post-commit handoff is marked degraded.
