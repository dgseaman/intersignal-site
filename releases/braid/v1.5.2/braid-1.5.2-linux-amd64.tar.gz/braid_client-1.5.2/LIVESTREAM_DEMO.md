# Braid v1.5.2 — Short Livestream Demo Flow

The cleanest story is not “look at all the transports.” It is:

> **One field. Any path. The receiver decides.**

## 60-second preflight

```bash
braid-client --version
braid-client doctor
braid-client serve --port 8080
```

Open `http://127.0.0.1:8080/` and confirm the top-right badge says **FIELD READY**.

For a camera demo, run the stream from an environment with a native browser `BarcodeDetector` or install `braid-client[camera]` for the local OpenCV fallback.

## Suggested live sequence

1. Point out **384 receiver dimensions** and the single receiver chain.
2. Click **Generate state**. Explain that this creates a signed object but does not create receiver finality.
3. Click **Commit locally**. Let the chain move through quarantine, 384D resolution, validation, and Phase B.
4. Point to **finality committed**. Explain: “accepted has exactly one meaning now.”
5. Click **Beam QR reel**. Explain that the exact same signed object can cross an air gap as visible light.
6. If using a second device, choose **Receive by camera** there and let reassembly terminate in its own receiver automatically.
7. Optionally show **Sense nearby nodes** and immediately state that RSSI is context, not trust.

## Good concise language

- “Transport moves the signed object. The receiver owns acceptance.”
- “The path can be optical, LAN, or explicit Internet/TLS. The trust boundary stays local.”
- “Phase A is evidence. Phase B is finality.”
- “BLE can tell you something is nearby; it cannot tell you that it is trusted.”

## Avoid overclaiming

Do not describe the bundled Gate-3 artifacts as universal production anomaly models, BLE as distance/identity, or a browser/camera smoke test as proof of every physical environment. The demo is strongest when the claims stay exactly aligned with what the code verifies.
