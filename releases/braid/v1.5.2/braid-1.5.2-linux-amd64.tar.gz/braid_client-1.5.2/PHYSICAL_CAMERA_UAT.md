# Braid v1.5.2 Physical Two-Device Camera Acceptance

## Purpose

Verify the environmental path that a headless build container cannot reproduce: one physical display emitting the QR reel and a second physical camera reconstructing the same signed object into an independently configured automated receiver.

## Preparation

Install the wheel with local camera fallback on both devices if a native browser `BarcodeDetector` is not available:

```bash
pip install 'braid_client-1.5.2-py3-none-any.whl[camera]'
```

Run on each device:

```bash
braid-client doctor
```

The core readiness result should be `"ready": true`.

### Node A — transmitter

```bash
braid-client serve --port 8080 --signing-key node-a.key
```

Open `http://127.0.0.1:8080/`, confirm **FIELD READY**, and securely copy `node-a.pub` to Node B.

### Node B — receiver

```bash
braid-client serve \
  --port 8080 \
  --signing-key node-b.key \
  --trusted-key node-a.pub
```

Open `http://127.0.0.1:8080/` and grant camera permission when requested.

## Positive acceptance run

1. On Node A, click **Generate state**.
2. Click **Beam QR reel** and keep the QR display visible.
3. On Node B, click **Receive by camera** and point the camera squarely at Node A's display.
4. Confirm collector progress continues despite repeated reel frames and out-of-order observation.
5. Vary angle/distance modestly and confirm decoding resumes without false slot advancement.
6. Wait for complete reassembly.
7. Confirm Node B receiver evidence shows:
   - the same object digest as Node A;
   - 384 receiver dimensions;
   - cryptographic/integrity evidence passing;
   - Gate-3 evidence still labeled/understood as DEMO artifacts;
   - Phase B committed;
   - `finality: committed` and `accepted: true`;
   - a receiver-local 384D vector artifact.
8. Stop camera reception and verify the browser releases the camera.

## Negative checks

- Launch Node B with an unrelated trusted public key: completed reassembly must not commit.
- Cover the camera intermittently: progress may pause but valid slots must remain bounded/consistent.
- Present the same chunk repeatedly: duplicate observations must not falsely advance slot count.
- Present a non-BRAD1 QR symbol: ignore it.
- Submit a malformed completed stream: return a bounded error and keep the Field server alive.
- Request oversized QR content: return `ERR_QR_CAPACITY` rather than a malformed symbol.
- Re-submit an already committed signed frame: it must not create a second committed receiver state.

## Environmental matrix

| Condition | Target |
|---|---:|
| Bright indoor light, display straight-on | Complete frame |
| Moderate glare, 10–20° camera angle | Complete frame |
| ~1 meter distance | Complete frame |
| Reel around 3 FPS | Complete frame |
| Reel around 6 FPS | Complete frame |
| Native detector available | Complete frame |
| OpenCV fallback forced | Complete frame |

## Promotion gate

Describe the client as physically demonstrated camera-to-receiver transport only after two independent devices complete the positive run. Keep the finality language and DEMO-artifact boundary visible in public walkthroughs.
