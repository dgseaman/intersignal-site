# Braid v1.5.2 Technical Audit Summary

## Review target

Braid Light Client v1.5.2 source tree, with emphasis on heterogeneous semantic ingestion and the macOS/front-door changes.

## Architectural result

The release preserves the receiver-owned Phase B finality boundary while adding a distinct semantic-interoperability layer.

The central audit conclusion is that heterogeneous behavior is now explicit rather than implicit:

- exact embedding identity is digest-gated;
- non-identical embedding spaces require signed canonical semantic material;
- the receiver creates its own representation locally;
- receiver-created state is not presented as sender-signed state;
- an opaque vector is never converted into invented semantics.

## Pre-Phase-B gates added for Semantic Capsule

- closed schema validation;
- bounded canonical inline content;
- capsule JCS self-digest;
- source FP16 wire-payload digest binding;
- frozen route/source model-name binding;
- frozen route/source model-digest binding;
- 384D source route dimension binding;
- Legend digest/semantic-view binding when capsule mode is `legend_ref`;
- receiver local-model digest resolution;
- local native re-embedding preflight when digests differ.

## Post-Phase-B behavior

Semantic vector + lineage are published as an atomic private directory bundle. Optional receiver-local completion happens afterward. Failures remain delivery degradation and cannot undo a committed replay/finality transaction.

## Front door

`/api/environment` is loopback UI data and uses only local platform/filesystem/network-interface inspection plus loopback Ollama. Commands are generated from local values and are displayed for operator use rather than executed automatically.

`Braid.app` launches the loopback visualizer; the production standalone app/DMG build is native-macOS only.

## Regression result

The split test run passes all legacy 1.4.x transport/finality/canonicalization tests, v1.5.0 heterogeneous/Ollama/Legend tests, and new v1.5.2 Semantic Capsule/front-door tests.

See `BRAID_CLIENT_V1_5_2_TEST_EVIDENCE.txt` for exact counts and command groups.

## Remaining release gates

Not simulated as complete:

- physical two-Mac LAN UAT;
- real local Ollama source/receiver model pair with differing digests/dimensions;
- camera-held optical Semantic Capsule transfer;
- native macOS standalone `Braid.app` build and `hdiutil` DMG verification;
- Gatekeeper/codesign/notarization behavior on the intended public distribution path.

These are hardware/platform release gates, not hidden claims in the current test evidence.
