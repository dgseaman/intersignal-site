#!/bin/bash
set -eu

if [ "$(uname -s)" != "Darwin" ]; then
  echo "Standalone Braid.app must be built on macOS because PyInstaller does not cross-build Mach-O applications." >&2
  exit 2
fi

ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
PYTHON=${PYTHON:-python3}
BUILDROOT="$ROOT/build/macos-standalone"
VENV="$BUILDROOT/venv"
DIST="$ROOT/dist/macos-standalone"
REQ="$ROOT/packaging/macos/release-requirements.txt"
ICON_SOURCE="$ROOT/packaging/macos/assets/BraidIcon-1024.png"
ICNS="$ROOT/build/macos-assets/Braid.icns"

PYVER=$($PYTHON -c 'import platform; print(platform.python_version())')
if [ "${BRAID_ALLOW_PYTHON_PATCH_DRIFT:-0}" = "1" ]; then
  case "$PYVER" in 3.12.*) ;; *) echo "Braid local UAT build requires CPython 3.12.x; got $PYVER" >&2; exit 3 ;; esac
else
  [ "$PYVER" = "3.12.10" ] || {
    echo "Braid v1.5.2 public release build requires CPython 3.12.10; got $PYVER" >&2
    echo "For a non-public local UAT build only, set BRAID_ALLOW_PYTHON_PATCH_DRIFT=1." >&2
    exit 3
  }
fi

ARCH=$(uname -m)
case "$ARCH" in arm64|x86_64) ;; *) echo "Unsupported macOS release architecture: $ARCH" >&2; exit 4 ;; esac

rm -rf "$BUILDROOT" "$DIST"
mkdir -p "$BUILDROOT" "$DIST"

# Refuse to freeze bytes from a tree that no longer matches the reviewed source
# manifest. PACKAGE_CONTENT_SHA256SUMS intentionally does not hash itself.
( cd "$ROOT" && /usr/bin/shasum -a 256 -c PACKAGE_CONTENT_SHA256SUMS.txt ) > "$BUILDROOT/source-manifest-verification.txt"

"$ROOT/packaging/macos/make_icon.sh" "$ICON_SOURCE" "$ICNS" >/dev/null

"$PYTHON" -m venv "$VENV"
"$VENV/bin/python" -m pip install --disable-pip-version-check --no-input "pip==26.1.2"

WHEELHOUSE="$BUILDROOT/wheelhouse"
mkdir -p "$WHEELHOUSE"
"$VENV/bin/python" -m pip download --disable-pip-version-check --no-input --only-binary=:all: --dest "$WHEELHOUSE" -r "$REQ"
( cd "$WHEELHOUSE" && /usr/bin/shasum -a 256 * | LC_ALL=C sort ) > "$BUILDROOT/release-wheelhouse-sha256.txt"
"$VENV/bin/python" -m pip install --disable-pip-version-check --no-input --no-index --find-links "$WHEELHOUSE" -r "$REQ"
"$VENV/bin/python" -m pip install --disable-pip-version-check --no-input --no-build-isolation --no-deps "$ROOT"

"$VENV/bin/python" -m pip freeze --all | LC_ALL=C sort > "$BUILDROOT/release-runtime-lock.txt"
"$VENV/bin/python" -m pip inspect > "$BUILDROOT/release-pip-inspect.json"
cp "$REQ" "$BUILDROOT/release-requirements.txt"
printf '%s\n' "$PYVER" > "$BUILDROOT/release-python-version.txt"
printf '%s\n' "$ARCH" > "$BUILDROOT/release-architecture.txt"
printf '%s\n' "$(/usr/bin/sw_vers -productVersion)" > "$BUILDROOT/release-macos-builder-version.txt"

# PyInstaller performs its normal ad-hoc signing while assembling Apple Silicon
# binaries. We make every Info.plist/resource mutation next, then replace those
# signatures in a deliberate inside-out signing pass below.
"$VENV/bin/pyinstaller" \
  --noconfirm --clean --windowed --name Braid \
  --target-arch "$ARCH" \
  --osx-bundle-identifier ai.intersignal.braid \
  --icon "$ICNS" \
  --collect-data braid_client --collect-all cv2 --collect-all bleak \
  --distpath "$DIST" --workpath "$BUILDROOT/work-gui" --specpath "$BUILDROOT/spec-gui" \
  "$ROOT/packaging/macos/braid_app_entry.py"

APP="$DIST/Braid.app"
[ -x "$APP/Contents/MacOS/Braid" ] || { echo "PyInstaller did not produce Braid.app correctly" >&2; exit 5; }

# The same frozen executable is both GUI launcher and CLI dispatcher. A relative
# symlink avoids shipping a second embedded Python/runtime just for the CLI.
rm -f "$APP/Contents/MacOS/braid-client"
ln -s Braid "$APP/Contents/MacOS/braid-client"

mkdir -p "$APP/Contents/Resources/BraidRelease"
cp "$BUILDROOT/release-runtime-lock.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$BUILDROOT/release-pip-inspect.json" "$APP/Contents/Resources/BraidRelease/"
cp "$BUILDROOT/release-requirements.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$BUILDROOT/release-wheelhouse-sha256.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$BUILDROOT/release-python-version.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$BUILDROOT/release-architecture.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$BUILDROOT/release-macos-builder-version.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$BUILDROOT/source-manifest-verification.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$ROOT/PACKAGE_CONTENT_SHA256SUMS.txt" "$APP/Contents/Resources/BraidRelease/"
cp "$ROOT/THIRD_PARTY_NOTICES.md" "$APP/Contents/Resources/BraidRelease/"

PLIST="$APP/Contents/Info.plist"
plist_set() {
  key=$1
  value=$2
  /usr/bin/plutil -replace "$key" -string "$value" "$PLIST" 2>/dev/null || \
    /usr/bin/plutil -insert "$key" -string "$value" "$PLIST"
}
plist_set CFBundleDisplayName Braid
plist_set CFBundleName Braid
plist_set CFBundleShortVersionString 1.5.2
plist_set CFBundleVersion 152
plist_set NSCameraUsageDescription "Braid can use the camera for explicit optical QR transport when you choose the camera receiver."
plist_set NSLocalNetworkUsageDescription "Braid can discover and exchange signed state with nodes on your local network when you explicitly enable LAN transport."
plist_set NSBluetoothAlwaysUsageDescription "Braid can scan for nearby BLE discovery hints only when you explicitly start local sensing."

# Derive the advertised minimum OS from the actual Mach-O deployment targets in
# the frozen bundle instead of claiming compatibility below the build artifacts.
MIN_LIST="$BUILDROOT/release-macho-minimums.txt"
: > "$MIN_LIST"
/usr/bin/find "$APP/Contents" -type f -print0 | while IFS= read -r -d '' f; do
  if /usr/bin/file -b "$f" 2>/dev/null | /usr/bin/grep -q 'Mach-O'; then
    /usr/bin/otool -l "$f" 2>/dev/null | /usr/bin/awk '/minos / {print $2} /version / && seen_legacy {print $2; seen_legacy=0} /LC_VERSION_MIN_MACOSX/ {seen_legacy=1}' >> "$MIN_LIST"
  fi
done
if [[ -s "$MIN_LIST" ]]; then
  MIN_OS=$("$VENV/bin/python" -c 'import sys; vs=[x.strip() for x in open(sys.argv[1]) if x.strip()]; key=lambda s: tuple(int(p) for p in s.split(".")); print(max(vs, key=key))' "$MIN_LIST")
else
  MIN_OS=$(/usr/bin/sw_vers -productVersion | /usr/bin/awk -F. '{print $1"."$2}')
fi
plist_set LSMinimumSystemVersion "$MIN_OS"
printf '%s\n' "$MIN_OS" > "$BUILDROOT/release-minimum-macos.txt"
cp "$BUILDROOT/release-minimum-macos.txt" "$BUILDROOT/release-macho-minimums.txt" "$APP/Contents/Resources/BraidRelease/"

# No bundle mutation occurs after this point. Apple recommends signing nested
# code inside-out and avoiding --deep for signing; --deep remains appropriate
# for recursive verification.
"$ROOT/packaging/macos/sign_app.sh" "$APP" "${BRAID_CODESIGN_IDENTITY:--}" >/dev/null

CLI="$APP/Contents/MacOS/braid-client"
[ -L "$CLI" ] || { echo "Bundled CLI is not the expected same-runtime symlink" >&2; exit 6; }
"$CLI" --version >/dev/null
"$CLI" doctor >/dev/null
"$CLI" environment > "$BUILDROOT/environment.json"
/usr/bin/grep -F "$CLI" "$BUILDROOT/environment.json" >/dev/null || {
  echo "Environment quick-start commands are not bound to the same-install CLI" >&2
  exit 6
}

printf '%s\n' "$APP"
