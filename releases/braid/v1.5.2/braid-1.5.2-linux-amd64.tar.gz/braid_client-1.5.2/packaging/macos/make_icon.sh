#!/bin/bash
set -eu

if [ "$(uname -s)" != "Darwin" ]; then
  echo "Braid icon compilation requires macOS iconutil/sips." >&2
  exit 2
fi

ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
SOURCE=${1:-"$ROOT/packaging/macos/assets/BraidIcon-1024.png"}
OUT=${2:-"$ROOT/build/macos-assets/Braid.icns"}
ICONSET="${OUT%.icns}.iconset"

[ -f "$SOURCE" ] || { echo "Missing source icon: $SOURCE" >&2; exit 1; }
rm -rf "$ICONSET"
mkdir -p "$ICONSET" "$(dirname "$OUT")"

make_png() {
  pixels=$1
  name=$2
  /usr/bin/sips -s format png -z "$pixels" "$pixels" "$SOURCE" --out "$ICONSET/$name" >/dev/null
}

make_png 16 icon_16x16.png
make_png 32 icon_16x16@2x.png
make_png 32 icon_32x32.png
make_png 64 icon_32x32@2x.png
make_png 128 icon_128x128.png
make_png 256 icon_128x128@2x.png
make_png 256 icon_256x256.png
make_png 512 icon_256x256@2x.png
make_png 512 icon_512x512.png
make_png 1024 icon_512x512@2x.png

/usr/bin/iconutil -c icns "$ICONSET" -o "$OUT"
rm -rf "$ICONSET"
[ -s "$OUT" ] || { echo "iconutil produced no ICNS output" >&2; exit 1; }
echo "$OUT"
