#!/bin/bash
set -euo pipefail

HERE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$HERE/../.." && pwd)
cd "$ROOT"

clear
printf '\n  BRAID 1.5.2 — NATIVE MAC RELEASE BUILDER\n'
printf '  ========================================\n\n'

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This builder must run on a Mac."
  read -r -p "Press Return to close..." _
  exit 2
fi

pick_python() {
  local p v
  for p in "${PYTHON:-}" python3.12 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 /Library/Frameworks/Python.framework/Versions/3.12/bin/python3; do
    [[ -n "$p" ]] || continue
    if command -v "$p" >/dev/null 2>&1; then
      p=$(command -v "$p")
    fi
    [[ -x "$p" ]] || continue
    v=$($p -c 'import platform; print(platform.python_version())' 2>/dev/null || true)
    if [[ "$v" == "3.12.10" ]]; then
      printf '%s\n' "$p"
      return 0
    fi
  done
  return 1
}

PY=$(pick_python || true)
if [[ -z "$PY" ]]; then
  echo "CPython 3.12.10 is required for the frozen public-release bytes."
  echo "Install Python 3.12.10, then double-click this builder again."
  echo
  echo "For an explicitly non-public local UAT build, Terminal users may run:"
  echo "  BRAID_ALLOW_PYTHON_PATCH_DRIFT=1 PYTHON=/path/to/python3.12 ./packaging/macos/build_release_macos.sh"
  echo
  read -r -p "Press Return to close..." _
  exit 3
fi

export PYTHON="$PY"
echo "Builder Python: $($PY -c 'import platform; print(platform.python_version())')"
echo "Architecture: $(uname -m)"
echo

if [[ -n "${BRAID_CODESIGN_IDENTITY:-}" && -n "${BRAID_NOTARY_PROFILE:-}" ]]; then
  export BRAID_PUBLIC_RELEASE=1
  echo "Developer ID + notary profile detected: building PUBLIC signed/notarized DMG."
else
  export BRAID_PUBLIC_RELEASE=0
  echo "No Developer ID/notary environment detected: building an ad-hoc signed LOCAL-UAT DMG."
  echo "The result is functional for local validation but is not the public Gatekeeper/notarized release."
fi

echo
"$HERE/build_release_macos.sh"

DMG="$ROOT/dist/Braid-1.5.2-macOS-$(uname -m).dmg"
echo
printf 'BUILD COMPLETE\n\n%s\n\n' "$DMG"
/usr/bin/open -R "$DMG" || true
read -r -p "Press Return to close..." _
