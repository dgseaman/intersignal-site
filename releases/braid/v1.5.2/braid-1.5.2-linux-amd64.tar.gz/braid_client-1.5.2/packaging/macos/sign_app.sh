#!/bin/bash
set -eu

if [ "$(uname -s)" != "Darwin" ]; then
  echo "macOS app signing requires Darwin codesign." >&2
  exit 2
fi

APP=${1:?usage: sign_app.sh /path/to/Braid.app [identity]}
IDENTITY=${2:-${BRAID_CODESIGN_IDENTITY:--}}
[ -d "$APP" ] || { echo "Missing app: $APP" >&2; exit 1; }

if [ "$IDENTITY" != "-" ]; then
  case "$IDENTITY" in
    Developer\ ID\ Application:*) ;;
    *) echo "Public Braid builds require a Developer ID Application identity; got: $IDENTITY" >&2; exit 3 ;;
  esac
  /usr/bin/security find-identity -v -p codesigning | /usr/bin/grep -F "$IDENTITY" >/dev/null || {
    echo "Signing identity is not available in this keychain: $IDENTITY" >&2
    exit 3
  }
fi

sign_one() {
  target=$1
  if [ "$IDENTITY" = "-" ]; then
    /usr/bin/codesign --force --options runtime --sign - "$target"
  else
    /usr/bin/codesign --force --options runtime --timestamp --sign "$IDENTITY" "$target"
  fi
}

is_macho() {
  /usr/bin/file -b "$1" 2>/dev/null | /usr/bin/grep -q 'Mach-O'
}

# Apple recommends signing nested code from the inside out and avoiding
# `codesign --deep` for signing. Sign every standalone Mach-O in standard code
# locations first, then nested bundles deepest-first, then the outer app.
for code_dir in \
  "$APP/Contents/Frameworks" \
  "$APP/Contents/PlugIns" \
  "$APP/Contents/XPCServices" \
  "$APP/Contents/Helpers" \
  "$APP/Contents/Library" \
  "$APP/Contents/MacOS"
do
  [ -d "$code_dir" ] || continue
  /usr/bin/find "$code_dir" -type f -print0 | while IFS= read -r -d '' f; do
    if is_macho "$f"; then
      sign_one "$f"
    fi
  done
done

# Seal any nested code bundles after their inner Mach-O objects have signatures.
/usr/bin/find "$APP" -depth -type d \( \
  -name '*.framework' -o -name '*.app' -o -name '*.xpc' -o -name '*.appex' -o -name '*.bundle' \
\) -print0 | while IFS= read -r -d '' bundle; do
  [ "$bundle" = "$APP" ] && continue
  sign_one "$bundle"
done

sign_one "$APP"
/usr/bin/codesign --verify --deep --strict --verbose=2 "$APP"

# Make hidden nested-signing failures visible before notarization.
for code_dir in "$APP/Contents/Frameworks" "$APP/Contents/MacOS"; do
  [ -d "$code_dir" ] || continue
  /usr/bin/find "$code_dir" -type f -print0 | while IFS= read -r -d '' f; do
    if is_macho "$f"; then
      /usr/bin/codesign --verify --strict --verbose=1 "$f" >/dev/null
    fi
  done
done

echo "$APP"
