#!/bin/bash
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "DMG creation requires macOS hdiutil. Run this script on the release Mac." >&2
  exit 2
fi

ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
APP=${1:-"$ROOT/dist/macos-standalone/Braid.app"}
ARCH=$(uname -m)
OUT=${2:-"$ROOT/dist/Braid-1.5.2-macOS-$ARCH.dmg"}
VOLNAME="Braid 1.5.2"
BACKGROUND="$ROOT/packaging/macos/assets/BraidDMGBackground.png"
QUICKSTART="$ROOT/packaging/macos/QUICK_START.txt"
BUILD="$ROOT/build/macos-dmg"
STAGE="$BUILD/stage"
RW_DMG="$BUILD/Braid-1.5.2-rw.dmg"
MOUNT="$BUILD/mount"
EVIDENCE="$ROOT/dist/release-gate-evidence"

[[ -d "$APP" ]] || { echo "Missing app: $APP" >&2; exit 1; }
[[ -f "$BACKGROUND" ]] || { echo "Missing DMG background: $BACKGROUND" >&2; exit 1; }
[[ -f "$QUICKSTART" ]] || { echo "Missing quick start: $QUICKSTART" >&2; exit 1; }

if [[ "${BRAID_PUBLIC_RELEASE:-0}" == "1" ]]; then
  [[ -n "${BRAID_CODESIGN_IDENTITY:-}" ]] || { echo "BRAID_PUBLIC_RELEASE=1 requires BRAID_CODESIGN_IDENTITY" >&2; exit 3; }
  [[ -n "${BRAID_NOTARY_PROFILE:-}" ]] || { echo "BRAID_PUBLIC_RELEASE=1 requires BRAID_NOTARY_PROFILE" >&2; exit 3; }
fi

rm -rf "$BUILD" "$OUT"
mkdir -p "$STAGE/.background" "$MOUNT" "$EVIDENCE" "$(dirname "$OUT")"
/usr/bin/ditto "$APP" "$STAGE/Braid.app"
ln -s /Applications "$STAGE/Applications"
cp "$BACKGROUND" "$STAGE/.background/BraidDMGBackground.png"
cp "$QUICKSTART" "$STAGE/QUICK_START.txt"
cp "$ROOT/README.md" "$ROOT/LICENSE" "$STAGE/"

# Create a writable image first so Finder can persist an intentional, sparse
# drag-to-Applications layout. Add generous metadata/headroom above payload size.
KB=$(/usr/bin/du -sk "$STAGE" | /usr/bin/awk '{print $1}')
SIZE_KB=$((KB + 131072))
/usr/bin/hdiutil create -quiet -ov -volname "$VOLNAME" -fs HFS+ -format UDRW -size "${SIZE_KB}k" -srcfolder "$STAGE" "$RW_DMG"

cleanup_mount() {
  /usr/bin/hdiutil detach "$MOUNT" -quiet >/dev/null 2>&1 || true
}
trap cleanup_mount EXIT HUP INT TERM
/usr/bin/hdiutil attach -quiet -readwrite -noverify -noautoopen -mountpoint "$MOUNT" "$RW_DMG"

# Finder layout. The image remains fully functional if Finder automation is
# unavailable in a headless build session, but public release builds require it.
LAYOUT_OK=0
if /usr/bin/osascript <<APPLESCRIPT
 tell application "Finder"
   tell disk "$VOLNAME"
     open
     set current view of container window to icon view
     set toolbar visible of container window to false
     set statusbar visible of container window to false
     set pathbar visible of container window to false
     set bounds of container window to {160, 160, 880, 620}
     set theViewOptions to the icon view options of container window
     set arrangement of theViewOptions to not arranged
     set icon size of theViewOptions to 96
     set text size of theViewOptions to 12
     set background picture of theViewOptions to file ".background:BraidDMGBackground.png"
     set position of item "Braid.app" of container window to {170, 310}
     set position of item "Applications" of container window to {550, 310}
     set position of item "QUICK_START.txt" of container window to {170, 400}
     set position of item "README.md" of container window to {350, 400}
     set position of item "LICENSE" of container window to {530, 400}
     update without registering applications
     delay 2
     close
   end tell
 end tell
APPLESCRIPT
then
  LAYOUT_OK=1
fi

if [[ "${BRAID_PUBLIC_RELEASE:-0}" == "1" && "$LAYOUT_OK" != "1" ]]; then
  echo "Finder DMG layout failed during a public release build." >&2
  exit 4
fi

/usr/bin/sync
/usr/bin/hdiutil detach "$MOUNT" -quiet
trap - EXIT HUP INT TERM

/usr/bin/hdiutil convert -quiet "$RW_DMG" -format UDZO -imagekey zlib-level=9 -o "$OUT"
/usr/bin/hdiutil verify "$OUT" >/dev/null

if [[ -n "${BRAID_CODESIGN_IDENTITY:-}" ]]; then
  /usr/bin/codesign --force --timestamp --sign "$BRAID_CODESIGN_IDENTITY" "$OUT"
  /usr/bin/codesign --verify --strict --verbose=2 "$OUT"
fi

if [[ -n "${BRAID_NOTARY_PROFILE:-}" ]]; then
  [[ -n "${BRAID_CODESIGN_IDENTITY:-}" ]] || { echo "BRAID_NOTARY_PROFILE requires a Developer ID Application identity." >&2; exit 3; }
  NOTARY_JSON="$EVIDENCE/notary-submit-$ARCH.json"
  /usr/bin/xcrun notarytool submit "$OUT" --keychain-profile "$BRAID_NOTARY_PROFILE" --wait --output-format json > "$NOTARY_JSON"
  STATUS=$(/usr/bin/plutil -extract status raw -o - "$NOTARY_JSON" 2>/dev/null || true)
  ID=$(/usr/bin/plutil -extract id raw -o - "$NOTARY_JSON" 2>/dev/null || true)
  [[ "$STATUS" == "Accepted" ]] || {
    echo "Apple notarization did not return Accepted (status: ${STATUS:-unknown})." >&2
    [[ -n "$ID" ]] && /usr/bin/xcrun notarytool log "$ID" --keychain-profile "$BRAID_NOTARY_PROFILE" "$EVIDENCE/notary-log-$ARCH.json" || true
    exit 5
  }
  if [[ -n "$ID" ]]; then
    NOTARY_LOG="$EVIDENCE/notary-log-$ARCH.json"
    /usr/bin/xcrun notarytool log "$ID" --keychain-profile "$BRAID_NOTARY_PROFILE" "$NOTARY_LOG"
    if [[ "${BRAID_PUBLIC_RELEASE:-0}" == "1" && "${BRAID_ALLOW_NOTARY_WARNINGS:-0}" != "1" ]]; then
      PY="$ROOT/build/macos-standalone/venv/bin/python"
      ISSUE_COUNT=$("$PY" -c 'import json,sys; d=json.load(open(sys.argv[1])); print(len(d.get("issues") or []))' "$NOTARY_LOG")
      [[ "$ISSUE_COUNT" == "0" ]] || {
        echo "Notarization was Accepted but the log contains $ISSUE_COUNT issue/warning entries. Review before release." >&2
        exit 5
      }
    fi
  fi
  /usr/bin/xcrun stapler staple -v "$OUT"
  /usr/bin/xcrun stapler validate -v "$OUT"
fi

/usr/bin/shasum -a 256 "$OUT" | tee "$OUT.sha256"
printf '%s\n' "$LAYOUT_OK" > "$EVIDENCE/dmg-finder-layout-$ARCH.txt"
echo "$OUT"
