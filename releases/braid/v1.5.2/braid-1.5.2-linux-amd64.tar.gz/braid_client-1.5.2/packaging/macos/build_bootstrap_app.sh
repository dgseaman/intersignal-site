#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
OUT=${1:-"$ROOT/dist/macos-bootstrap"}
APP="$OUT/Braid.app"
mkdir -p "$OUT"
rm -rf "$APP"
cp -R "$ROOT/packaging/macos/bootstrap/Braid.app" "$APP"
mkdir -p "$APP/Contents/Resources"
WHEEL=$(find "$ROOT/dist" -maxdepth 1 -type f -name 'braid_client-1.5.2-*.whl' | head -1)
if [ -z "$WHEEL" ]; then
  echo "Build the wheel first: python3 -m pip wheel --no-deps . -w dist" >&2
  exit 1
fi
cp "$WHEEL" "$APP/Contents/Resources/"
cp "$ROOT/README.md" "$ROOT/LICENSE" "$APP/Contents/Resources/"
chmod +x "$APP/Contents/MacOS/Braid" "$APP/Contents/MacOS/braid-client"
echo "$APP"
