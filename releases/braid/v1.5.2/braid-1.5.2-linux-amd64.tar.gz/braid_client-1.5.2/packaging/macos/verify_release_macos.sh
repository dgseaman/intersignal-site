#!/bin/bash
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "macOS release verification must run on Darwin." >&2
  exit 2
fi

ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
APP=${BRAID_APP_PATH:-"$ROOT/dist/macos-standalone/Braid.app"}
DMG=${BRAID_DMG_PATH:-}
ARCH=$(uname -m)

if [[ -z "$DMG" ]]; then
  DMG=$(find "$ROOT/dist" -maxdepth 1 -type f -name 'Braid-1.5.2-macOS-*.dmg' | head -1 || true)
fi

[[ -d "$APP" ]] || { echo "Missing standalone app: $APP" >&2; exit 1; }
[[ -n "$DMG" && -f "$DMG" ]] || { echo "Missing Braid 1.5.2 DMG under $ROOT/dist (or set BRAID_DMG_PATH)." >&2; exit 1; }
CLI="$APP/Contents/MacOS/braid-client"
MAIN="$APP/Contents/MacOS/Braid"
RELEASE_RES="$APP/Contents/Resources/BraidRelease"
[[ -x "$MAIN" ]] || { echo "Missing main executable: $MAIN" >&2; exit 1; }
[[ -L "$CLI" && -x "$CLI" ]] || { echo "Missing same-runtime bundled CLI symlink: $CLI" >&2; exit 1; }
[[ "$(readlink "$CLI")" == "Braid" ]] || { echo "Unexpected CLI link target: $(readlink "$CLI")" >&2; exit 1; }
for required in release-runtime-lock.txt release-pip-inspect.json release-requirements.txt release-wheelhouse-sha256.txt release-python-version.txt release-architecture.txt release-macos-builder-version.txt release-minimum-macos.txt release-macho-minimums.txt source-manifest-verification.txt PACKAGE_CONTENT_SHA256SUMS.txt THIRD_PARTY_NOTICES.md; do
  [[ -s "$RELEASE_RES/$required" ]] || { echo "Missing release evidence in app: $required" >&2; exit 1; }
done

EVIDENCE_DIR=${BRAID_GATE_EVIDENCE_DIR:-"$ROOT/dist/release-gate-evidence"}
mkdir -p "$EVIDENCE_DIR"
REPORT="$EVIDENCE_DIR/native-macos-verification-$ARCH.txt"
: > "$REPORT"

log() { printf '%s\n' "$*" | tee -a "$REPORT"; }
run() { log "+ $*"; "$@" >> "$REPORT" 2>&1; }

log "Braid v1.5.2 native macOS release verification"
log "Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
log "Host: $(sw_vers -productName) $(sw_vers -productVersion) / $ARCH"
log "App: $APP"
log "DMG: $DMG"
log ""

run /usr/bin/codesign --verify --deep --strict --verbose=2 "$APP"
run /usr/bin/codesign -dv --verbose=4 "$APP"
run /usr/bin/hdiutil verify "$DMG"
run "$CLI" --version
run "$CLI" doctor
ENV_JSON="$EVIDENCE_DIR/environment-$ARCH.json"
"$CLI" environment > "$ENV_JSON"
/usr/bin/grep -F "$CLI" "$ENV_JSON" >/dev/null || { log "FAIL: environment commands are not bound to bundled CLI path"; exit 1; }
log "PASS: GUI and CLI share one frozen runtime; environment points to same-install CLI"

PYVER=$(cat "$RELEASE_RES/release-python-version.txt")
if [[ "${BRAID_ALLOW_PYTHON_PATCH_DRIFT:-0}" != "1" ]]; then
  [[ "$PYVER" == "3.12.10" ]] || { log "FAIL: unexpected frozen Python: $PYVER"; exit 1; }
else
  [[ "$PYVER" == 3.12.* ]] || { log "FAIL: local UAT Python is not 3.12.x: $PYVER"; exit 1; }
fi
BUILD_ARCH=$(cat "$RELEASE_RES/release-architecture.txt")
[[ "$BUILD_ARCH" == "$ARCH" ]] || { log "FAIL: app architecture evidence $BUILD_ARCH != host $ARCH"; exit 1; }
for pin in 'numpy==2.5.1' 'cryptography==49.0.0' 'jsonschema==4.26.0' 'bleak==3.0.2' 'opencv-python-headless==4.13.0.92' 'pyinstaller==6.21.0'; do
  /usr/bin/grep -F "$pin" "$RELEASE_RES/release-runtime-lock.txt" >/dev/null || { log "FAIL: runtime lock missing $pin"; exit 1; }
done
log "PASS: frozen Python and direct runtime pins match release inputs"
/usr/bin/grep -q ': OK$' "$RELEASE_RES/source-manifest-verification.txt" || { log "FAIL: embedded source-manifest verification contains no successful entries"; exit 1; }
if /usr/bin/grep -v ': OK$' "$RELEASE_RES/source-manifest-verification.txt" | /usr/bin/grep -q .; then
  log "FAIL: embedded source-manifest verification contains a mismatch"
  exit 1
fi
log "PASS: frozen app was built from a tree matching the reviewed source manifest"

PLIST="$APP/Contents/Info.plist"
BUNDLE_ID=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$PLIST")
VERSION=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$PLIST")
BUILD_VERSION=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$PLIST")
MIN_OS=$(/usr/libexec/PlistBuddy -c 'Print :LSMinimumSystemVersion' "$PLIST")
RECORDED_MIN_OS=$(cat "$RELEASE_RES/release-minimum-macos.txt")
[[ "$BUNDLE_ID" == "ai.intersignal.braid" ]] || { log "FAIL: unexpected bundle id: $BUNDLE_ID"; exit 1; }
[[ "$VERSION" == "1.5.2" ]] || { log "FAIL: unexpected app version: $VERSION"; exit 1; }
[[ "$BUILD_VERSION" == "152" ]] || { log "FAIL: unexpected CFBundleVersion: $BUILD_VERSION"; exit 1; }
[[ "$MIN_OS" == "$RECORDED_MIN_OS" ]] || { log "FAIL: plist minOS $MIN_OS != recorded Mach-O max minOS $RECORDED_MIN_OS"; exit 1; }
log "PASS: bundle identity/version/minimum OS = $BUNDLE_ID / $VERSION ($BUILD_VERSION) / $MIN_OS"

run /usr/bin/file "$MAIN"
run /usr/bin/file "$CLI"
/usr/bin/file -b "$MAIN" | /usr/bin/grep -q 'Mach-O' || { log "FAIL: main executable is not Mach-O"; exit 1; }
run /usr/bin/codesign --verify --strict --verbose=1 "$MAIN"
run /usr/bin/shasum -a 256 "$DMG"
[[ -s "$DMG.sha256" ]] || { log "FAIL: missing sibling DMG checksum file"; exit 1; }
EXPECTED_DMG_HASH=$(awk '{print $1}' "$DMG.sha256")
ACTUAL_DMG_HASH=$(/usr/bin/shasum -a 256 "$DMG" | awk '{print $1}')
[[ "$EXPECTED_DMG_HASH" == "$ACTUAL_DMG_HASH" ]] || { log "FAIL: DMG sibling checksum mismatch"; exit 1; }
log "PASS: DMG SHA-256 matches sibling checksum"

MOUNT_DIR=$(mktemp -d "${TMPDIR:-/tmp}/braid152-dmg.XXXXXX")
INSTALL_DIR=$(mktemp -d "${TMPDIR:-/tmp}/braid152-install.XXXXXX")
cleanup() {
  /usr/bin/hdiutil detach "$MOUNT_DIR" -quiet >/dev/null 2>&1 || true
  rm -rf "$INSTALL_DIR" >/dev/null 2>&1 || true
  rmdir "$MOUNT_DIR" >/dev/null 2>&1 || true
}
trap cleanup EXIT HUP INT TERM

run /usr/bin/hdiutil attach -nobrowse -readonly -mountpoint "$MOUNT_DIR" "$DMG"
[[ -d "$MOUNT_DIR/Braid.app" ]] || { log "FAIL: mounted DMG missing Braid.app"; exit 1; }
[[ -L "$MOUNT_DIR/Applications" ]] || { log "FAIL: mounted DMG missing Applications symlink"; exit 1; }
[[ -f "$MOUNT_DIR/QUICK_START.txt" ]] || { log "FAIL: mounted DMG missing QUICK_START.txt"; exit 1; }
[[ -f "$MOUNT_DIR/README.md" && -f "$MOUNT_DIR/LICENSE" ]] || { log "FAIL: mounted DMG missing README/LICENSE"; exit 1; }
[[ -f "$MOUNT_DIR/.background/BraidDMGBackground.png" ]] || { log "FAIL: mounted DMG missing Finder background"; exit 1; }
run /usr/bin/codesign --verify --deep --strict --verbose=2 "$MOUNT_DIR/Braid.app"
log "PASS: mounted DMG layout and app signature verify"

# Simulate the user's drag-install with ditto, then exercise the installed copy.
/usr/bin/ditto "$MOUNT_DIR/Braid.app" "$INSTALL_DIR/Braid.app"
INSTALLED_CLI="$INSTALL_DIR/Braid.app/Contents/MacOS/braid-client"
run /usr/bin/codesign --verify --deep --strict --verbose=2 "$INSTALL_DIR/Braid.app"
run "$INSTALLED_CLI" --version
run "$INSTALLED_CLI" doctor
INSTALLED_ENV="$EVIDENCE_DIR/environment-installed-copy-$ARCH.json"
"$INSTALLED_CLI" environment > "$INSTALLED_ENV"
/usr/bin/grep -F "$INSTALLED_CLI" "$INSTALLED_ENV" >/dev/null || { log "FAIL: installed-copy commands do not rebind to installed CLI"; exit 1; }
log "PASS: drag-installed copy remains signed, executable, healthy, and path-self-aware"

# LaunchServices smoke without opening the browser: the app main executable is a
# CLI dispatcher whenever arguments are supplied. This proves macOS can launch
# the actual .app bundle rather than only the nested CLI path.
run /usr/bin/open -n -W "$INSTALL_DIR/Braid.app" --args doctor
log "PASS: LaunchServices can start and exit the installed Braid.app"

if [[ -n "${BRAID_CODESIGN_IDENTITY:-}" ]]; then
  log "Developer ID identity supplied; running Gatekeeper assessment on app and DMG."
  run /usr/sbin/spctl --assess --type execute --verbose=4 "$INSTALL_DIR/Braid.app"
  run /usr/sbin/spctl --assess --type open --context context:primary-signature --verbose=4 "$DMG"
else
  log "NOTE: ad-hoc/local UAT signature only; this is not a public Gatekeeper/notarization claim."
fi

if [[ -n "${BRAID_NOTARY_PROFILE:-}" ]]; then
  run /usr/bin/xcrun stapler validate -v "$DMG"
  NOTARY_JSON="$EVIDENCE_DIR/notary-submit-$ARCH.json"
  [[ -s "$NOTARY_JSON" ]] || { log "FAIL: notary submission evidence is missing"; exit 1; }
  STATUS=$(/usr/bin/plutil -extract status raw -o - "$NOTARY_JSON" 2>/dev/null || true)
  [[ "$STATUS" == "Accepted" ]] || { log "FAIL: notarization evidence status is ${STATUS:-unknown}"; exit 1; }
  log "PASS: notarization status Accepted and ticket validates"
fi

if [[ "${BRAID_PUBLIC_RELEASE:-0}" == "1" ]]; then
  [[ -n "${BRAID_CODESIGN_IDENTITY:-}" && -n "${BRAID_NOTARY_PROFILE:-}" ]] || { log "FAIL: public mode lacks signing/notary credentials"; exit 1; }
  LAYOUT_EVIDENCE="$EVIDENCE_DIR/dmg-finder-layout-$ARCH.txt"
  [[ -s "$LAYOUT_EVIDENCE" && "$(cat "$LAYOUT_EVIDENCE")" == "1" ]] || { log "FAIL: public DMG Finder layout was not verified during creation"; exit 1; }
fi

log ""
log "PASS: native package integrity and installability gate complete."
log "MANUAL RELEASE-BLOCKING FOLLOW-UP: launch /Applications/Braid.app normally and execute FINAL_MACOS_RELEASE_GATE_v1.5.2.md plus BRAID_V1_5_2_2NODE_SEMANTIC_UAT.md on the physical Macs."
log "Evidence: $REPORT"
