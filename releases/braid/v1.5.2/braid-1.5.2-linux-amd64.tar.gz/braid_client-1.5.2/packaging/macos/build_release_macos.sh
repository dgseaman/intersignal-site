#!/bin/bash
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "The native Braid release pipeline must run on macOS." >&2
  exit 2
fi

ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
ARCH=$(uname -m)
EVIDENCE="$ROOT/dist/release-gate-evidence"
mkdir -p "$EVIDENCE"
REPORT="$EVIDENCE/build-release-$ARCH.txt"
exec > >(tee "$REPORT") 2>&1

echo "Braid v1.5.2 native release pipeline"
echo "UTC: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "Host: $(sw_vers -productName) $(sw_vers -productVersion) / $ARCH"
echo "Public release: ${BRAID_PUBLIC_RELEASE:-0}"
echo "Signing identity configured: $([[ -n ${BRAID_CODESIGN_IDENTITY:-} ]] && echo yes || echo no)"
echo "Notary profile configured: $([[ -n ${BRAID_NOTARY_PROFILE:-} ]] && echo yes || echo no)"
echo

"$ROOT/packaging/macos/build_standalone_app.sh"
APP="$ROOT/dist/macos-standalone/Braid.app"
DMG="$ROOT/dist/Braid-1.5.2-macOS-$ARCH.dmg"
"$ROOT/packaging/macos/build_dmg.sh" "$APP" "$DMG"
BRAID_APP_PATH="$APP" BRAID_DMG_PATH="$DMG" "$ROOT/packaging/macos/verify_release_macos.sh"

echo
printf 'READY: %s\n' "$DMG"
printf 'SHA256: '
/usr/bin/shasum -a 256 "$DMG" | /usr/bin/awk '{print $1}'
