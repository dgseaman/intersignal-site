"""Native macOS Braid.app entry point."""
from __future__ import annotations

import os
import sys
from pathlib import Path


def main() -> int:
    support = Path.home() / "Library" / "Application Support" / "Intersignal" / "Braid"
    support.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("BRAID_RECEIVER_DIR", str(support / "inbox"))
    os.chdir(support)
    from braid_client.cli import main as braid_main
    argv = sys.argv[1:]
    if not argv:
        argv = ["demo", "--port", "0"]
    return int(braid_main(argv))


if __name__ == "__main__":
    raise SystemExit(main())
