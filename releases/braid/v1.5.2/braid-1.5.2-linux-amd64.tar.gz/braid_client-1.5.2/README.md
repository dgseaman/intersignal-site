# Intersignal Braid Light Client v1.5.2

Braid is a receiver-sovereign transport and acceptance layer for signed AI state across optical, private-LAN, and explicitly enabled Internet paths.

**v1.5.2 plants a strict heterogeneous-semantic boundary:** exact representation identity gets an exact-space fast path; different embedding spaces require a signed Semantic Capsule and receiver-local re-embedding. Braid never invents semantics from an opaque vector.

## The rule

A signed Braid frame may contain two related forms of evidence:

1. the existing signed 384D route-space vector; and
2. an optional signed `braid.semantic-capsule.v1` containing explicit canonical semantic material and source-model provenance.

At the receiver:

- **same embedding-model digest:** Braid may use the signed 384D route-space vector directly as the exact-space fast path;
- **different embedding-model digest:** Braid resolves the signed capsule and re-embeds its explicit semantic material with the receiver's local model;
- **different embedding space + no capsule:** heterogeneous semantic ingestion is rejected. No projection, nearest-neighbor story, or synthetic text is invented to bridge the gap.

Receiver-created vectors and model responses are local derived artifacts. They do **not** inherit the sender signature or sender authority.

See [`docs/SEMANTIC_CAPSULE.md`](docs/SEMANTIC_CAPSULE.md).

## Five-minute front door

### macOS app / DMG

The macOS release flow builds `Braid.app` as a standalone application and places it in an HFS+ DMG with an Applications link. Opening Braid launches the loopback-only visualizer automatically. No Terminal setup is required for the first result: **Generate state -> Commit locally** produces a real signed/verified/Phase-B-committed Braid object immediately.

The same application bundle exposes `Braid.app/Contents/MacOS/braid-client` as a relative symlink to the **same frozen Braid executable** used by Finder. The visualizer generates commands against that exact same-runtime CLI path, so the DMG and CLI are one coherent installation without shipping a duplicated Python runtime.

The visualizer performs bounded read-only/local autodetection and shows:

- machine and architecture;
- private LAN address candidates;
- the exact bundled CLI invocation;
- loopback Ollama reachability and models classified from reported capabilities rather than name heuristics;
- explicit cloud/remote model rejection state and cloud-disable configuration evidence;
- camera/browser-QR/OpenCV and BLE availability;
- Braid workspace/route/key presence;
- copyable CLI commands populated with values detected on that Mac.

The production DMG is built on macOS with:

```sh
./packaging/macos/build_release_macos.sh
```

That script uses a fixed CPython 3.12.10 release interpreter, exact direct dependency pins, a pre-downloaded wheelhouse with a SHA-256 manifest, PyInstaller for the self-contained app, and Apple's `hdiutil` for the DMG. It compiles the Braid icon, derives the advertised minimum macOS version from the actual frozen Mach-O deployment targets, signs nested code inside-out, creates the arranged drag-to-Applications image, and records native verification/notarization evidence. The resolved runtime lock and dependency-byte manifest are embedded inside the app. A `Developer ID Application` identity and `notarytool` profile promote the pipeline to the public signed/notarized path; absent them, the result is explicitly an ad-hoc local-UAT build. DMG creation is intentionally not faked on non-macOS hosts.

For the easiest release-Mac flow, double-click `packaging/macos/Build Braid 1.5.2.command` or run the script above. Before a public stamp, complete [`FINAL_MACOS_RELEASE_GATE_v1.5.2.md`](FINAL_MACOS_RELEASE_GATE_v1.5.2.md). The gate deliberately places external adversarial review before physical UAT so any review-driven code change cannot silently invalidate the Mac evidence.

A lightweight bootstrap `Braid.app` template is also included for developer testing. The standalone DMG is the intended hobbyist distribution.

### Python / CLI

Requires Python 3.10+:

```sh
python3 -m pip install braid_client-1.5.2-py3-none-any.whl
braid-client doctor
braid-client demo --port 0
```

`braid-client demo` serves the visualizer on loopback and opens the browser. The local UI remains a presentation/inspection surface; receiver acceptance still terminates in the same Phase A / Phase B authority boundary as the CLI/network paths.

## Local autodetect

```sh
braid-client environment
```

The JSON probe is deliberately local-only: Braid only calls the loopback Ollama API. Models whose names explicitly denote cloud execution, or whose Ollama metadata reports a non-empty `remote_model` / `remote_host`, are not eligible for Braid's built-in local-model adapter. The UI separately reports whether Ollama's local cloud-disable configuration was detected; that configuration is evidence, not a cryptographic attestation of the Ollama server process.

Typical generated commands include:

```sh
braid-client doctor
braid-client demo --port 0
braid-client discover --timeout 3
braid-client ollama-route --embed-model <detected-model> --output-dir <workspace>/route --count 576
braid-client capsule-frame --route-package <workspace>/route --text 'hello from Braid' --signing-key <workspace>/sender.key --output <workspace>/semantic-capsule.brad
braid-client receive --trusted-key <workspace>/sender.pub --route-package <workspace>/route --bind 0.0.0.0 --allow-lan --port 8745 --output-dir <workspace>/inbox --semantic-embed-model <receiver-model>
braid-client send semantic-capsule.brad --host <private-lan-ip> --port 8745
```

The exact commands shown in the UI are populated from the current Mac rather than copied from a static example.

## Semantic Capsule workflow

Create or reuse a digest-bound source route:

```sh
braid-client ollama-route \
  --embed-model nomic-embed-text:latest \
  --output-dir ./route
```

Create a signed capsule frame from explicit text:

```sh
braid-client capsule-frame \
  --route-package ./route \
  --text 'Decision: run the receiver locally. Constraint: do not infer missing state.' \
  --signing-key ./sender.key \
  --output semantic-capsule.brad
```

On a receiver whose local embedding model may be different:

```sh
braid-client receive \
  --trusted-key ./sender.pub \
  --route-package ./route \
  --bind 0.0.0.0 \
  --allow-lan \
  --port 8745 \
  --output-dir ./receiver \
  --semantic-embed-model <receiver-local-embedding-model>
```

Send the exact signed bytes:

```sh
braid-client send semantic-capsule.brad --host <receiver-private-ip> --port 8745
```

The receiver preflights the capsule before Phase B. If the receiver embedding-model digest differs, it calls the receiver-local loopback Ollama `/api/embed` without forcing Braid's 384D route dimension, then stores an atomic semantic bundle:

```text
receiver/semantic/<object-digest>/
  vector.npy
  lineage.json
  response.json       # only if an optional local completion model is configured
```

`lineage.json` explicitly records the capsule digest, source and receiver model digests, source wire payload digest, receiver-native dimension, derivation method, finality, and the fact that the sender signature does not cover the receiver-created vector.

## Signed Legend + Semantic Capsule

`ollama-frame` continues to distill bounded signed Legend state, and v1.5.2 also attaches a `legend_ref` Semantic Capsule whose semantic material resolves to the exact signed Legend semantic view.

```sh
braid-client ollama-frame \
  --route-package ./route \
  --model mistral:latest \
  --text-file state.txt \
  --signing-key ./sender.key \
  --output state.brad
```

This lets a heterogeneous receiver reconstruct useful local semantic state from explicit signed material without claiming that hidden activations, native embeddings, model weights, or a conversation process were transferred.

## Exact-space fast path

If the receiver-selected embedding model resolves to the same exact Ollama model digest recorded in the signed capsule and frozen source route, Braid does not perform a redundant native re-embedding. It normalizes and uses the signed source 384D route-space vector as `exact_space_fast_path`.

The optimization is identity-gated, not name-gated. Receivers that want stronger consistency checking can add `--semantic-verify-fast-path`; Braid then re-embeds the capsule material with the exact same local embedding model before Phase B and requires the configured cosine threshold (default `0.999`). This verifies same-model capsule/vector coherence without turning a sender assertion into receiver authority.

## Existing calibrated heterogeneous route

The v1.5.0 empirical source-to-target route calibration machinery remains available (`hetero-calibrate`, `hetero-frame`, `hetero-route-info`) for measured projection experiments and regression compatibility.

It is **not** used as a license to invent meaning for arbitrary opaque vectors. For interoperable heterogeneous semantic ingestion in v1.5.2, the preferred path is the signed Semantic Capsule with receiver-local re-embedding.

See [`docs/HETEROGENEOUS_SEMANTIC_TRANSFER.md`](docs/HETEROGENEOUS_SEMANTIC_TRANSFER.md).

## Receiver finality

Braid preserves its central authority invariant:

```text
transport arrival != acceptance
Phase A validation != acceptance
external validator success != acceptance
local model output != acceptance
only successful receiver-owned Phase B commit == accepted
```

Semantic re-embedding is preflighted before Phase B when configured. Receiver-local artifact writing and optional completion handoff occur after Phase B. A post-commit local-model or filesystem failure can degrade delivery but cannot rewrite committed finality into rejection.

## Transport paths

- **Optical QR reels:** air-gapped/visible transport with bounded chunk collection and exact byte reassembly.
- **Private LAN:** explicit `--allow-lan` receiver policy; exact signed frame bytes over the network transport.
- **Public Internet:** explicit opt-in and TLS policy remain required.
- **BLE sensing/discovery:** untrusted hints only; never authority.

The same signed semantic object can travel over different transports. Transport does not gain authority over the receiver.

## Security posture

- Ed25519 signatures and digest-bound payloads.
- RFC 8785/JCS canonical manifest handling and regression vectors.
- scoped replay/session ledger with receiver-owned Phase B transaction.
- loopback-only local UI and Ollama API adapter; explicit cloud names and Ollama-reported remote model/host markers fail closed.
- closed/bounded Semantic Capsule schema.
- capsule digest + source wire-payload binding + frozen route/source-model digest binding.
- no remote URL supplied by a capsule is ever followed; capsules contain semantic data and model identity, not executable transport instructions.
- derived receiver semantic artifacts are private-mode and explicitly local-authority only.
- model-generated responses remain untrusted local outputs and must not be used as authority for tool execution.

See [`SECURITY.md`](SECURITY.md).

## Tests

The v1.5.2 source tree contains the full historical conformance suite plus dedicated Semantic Capsule and front-door tests. The release evidence records the exact commands and results.

Key v1.5.2 cases include:

- payload-bound inline capsule;
- exact-digest fast path;
- different-digest native receiver re-embedding;
- missing capsule rejection when heterogeneous semantic ingestion is configured;
- signed capsule self-tamper rejection;
- forged source-model/digest route-binding rejection;
- post-commit local completion failure preserving Phase B finality;
- receiver-native non-384 embedding dimension;
- loopback/local-only autodetect and visualizer endpoint behavior;
- capability-based Ollama classification plus explicit/metadata-reported remote-model rejection;
- same-install DMG/CLI command generation and release-build pin/evidence contracts;
- optional strict exact-space capsule/vector coherence verification.

Physical two-node macOS/Ollama/camera UAT remains a separate release gate and is not represented as having occurred in simulation.

## Development

```sh
PYTHONPATH=. python3 -m unittest discover -s tests -v
```

Because the calibration tests are intentionally heavier, CI or constrained environments may run the suite in file groups.

## License

MIT. See `LICENSE` and `THIRD_PARTY_NOTICES.md`.
