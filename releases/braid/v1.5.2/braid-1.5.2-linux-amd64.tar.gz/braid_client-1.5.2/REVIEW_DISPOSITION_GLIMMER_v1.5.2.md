# Braid v1.5.2 — Glimmer review disposition

This file records adjudication of the focused Warp-9.5 external review. Native DMG/notarization and physical Air+Pro UAT remain release-blocking and unexecuted.

1. **Ollama `model_digest` locality bypass — partially valid direction, P0 rejected.** The reviewed tree already rejected explicit cloud names and tag-level remote markers. Hardening accepted: digest lookup now calls the full local-model inspection path, including `/api/show` remote markers.
2. **Verification loader private-key fallback — valid hardening, severity reduced.** Fallback into `load_signing_key` removed. Verification-key loading never invokes the private-key parser.
3. **No-capsule global rejection — not accepted.** A receiver without a semantic handoff may accept authenticated opaque Braid state; that is not heterogeneous semantic ingestion. When semantic ingestion is configured, a capsule is required pre-Phase-B and the existing negative test proves fail-closed behavior.
4. **Fast-path vector/capsule wire binding — not accepted as a defect.** `extract_semantic_capsule` requires capsule `wire_payload_digest == manifest.payload_digest`; Phase A independently requires `manifest.payload_digest == SHA-256(raw wire payload)`. This binds the capsule to the actual wire payload before fast-path preparation. Optional strict coherence addresses a different question: whether a dishonest signer truthfully derived that authenticated vector from the signed semantic material.
5. **Derived-artifact authority confusion — UX hardening accepted.** Visualizer now emits an explicit `RECEIVER-LOCAL DERIVED ARTIFACT — NOT SENDER-SIGNED` notice and receiver-local committed status.
6. **Origin-less browser requests — defense-in-depth accepted.** Plain non-browser loopback API clients remain supported; browser requests marked `Sec-Fetch-Site: cross-site` are rejected even if Origin is absent.
7. **Private-key permission repair race — hardening accepted.** Key reads now use an opened file descriptor, reject symlink indirection where supported, operate on the opened inode, and verify `0600` repair.
8. **Same-install CLI hard-coded path — not reproduced.** Runtime `_cli_argv()` already discovers the sibling executable from `sys.executable` inside the frozen app; it does not hard-code `/Applications/Braid.app`.
9. **Cloud-disable evidence overclaim — not reproduced.** The environment report carries `server_environment_attested: false`, and the visualizer says either `cloud-disabled config evidence` or `server cloud-off not verified`.

Review-hardening regression result: **129/129 unique tests pass** in split execution.
