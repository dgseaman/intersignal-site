"""Ambient local sensing for Braid v1.5.2.

BLE observations are discovery hints only. RSSI is smoothed for relative
proximity (warmer/colder) and is never treated as authenticated identity or an
exact distance measurement. Trust remains in the normal Braid receiver gates.
"""
from __future__ import annotations

import asyncio
import time
import threading
from collections import deque
from dataclasses import dataclass, field
from typing import Any

BRAID_BLE_SERVICE_UUID = "f7d7b2a0-8b86-4d51-9bd6-b1a2d8f51446"


def _bounded_sensing_text(value: object, *, max_chars: int) -> str:
    text = str(value).replace("\x00", "")
    text = "".join(ch for ch in text if ch == "\t" or ord(ch) >= 0x20)
    return text[:max_chars]


def proximity_band(rssi: float) -> str:
    if rssi >= -48:
        return "immediate"
    if rssi >= -60:
        return "near"
    if rssi >= -72:
        return "room"
    return "far"


@dataclass
class _Track:
    key: str
    label: str
    samples: deque[float] = field(default_factory=lambda: deque(maxlen=12))
    smoothed_rssi: float | None = None
    last_seen_unix: float = 0.0
    seen_count: int = 0

    def observe(self, rssi: float, label: str | None = None, alpha: float = 0.34) -> dict[str, Any]:
        if label:
            self.label = label
        self.samples.append(float(rssi))
        self.seen_count += 1
        self.last_seen_unix = time.time()
        if self.smoothed_rssi is None:
            self.smoothed_rssi = float(rssi)
        else:
            self.smoothed_rssi = alpha * float(rssi) + (1.0 - alpha) * self.smoothed_rssi
        variance = 0.0
        if len(self.samples) > 1:
            mean = sum(self.samples) / len(self.samples)
            variance = sum((x - mean) ** 2 for x in self.samples) / len(self.samples)
        confidence = max(0.0, min(1.0, (len(self.samples) / 6.0) * (1.0 / (1.0 + variance / 36.0))))
        return self.snapshot(confidence)

    def snapshot(self, confidence: float | None = None) -> dict[str, Any]:
        if confidence is None:
            confidence = min(1.0, len(self.samples) / 6.0)
        return {
            "key": self.key,
            "label": self.label,
            "rssi": self.samples[-1] if self.samples else None,
            "smoothed_rssi": round(self.smoothed_rssi, 2) if self.smoothed_rssi is not None else None,
            "band": proximity_band(self.smoothed_rssi) if self.smoothed_rssi is not None else "unknown",
            "confidence": round(confidence, 3),
            "seen_count": self.seen_count,
            "last_seen_unix": self.last_seen_unix,
            "distance_claim": "relative_only",
            "trust": "untrusted_discovery_hint",
        }


class ProximityField:
    def __init__(self, *, max_tracks: int = 256, max_key_chars: int = 128, max_label_chars: int = 96) -> None:
        if max_tracks <= 0:
            raise ValueError("ERR_SENSING_MAX_TRACKS")
        self.max_tracks = max_tracks
        self.max_key_chars = max_key_chars
        self.max_label_chars = max_label_chars
        self._tracks: dict[str, _Track] = {}
        self._lock = threading.Lock()

    def observe(self, key: str, rssi: float, label: str | None = None) -> dict[str, Any]:
        key = _bounded_sensing_text(key, max_chars=self.max_key_chars)
        if not key:
            raise ValueError("ERR_SENSING_KEY_REQUIRED")
        clean_label = _bounded_sensing_text(label if label is not None else key, max_chars=self.max_label_chars) or key
        rssi = float(rssi)
        if not (-127.0 <= rssi <= 20.0):
            raise ValueError("ERR_RSSI_RANGE")
        with self._lock:
            track = self._tracks.get(key)
            if track is None:
                if len(self._tracks) >= self.max_tracks:
                    oldest_key = min(self._tracks, key=lambda item: self._tracks[item].last_seen_unix)
                    del self._tracks[oldest_key]
                track = _Track(key=key, label=clean_label)
                self._tracks[key] = track
            return track.observe(rssi, label=clean_label)

    def snapshot(self, max_age_seconds: float = 30.0) -> list[dict[str, Any]]:
        if max_age_seconds <= 0:
            raise ValueError("ERR_SENSING_MAX_AGE")
        now = time.time()
        with self._lock:
            stale = [key for key, track in self._tracks.items() if now - track.last_seen_unix > max_age_seconds]
            for key in stale:
                del self._tracks[key]
            records = [track.snapshot() for track in self._tracks.values()]
        records.sort(key=lambda item: item.get("smoothed_rssi") or -999, reverse=True)
        return records

    async def scan_ble(self, timeout_seconds: float = 3.0) -> list[dict[str, Any]]:
        try:
            from bleak import BleakScanner
        except ImportError as exc:
            raise RuntimeError("ERR_BLEAK_UNAVAILABLE: install braid-client[sensing]") from exc

        discovered = await BleakScanner.discover(timeout=float(timeout_seconds), return_adv=True)
        for address, pair in discovered.items():
            try:
                device, adv = pair
            except Exception:
                continue
            service_uuids = {str(x).lower() for x in (getattr(adv, "service_uuids", None) or [])}
            local_name = getattr(adv, "local_name", None) or getattr(device, "name", None) or ""
            # Only surface devices intentionally presenting a Braid hint.
            if BRAID_BLE_SERVICE_UUID not in service_uuids and not str(local_name).upper().startswith("BRAID"):
                continue
            rssi = getattr(adv, "rssi", None)
            if rssi is None:
                rssi = getattr(device, "rssi", None)
            if rssi is None:
                continue
            self.observe(str(address), float(rssi), label=str(local_name or address))
        return self.snapshot()

    def scan_ble_sync(self, timeout_seconds: float = 3.0) -> list[dict[str, Any]]:
        return asyncio.run(self.scan_ble(timeout_seconds))


SENSOR_FIELD = ProximityField()
