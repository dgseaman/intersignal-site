"""Signed Braid Legend support for v1.5.2.

A Legend is compact sender-provided semantic context carried inside the signed
Braid manifest. It identifies decision-critical meaning that should survive a
handoff, but it never grants receiver authority. Receiver policy and Phase B
remain authoritative.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
from typing import Any, Mapping

from .mcp_core.canonical import jcs_serialize


LEGEND_SCHEMA = "braid.legend.v1"
LEGEND_DIGEST_PREFIX = b"BRAID-LEGEND-v1\x00"
LEGEND_MAX_JCS_BYTES = 7168
LEGEND_MAX_TEXT = 512
LEGEND_MAX_SHORT_TEXT = 256
LEGEND_MAX_CONSTRAINTS = 8
LEGEND_MAX_BRANCHES = 8
LEGEND_MAX_FACTS = 12
LEGEND_MAX_TEMPORAL = 8
LEGEND_MAX_SIGNIFICANCE = 8
LEGEND_MAX_MUST_PRESERVE = 12
LEGEND_MAX_ARCHIVE_REFS = 8

_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_HEX64_RE = re.compile(r"^[0-9a-f]{64}$")

_CONSTRAINT_KINDS = {
    "operational", "safety", "policy", "budget", "technical", "temporal", "other"
}
_PROVENANCE_KINDS = {
    "source_text_explicit", "model_inference", "source_claimed_tool_result",
    "source_claimed_document", "unknown"
}
_CONFIDENCE_KINDS = {"asserted", "inferred", "uncertain"}
_HORIZONS = {"immediate", "session", "durable", "unknown"}


def _text(value: Any, *, field: str, max_chars: int = LEGEND_MAX_TEXT, required: bool = True) -> str:
    if not isinstance(value, str):
        raise ValueError(f"ERR_LEGEND_FIELD_TYPE:{field}")
    value = _CONTROL_RE.sub("", value).strip()
    if required and not value:
        raise ValueError(f"ERR_LEGEND_FIELD_EMPTY:{field}")
    if len(value) > max_chars:
        raise ValueError(f"ERR_LEGEND_FIELD_TOO_LONG:{field}:{len(value)}")
    return value


def _bool(value: Any, *, field: str) -> bool:
    if type(value) is not bool:
        raise ValueError(f"ERR_LEGEND_FIELD_TYPE:{field}")
    return value


def _enum(value: Any, *, field: str, allowed: set[str]) -> str:
    text = _text(value, field=field, max_chars=64)
    if text not in allowed:
        raise ValueError(f"ERR_LEGEND_ENUM:{field}:{text}")
    return text


def legend_model_schema() -> dict[str, Any]:
    """JSON schema used with Ollama structured outputs.

    Metadata that must come from Braid itself (schema, source digest, generator,
    timestamp) is intentionally excluded from model output and added only after
    the response is parsed.
    """
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "objective": {"type": "string"},
            "active_intent": {"type": "string"},
            "constraints": {
                "type": "array",
                "maxItems": LEGEND_MAX_CONSTRAINTS,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "kind": {"type": "string", "enum": sorted(_CONSTRAINT_KINDS)},
                        "text": {"type": "string"},
                        "critical": {"type": "boolean"},
                    },
                    "required": ["kind", "text", "critical"],
                },
            },
            "branch_conditions": {
                "type": "array",
                "maxItems": LEGEND_MAX_BRANCHES,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "if": {"type": "string"},
                        "then": {"type": "string"},
                        "critical": {"type": "boolean"},
                    },
                    "required": ["if", "then", "critical"],
                },
            },
            "provenance_facts": {
                "type": "array",
                "maxItems": LEGEND_MAX_FACTS,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "statement": {"type": "string"},
                        "provenance": {"type": "string", "enum": sorted(_PROVENANCE_KINDS)},
                        "confidence": {"type": "string", "enum": sorted(_CONFIDENCE_KINDS)},
                        "critical": {"type": "boolean"},
                    },
                    "required": ["statement", "provenance", "confidence", "critical"],
                },
            },
            "temporal_salience": {
                "type": "array",
                "maxItems": LEGEND_MAX_TEMPORAL,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "statement": {"type": "string"},
                        "horizon": {"type": "string", "enum": sorted(_HORIZONS)},
                        "expires_at": {"type": ["integer", "null"]},
                    },
                    "required": ["statement", "horizon", "expires_at"],
                },
            },
            "significance": {
                "type": "array",
                "maxItems": LEGEND_MAX_SIGNIFICANCE,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "concept": {"type": "string"},
                        "weight": {"type": "integer", "minimum": 1, "maximum": 5},
                        "reason": {"type": "string"},
                    },
                    "required": ["concept", "weight", "reason"],
                },
            },
            "must_preserve": {
                "type": "array",
                "maxItems": LEGEND_MAX_MUST_PRESERVE,
                "items": {"type": "string"},
            },
            "archive_refs": {
                "type": "array",
                "maxItems": LEGEND_MAX_ARCHIVE_REFS,
                "items": {"type": "string"},
            },
        },
        "required": [
            "objective", "active_intent", "constraints", "branch_conditions",
            "provenance_facts", "temporal_salience", "significance",
            "must_preserve", "archive_refs",
        ],
    }


def _bounded_list(value: Any, *, field: str, max_items: int) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"ERR_LEGEND_FIELD_TYPE:{field}")
    if len(value) > max_items:
        raise ValueError(f"ERR_LEGEND_TOO_MANY:{field}:{len(value)}")
    return value


def normalize_model_legend(value: Mapping[str, Any]) -> dict[str, Any]:
    """Validate and bound only the semantic portion returned by the model."""
    if not isinstance(value, Mapping):
        raise ValueError("ERR_LEGEND_MODEL_OBJECT")
    expected = {
        "objective", "active_intent", "constraints", "branch_conditions",
        "provenance_facts", "temporal_salience", "significance",
        "must_preserve", "archive_refs",
    }
    if set(value) != expected:
        missing = sorted(expected - set(value))
        extra = sorted(set(value) - expected)
        raise ValueError(f"ERR_LEGEND_MODEL_FIELDS:missing={missing}:extra={extra}")

    constraints = []
    for index, item in enumerate(_bounded_list(value["constraints"], field="constraints", max_items=LEGEND_MAX_CONSTRAINTS)):
        if not isinstance(item, Mapping) or set(item) != {"kind", "text", "critical"}:
            raise ValueError(f"ERR_LEGEND_CONSTRAINT:{index}")
        constraints.append({
            "kind": _enum(item["kind"], field=f"constraints[{index}].kind", allowed=_CONSTRAINT_KINDS),
            "text": _text(item["text"], field=f"constraints[{index}].text"),
            "critical": _bool(item["critical"], field=f"constraints[{index}].critical"),
        })

    branches = []
    for index, item in enumerate(_bounded_list(value["branch_conditions"], field="branch_conditions", max_items=LEGEND_MAX_BRANCHES)):
        if not isinstance(item, Mapping) or set(item) != {"if", "then", "critical"}:
            raise ValueError(f"ERR_LEGEND_BRANCH:{index}")
        branches.append({
            "if": _text(item["if"], field=f"branch_conditions[{index}].if"),
            "then": _text(item["then"], field=f"branch_conditions[{index}].then"),
            "critical": _bool(item["critical"], field=f"branch_conditions[{index}].critical"),
        })

    facts = []
    for index, item in enumerate(_bounded_list(value["provenance_facts"], field="provenance_facts", max_items=LEGEND_MAX_FACTS)):
        required = {"statement", "provenance", "confidence", "critical"}
        if not isinstance(item, Mapping) or set(item) != required:
            raise ValueError(f"ERR_LEGEND_FACT:{index}")
        facts.append({
            "statement": _text(item["statement"], field=f"provenance_facts[{index}].statement"),
            "provenance": _enum(item["provenance"], field=f"provenance_facts[{index}].provenance", allowed=_PROVENANCE_KINDS),
            "confidence": _enum(item["confidence"], field=f"provenance_facts[{index}].confidence", allowed=_CONFIDENCE_KINDS),
            "critical": _bool(item["critical"], field=f"provenance_facts[{index}].critical"),
        })

    temporal = []
    for index, item in enumerate(_bounded_list(value["temporal_salience"], field="temporal_salience", max_items=LEGEND_MAX_TEMPORAL)):
        required = {"statement", "horizon", "expires_at"}
        if not isinstance(item, Mapping) or set(item) != required:
            raise ValueError(f"ERR_LEGEND_TEMPORAL:{index}")
        expires_at = item["expires_at"]
        if expires_at is not None and (type(expires_at) is not int or expires_at <= 0):
            raise ValueError(f"ERR_LEGEND_EXPIRES_AT:{index}")
        temporal.append({
            "statement": _text(item["statement"], field=f"temporal_salience[{index}].statement"),
            "horizon": _enum(item["horizon"], field=f"temporal_salience[{index}].horizon", allowed=_HORIZONS),
            "expires_at": expires_at,
        })

    significance = []
    for index, item in enumerate(_bounded_list(value["significance"], field="significance", max_items=LEGEND_MAX_SIGNIFICANCE)):
        required = {"concept", "weight", "reason"}
        if not isinstance(item, Mapping) or set(item) != required:
            raise ValueError(f"ERR_LEGEND_SIGNIFICANCE:{index}")
        weight = item["weight"]
        if type(weight) is not int or not 1 <= weight <= 5:
            raise ValueError(f"ERR_LEGEND_WEIGHT:{index}")
        significance.append({
            "concept": _text(item["concept"], field=f"significance[{index}].concept", max_chars=LEGEND_MAX_SHORT_TEXT),
            "weight": weight,
            "reason": _text(item["reason"], field=f"significance[{index}].reason"),
        })

    must_preserve = [
        _text(item, field=f"must_preserve[{index}]", max_chars=LEGEND_MAX_SHORT_TEXT)
        for index, item in enumerate(_bounded_list(value["must_preserve"], field="must_preserve", max_items=LEGEND_MAX_MUST_PRESERVE))
    ]
    archive_refs = [
        _text(item, field=f"archive_refs[{index}]", max_chars=LEGEND_MAX_SHORT_TEXT)
        for index, item in enumerate(_bounded_list(value["archive_refs"], field="archive_refs", max_items=LEGEND_MAX_ARCHIVE_REFS))
    ]

    return {
        "objective": _text(value["objective"], field="objective"),
        "active_intent": _text(value["active_intent"], field="active_intent"),
        "constraints": constraints,
        "branch_conditions": branches,
        "provenance_facts": facts,
        "temporal_salience": temporal,
        "significance": significance,
        "must_preserve": must_preserve,
        "archive_refs": archive_refs,
    }


def finalize_legend(
    model_legend: Mapping[str, Any],
    *,
    generator_model: str,
    generator_model_digest: str,
    source_text: str,
    created_at: int | None = None,
) -> dict[str, Any]:
    semantic = normalize_model_legend(model_legend)
    if not isinstance(generator_model_digest, str) or not _HEX64_RE.fullmatch(generator_model_digest):
        raise ValueError("ERR_LEGEND_GENERATOR_DIGEST")
    source_bytes = source_text.encode("utf-8")
    legend = {
        "schema": LEGEND_SCHEMA,
        **semantic,
        "generator": {
            "backend": "ollama:/api/chat",
            "model": _text(generator_model, field="generator.model", max_chars=160),
            "model_digest": generator_model_digest,
        },
        "source_text_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "created_at": int(time.time()) if created_at is None else int(created_at),
    }
    return validate_legend(legend)


def validate_legend(value: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError("ERR_LEGEND_OBJECT")
    expected = {
        "schema", "objective", "active_intent", "constraints", "branch_conditions",
        "provenance_facts", "temporal_salience", "significance", "must_preserve",
        "archive_refs", "generator", "source_text_sha256", "created_at",
    }
    if set(value) != expected:
        missing = sorted(expected - set(value))
        extra = sorted(set(value) - expected)
        raise ValueError(f"ERR_LEGEND_FIELDS:missing={missing}:extra={extra}")
    if value.get("schema") != LEGEND_SCHEMA:
        raise ValueError("ERR_LEGEND_SCHEMA")

    semantic = normalize_model_legend({key: value[key] for key in (
        "objective", "active_intent", "constraints", "branch_conditions",
        "provenance_facts", "temporal_salience", "significance", "must_preserve", "archive_refs",
    )})
    generator = value.get("generator")
    if not isinstance(generator, Mapping) or set(generator) != {"backend", "model", "model_digest"}:
        raise ValueError("ERR_LEGEND_GENERATOR")
    if generator.get("backend") != "ollama:/api/chat":
        raise ValueError("ERR_LEGEND_GENERATOR_BACKEND")
    generator_model = _text(generator.get("model"), field="generator.model", max_chars=160)
    generator_digest = generator.get("model_digest")
    if not isinstance(generator_digest, str) or not _HEX64_RE.fullmatch(generator_digest):
        raise ValueError("ERR_LEGEND_GENERATOR_DIGEST")
    source_digest = value.get("source_text_sha256")
    if not isinstance(source_digest, str) or not _HEX64_RE.fullmatch(source_digest):
        raise ValueError("ERR_LEGEND_SOURCE_DIGEST")
    created_at = value.get("created_at")
    if type(created_at) is not int or created_at <= 0:
        raise ValueError("ERR_LEGEND_CREATED_AT")

    normalized = {
        "schema": LEGEND_SCHEMA,
        **semantic,
        "generator": {"backend": "ollama:/api/chat", "model": generator_model, "model_digest": generator_digest},
        "source_text_sha256": source_digest,
        "created_at": created_at,
    }
    if len(jcs_serialize(normalized)) > LEGEND_MAX_JCS_BYTES:
        raise ValueError("ERR_LEGEND_TOO_LARGE")
    return normalized


def legend_digest(legend: Mapping[str, Any]) -> str:
    normalized = validate_legend(legend)
    return hashlib.sha256(LEGEND_DIGEST_PREFIX + jcs_serialize(normalized)).hexdigest()


def legend_semantic_view(legend: Mapping[str, Any]) -> dict[str, Any]:
    normalized = validate_legend(legend)
    return {key: normalized[key] for key in (
        "schema", "objective", "active_intent", "constraints", "branch_conditions",
        "provenance_facts", "temporal_salience", "significance", "must_preserve", "archive_refs",
    )}


def legend_embedding_text(legend: Mapping[str, Any]) -> str:
    """Canonical semantic rendering used to produce the 384D Braid state."""
    return jcs_serialize(legend_semantic_view(legend)).decode("utf-8")


def attach_legend_extension(manifest: dict[str, Any], legend: Mapping[str, Any]) -> dict[str, Any]:
    normalized = validate_legend(legend)
    extensions = manifest.setdefault("extensions", {})
    if not isinstance(extensions, dict):
        raise ValueError("ERR_LEGEND_EXTENSIONS_OBJECT")
    extensions["braid_legend"] = normalized
    extensions["braid_legend_digest"] = legend_digest(normalized)
    extensions["braid_legend_authority"] = "signed_sender_context_only"
    return manifest


def extract_legend_extension(manifest: Mapping[str, Any], *, required: bool = False) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    extensions = manifest.get("extensions")
    if extensions is None:
        if required:
            raise ValueError("ERR_LEGEND_REQUIRED")
        return None, {"present": False, "authority": "none"}
    if not isinstance(extensions, Mapping):
        raise ValueError("ERR_LEGEND_EXTENSIONS_OBJECT")
    raw = extensions.get("braid_legend")
    digest = extensions.get("braid_legend_digest")
    if raw is None and digest is None:
        if required:
            raise ValueError("ERR_LEGEND_REQUIRED")
        return None, {"present": False, "authority": "none"}
    if raw is None or digest is None:
        raise ValueError("ERR_LEGEND_INCOMPLETE")
    normalized = validate_legend(raw)
    computed = legend_digest(normalized)
    if not isinstance(digest, str) or digest != computed:
        raise ValueError("ERR_LEGEND_DIGEST")
    authority = extensions.get("braid_legend_authority")
    if authority != "signed_sender_context_only":
        raise ValueError("ERR_LEGEND_AUTHORITY_LABEL")
    critical_count = sum(bool(item["critical"]) for item in normalized["constraints"])
    critical_count += sum(bool(item["critical"]) for item in normalized["branch_conditions"])
    critical_count += sum(bool(item["critical"]) for item in normalized["provenance_facts"])
    evidence = {
        "present": True,
        "schema": LEGEND_SCHEMA,
        "digest": computed,
        "must_preserve_count": len(normalized["must_preserve"]),
        "critical_anchor_count": critical_count,
        "authority": "signed_sender_context_only",
    }
    return normalized, evidence


def receiver_prompt_payload(legend: Mapping[str, Any]) -> str:
    """Deterministic JSON payload presented to the receiver model as data."""
    return json.dumps(legend_semantic_view(legend), sort_keys=True, ensure_ascii=False, indent=2)
