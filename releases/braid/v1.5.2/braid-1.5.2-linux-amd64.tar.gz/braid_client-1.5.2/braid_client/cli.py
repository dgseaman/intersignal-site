"""CLI entrypoint for Braid Client v1.5.2."""
from __future__ import annotations

import argparse
import json
import importlib.util
import math
import platform
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

from . import __version__
from .keys import load_or_create_signing_key, load_verification_key, get_raw_public_bytes
from .server import generate_frame_object, create_authoritative_validator, analyze_vector_stats, serve_http_app
from .qr_engine import (
    chunk_binary_frame, OpticalChunkCollector, StandardQRCodeEncoder,
    rasterize_qr_matrix, decode_qr_raster,
)
from .mcp_core.protocol import BraidFrame
from .receiver import AutomatedReceiver, ReceiverAutomationConfig
from .sensing import SENSOR_FIELD
from .transport.client import send_frame
from .transport.protocol import atomic_write
from .transport.discovery import DEFAULT_DISCOVERY_PORT, advertise_once, discover
from .transport.server import ReceiverConfig as NetworkReceiverConfig, TransportServer
from .semantic_transfer import (
    build_conformance_corpus, write_corpus, calibrate_ollama_route,
    build_frame_from_text, build_frame_from_legend, create_validator_from_route_package, load_route_package,
)
from .ollama_adapter import (
    DEFAULT_OLLAMA_URL, DEFAULT_COMPLETION_MODEL, DEFAULT_EMBEDDING_MODEL,
    OllamaClient, OllamaHandoffConfig, generate_legend, ollama_doctor,
)
from .legend import legend_digest
from .semantic_capsule import (
    SemanticCapsuleHandoffConfig, extract_semantic_capsule, semantic_capsule_digest,
)


def _print_json(value: object) -> None:
    print(json.dumps(value, sort_keys=True, indent=2), flush=True)


def _positive_float(value: str) -> float:
    result = float(value)
    if result <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return result


def _ollama_handoff_from_args(args: argparse.Namespace) -> OllamaHandoffConfig | None:
    model = getattr(args, "ollama_model", None)
    if not model:
        return None
    return OllamaHandoffConfig(
        completion_model=model,
        embedding_model=getattr(args, "ollama_embed_model", DEFAULT_EMBEDDING_MODEL),
        base_url=getattr(args, "ollama_url", DEFAULT_OLLAMA_URL),
        timeout_seconds=getattr(args, "ollama_timeout", 180.0),
        min_alignment=getattr(args, "ollama_min_alignment", None),
    )


def _semantic_handoff_from_args(args: argparse.Namespace) -> SemanticCapsuleHandoffConfig | None:
    model = getattr(args, "semantic_embed_model", None)
    if not model:
        return None
    return SemanticCapsuleHandoffConfig(
        embedding_model=model,
        completion_model=getattr(args, "semantic_completion_model", None),
        base_url=getattr(args, "ollama_url", DEFAULT_OLLAMA_URL),
        timeout_seconds=getattr(args, "ollama_timeout", 180.0),
        verify_exact_space_coherence=getattr(args, "semantic_verify_fast_path", False),
        min_exact_space_cosine=getattr(args, "semantic_min_fast_path_cosine", 0.999),
    )


def _read_bounded_file(path: Path, max_bytes: int = 2 * 1024 * 1024) -> bytes:
    size = path.stat().st_size
    if size <= 0:
        raise ValueError("ERR_EMPTY_FRAME")
    if size > max_bytes:
        raise ValueError("ERR_FRAME_TOO_LARGE")
    return path.read_bytes()


def run_doctor() -> dict[str, object]:
    """Fast, side-effect-contained readiness check for a live demo or install."""
    checks: dict[str, object] = {
        "version": __version__,
        "python": platform.python_version(),
        "field_assets": False,
        "qr_encode": False,
        "receiver_roundtrip": False,
        "finality_invariant": False,
        "camera_fallback": importlib.util.find_spec("cv2") is not None,
        "ble_sensing": importlib.util.find_spec("bleak") is not None,
    }
    base = Path(__file__).resolve().parent
    checks["field_assets"] = (base / "static" / "braid_visualizer.html").is_file() and (base / "static" / "camera_receiver.js").is_file()
    qr = StandardQRCodeEncoder("BRAD1:doctor")
    checks["qr_encode"] = bool(qr.matrix and qr.size >= 21)

    with tempfile.TemporaryDirectory() as tmp_dir:
        root = Path(tmp_dir)
        sk, _, _ = load_or_create_signing_key(str(root / "doctor.key"))
        vk = sk.public_key()
        _, raw, _ = generate_frame_object(signing_key=sk)
        validator, registry, ledger = create_authoritative_validator(get_raw_public_bytes(vk).hex(), ledger_path=root / "replay_ledger.db")
        receiver = AutomatedReceiver(
            validator=validator, registry=registry, ledger=ledger, verification_key=vk,
            config=ReceiverAutomationConfig(storage_dir=root / "inbox", auto_commit=True),
        )
        report = receiver.process_bytes(raw, source_transport="doctor", source_name="doctor.brad", peer="loopback")
        checks["receiver_roundtrip"] = bool(report.get("accepted") and report.get("post_commit_complete"))
        checks["finality_invariant"] = bool(report.get("accepted") == (report.get("finality") == "committed") and report.get("phase_b_committed"))

    checks["ready"] = bool(checks["field_assets"] and checks["qr_encode"] and checks["receiver_roundtrip"] and checks["finality_invariant"])
    checks["optional_note"] = "camera_fallback and ble_sensing are optional; native browser camera decoding may be available without OpenCV"
    return checks


def _build_receiver(trusted_key_path: str, output_dir: Path, *, auto_commit: bool = True,
                    handoff_command: str | None = None, audit_log: Path | None = None,
                    route_package: Path | None = None,
                    ollama_handoff: OllamaHandoffConfig | None = None,
                    semantic_handoff: SemanticCapsuleHandoffConfig | None = None) -> AutomatedReceiver:
    output_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        output_dir.chmod(0o700)
    except OSError:
        pass
    vk = load_verification_key(trusted_key_path)
    if route_package is None:
        validator, registry, ledger = create_authoritative_validator(
            get_raw_public_bytes(vk).hex(), ledger_path=output_dir / "replay_ledger.db"
        )
    else:
        validator, registry, ledger, _ = create_validator_from_route_package(
            route_package, get_raw_public_bytes(vk).hex(), output_dir / "replay_ledger.db"
        )
    return AutomatedReceiver(
        validator=validator,
        registry=registry,
        ledger=ledger,
        verification_key=vk,
        config=ReceiverAutomationConfig(
            storage_dir=output_dir,
            auto_commit=auto_commit,
            handoff_command=handoff_command,
            ollama_handoff=ollama_handoff,
            semantic_capsule_handoff=semantic_handoff,
            audit_log=audit_log,
        ),
    )


def run_2node_smoke_test(verbose: bool = True) -> bool:
    """Real image-channel QR smoke test through the v1.5.2 automated receiver."""
    if verbose:
        print("===========================================================")
        print(f"  BRAID v{__version__} OPTICAL -> AUTOMATED 384D RECEIVER SMOKE    ")
        print("===========================================================")

    with tempfile.TemporaryDirectory() as tmp_dir:
        sender_key_path = str(Path(tmp_dir) / "node_a_sender.key")
        sk, _, _ = load_or_create_signing_key(sender_key_path)
        vk = sk.public_key()
        vk_hex = get_raw_public_bytes(vk).hex()

        frame_a, raw_bytes_a, _ = generate_frame_object(signing_key=sk)
        if verbose:
            print(" [Node A] Signed 384D frame generated")
            print(f"    - bytes: {len(raw_bytes_a)}")
            print(f"    - digest: {frame_a.object_digest}")

        chunks = chunk_binary_frame(raw_bytes_a, max_chunk_size=120)
        decoded_chunks: list[str] = []
        for idx, chunk in enumerate(chunks):
            qr = StandardQRCodeEncoder(chunk["chunk_str"])
            raster = rasterize_qr_matrix(qr.matrix, module_scale=8, quiet_zone_modules=4)
            decoded = decode_qr_raster(raster)
            assert decoded == chunk["chunk_str"], f"QR raster decode mismatch at chunk {idx}"
            decoded_chunks.append(decoded)

        import random
        collector = OpticalChunkCollector()
        delivery = list(decoded_chunks)
        random.Random(146).shuffle(delivery)
        delivery.extend(decoded_chunks[:2])
        reassembled = None
        for text in delivery:
            result = collector.ingest_chunk_string(text)
            assert result["status"] == "success", result
            if result["is_complete"]:
                reassembled = result["reassembled_bytes"]
        assert reassembled == raw_bytes_a

        validator, registry, ledger = create_authoritative_validator(vk_hex, ledger_path=Path(tmp_dir) / "replay_ledger.db")
        receiver = AutomatedReceiver(
            validator=validator,
            registry=registry,
            ledger=ledger,
            verification_key=vk,
            config=ReceiverAutomationConfig(storage_dir=Path(tmp_dir) / "receiver", auto_commit=True),
        )
        report = receiver.process_bytes(
            reassembled,
            source_transport="optical_qr",
            source_name="smoke.brad",
            peer="camera",
        )
        assert report["accepted"], report
        assert report["phase_b_committed"], report
        assert report["receiver_vector"]["dimension"] == 384
        vector_path = Path(report["vector_path"])
        recovered = np.load(vector_path, allow_pickle=False)
        assert recovered.shape == (384,)
        assert np.allclose(recovered, frame_a.vector, atol=1e-3)
        if verbose:
            print(" [Node B] quarantine -> gates -> Phase B commit -> 384D emit: PASS")
            print(f"    - pipeline: {' -> '.join(report['pipeline'])}")
            print(f"    - latency: {report['latency_ms']:.2f} ms")
            print("===========================================================")
            print(f"  2-NODE v{__version__} SMOKE TEST PASSED                          ")
            print("===========================================================")
    return True


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="braid-client",
        description=f"Braid v{__version__} — signed state transport with exact-space fast path and receiver-local Semantic Capsule re-embedding",
    )
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command")

    gen = sub.add_parser("generate", help="Generate a signed Braid frame (.brad)")
    gen.add_argument("--output", "-o", default="state.brad")
    gen.add_argument("--signing-key", "-s")
    gen.add_argument("--preset", default="llama3_gemma2_soft_prefix")
    gen.add_argument("--noise", type=float, default=0.0)
    gen.add_argument("--capability-ref", default="cap_ref_8f9a2b")
    gen.add_argument("--refund-max", type=float, default=75.0)

    inspect = sub.add_parser("inspect", help="Phase A inspect without committing receiver state")
    inspect.add_argument("file")
    inspect.add_argument("--trusted-key", "-t", required=True)
    inspect.add_argument("--route-package", type=Path)

    accept = sub.add_parser("receive-file", help="Run a .brad file through the automated 384D receiver")
    accept.add_argument("file", type=Path)
    accept.add_argument("--trusted-key", "-t", required=True)
    accept.add_argument("--output-dir", type=Path, default=Path("braid-inbox"))
    accept.add_argument("--no-commit", action="store_true")
    accept.add_argument("--handoff-command")
    accept.add_argument("--audit-log", type=Path)
    accept.add_argument("--route-package", type=Path)
    accept.add_argument("--ollama-model")
    accept.add_argument("--ollama-embed-model", default=DEFAULT_EMBEDDING_MODEL)
    accept.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    accept.add_argument("--ollama-timeout", type=_positive_float, default=180.0)
    accept.add_argument("--ollama-min-alignment", type=float)
    accept.add_argument("--semantic-embed-model", help="Receiver-local embedding model for Semantic Capsule exact/heterogeneous ingestion")
    accept.add_argument("--semantic-completion-model", help="Optional receiver-local completion model to continue from the committed capsule")
    accept.add_argument("--semantic-verify-fast-path", action="store_true", help="Strict mode: recompute same-model capsule embedding before Phase B")
    accept.add_argument("--semantic-min-fast-path-cosine", type=float, default=0.999)

    serve = sub.add_parser("serve", help="Launch the cohesive loopback-only Braid Field UI")
    serve.add_argument("--bind", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8080)
    serve.add_argument("--signing-key", "-s")
    serve.add_argument("--trusted-key", "-t")
    serve.add_argument("--open", action="store_true", help="Open the local visualizer in the default browser")

    demo = sub.add_parser("demo", help="Open the local Braid visualizer and synthetic tinkering environment")
    demo.add_argument("--port", type=int, default=8080)

    receive = sub.add_parser("receive", help="Automated network receiver: LAN or explicit Internet host:port")
    receive.add_argument("--trusted-key", "-t", required=True)
    receive.add_argument("--bind", default="127.0.0.1")
    receive.add_argument("--port", type=int, default=8745)
    receive.add_argument("--output-dir", type=Path, default=Path("braid-inbox"))
    receive.add_argument("--allow-lan", action="store_true")
    receive.add_argument("--allow-public", action="store_true")
    receive.add_argument("--insecure-public", action="store_true")
    receive.add_argument("--tls-cert", type=Path)
    receive.add_argument("--tls-key", type=Path)
    receive.add_argument("--client-ca", type=Path)
    receive.add_argument("--require-client-cert", action="store_true")
    receive.add_argument("--socket-timeout", type=_positive_float, default=10.0)
    receive.add_argument("--max-frame-bytes", type=int, default=2 * 1024 * 1024)
    receive.add_argument("--handoff-command")
    receive.add_argument("--audit-log", type=Path)
    receive.add_argument("--route-package", type=Path)
    receive.add_argument("--ollama-model")
    receive.add_argument("--ollama-embed-model", default=DEFAULT_EMBEDDING_MODEL)
    receive.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    receive.add_argument("--ollama-timeout", type=_positive_float, default=180.0)
    receive.add_argument("--ollama-min-alignment", type=float)
    receive.add_argument("--semantic-embed-model", help="Receiver-local embedding model for Semantic Capsule exact/heterogeneous ingestion")
    receive.add_argument("--semantic-completion-model", help="Optional receiver-local completion model to continue from the committed capsule")
    receive.add_argument("--semantic-verify-fast-path", action="store_true", help="Strict mode: recompute same-model capsule embedding before Phase B and verify cosine coherence")
    receive.add_argument("--semantic-min-fast-path-cosine", type=float, default=0.999)

    send = sub.add_parser("send", help="Send exact signed .brad bytes over LAN or explicit Internet host:port")
    send.add_argument("frame", type=Path)
    send.add_argument("--host", required=True)
    send.add_argument("--port", type=int, default=8745)
    send.add_argument("--timeout", type=_positive_float, default=15.0)
    send.add_argument("--max-frame-bytes", type=int, default=2 * 1024 * 1024)
    send.add_argument("--tls", action="store_true")
    send.add_argument("--ca-file", type=Path)
    send.add_argument("--server-name")
    send.add_argument("--insecure-tls", action="store_true")
    send.add_argument("--allow-plaintext-public", action="store_true")

    adv = sub.add_parser("advertise", help="Broadcast an untrusted LAN discovery hint")
    adv.add_argument("--node-id", required=True)
    adv.add_argument("--transport-port", type=int, default=8745)
    adv.add_argument("--discovery-port", type=int, default=DEFAULT_DISCOVERY_PORT)
    adv.add_argument("--tls", action="store_true")
    adv.add_argument("--broadcast", default="255.255.255.255")
    adv.add_argument("--interval", type=_positive_float, default=2.0)
    adv.add_argument("--once", action="store_true")

    disc = sub.add_parser("discover", help="Listen for untrusted LAN discovery hints")
    disc.add_argument("--discovery-port", type=int, default=DEFAULT_DISCOVERY_PORT)
    disc.add_argument("--timeout", type=_positive_float, default=3.0)
    disc.add_argument("--bind", default="0.0.0.0")

    sense = sub.add_parser("sense", help="Scan for nearby Braid BLE hints and smooth RSSI into relative proximity")
    sense.add_argument("--timeout", type=_positive_float, default=3.0)

    hetero_corpus = sub.add_parser("hetero-corpus", help="Write the deterministic heterogeneous semantic conformance corpus")
    hetero_corpus.add_argument("--output", type=Path, default=Path("hetero_conformance_corpus.jsonl"))
    hetero_corpus.add_argument("--count", type=int, default=768)

    hetero_cal = sub.add_parser("hetero-calibrate", help="Calibrate and held-out-test a source-model -> target-model semantic route using local Ollama embeddings")
    hetero_cal.add_argument("--source-model", required=True)
    hetero_cal.add_argument("--target-model", required=True)
    hetero_cal.add_argument("--output-dir", type=Path, required=True)
    hetero_cal.add_argument("--corpus", type=Path)
    hetero_cal.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    hetero_cal.add_argument("--include-elm", action="store_true")
    hetero_cal.add_argument("--count", type=int, default=768)

    hetero_frame = sub.add_parser("hetero-frame", help="Embed text with the calibrated source model and write a signed Braid frame")
    hetero_frame.add_argument("--route-package", type=Path, required=True)
    text_group = hetero_frame.add_mutually_exclusive_group(required=True)
    text_group.add_argument("--text")
    text_group.add_argument("--text-file", type=Path)
    hetero_frame.add_argument("--output", "-o", type=Path, default=Path("hetero-state.brad"))
    hetero_frame.add_argument("--signing-key", "-s")
    hetero_frame.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    hetero_frame.add_argument("--session-id")

    capsule_frame = sub.add_parser("capsule-frame", help="Create a signed Semantic Capsule frame from explicit text using a source route package")
    capsule_frame.add_argument("--route-package", type=Path, required=True)
    capsule_text = capsule_frame.add_mutually_exclusive_group(required=True)
    capsule_text.add_argument("--text")
    capsule_text.add_argument("--text-file", type=Path)
    capsule_frame.add_argument("--output", "-o", type=Path, default=Path("semantic-capsule.brad"))
    capsule_frame.add_argument("--signing-key", "-s")
    capsule_frame.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    capsule_frame.add_argument("--session-id")

    hetero_info = sub.add_parser("hetero-route-info", help="Verify and print a calibrated heterogeneous route package")
    hetero_info.add_argument("route_package", type=Path)

    ollama_route = sub.add_parser("ollama-route", help="Build a digest-bound same-space 384D route for a local Ollama embedding model")
    ollama_route.add_argument("--embed-model", default=DEFAULT_EMBEDDING_MODEL)
    ollama_route.add_argument("--output-dir", type=Path, required=True)
    ollama_route.add_argument("--corpus", type=Path)
    ollama_route.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    ollama_route.add_argument("--count", type=int, default=768)

    ollama_frame = sub.add_parser("ollama-frame", help="Distill a signed Legend with a local completion model and encode it into a Braid frame")
    ollama_frame.add_argument("--route-package", type=Path, required=True)
    ollama_text = ollama_frame.add_mutually_exclusive_group(required=True)
    ollama_text.add_argument("--text")
    ollama_text.add_argument("--text-file", type=Path)
    ollama_frame.add_argument("--model", default=DEFAULT_COMPLETION_MODEL)
    ollama_frame.add_argument("--output", "-o", type=Path, default=Path("ollama-state.brad"))
    ollama_frame.add_argument("--legend-output", type=Path)
    ollama_frame.add_argument("--signing-key", "-s")
    ollama_frame.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    ollama_frame.add_argument("--session-id")

    ollama_check = sub.add_parser("ollama-doctor", help="Verify loopback Ollama completion and 384D embedding readiness")
    ollama_check.add_argument("--model", default=DEFAULT_COMPLETION_MODEL)
    ollama_check.add_argument("--embed-model", default=DEFAULT_EMBEDDING_MODEL)
    ollama_check.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    ollama_check.add_argument("--timeout", type=_positive_float, default=60.0)

    sub.add_parser("environment", help="Print local machine, LAN, Ollama, camera, and CLI autodetection facts")
    sub.add_parser("doctor", help="Run a fast local readiness check for install/demo use")
    sub.add_parser("smoke-test", help="Run the optical-to-automated-receiver smoke test")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "generate":
            if not math.isfinite(args.noise) or args.noise < 0.0 or args.noise > 1.0:
                raise ValueError("ERR_NOISE_RANGE")
            if not math.isfinite(args.refund_max) or args.refund_max < 0.0:
                raise ValueError("ERR_REFUND_MAX")
            sk, priv_p, pub_p = load_or_create_signing_key(args.signing_key)
            frame, raw_bytes, _ = generate_frame_object(
                preset=args.preset,
                noise_std=args.noise,
                capability_ref=args.capability_ref,
                sender_requested_refund_max=args.refund_max,
                signing_key=sk,
            )
            out = Path(args.output)
            atomic_write(out, raw_bytes, mode=0o600)
            _print_json({
                "status": "generated", "version": __version__, "file": str(out.resolve()),
                "frame_bytes": len(raw_bytes), "object_digest": frame.object_digest,
                "signing_key": priv_p, "verification_key": pub_p,
            })
            return 0

        if args.command == "inspect":
            raw = _read_bounded_file(Path(args.file))
            vk = load_verification_key(args.trusted_key)
            if args.route_package is None:
                validator, _, _ = create_authoritative_validator(get_raw_public_bytes(vk).hex())
            else:
                validator, _, _, _ = create_validator_from_route_package(
                    args.route_package, get_raw_public_bytes(vk).hex(), ":memory:"
                )
            result = validator.validate_frame_phase_a(raw)
            frame = BraidFrame.from_bytes(raw)
            print(f"PHASE A VALIDATED: {result.is_valid}")
            _print_json({
                "status": "phase_a_validated" if result.is_valid else "rejected",
                "accepted": False,
                "finality": "not_committed" if result.is_valid else "rejected",
                "phase": "A_non_locking", "gate": result.gate_name, "message": result.message,
                "object_digest": frame.object_digest, "stats": analyze_vector_stats(frame.vector),
                "manifest": frame.manifest,
            })
            return 0 if result.is_valid else 2

        if args.command == "receive-file":
            receiver = _build_receiver(
                args.trusted_key, args.output_dir, auto_commit=not args.no_commit,
                handoff_command=args.handoff_command, audit_log=args.audit_log,
                route_package=args.route_package,
                ollama_handoff=_ollama_handoff_from_args(args),
                semantic_handoff=_semantic_handoff_from_args(args),
            )
            report = receiver.process_bytes(_read_bounded_file(args.file), source_transport="file", source_name=args.file.name, peer="local")
            _print_json(report)
            return 0 if report.get("accepted") else 2

        if args.command == "serve":
            serve_http_app(args.bind, args.port, args.signing_key, args.trusted_key, open_browser=args.open)
            return 0

        if args.command == "demo":
            serve_http_app("127.0.0.1", args.port, None, None, open_browser=True)
            return 0

        if args.command == "receive":
            receiver = _build_receiver(
                args.trusted_key, args.output_dir, auto_commit=True,
                handoff_command=args.handoff_command, audit_log=args.audit_log,
                route_package=args.route_package,
                ollama_handoff=_ollama_handoff_from_args(args),
                semantic_handoff=_semantic_handoff_from_args(args),
            )
            config = NetworkReceiverConfig(
                bind=args.bind, port=args.port, output_dir=args.output_dir,
                allow_lan=args.allow_lan, allow_public=args.allow_public,
                insecure_public=args.insecure_public, tls_cert=args.tls_cert, tls_key=args.tls_key,
                client_ca=args.client_ca, require_client_cert=args.require_client_cert,
                socket_timeout_seconds=args.socket_timeout, max_frame_bytes=args.max_frame_bytes,
                audit_log=args.audit_log, receiver_callback=receiver.process_bytes,
            )
            server = TransportServer(config).start()
            host, port = server.address
            _print_json({"status": "LISTENING", "bind": host, "port": port, "scope": server.decision.scope.value, "tls": config.tls_enabled, "receiver": "automated_384d"})
            try:
                while True:
                    time.sleep(3600)
            except KeyboardInterrupt:
                server.stop()
                return 130

        if args.command == "send":
            result = send_frame(
                args.frame, args.host, args.port, timeout_seconds=args.timeout,
                max_frame_bytes=args.max_frame_bytes, use_tls=args.tls, ca_file=args.ca_file,
                server_name=args.server_name, insecure_tls=args.insecure_tls,
                allow_plaintext_public=args.allow_plaintext_public,
            )
            _print_json(result.ack.to_dict())
            return 0 if result.ack.accepted else 2

        if args.command == "advertise":
            while True:
                advertise_once(args.node_id, args.transport_port, discovery_port=args.discovery_port, tls=args.tls, broadcast=args.broadcast)
                if args.once:
                    return 0
                time.sleep(args.interval)

        if args.command == "discover":
            _print_json([r.__dict__ for r in discover(args.timeout, discovery_port=args.discovery_port, bind=args.bind)])
            return 0

        if args.command == "sense":
            records = SENSOR_FIELD.scan_ble_sync(args.timeout)
            _print_json({"status": "success", "records": records, "distance_claim": "relative_only", "trust": "untrusted_discovery_hint"})
            return 0

        if args.command == "hetero-corpus":
            info = write_corpus(args.output, build_conformance_corpus(count=args.count))
            _print_json({"status": "written", **info})
            return 0

        if args.command == "hetero-calibrate":
            report = calibrate_ollama_route(
                source_model=args.source_model, target_model=args.target_model,
                output_dir=args.output_dir, corpus_path=args.corpus,
                ollama_url=args.ollama_url, include_elm=args.include_elm, count=args.count,
            )
            _print_json(report)
            return 0 if report.get("promotion", {}).get("passed") else 2

        if args.command == "hetero-frame":
            text = args.text if args.text is not None else args.text_file.read_text(encoding="utf-8")
            sk, priv_p, pub_p = load_or_create_signing_key(args.signing_key)
            frame, raw_bytes, source_vector, package = build_frame_from_text(
                args.route_package, text, sk, ollama_url=args.ollama_url, session_id=args.session_id
            )
            atomic_write(args.output, raw_bytes, mode=0o600)
            _print_json({
                "status": "generated", "version": __version__, "file": str(args.output.resolve()),
                "frame_bytes": len(raw_bytes), "object_digest": frame.object_digest,
                "route_id": package["route"]["route_id"], "source_model": package["source_model"],
                "target_model": package["target_model"], "source_vector_norm": float(np.linalg.norm(source_vector)),
                "semantic_capsule_digest": extract_semantic_capsule(frame.manifest, required=True)[1]["digest"],
                "signing_key": priv_p, "verification_key": pub_p,
            })
            return 0

        if args.command == "capsule-frame":
            text = args.text if args.text is not None else args.text_file.read_text(encoding="utf-8")
            sk, priv_p, pub_p = load_or_create_signing_key(args.signing_key)
            frame, raw_bytes, source_vector, package = build_frame_from_text(
                args.route_package, text, sk, ollama_url=args.ollama_url, session_id=args.session_id
            )
            atomic_write(args.output, raw_bytes, mode=0o600)
            capsule, evidence = extract_semantic_capsule(frame.manifest, required=True)
            _print_json({
                "status": "generated", "version": __version__, "file": str(args.output.resolve()),
                "frame_bytes": len(raw_bytes), "object_digest": frame.object_digest,
                "capsule_digest": evidence["digest"], "capsule_mode": evidence["mode"],
                "source_embedding_model": package["source_model"],
                "source_vector_norm": float(np.linalg.norm(source_vector)),
                "signing_key": priv_p, "verification_key": pub_p,
                "heterogeneous_policy": "receiver_local_reembed_only",
                "bridge_semantic_invention": False,
            })
            return 0

        if args.command == "ollama-route":
            report = calibrate_ollama_route(
                source_model=args.embed_model, target_model=args.embed_model,
                output_dir=args.output_dir, corpus_path=args.corpus,
                ollama_url=args.ollama_url, count=args.count,
            )
            _print_json(report)
            return 0 if report.get("promotion", {}).get("passed") else 2

        if args.command == "ollama-frame":
            text = args.text if args.text is not None else args.text_file.read_text(encoding="utf-8")
            legend = generate_legend(
                text, completion_model=args.model, client=OllamaClient(args.ollama_url)
            )
            sk, priv_p, pub_p = load_or_create_signing_key(args.signing_key)
            frame, raw_bytes, source_vector, package = build_frame_from_legend(
                args.route_package, legend, sk, source_completion_model=args.model,
                ollama_url=args.ollama_url, session_id=args.session_id,
            )
            atomic_write(args.output, raw_bytes, mode=0o600)
            if args.legend_output is not None:
                atomic_write(args.legend_output, json.dumps(legend, sort_keys=True, indent=2, ensure_ascii=False).encode("utf-8"), mode=0o600)
            _print_json({
                "status": "generated", "version": __version__, "file": str(args.output.resolve()),
                "frame_bytes": len(raw_bytes), "object_digest": frame.object_digest,
                "legend_digest": legend_digest(legend), "legend_schema": legend.get("schema"),
                "source_completion_model": args.model, "source_embedding_model": package["source_model"],
                "target_embedding_model": package["target_model"],
                "source_vector_norm": float(np.linalg.norm(source_vector)),
                "signing_key": priv_p, "verification_key": pub_p,
                "semantic_capsule_digest": extract_semantic_capsule(frame.manifest, required=True)[1]["digest"],
                "heterogeneous_policy": "receiver_local_reembed_only",
                "generative_vector_injection": False,
            })
            return 0

        if args.command == "ollama-doctor":
            report = ollama_doctor(
                completion_model=args.model, embedding_model=args.embed_model,
                base_url=args.ollama_url, timeout_seconds=args.timeout,
            )
            _print_json(report)
            return 0 if report.get("ready") else 2

        if args.command == "hetero-route-info":
            package = load_route_package(args.route_package)
            package = {k: v for k, v in package.items() if not k.startswith("_")}
            _print_json(package)
            return 0

        if args.command == "environment":
            from .environment import detect_environment
            _print_json(detect_environment())
            return 0

        if args.command == "doctor":
            report = run_doctor()
            _print_json(report)
            return 0 if report.get("ready") else 2

        if args.command == "smoke-test":
            return 0 if run_2node_smoke_test(verbose=True) else 1

        parser.print_help()
        return 0
    except (OSError, ValueError, RuntimeError, FileNotFoundError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
