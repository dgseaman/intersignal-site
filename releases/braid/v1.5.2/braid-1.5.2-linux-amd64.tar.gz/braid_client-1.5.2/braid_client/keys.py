"""
Persistent Ed25519 Key Management for Braid Client
Enforces 0600 private key file permissions and atomic keypair creation.
"""

import os
import secrets
import stat
from pathlib import Path
from typing import Tuple, Optional
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

DEFAULT_KEY_DIR = Path.home() / ".braid" / "keys"


def get_raw_private_bytes(key: ed25519.Ed25519PrivateKey) -> bytes:
    return key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption()
    )


def get_raw_public_bytes(key: ed25519.Ed25519PublicKey) -> bytes:
    return key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw
    )


def _atomic_write_bytes(path: Path, data: bytes, mode: int) -> None:
    """Write bytes atomically without interpreting raw key material as text."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.{secrets.token_hex(4)}.tmp")
    fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(str(temp), mode)
        os.replace(str(temp), str(path))
        os.chmod(str(path), mode)
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        finally:
            raise


def _write_public_key(key: ed25519.Ed25519PublicKey, path: Path) -> None:
    _atomic_write_bytes(path, get_raw_public_bytes(key), 0o644)


def save_keypair(key: ed25519.Ed25519PrivateKey, priv_path: str, pub_path: Optional[str] = None) -> Tuple[str, str]:
    """Atomically save a 0600 raw private key and 0644 companion public key."""
    priv_p = Path(priv_path)
    if pub_path is None:
        pub_p = priv_p.with_suffix(".pub") if priv_p.suffix else Path(str(priv_p) + ".pub")
    else:
        pub_p = Path(pub_path)

    _atomic_write_bytes(priv_p, get_raw_private_bytes(key), 0o600)
    _write_public_key(key.public_key(), pub_p)
    return str(priv_p), str(pub_p)


def _read_private_key_bytes(path: Path) -> bytes:
    """Read a private key from a regular non-symlink file and enforce 0600 on the opened inode."""
    flags = os.O_RDONLY
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    elif path.is_symlink():
        raise ValueError(f"Refusing symlink private key path: {path}")

    try:
        fd = os.open(str(path), flags)
    except FileNotFoundError:
        raise FileNotFoundError(f"Signing key file not found: {path}") from None
    except OSError as exc:
        raise ValueError(f"Unable to securely open private key file at {path}: {exc}") from exc

    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError(f"Private key path is not a regular file: {path}")
        if info.st_mode & 0o077:
            os.fchmod(fd, 0o600)
            repaired = os.fstat(fd).st_mode & 0o777
            if repaired & 0o077:
                raise PermissionError(f"Unable to enforce 0600 private key permissions at {path}")
        chunks = []
        while True:
            chunk = os.read(fd, 4096)
            if not chunk:
                break
            chunks.append(chunk)
            if sum(map(len, chunks)) > 4096:
                raise ValueError(f"Private key file too large at {path}")
        return b"".join(chunks)
    finally:
        os.close(fd)


def load_signing_key(key_path: str) -> ed25519.Ed25519PrivateKey:
    """Load a raw 32-byte or textual 64-hex-character Ed25519 private key."""
    p = Path(key_path)
    data = _read_private_key_bytes(p)
    if len(data) == 32:
        return ed25519.Ed25519PrivateKey.from_private_bytes(data)
    text = data.strip()
    if len(text) == 64:
        try:
            raw = bytes.fromhex(text.decode("ascii"))
            return ed25519.Ed25519PrivateKey.from_private_bytes(raw)
        except Exception:
            pass
    raise ValueError(f"Invalid private key file format at {key_path} (expected 32 raw bytes or 64 hex chars)")


def load_verification_key(key_path: str) -> ed25519.Ed25519PublicKey:
    """Load a raw 32-byte or textual 64-hex-character Ed25519 public key."""
    p = Path(key_path)
    if not p.exists():
        raise FileNotFoundError(f"Verification key file not found: {key_path}")

    data = p.read_bytes()
    if len(data) == 32:
        return ed25519.Ed25519PublicKey.from_public_bytes(data)
    text = data.strip()
    if len(text) == 64:
        try:
            raw = bytes.fromhex(text.decode("ascii"))
            return ed25519.Ed25519PublicKey.from_public_bytes(raw)
        except Exception:
            pass

    raise ValueError(f"Invalid public key file format at {key_path} (expected 32 raw bytes or 64 hex chars)")


def load_or_create_signing_key(key_path: Optional[str] = None) -> Tuple[ed25519.Ed25519PrivateKey, str, str]:
    """Load or create a persistent key and repair a missing/malformed companion public key."""
    if key_path is not None:
        priv_p = Path(key_path)
        pub_p = priv_p.with_suffix(".pub") if priv_p.suffix else Path(str(priv_p) + ".pub")
    else:
        priv_p = DEFAULT_KEY_DIR / "default_sender.key"
        pub_p = DEFAULT_KEY_DIR / "default_sender.pub"

    if priv_p.exists():
        sk = load_signing_key(str(priv_p))
        expected = get_raw_public_bytes(sk.public_key())
        repair = True
        if pub_p.exists():
            try:
                repair = get_raw_public_bytes(load_verification_key(str(pub_p))) != expected
            except Exception:
                repair = True
        if repair:
            _write_public_key(sk.public_key(), pub_p)
        return sk, str(priv_p), str(pub_p)

    sk = ed25519.Ed25519PrivateKey.generate()
    saved_priv, saved_pub = save_keypair(sk, str(priv_p), str(pub_p))
    return sk, saved_priv, saved_pub
