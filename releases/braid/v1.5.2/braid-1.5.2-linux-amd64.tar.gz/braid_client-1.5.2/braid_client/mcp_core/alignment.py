import numpy as np
import hashlib
from typing import List, Dict, Any, Tuple, Optional
from types import MappingProxyType
from braid_client.mcp_core.canonical import jcs_serialize

class ImmutableArtifact:
    """Base class providing immutability protection for Braid registry configurations."""
    _frozen = False
    
    def _freeze(self):
        self._frozen = True

    def __setattr__(self, key, value):
        if self._frozen:
            raise TypeError("Braid Registry Error: Attempted to mutate an immutable registry artifact.")
        super().__setattr__(key, value)

    def __delattr__(self, item):
        if self._frozen:
            raise TypeError("Braid Registry Error: Attempted to delete from an immutable registry artifact.")
        super().__delattr__(item)


class RepresentationSpace(ImmutableArtifact):
    """
    Formally defines a high-dimensional activation space for a model.
    A 384D shape match alone does not imply coordinate compatibility.
    """
    def __init__(
        self,
        model_revision: str,
        layer: str,
        pooling: str,
        dimension: int = 384,
        dtype: str = "float32",
        normalization: str = "unit",
        adapter_id: str = "none",
        adapter_digest: str = "none",
        tokenizer_hash: str = "none",
        semantic_label: str = "none"
    ):
        self.model_revision = model_revision
        self.layer = layer
        self.pooling = pooling
        self.dimension = dimension
        self.dtype = dtype
        self.normalization = normalization
        self.adapter_id = adapter_id
        self.adapter_digest = adapter_digest
        self.tokenizer_hash = tokenizer_hash
        self.semantic_label = semantic_label
        
        # Self-validation at construction (P1-3)
        if self.dimension <= 0 or self.dtype != "float32" or self.normalization not in ["unit", "none"]:
            raise ValueError("Braid Space Error: Invalid dimension, dtype, or normalization policy.")
            
        self._freeze()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_revision": self.model_revision,
            "layer": self.layer,
            "pooling": self.pooling,
            "dimension": self.dimension,
            "dtype": self.dtype,
            "normalization": self.normalization,
            "adapter_id": self.adapter_id,
            "adapter_digest": self.adapter_digest,
            "tokenizer_hash": self.tokenizer_hash,
            "semantic_label": self.semantic_label
        }

    def matches(self, other: 'RepresentationSpace') -> bool:
        return (
            self.model_revision == other.model_revision and
            self.layer == other.layer and
            self.pooling == other.pooling and
            self.dimension == other.dimension and
            self.dtype == other.dtype and
            self.normalization == other.normalization and
            self.adapter_id == other.adapter_id and
            self.adapter_digest == other.adapter_digest and
            self.tokenizer_hash == other.tokenizer_hash and
            self.semantic_label == other.semantic_label
        )

    def compute_digest(self) -> str:
        """Computes a SHA-256 digest over the canonical JCS representation."""
        canonical = jcs_serialize(self.to_dict())
        return hashlib.sha256(canonical).hexdigest()

    @classmethod
    def from_strict_dict(cls, data: Dict[str, Any]) -> 'RepresentationSpace':
        """Parses and validates a dictionary into a strict, complete RepresentationSpace object."""
        # Enforce all required fields to prevent defaults-by-omission bypasses (P0-4)
        required = [
            "model_revision", "layer", "pooling", "dimension", "dtype", 
            "normalization", "adapter_id", "adapter_digest", "tokenizer_hash", "semantic_label"
        ]
        for r in required:
            if r not in data:
                raise KeyError(f"Missing required field in representation descriptor: {r}")
        
        # additionalProperties: false check
        for k in data.keys():
            if k not in required:
                raise KeyError(f"Unknown property in representation descriptor: {k}")

        return cls(
            model_revision=data["model_revision"],
            layer=data["layer"],
            pooling=data["pooling"],
            dimension=data["dimension"],
            dtype=data["dtype"],
            normalization=data["normalization"],
            adapter_id=data["adapter_id"],
            adapter_digest=data["adapter_digest"],
            tokenizer_hash=data["tokenizer_hash"],
            semantic_label=data["semantic_label"]
        )


class TransportMap(ImmutableArtifact):
    """
    An immutable, verified representation transport map (Φ) translating coordinates 
    between independent source and target spaces while minimizing Feature Discrepancy (Δ).
    Supports Procrustes, Ridge Regression, and Non-linear Extreme Learning Machine (ELM) mappings.
    """
    def __init__(
        self,
        algorithm: str,
        rotation_matrix: np.ndarray,      # or linear projection matrix W
        translation_vector: np.ndarray,   # or bias b
        source_space_digest: str,
        target_space_digest: str,
        normalization_policy: str = "unit",
        map_digest: str = "none",
        elm_W_in: Optional[np.ndarray] = None, # For non-linear mapping
        elm_b_in: Optional[np.ndarray] = None
    ):
        if algorithm not in ["procrustes", "ridge-linear", "nonlinear-elm"]:
            raise ValueError(f"Braid Map Error: Unknown algorithm '{algorithm}'.")
        if normalization_policy not in ["unit", "none"]:
            raise ValueError(f"Braid Map Error: Unknown normalization policy '{normalization_policy}'.")

        # Defensive deep copy and freeze of NumPy arrays (P1 deep immutability)
        self.algorithm = algorithm
        self.R = np.array(rotation_matrix, dtype=np.float64, copy=True)
        self.R.setflags(write=False)
        self.t = np.array(translation_vector, dtype=np.float64, copy=True)
        self.t.setflags(write=False)
        
        self.source_space_digest = source_space_digest
        self.target_space_digest = target_space_digest
        self.normalization_policy = normalization_policy
        self.map_digest = map_digest
        
        # Reject missing, none, or empty digests in creation
        if not self.source_space_digest or self.source_space_digest in ["none", "placeholder", ""]:
            raise ValueError("Braid Map Error: Missing or invalid source space digest.")
        if not self.target_space_digest or self.target_space_digest in ["none", "placeholder", ""]:
            raise ValueError("Braid Map Error: Missing or invalid target space digest.")
        
        # Non-linear model weights
        self.elm_W_in = np.array(elm_W_in, dtype=np.float64, copy=True) if elm_W_in is not None else None
        if self.elm_W_in is not None:
            self.elm_W_in.setflags(write=False)
        self.elm_b_in = np.array(elm_b_in, dtype=np.float64, copy=True) if elm_b_in is not None else None
        if self.elm_b_in is not None:
            self.elm_b_in.setflags(write=False)
            
        # Validate dimensions and coefficients are finite
        if not np.isfinite(self.R).all() or not np.isfinite(self.t).all():
            raise ValueError("Braid Map Error: Map matrices contain non-finite coefficients.")
        if self.R.ndim != 2 or self.t.ndim != 1 or self.R.shape[1] != len(self.t):
            raise ValueError("Braid Map Error: Inconsistent matrix/vector shapes.")
            
        # Reject incomplete ELM parameters
        if self.algorithm == "nonlinear-elm" and (self.elm_W_in is None or self.elm_b_in is None):
            raise ValueError("Braid Map Error: Missing input weight or bias matrices for non-linear ELM model.")
        
        # Auto-compute digest if none is provided
        if self.map_digest == "none" or not self.map_digest:
            self.map_digest = self.compute_digest()
            
        self._freeze()

    def compute_digest(self) -> str:
        """
        Computes a SHA-256 digest over the JCS serialization of all active weights and metadata parameters.
        Included ELM weights and biases in the non-linear digest to seal the entire parameter architecture.
        """
        R_list = self.R.tolist()
        t_list = self.t.tolist()
        
        meta = {
            "R": R_list,
            "t": t_list,
            "algorithm": self.algorithm,
            "normalization_policy": self.normalization_policy,
            "source_space_digest": self.source_space_digest,
            "target_space_digest": self.target_space_digest,
        }
        
        if self.algorithm == "nonlinear-elm" and self.elm_W_in is not None:
            meta["elm_W_in"] = self.elm_W_in.tolist()
            meta["elm_b_in"] = self.elm_b_in.tolist()
            
        canonical = jcs_serialize(meta)
        return hashlib.sha256(canonical).hexdigest()

    def apply(self, vector: np.ndarray) -> np.ndarray:
        """
        Executes the real coordinate transformation Φ and enforces the declared normalization policy.
        Recomputes and verifies the digest immediately before execution to ensure parameters are unaltered.
        """
        # 1. Verification of weight integrity immediately prior to execution
        current_digest = self.compute_digest()
        if current_digest != self.map_digest:
            raise SecurityError("Braid Security Alert: Transport map weights have been mutated! Execution blocked.")
            
        # Reject none, empty, and placeholder digests
        if not self.map_digest or self.map_digest in ["none", "placeholder", ""]:
            raise ValueError("Braid Registry Error: Unknown or placeholder map digest. Execution blocked.")

        vec = np.array(vector, dtype=np.float64)
        if not np.isfinite(vec).all():
            raise ValueError("Braid Map Execution Error: Input vector contains non-finite coefficients.")

        if self.algorithm == "nonlinear-elm" and self.elm_W_in is not None and self.elm_b_in is not None:
            # 1. Non-linear mapping: H = max(0, x * W_in + b_in)
            hidden = vec @ self.elm_W_in + self.elm_b_in
            hidden = np.maximum(0, hidden) # ReLU non-linearity
            # 2. Output projection: y = H * W_out + bias
            transformed = hidden @ self.R + self.t
        else:
            # Linear or Procrustes: y = x * R + t
            transformed = vec @ self.R + self.t
            
        # Respect the declared normalization policy strictly
        if self.normalization_policy == "unit":
            norm = np.linalg.norm(transformed)
            if norm <= 1e-15:
                raise ValueError("Braid Map Execution Error: Zero-norm vector resulting from map projection.")
            transformed = transformed / norm
        return transformed

    @classmethod
    def fit_procrustes(cls, X: np.ndarray, Y: np.ndarray, source_digest: str, target_digest: str, norm_policy: str = "unit") -> 'TransportMap':
        """Fits an optimal rigid orthogonal Procrustes mapping."""
        mu_x = np.mean(X, axis=0)
        mu_y = np.mean(Y, axis=0)
        X_c = X - mu_x
        Y_c = Y - mu_y
        
        H = X_c.T @ Y_c
        U, S, Vt = np.linalg.svd(H, full_matrices=False)
        R = U @ Vt
        if np.linalg.det(R) < 0:
            Vt[-1, :] *= -1
            R = U @ Vt
        t = mu_y - mu_x @ R
        return cls("procrustes", R, t, source_digest, target_digest, norm_policy)

    @classmethod
    def fit_ridge(cls, X: np.ndarray, Y: np.ndarray, source_digest: str, target_digest: str, alpha: float = 1.0, norm_policy: str = "unit") -> 'TransportMap':
        """Fits an optimal linear mapping using Ridge Regression (L2 regularization). Uses stable linear solve."""
        mu_x = np.mean(X, axis=0)
        mu_y = np.mean(Y, axis=0)
        X_c = X - mu_x
        Y_c = Y - mu_y
        
        dim = X_c.shape[1]
        I = np.identity(dim)
        # Use np.linalg.solve for stable linear system resolution rather than explicit inversion
        A = X_c.T @ X_c + alpha * I
        B = X_c.T @ Y_c
        W = np.linalg.solve(A, B)
        b = mu_y - mu_x @ W
        return cls("ridge-linear", W, b, source_digest, target_digest, norm_policy)

    @classmethod
    def fit_nonlinear_elm(
        cls, 
        X: np.ndarray, 
        Y: np.ndarray, 
        source_digest: str,
        target_digest: str,
        hidden_dim: int = 128, 
        alpha: float = 1.0, 
        norm_policy: str = "unit",
        seed: int = 42
    ) -> 'TransportMap':
        """Fits an optimal non-linear single-hidden-layer network (Extreme Learning Machine) using stable linear solve."""
        rng = np.random.default_rng(seed)
        dim = X.shape[1]
        
        # Fixed, random input weights and biases
        W_in = rng.normal(size=(dim, hidden_dim))
        b_in = rng.normal(size=(hidden_dim,)) * 0.1
        
        # Map input to hidden activations: H = max(0, X * W_in + b_in)
        H = X @ W_in + b_in
        H = np.maximum(0, H) # ReLU
        
        # Center the hidden representation
        mu_h = np.mean(H, axis=0)
        mu_y = np.mean(Y, axis=0)
        H_c = H - mu_h
        Y_c = Y - mu_y
        
        # Solve for output weights using stable linear system resolution
        A = H_c.T @ H_c + alpha * np.identity(hidden_dim)
        B = H_c.T @ Y_c
        W_out = np.linalg.solve(A, B)
        b_out = mu_y - mu_h @ W_out
        
        return cls("nonlinear-elm", W_out, b_out, source_digest, target_digest, norm_policy, elm_W_in=W_in, elm_b_in=b_in)


class SecurityError(Exception):
    """Exception raised when cryptographic parameter modification is detected."""
    pass


def evaluate_transport_discrepancy(
    source_test_points: np.ndarray,
    target_test_points: np.ndarray,
    transport_map: TransportMap
) -> Tuple[float, float, float, np.ndarray]:
    """
    Evaluates alignment performance over independent, held-out test points.
    Returns: Tuple[mean_baseline_discrepancy, mean_translated_discrepancy, p95_discrepancy, discrepancy_list]
    """
    baseline_discrepancies = []
    translated_discrepancies = []

    for src_pt, tgt_pt in zip(source_test_points, target_test_points):
        base_discrepancy = np.linalg.norm(src_pt - tgt_pt)
        baseline_discrepancies.append(base_discrepancy)

        translated_pt = transport_map.apply(src_pt)
        trans_discrepancy = np.linalg.norm(translated_pt - tgt_pt)
        translated_discrepancies.append(trans_discrepancy)

    baseline_arr = np.array(baseline_discrepancies)
    translated_arr = np.array(translated_discrepancies)

    mean_base = float(np.mean(baseline_arr))
    mean_trans = float(np.mean(translated_arr))
    p95_trans = float(np.percentile(translated_arr, 95))

    return mean_base, mean_trans, p95_trans, translated_arr
