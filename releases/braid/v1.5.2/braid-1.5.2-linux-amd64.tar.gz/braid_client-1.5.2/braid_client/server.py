"""
Hardened HTTP Server & Authoritative API Engine for Braid Client
----------------------------------------------------------------
Serves the web visualizer UI and API endpoints locally on 127.0.0.1 by default.
Enforces request body limits, path traversal protection, security headers, and
integrates the authoritative BraidValidator & TrustedRegistry pipeline.
"""

import os
import ipaddress
import json
import importlib.util
import base64
import binascii
import time
import uuid
import struct
import numpy as np
import http.server
import socketserver
import threading
import webbrowser
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from typing import Dict, Any, Tuple, Optional, List
from cryptography.hazmat.primitives.asymmetric import ed25519

from . import __version__
from .mcp_core.protocol import BraidFrame, ReplayLedger
from .mcp_core.canonical import (
    jcs_serialize, jcs_loads, serialize_fp16_payload, deserialize_fp16_payload,
    compute_object_digest, compute_payload_digest
)
from .mcp_core.validation import BraidValidator, compute_regularized_mahalanobis_ood
from .mcp_core.registry import (
    TrustedRegistry, RouteContract, AuthorizedSigner, TransportMap, FeatureSpec,
    PCAModel, CovarianceModel, RepresentationSpace
)
from .keys import load_or_create_signing_key, load_verification_key, get_raw_public_bytes
from .receiver import AutomatedReceiver, ReceiverAutomationConfig
from .sensing import SENSOR_FIELD
from .transport.policy import BindScope, classify_bind_scope
from .qr_engine import (
    chunk_binary_frame, OpticalChunkCollector, StandardQRCodeEncoder, QRCapacityError,
    decode_qr_raster
)
from .environment import detect_environment, default_workspace

BASE_DIR = Path(__file__).resolve().parent
STATIC_HTML_PATH = BASE_DIR / "static" / "braid_visualizer.html"
STATIC_CAMERA_PATH = BASE_DIR / "static" / "camera_receiver.js"

# Bounded Multi-Frame Optical Chunk Collector instance
CHUNK_COLLECTOR = OpticalChunkCollector(max_aggregate_bytes=102400, session_ttl_seconds=300)


def get_default_route_contract() -> RouteContract:
    src_space = RepresentationSpace(model_revision="1.0", layer="16", pooling="query", dimension=384)
    tgt_space = RepresentationSpace(model_revision="1.0", layer="12", pooling="query", dimension=384)
    src_digest = src_space.compute_digest()
    tgt_digest = tgt_space.compute_digest()

    t_map = TransportMap(
        algorithm="procrustes",
        rotation_matrix=np.identity(384, dtype=np.float64),
        translation_vector=np.zeros(384, dtype=np.float64),
        source_space_digest=src_digest,
        target_space_digest=tgt_digest
    )
    map_digest = t_map.compute_digest()

    probe_vec = [0.0] * 384
    probe_vec[0] = 1.0
    f_spec = FeatureSpec(
        feature_spec_id="spec_identity",
        target_space_digest=tgt_digest,
        probes={"sec_probe_1": probe_vec},
        weights={"sec_probe_1": 1.0},
        aggregate_threshold=0.30,
        per_probe_thresholds={"sec_probe_1": 0.35}
    )
    spec_digest = f_spec.compute_spec_digest()

    return RouteContract(
        route_id="route_llama3_gemma2_sec_high",
        sender_node_id="node:intersignal:atlas-a",
        receiver_node_id="node:intersignal:atlas-b",
        signer_key_id="ed25519:atlas-a:2026-01",
        source_space_id="space_llama3",
        target_space_id="space_gemma2",
        transport_map_id="map_identity",
        feature_spec_id="spec_identity",
        source_space_digest=src_digest,
        target_space_digest=tgt_digest,
        source_extraction_adapter_digest="c"*64,
        source_expansion_adapter_digest="c"*64,
        target_extraction_adapter_digest="d"*64,
        target_expansion_adapter_digest="d"*64,
        transport_map_digest=map_digest,
        feature_spec_digest=spec_digest,
        canonical_space_spec_digest="1"*64,
        quantization_spec_digest="2"*64,
        subspace_residual_ceiling=0.85,
        mahalanobis_ood_ceiling=12.0,
        max_ttl_s=3600,
        max_clock_skew_s=60,
        max_age_s=1800
    )


def get_default_route_objects() -> Tuple[RouteContract, RepresentationSpace, RepresentationSpace, TransportMap, FeatureSpec]:
    src_space = RepresentationSpace(model_revision="1.0", layer="16", pooling="query", dimension=384)
    tgt_space = RepresentationSpace(model_revision="1.0", layer="12", pooling="query", dimension=384)
    src_digest = src_space.compute_digest()
    tgt_digest = tgt_space.compute_digest()

    t_map = TransportMap(
        algorithm="procrustes",
        rotation_matrix=np.identity(384, dtype=np.float64),
        translation_vector=np.zeros(384, dtype=np.float64),
        source_space_digest=src_digest,
        target_space_digest=tgt_digest
    )
    map_digest = t_map.compute_digest()

    probe_vec = [0.0] * 384
    probe_vec[0] = 1.0
    f_spec = FeatureSpec(
        feature_spec_id="spec_identity",
        target_space_digest=tgt_digest,
        probes={"sec_probe_1": probe_vec},
        weights={"sec_probe_1": 1.0},
        aggregate_threshold=0.30,
        per_probe_thresholds={"sec_probe_1": 0.35}
    )
    spec_digest = f_spec.compute_spec_digest()

    route = RouteContract(
        route_id="route_llama3_gemma2_sec_high",
        sender_node_id="node:intersignal:atlas-a",
        receiver_node_id="node:intersignal:atlas-b",
        signer_key_id="ed25519:atlas-a:2026-01",
        source_space_id="space_llama3",
        target_space_id="space_gemma2",
        transport_map_id="map_identity",
        feature_spec_id="spec_identity",
        source_space_digest=src_digest,
        target_space_digest=tgt_digest,
        source_extraction_adapter_digest="c"*64,
        source_expansion_adapter_digest="c"*64,
        target_extraction_adapter_digest="d"*64,
        target_expansion_adapter_digest="d"*64,
        transport_map_digest=map_digest,
        feature_spec_digest=spec_digest,
        canonical_space_spec_digest="1"*64,
        quantization_spec_digest="2"*64,
        subspace_residual_ceiling=0.85,
        mahalanobis_ood_ceiling=12.0,
        max_ttl_s=3600,
        max_clock_skew_s=60,
        max_age_s=1800
    )
    return route, src_space, tgt_space, t_map, f_spec


def _demo_route_reference_vector() -> np.ndarray:
    """Deterministic prototype centroid for bundled demo OOD artifacts."""
    d = 384
    t = np.linspace(0, 4 * np.pi, d)
    vec = np.sin(t) * np.cos(2 * t) + 0.5 * np.exp(-((np.arange(d) - 192) ** 2) / 2000.0)
    return (vec / np.linalg.norm(vec)).astype(np.float64)


def create_authoritative_validator(vk_hex: str, ledger_path: str | Path | None = None) -> Tuple[BraidValidator, TrustedRegistry, ReplayLedger]:
    """Sets up the authoritative Braid TrustedRegistry, ReplayLedger, and BraidValidator."""
    registry = TrustedRegistry()

    signer = AuthorizedSigner("ed25519:atlas-a:2026-01", vk_hex, authorized_route_ids=["route_llama3_gemma2_sec_high"])
    registry.register_signer(signer)

    route, src_space, tgt_space, t_map, f_spec = get_default_route_objects()

    registry.register_source_space("space_llama3", src_space)
    registry.register_target_space("space_gemma2", tgt_space)
    registry.register_transport_map("map_identity", t_map)
    registry.register_feature_spec("spec_identity", f_spec)
    registry.register_route(route)

    d = 384
    t = np.linspace(0, 4 * np.pi, d)
    demo_centroid = _demo_route_reference_vector()
    tangent = np.sin(t)
    tangent = tangent - demo_centroid * float(tangent @ demo_centroid)
    tangent = tangent / np.linalg.norm(tangent)
    pca = PCAModel(
        principal_components=tangent.reshape(1, d),
        mean_vector=demo_centroid
    )
    registry._pca_models["route_llama3_gemma2_sec_high"] = pca

    std_profile = 0.045 + 0.015 * (1.0 + np.sin(np.linspace(0, 6 * np.pi, d))) / 2.0
    cov = CovarianceModel(
        covariance_matrix=np.diag(std_profile ** 2),
        mean_vector=demo_centroid
    )
    registry._cov_models["route_llama3_gemma2_sec_high"] = cov

    registry.set_local_policy("route_llama3_gemma2_sec_high", {
        "refund_max": 50.0,
        "capability_ref": "cap_ref_8f9a2b"
    })

    registry.freeze_registry()

    ledger = ReplayLedger(db_path=str(ledger_path or "/tmp/braid_replay_ledger.db"))
    validator = BraidValidator(registry=registry, ledger=ledger, local_node_id="node:intersignal:atlas-b")
    return validator, registry, ledger


def evaluate_normative_receiver_gates(
    frame: BraidFrame,
    trusted_vk: Optional[ed25519.Ed25519PublicKey] = None,
    validator: Optional[BraidValidator] = None,
    registry: Optional[TrustedRegistry] = None,
) -> Dict[str, Any]:
    """Return truthful, independent per-gate evidence plus Phase A status."""
    if trusted_vk is None:
        if getattr(frame, "signer_private_key", None) is not None:
            trusted_vk = frame.signer_private_key.public_key()
        else:
            raise ValueError("ERR_TRUST_KEY_REQUIRED: A trusted Ed25519 public key is required.")

    if validator is None or registry is None:
        vk_hex = get_raw_public_bytes(trusted_vk).hex()
        validator, registry, _ = create_authoritative_validator(vk_hex)

    raw_bytes = frame.to_bytes()
    phase_a = validator.validate_frame_phase_a(raw_bytes)
    manifest = frame.manifest

    # Gate 1: direct trusted-key signature verification and payload digest binding.
    signature_ok = False
    payload_digest_ok = False
    gate1_message = ""
    try:
        trusted_vk.verify(frame.signature_bytes, frame.signature_preimage)
        signature_ok = True
        computed_payload = compute_payload_digest(frame.raw_payload)
        payload_digest_ok = manifest.get("payload_digest") == computed_payload
        if not payload_digest_ok:
            gate1_message = "ERR_PAYLOAD_DIGEST: Signed manifest does not bind the received payload."
        else:
            gate1_message = "Ed25519 signature and SHA-256 payload binding verified."
    except Exception as exc:
        gate1_message = f"ERR_BAD_SIGNATURE: Ed25519 verification failed: {exc}"
    gate1_passed = signature_ok and payload_digest_ok

    # Gate 2: representation evidence independent of aggregate validator outcome.
    arr = np.asarray(frame.vector, dtype=np.float64)
    finite = bool(np.isfinite(arr).all())
    vector_length_ok = bool(arr.ndim == 1 and arr.size == 384 and manifest.get("vector_length") == 384)
    encoding_ok = manifest.get("vector_encoding") == "ieee754-binary16-le"
    norm = float(np.linalg.norm(arr)) if finite else float("nan")
    norm_valid = bool(finite and 0.99 <= norm <= 1.01)
    gate2_passed = vector_length_ok and encoding_ok and norm_valid
    gate2_message = (
        "384D finite IEEE-754 binary16 vector with unit norm verified."
        if gate2_passed
        else "ERR_REPRESENTATION: Expected finite 384D binary16 vector with L2 norm in [0.99, 1.01]."
    )

    # Gate 3: actual receiver-local artifact calculations, never constants.
    route_id = manifest.get("route_id")
    route = registry.get_route(route_id) if registry else None
    residual = None
    mahalanobis = None
    residual_ceiling = getattr(route, "subspace_residual_ceiling", None)
    mahalanobis_ceiling = getattr(route, "mahalanobis_ood_ceiling", None)
    gate3_passed = False
    gate3_message = "ERR_OOD_ARTIFACTS: Receiver anomaly artifacts unavailable."
    artifact_mode = "demo"
    if route is not None and finite and vector_length_ok:
        transport_map = registry.get_transport_map(route.transport_map_id)
        mapped = transport_map.apply(arr)
        pca_model = registry.get_pca_model(route.route_id)
        cov_model = registry.get_covariance_model(route.route_id)
        if pca_model is not None and cov_model is not None:
            residual = float(pca_model.compute_reconstruction_residual(mapped))
            mahalanobis = float(compute_regularized_mahalanobis_ood(
                mapped, cov_model.mean_vector, cov_model.covariance_matrix
            ))
            gate3_passed = bool(
                residual <= residual_ceiling and mahalanobis <= mahalanobis_ceiling
            )
            gate3_message = (
                "Receiver-local demo subspace and covariance checks passed."
                if gate3_passed
                else "ERR_OOD: Receiver-local subspace or Mahalanobis ceiling exceeded."
            )

    effective_authority = {}
    if phase_a.diagnostic_payload:
        effective_authority = phase_a.diagnostic_payload.get("effective_authority", {})
    if not effective_authority:
        requested = manifest.get("requested_constraints", {})
        requested_refund = float(requested.get("refund_max", 75.0))
        effective_authority = {"refund_max": min(requested_refund, 50.0)}

    overall = bool(phase_a.is_valid and gate1_passed and gate2_passed and gate3_passed)
    return {
        "overall_accepted": overall,
        "validation_phase": "phase_a_non_locking",
        "phase_a": {
            "passed": bool(phase_a.is_valid),
            "gate_name": phase_a.gate_name,
            "message": phase_a.message,
            "replay_safe_commit": False,
        },
        "gate_name": phase_a.gate_name,
        "message": phase_a.message,
        "rejection_reason": "" if overall else (
            phase_a.message if not phase_a.is_valid else
            gate1_message if not gate1_passed else
            gate2_message if not gate2_passed else
            gate3_message
        ),
        "gate1_signature": {
            "passed": gate1_passed,
            "signature_verified": signature_ok,
            "payload_digest_verified": payload_digest_ok,
            "message": gate1_message,
        },
        "gate2_representation": {
            "passed": gate2_passed,
            "dimension": int(arr.size),
            "finite": finite,
            "encoding": manifest.get("vector_encoding"),
            "l2_norm": norm,
            "norm_floor": 0.99,
            "norm_ceiling": 1.01,
            "message": gate2_message,
        },
        "gate3_anomaly": {
            "passed": gate3_passed,
            "subspace_residual": residual,
            "subspace_ceiling": residual_ceiling,
            "mahalanobis_dist": mahalanobis,
            "mahalanobis_ceiling": mahalanobis_ceiling,
            "artifact_mode": artifact_mode,
            "message": gate3_message,
        },
        "effective_authority": effective_authority,
    }


def analyze_vector_stats(vector: List[float]) -> Dict[str, Any]:
    """Computes high-dimensional statistical properties for a 384D vector."""
    arr = np.array(vector, dtype=np.float32)
    norm = float(np.linalg.norm(arr))
    mean = float(np.mean(arr))
    std = float(np.std(arr))
    min_val = float(np.min(arr))
    max_val = float(np.max(arr))
    skewness = float(np.mean(((arr - mean) / (std + 1e-9)) ** 3))

    abs_arr = np.abs(arr)
    p = abs_arr / (np.sum(abs_arr) + 1e-9)
    p_nonzero = p[p > 1e-9]
    entropy = float(-np.sum(p_nonzero * np.log2(p_nonzero)))
    sparsity = float(np.mean(abs_arr < 0.01))

    return {
        "dimension": len(vector),
        "l2_norm": norm,
        "norm_valid": bool(abs(norm - 1.0) <= 0.01),
        "mean": mean,
        "std_dev": std,
        "min_val": min_val,
        "max_val": max_val,
        "skewness": skewness,
        "shannon_entropy": entropy,
        "sparsity_ratio": sparsity
    }


def get_default_route_digests():
    route, src_space, tgt_space, t_map, f_spec = get_default_route_objects()
    return {
        "source_space_digest": route.source_space_digest,
        "target_space_digest": route.target_space_digest,
        "transport_map_digest": route.transport_map_digest,
        "feature_spec_digest": route.feature_spec_digest,
        "route_contract_digest": route.route_contract_digest
    }


def create_sample_manifest(
    session_id: Optional[str] = None,
    capability_ref: str = "cap_ref_8f9a2b",
    sender_requested_refund_max: float = 75.0,
    sequence_num: int = 1,
    predecessor_object_digest: Optional[str] = None
) -> Dict[str, Any]:
    now = int(time.time())
    if session_id is None:
        session_id = str(uuid.uuid4())
    if predecessor_object_digest is None:
        predecessor_object_digest = "0" * 64

    digests = get_default_route_digests()

    manifest = {
        "protocol_version": "1.4",
        "message_type": "state_handoff",
        "signature_algorithm": "Ed25519",
        "digest_algorithm": "SHA-256",
        "sender_node_id": "node:intersignal:atlas-a",
        "receiver_node_id": "node:intersignal:atlas-b",
        "signer_key_id": "ed25519:atlas-a:2026-01",
        "route_id": "route_llama3_gemma2_sec_high",
        "session_id": session_id,
        "sequence_num": sequence_num,
        "issued_at": now,
        "expires_at": now + 300,
        "predecessor_object_digest": predecessor_object_digest,
        "vector_encoding": "ieee754-binary16-le",
        "vector_length": 384,
        "payload_digest": "0" * 64,  # Auto-calculated on frame creation
        "source_space_digest": digests["source_space_digest"],
        "target_space_digest": digests["target_space_digest"],
        "source_extraction_adapter_digest": "c" * 64,
        "source_expansion_adapter_digest": "c" * 64,
        "target_extraction_adapter_digest": "d" * 64,
        "target_expansion_adapter_digest": "d" * 64,
        "transport_map_digest": digests["transport_map_digest"],
        "feature_spec_digest": digests["feature_spec_digest"],
        "canonical_space_spec_digest": "1" * 64,
        "quantization_spec_digest": "2" * 64,
        "route_contract_digest": digests["route_contract_digest"],
        "subject_ref": None,
        "capability_ref": capability_ref,
        "requested_constraints": {
            "refund_max": float(sender_requested_refund_max)
        },
        "extensions": {}
    }
    return manifest


def generate_sample_vector(preset: str = "llama3_gemma2_soft_prefix", noise_std: float = 0.0) -> np.ndarray:
    np.random.seed(42 if noise_std == 0.0 else int(time.time() * 1000) % 100000)
    d = 384
    if preset == "llama3_gemma2_soft_prefix":
        t = np.linspace(0, 4 * np.pi, d)
        vec = np.sin(t) * np.cos(2 * t) + 0.5 * np.exp(-((np.arange(d) - 192) ** 2) / 2000.0)
    elif preset == "task_context_session":
        vec = np.sin(np.arange(d) * 0.1) + np.cos(np.arange(d) * 0.3)
    elif preset == "security_constrained_policy":
        vec = np.ones(d)
        vec[::2] = -1.0
    else:
        vec = np.random.randn(d)

    if noise_std > 0.0:
        vec += np.random.normal(0.0, noise_std, size=d)

    norm = np.linalg.norm(vec)
    if norm > 0:
        vec = vec / norm
    return vec.astype(np.float32)


def generate_frame_object(
    preset: str = "llama3_gemma2_soft_prefix",
    noise_std: float = 0.0,
    capability_ref: str = "cap_ref_8f9a2b",
    sender_requested_refund_max: float = 75.0,
    sender_requested_max_action: Optional[str] = None,
    signing_key: Optional[ed25519.Ed25519PrivateKey] = None,
    key_path: Optional[str] = None
) -> Tuple[BraidFrame, bytes, ed25519.Ed25519PrivateKey]:
    if sender_requested_max_action is not None:
        import re
        m = re.search(r'(\d+(?:\.\d+)?)', str(sender_requested_max_action))
        if m:
            sender_requested_refund_max = float(m.group(1))

    if signing_key is None:
        signing_key, _, _ = load_or_create_signing_key(key_path)

    manifest = create_sample_manifest(
        capability_ref=capability_ref,
        sender_requested_refund_max=sender_requested_refund_max
    )
    vec = generate_sample_vector(preset=preset, noise_std=noise_std)
    frame = BraidFrame(manifest, vec, signer_private_key=signing_key)
    return frame, frame.to_bytes(), signing_key


class HardenedBraidHTTPHandler(http.server.BaseHTTPRequestHandler):
    """
    Hardened HTTP Request Handler.
    Serves visualizer HTML and explicit API endpoints.
    Strictly prevents path traversal and fallback file exposure.
    """
    server_version = f"BraidClient/{__version__}"
    signing_key: ed25519.Ed25519PrivateKey = None
    verification_key: ed25519.Ed25519PublicKey = None
    validator: BraidValidator = None
    registry: TrustedRegistry = None
    ledger: ReplayLedger = None
    receiver_automation: AutomatedReceiver = None
    last_receiver_report: Dict[str, Any] = {}

    def _get_receiver_automation(self) -> AutomatedReceiver:
        cls = type(self)
        if cls.receiver_automation is None:
            if cls.validator is None or cls.registry is None or cls.verification_key is None:
                raise RuntimeError("ERR_RECEIVER_NOT_CONFIGURED")
            ledger = cls.ledger or getattr(cls.validator, "ledger", None)
            if ledger is None:
                raise RuntimeError("ERR_RECEIVER_LEDGER_UNAVAILABLE")
            storage_dir = Path(os.environ.get("BRAID_RECEIVER_DIR", str(default_workspace() / "inbox")))
            cls.receiver_automation = AutomatedReceiver(
                validator=cls.validator,
                registry=cls.registry,
                ledger=ledger,
                verification_key=cls.verification_key,
                config=ReceiverAutomationConfig(storage_dir=storage_dir, auto_commit=True),
            )
        return cls.receiver_automation

    def _set_security_headers(self, content_type="application/json", status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("X-Permitted-Cross-Domain-Policies", "none")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Permissions-Policy", "camera=(self), microphone=(), geolocation=()")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
        )
        self.end_headers()

    @staticmethod
    def _is_loopback_name(host: str | None) -> bool:
        if not host:
            return False
        value = host.strip().rstrip(".").lower()
        if value == "localhost":
            return True
        try:
            return ipaddress.ip_address(value).is_loopback
        except ValueError:
            return False

    def _host_header_is_local(self) -> bool:
        raw = (self.headers.get("Host") or "").strip()
        if not raw:
            return False
        if raw.startswith("["):
            end = raw.find("]")
            host = raw[1:end] if end > 0 else ""
        else:
            host = raw.rsplit(":", 1)[0] if raw.count(":") == 1 else raw
        return self._is_loopback_name(host)

    def _origin_is_local(self) -> bool:
        origin = self.headers.get("Origin")
        fetch_site = (self.headers.get("Sec-Fetch-Site") or "").strip().lower()
        if not origin:
            # Non-browser API clients normally omit both headers. Browsers expose
            # cross-site context through Fetch Metadata even for requests where
            # Origin may be absent; fail closed for that case while preserving curl/CLI.
            return fetch_site != "cross-site"
        try:
            parsed = urlparse(origin)
        except Exception:
            return False
        return parsed.scheme in {"http", "https"} and self._is_loopback_name(parsed.hostname)

    def _enforce_local_browser_context(self) -> bool:
        if self._host_header_is_local() and self._origin_is_local():
            return True
        self._set_security_headers("application/json", 403)
        self.wfile.write(json.dumps({"status": "error", "error": "ERR_LOCAL_UI_CONTEXT"}).encode("utf-8"))
        return False

    def do_GET(self):
        if not self._enforce_local_browser_context():
            return
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            if not STATIC_HTML_PATH.exists():
                self._set_security_headers("text/plain", 404)
                self.wfile.write(b"404 Not Found: braid_visualizer.html missing")
                return

            self._set_security_headers("text/html; charset=utf-8", 200)
            html = STATIC_HTML_PATH.read_text(encoding="utf-8").replace("__BRAID_VERSION__", __version__)
            self.wfile.write(html.encode("utf-8"))

        elif path == "/static/camera_receiver.js":
            if not STATIC_CAMERA_PATH.exists():
                self._set_security_headers("application/json", 404)
                self.wfile.write(json.dumps({"status": "error", "error": "ERR_STATIC_MISSING"}).encode("utf-8"))
                return
            self._set_security_headers("application/javascript; charset=utf-8", 200)
            with open(STATIC_CAMERA_PATH, "rb") as f:
                self.wfile.write(f.read())

        elif path == "/api/sample":
            frame, raw_bytes, _ = generate_frame_object(signing_key=self.signing_key)
            gates = evaluate_normative_receiver_gates(
                frame, self.verification_key, self.validator, self.registry
            )
            chunks = chunk_binary_frame(raw_bytes)
            stats = analyze_vector_stats(frame.vector)

            response = {
                "manifest": frame.manifest,
                "vector": [float(x) for x in frame.vector],
                "stats": stats,
                "gates": gates,
                "object_digest": frame.object_digest,
                "raw_frame_hex": raw_bytes.hex(),
                "chunks": chunks
            }
            self._set_security_headers("application/json", 200)
            self.wfile.write(json.dumps(response).encode("utf-8"))

        elif path == "/api/receiver/status":
            response = {
                "version": __version__,
                "receiver": "automated",
                "auto_commit": True,
                "last": type(self).last_receiver_report,
                "sensing": SENSOR_FIELD.snapshot(),
            }
            self._set_security_headers("application/json", 200)
            self.wfile.write(json.dumps(response).encode("utf-8"))

        elif path == "/api/environment":
            response = detect_environment()
            self._set_security_headers("application/json", 200)
            self.wfile.write(json.dumps(response).encode("utf-8"))

        elif path == "/api/health":
            receiver = self._get_receiver_automation()
            response = {
                "status": "ready",
                "version": __version__,
                "field": "loopback_only",
                "receiver": "automated_384d",
                "auto_commit": bool(receiver.config.auto_commit),
                "storage_ready": receiver.config.storage_dir.is_dir(),
                "qr_engine": STATIC_HTML_PATH.is_file(),
                "camera_fallback": importlib.util.find_spec("cv2") is not None,
                "ble_sensing": importlib.util.find_spec("bleak") is not None,
                "semantic_capsule": True,
                "semantic_rule": "heterogeneous_reembedding_requires_signed_semantic_capsule",
                "exact_space_fast_path": True,
                "trust_note": "sensing_and_discovery_are_untrusted_hints",
            }
            self._set_security_headers("application/json", 200)
            self.wfile.write(json.dumps(response).encode("utf-8"))

        elif path == "/api/qr":
            query_data = params.get("data", [""])[0]
            if not query_data:
                self._set_security_headers("application/json", 400)
                self.wfile.write(json.dumps({"status": "error", "error": "ERR_MISSING_DATA"}).encode("utf-8"))
                return
            try:
                qr = StandardQRCodeEncoder(query_data)
                resp = {
                    "status": "success", "matrix": qr.matrix,
                    "size": qr.size, "version": qr.version,
                    "quiet_zone_modules": 4
                }
                status = 200
            except QRCapacityError as exc:
                resp = {"status": "error", "error": "ERR_QR_CAPACITY", "message": str(exc)}
                status = 400
            self._set_security_headers("application/json", status)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        else:
            self._set_security_headers("application/json", 404)
            self.wfile.write(json.dumps({"status": "error", "error": "404 Not Found"}).encode("utf-8"))

    def do_POST(self):
        if not self._enforce_local_browser_context():
            return
        raw_content_len = self.headers.get("Content-Length")
        try:
            content_len = int(raw_content_len) if raw_content_len is not None else -1
        except (TypeError, ValueError):
            content_len = -1
        if content_len < 0:
            self._set_security_headers("application/json", 411)
            self.wfile.write(json.dumps({"status": "error", "error": "ERR_CONTENT_LENGTH"}).encode("utf-8"))
            return
        if content_len > 102400:
            self._set_security_headers("application/json", 413)
            self.wfile.write(json.dumps({"status": "error", "error": "413 Payload Too Large"}).encode("utf-8"))
            return
        if content_len and self.headers.get_content_type() != "application/json":
            self._set_security_headers("application/json", 415)
            self.wfile.write(json.dumps({"status": "error", "error": "ERR_JSON_CONTENT_TYPE_REQUIRED"}).encode("utf-8"))
            return

        body_bytes = self.rfile.read(content_len)
        try:
            def reject_constant(value):
                raise ValueError(f"non-finite JSON constant: {value}")
            data = json.loads(body_bytes.decode("utf-8"), parse_constant=reject_constant) if body_bytes else {}
            if not isinstance(data, dict):
                raise TypeError("JSON body must be an object")
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, TypeError):
            self._set_security_headers("application/json", 400)
            self.wfile.write(json.dumps({"status": "error", "error": "ERR_JSON_OBJECT_REQUIRED"}).encode("utf-8"))
            return

        if self.path == "/api/generate":
            preset = data.get("preset", "llama3_gemma2_soft_prefix")
            try:
                noise_std = float(data.get("noise_std", 0.0))
                refund_max = float(data.get("sender_requested_refund_max", 75.0))
                chunk_size = int(data.get("max_chunk_size", 120))
                if not np.isfinite(noise_std) or noise_std < 0.0 or noise_std > 1.0:
                    raise ValueError("noise_std")
                if not np.isfinite(refund_max) or refund_max < 0.0:
                    raise ValueError("refund_max")
            except (TypeError, ValueError, OverflowError):
                self._set_security_headers("application/json", 400)
                self.wfile.write(json.dumps({"status": "error", "error": "ERR_GENERATE_ARGUMENTS"}).encode("utf-8"))
                return
            capability_ref = data.get("capability_ref", "cap_ref_8f9a2b")

            frame, raw_bytes, _ = generate_frame_object(
                preset=preset,
                noise_std=noise_std,
                capability_ref=capability_ref,
                sender_requested_refund_max=refund_max,
                signing_key=self.signing_key
            )

            try:
                chunks = chunk_binary_frame(raw_bytes, max_chunk_size=chunk_size)
            except (ValueError, QRCapacityError) as exc:
                code = "ERR_QR_CAPACITY" if "ERR_QR_CAPACITY" in str(exc) else "ERR_CHUNK_SIZE"
                self._set_security_headers("application/json", 400)
                self.wfile.write(json.dumps({
                    "status": "error", "error": code, "message": str(exc)
                }).encode("utf-8"))
                return
            gates = evaluate_normative_receiver_gates(
                frame, self.verification_key, self.validator, self.registry
            )
            stats = analyze_vector_stats(frame.vector)

            resp = {
                "status": "success",
                "manifest": frame.manifest,
                "vector": [float(x) for x in frame.vector],
                "stats": stats,
                "gates": gates,
                "object_digest": frame.object_digest,
                "raw_frame_hex": raw_bytes.hex(),
                "chunks": chunks
            }
            self._set_security_headers("application/json", 200)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        elif self.path == "/api/inspect":
            hex_str = data.get("raw_frame_hex", "").strip()
            try:
                raw_bytes = bytes.fromhex(hex_str)
                frame = BraidFrame.from_bytes(raw_bytes)
                gates = evaluate_normative_receiver_gates(
                    frame, self.verification_key, self.validator, self.registry
                )
                stats = analyze_vector_stats(frame.vector)

                phase_a_valid = bool(gates["overall_accepted"])
                resp = {
                    "status": "phase_a_validated" if phase_a_valid else "rejected",
                    "accepted": False,
                    "finality": "not_committed" if phase_a_valid else "rejected",
                    "phase": "A_non_locking",
                    "manifest": frame.manifest,
                    "vector": [float(x) for x in frame.vector],
                    "stats": stats,
                    "gates": gates,
                    "object_digest": frame.object_digest,
                    "effective_authority": gates.get("effective_authority", {})
                }
                status_code = 200 if gates["overall_accepted"] else 400
            except Exception as e:
                resp = {"status": "error", "error": f"ERR_INSPECT_FAILED: {str(e)}"}
                status_code = 400

            self._set_security_headers("application/json", status_code)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        elif self.path == "/api/ingest_chunk":
            chunk_str = data.get("chunk_str", "")
            res = CHUNK_COLLECTOR.ingest_chunk_string(chunk_str)
            status_code = 200 if res.get("status") == "success" else 400

            if res.get("status") == "success" and res.get("is_complete"):
                frame_id = res.get("frame_id")
                try:
                    raw = res["reassembled_bytes"]
                    frame = BraidFrame.from_bytes(raw)
                    report = self._get_receiver_automation().process_bytes(
                        raw,
                        source_transport="optical_qr",
                        source_name=f"optical-{frame_id}.brad",
                        peer="camera",
                    )
                    type(self).last_receiver_report = report
                    res.update({
                        "manifest": frame.manifest,
                        "object_digest": frame.object_digest,
                        "gates": report.get("gates", {}),
                        "vector": [float(x) for x in frame.vector],
                        "stats": report.get("stats", analyze_vector_stats(frame.vector)),
                        "raw_frame_hex": raw.hex(),
                        "effective_authority": report.get("effective_authority", {}),
                        "receiver": report,
                    })
                    status_code = 200 if report.get("accepted") else 400
                except Exception as exc:
                    CHUNK_COLLECTOR.reset_session(frame_id)
                    res = {
                        "status": "error",
                        "error": "ERR_REASSEMBLED_FRAME_INVALID",
                        "message": str(exc),
                        "frame_id": frame_id,
                    }
                    status_code = 400

            res.pop("reassembled_bytes", None)
            self._set_security_headers("application/json", status_code)
            self.wfile.write(json.dumps(res).encode("utf-8"))

        elif self.path == "/api/decode_qr":
            image_b64 = data.get("image_base64", "")
            if not isinstance(image_b64, str) or not image_b64:
                self._set_security_headers("application/json", 400)
                self.wfile.write(json.dumps({
                    "status": "error", "error": "ERR_MISSING_IMAGE"
                }).encode("utf-8"))
                return
            if image_b64.startswith("data:"):
                image_b64 = image_b64.split(",", 1)[-1]
            try:
                encoded = base64.b64decode(image_b64, validate=True)
                if len(encoded) > 75000:
                    raise ValueError("ERR_IMAGE_SIZE_LIMIT: Decoded image exceeds 75 KB.")
                import cv2
                image_arr = np.frombuffer(encoded, dtype=np.uint8)
                image = cv2.imdecode(image_arr, cv2.IMREAD_GRAYSCALE)
                if image is None:
                    raise ValueError("ERR_IMAGE_DECODE: Unsupported image bytes.")
                try:
                    text = decode_qr_raster(image)
                except ValueError as decode_exc:
                    if "ERR_QR_DECODE" not in str(decode_exc):
                        raise
                    text = ""
                if not text:
                    resp = {"status": "empty", "decoded": False}
                    status = 200
                elif not text.startswith("BRAD1:"):
                    resp = {"status": "ignored", "decoded": True, "reason": "NON_BRAD1"}
                    status = 200
                else:
                    resp = {"status": "success", "decoded": True, "text": text}
                    status = 200
            except ImportError:
                resp = {
                    "status": "error", "error": "ERR_QR_DECODER_UNAVAILABLE",
                    "message": "Install braid-client[camera] for the local OpenCV fallback."
                }
                status = 501
            except (ValueError, binascii.Error) as exc:
                resp = {"status": "error", "error": "ERR_IMAGE_INVALID", "message": str(exc)}
                status = 400
            self._set_security_headers("application/json", status)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        elif self.path == "/api/receive_frame":
            hex_str = str(data.get("raw_frame_hex", "")).strip()
            try:
                raw = bytes.fromhex(hex_str)
                report = self._get_receiver_automation().process_bytes(
                    raw, source_transport="local_api", source_name=str(data.get("name") or "api-frame.brad"), peer="loopback"
                )
                type(self).last_receiver_report = report
                status = 200 if report.get("accepted") else 400
                resp = {"status": "accepted" if report.get("accepted") else "rejected", "receiver": report}
            except Exception as exc:
                status = 400
                resp = {"status": "error", "error": "ERR_RECEIVER_INTAKE", "message": str(exc)}
            self._set_security_headers("application/json", status)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        elif self.path == "/api/sensing/observe":
            try:
                record = SENSOR_FIELD.observe(str(data.get("key") or ""), float(data.get("rssi")), label=data.get("label"))
                resp = {"status": "success", "record": record, "field": SENSOR_FIELD.snapshot()}
                status = 200
            except Exception as exc:
                resp = {"status": "error", "error": "ERR_SENSING_OBSERVATION", "message": str(exc)}
                status = 400
            self._set_security_headers("application/json", status)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        elif self.path == "/api/sensing/scan":
            try:
                timeout = max(0.5, min(10.0, float(data.get("timeout", 3.0))))
                records = SENSOR_FIELD.scan_ble_sync(timeout)
                resp = {"status": "success", "records": records, "trust": "untrusted_discovery_hint"}
                status = 200
            except RuntimeError as exc:
                resp = {"status": "error", "error": "ERR_BLE_UNAVAILABLE", "message": str(exc)}
                status = 501
            except Exception as exc:
                resp = {"status": "error", "error": "ERR_BLE_SCAN", "message": str(exc)}
                status = 400
            self._set_security_headers("application/json", status)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        elif self.path == "/api/qr":
            query_data = data.get("data", "")
            if not query_data:
                self._set_security_headers("application/json", 400)
                self.wfile.write(json.dumps({"status": "error", "error": "ERR_MISSING_DATA"}).encode("utf-8"))
                return
            try:
                qr = StandardQRCodeEncoder(query_data)
                resp = {
                    "status": "success", "matrix": qr.matrix,
                    "size": qr.size, "version": qr.version,
                    "quiet_zone_modules": 4
                }
                status = 200
            except QRCapacityError as exc:
                resp = {"status": "error", "error": "ERR_QR_CAPACITY", "message": str(exc)}
                status = 400
            self._set_security_headers("application/json", status)
            self.wfile.write(json.dumps(resp).encode("utf-8"))

        elif self.path == "/api/reset_collector":
            CHUNK_COLLECTOR.reset_session()
            self._set_security_headers("application/json", 200)
            self.wfile.write(json.dumps({"status": "success", "message": "Collector sessions reset."}).encode("utf-8"))

        else:
            self._set_security_headers("application/json", 404)
            self.wfile.write(json.dumps({"status": "error", "error": "404 Not Found"}).encode("utf-8"))


class _ReusableFieldServer(socketserver.TCPServer):
    allow_reuse_address = True


def serve_http_app(
    host: str = "127.0.0.1",
    port: int = 8080,
    key_path: Optional[str] = None,
    trusted_key_path: Optional[str] = None,
    *,
    open_browser: bool = False,
):
    """Launch the local Braid Field UI. The signer/receiver management plane is loopback-only."""
    decision = classify_bind_scope(host)
    if decision.scope != BindScope.LOOPBACK:
        raise ValueError("ERR_FIELD_UI_LOOPBACK_ONLY")
    sk, priv_p, pub_p = load_or_create_signing_key(key_path)
    vk = load_verification_key(trusted_key_path) if trusted_key_path else sk.public_key()

    vk_hex = get_raw_public_bytes(vk).hex()
    storage_dir = Path(os.environ.get("BRAID_RECEIVER_DIR", str(default_workspace() / "inbox")))
    storage_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(storage_dir, 0o700)
    except OSError:
        pass
    validator, registry, ledger = create_authoritative_validator(vk_hex, ledger_path=storage_dir / "replay_ledger.db")

    HardenedBraidHTTPHandler.signing_key = sk
    HardenedBraidHTTPHandler.verification_key = vk
    HardenedBraidHTTPHandler.validator = validator
    HardenedBraidHTTPHandler.registry = registry
    HardenedBraidHTTPHandler.ledger = ledger
    HardenedBraidHTTPHandler.receiver_automation = AutomatedReceiver(
        validator=validator,
        registry=registry,
        ledger=ledger,
        verification_key=vk,
        config=ReceiverAutomationConfig(
            storage_dir=storage_dir,
            auto_commit=True,
        ),
    )
    HardenedBraidHTTPHandler.last_receiver_report = {}

    with _ReusableFieldServer((host, port), HardenedBraidHTTPHandler) as httpd:
        actual_port = httpd.server_address[1]
        print(f"===========================================================")
        print(f"  BRAID v{__version__} FIELD CLIENT & AUTOMATED RECEIVER           ")
        print(f"===========================================================")
        print(f"  Listening on http://{host}:{actual_port}/")
        print(f"  Signing Key: {priv_p}")
        print(f"  Verification Key: {pub_p if not trusted_key_path else trusted_key_path}")
        print(f"  Authoritative Validator Active: True")
        print(f"===========================================================")
        if open_browser:
            url = f"http://{host}:{actual_port}/"
            threading.Timer(0.25, lambda: webbrowser.open(url, new=1, autoraise=True)).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer shut down cleanly.")
