/*
 * Braid Camera Receiver v1.5.2
 * Native BarcodeDetector first, with a loopback-only OpenCV fallback via
 * /api/decode_qr. No CDN or external network calls.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BraidCameraReceiver = factory();
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  class CameraReceiver {
    constructor(options) {
      const opts = options || {};
      if (!opts.video || !opts.canvas) throw new Error('ERR_CAMERA_ELEMENTS_REQUIRED');
      this.video = opts.video;
      this.canvas = opts.canvas;
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
      this.ingest = opts.ingest || (async function () {});
      this.onStatus = opts.onStatus || function () {};
      this.fetchFn = opts.fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(typeof globalThis !== 'undefined' ? globalThis : null) : null);
      this.mediaDevices = opts.mediaDevices || (typeof navigator !== 'undefined' ? navigator.mediaDevices : null);
      this.BarcodeDetectorCtor = opts.BarcodeDetectorCtor || (typeof BarcodeDetector !== 'undefined' ? BarcodeDetector : null);
      this.scanFps = Math.max(1, Math.min(12, Number(opts.scanFps || 6)));
      this.fallbackEvery = Math.max(1, Number(opts.fallbackEvery || 3));
      this.dedupeMs = Math.max(500, Number(opts.dedupeMs || 5000));
      this.maxCaptureWidth = Math.max(160, Number(opts.maxCaptureWidth || 400));
      this.jpegQuality = Math.max(0.25, Math.min(0.85, Number(opts.jpegQuality || 0.52)));
      this.now = opts.now || (() => Date.now());
      this.schedule = opts.schedule || ((fn, ms) => setTimeout(fn, ms));
      this.cancelSchedule = opts.cancelSchedule || ((id) => clearTimeout(id));
      this.running = false;
      this.stream = null;
      this.detector = null;
      this.backend = 'initializing';
      this.timer = null;
      this.frameCounter = 0;
      this.startedAt = 0;
      this.lastDecodeAt = 0;
      this.seen = new Map();
      this.inFlight = new Set();
      this.metrics = { attempts: 0, decoded: 0, accepted: 0, duplicates: 0, errors: 0 };
    }

    snapshot(extra) {
      const elapsed = this.startedAt ? Math.max(0.001, (this.now() - this.startedAt) / 1000) : 0;
      return Object.assign({
        running: this.running,
        backend: this.backend,
        scan_fps: this.scanFps,
        decode_rate_hz: elapsed ? this.metrics.decoded / elapsed : 0,
        attempts: this.metrics.attempts,
        decoded: this.metrics.decoded,
        accepted: this.metrics.accepted,
        duplicates: this.metrics.duplicates,
        errors: this.metrics.errors,
      }, extra || {});
    }

    emit(extra) { this.onStatus(this.snapshot(extra)); }

    async start() {
      if (this.running) return;
      if (!this.mediaDevices || !this.mediaDevices.getUserMedia) {
        throw new Error('ERR_CAMERA_UNAVAILABLE: getUserMedia is not available.');
      }
      this.stream = await this.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      this.video.srcObject = this.stream;
      if (typeof this.video.play === 'function') await this.video.play();
      await this._selectBackend();
      this.running = true;
      this.startedAt = this.now();
      this.emit({ state: 'scanning', message: 'Camera receiver active.' });
      this._scheduleNext(0);
    }

    async _selectBackend() {
      if (this.BarcodeDetectorCtor) {
        try {
          if (typeof this.BarcodeDetectorCtor.getSupportedFormats === 'function') {
            const formats = await this.BarcodeDetectorCtor.getSupportedFormats();
            if (formats.indexOf('qr_code') === -1) throw new Error('qr_code unsupported');
          }
          this.detector = new this.BarcodeDetectorCtor({ formats: ['qr_code'] });
          this.backend = 'native-barcode-detector';
          return;
        } catch (err) {
          this.detector = null;
        }
      }
      if (!this.fetchFn) throw new Error('ERR_QR_DECODER_UNAVAILABLE');
      this.backend = 'loopback-opencv-fallback';
    }

    stop() {
      this.running = false;
      if (this.timer !== null) this.cancelSchedule(this.timer);
      this.timer = null;
      if (this.stream && this.stream.getTracks) {
        this.stream.getTracks().forEach((track) => track.stop());
      }
      this.stream = null;
      this.video.srcObject = null;
      this.emit({ state: 'stopped', message: 'Camera receiver stopped.' });
    }

    _scheduleNext(delay) {
      if (!this.running) return;
      this.timer = this.schedule(() => this._scanOnce(), delay);
    }

    _captureFrame() {
      const vw = Number(this.video.videoWidth || this.video.width || 0);
      const vh = Number(this.video.videoHeight || this.video.height || 0);
      if (!vw || !vh) return null;
      const scale = Math.min(1, this.maxCaptureWidth / vw);
      const width = Math.max(1, Math.round(vw * scale));
      const height = Math.max(1, Math.round(vh * scale));
      if (this.canvas.width !== width) this.canvas.width = width;
      if (this.canvas.height !== height) this.canvas.height = height;
      this.ctx.drawImage(this.video, 0, 0, width, height);
      return { width, height };
    }

    async _scanOnce() {
      if (!this.running) return;
      const interval = Math.round(1000 / this.scanFps);
      this.metrics.attempts += 1;
      this.frameCounter += 1;
      try {
        const frame = this._captureFrame();
        if (frame) {
          let texts = [];
          if (this.detector) {
            const codes = await this.detector.detect(this.canvas);
            texts = (codes || []).map((c) => c.rawValue || '').filter(Boolean);
            // Native detectors can miss motion-blurred frames. Periodically ask the
            // local fallback as a bounded second opinion when nothing was found.
            if (!texts.length && this.frameCounter % this.fallbackEvery === 0 && this.fetchFn) {
              const fallback = await this._decodeViaLoopback();
              if (fallback) texts.push(fallback);
            }
          } else {
            const fallback = await this._decodeViaLoopback();
            if (fallback) texts.push(fallback);
          }
          for (const text of texts) await this._handleDecodedText(text);
        }
      } catch (err) {
        this.metrics.errors += 1;
        this.emit({ state: 'recoverable-error', error: String(err && err.message || err) });
      } finally {
        this._scheduleNext(interval);
      }
    }

    async _decodeViaLoopback() {
      if (!this.fetchFn || typeof this.canvas.toDataURL !== 'function') return '';
      const dataUrl = this.canvas.toDataURL('image/jpeg', this.jpegQuality);
      const imageBase64 = dataUrl.split(',', 2)[1] || '';
      const response = await this.fetchFn('/api/decode_qr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image_base64: imageBase64 }),
      });
      const data = await response.json();
      if (!response.ok && data.error !== 'ERR_QR_DECODER_UNAVAILABLE') {
        throw new Error(data.error || 'ERR_QR_FALLBACK');
      }
      return data && data.status === 'success' ? data.text : '';
    }

    _pruneSeen(now) {
      for (const [text, timestamp] of this.seen.entries()) {
        if (now - timestamp > this.dedupeMs) this.seen.delete(text);
      }
    }

    async _handleDecodedText(text) {
      if (typeof text !== 'string' || !text.startsWith('BRAD1:')) {
        this.emit({ state: 'ignored', message: 'Decoded non-BRAD1 symbol ignored.' });
        return false;
      }
      const now = this.now();
      this._pruneSeen(now);
      this.metrics.decoded += 1;
      this.lastDecodeAt = now;
      if (this.seen.has(text) || this.inFlight.has(text)) {
        this.metrics.duplicates += 1;
        this.emit({ state: 'duplicate', last_chunk: text.slice(0, 72) });
        return false;
      }
      this.inFlight.add(text);
      try {
        await this.ingest(text);
        this.seen.set(text, now);
        this.metrics.accepted += 1;
        this.emit({ state: 'accepted', last_chunk: text.slice(0, 72) });
        return true;
      } finally {
        this.inFlight.delete(text);
      }
    }
  }

  return CameraReceiver;
}));
