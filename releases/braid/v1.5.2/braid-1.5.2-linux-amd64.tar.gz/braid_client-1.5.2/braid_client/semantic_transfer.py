"""Measured heterogeneous-model semantic transfer for Braid v1.5.2.

This module deliberately separates three claims:

1. A model can produce a deterministic embedding for text.
2. A calibrated, digest-bound route can translate a 384D source representation
   into a 384D target representation with measured held-out fidelity.
3. Receiver authority remains independent of semantic-transfer quality.

The calibration path is designed for local Ollama models, but the saved paired
embedding format is backend-neutral. No network service is contacted except the
operator-selected local Ollama endpoint.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import random
import re
import urllib.error
import urllib.request
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np

from . import __version__
from .mcp_core.alignment import RepresentationSpace, TransportMap
from .mcp_core.canonical import jcs_serialize, compute_json_artifact_digest
from .mcp_core.protocol import BraidFrame, ReplayLedger
from .mcp_core.registry import (
    AuthorizedSigner,
    CovarianceModel,
    PCAModel,
    RouteContract,
    TrustedRegistry,
)
from .mcp_core.validation import BraidValidator, FeatureSpec
from .legend import validate_legend, legend_embedding_text
from .ollama_adapter import OllamaClient, attach_ollama_extension
from .semantic_capsule import (
    attach_semantic_capsule, build_inline_capsule, build_legend_capsule,
    capsule_payload_digest_for_vector,
)


BRAID_DIMENSION = 384
CORPUS_SCHEMA = "braid.hetero-semantic-corpus.v1"
ROUTE_SCHEMA = "braid.hetero-semantic-route.v1"
PAIRED_EMBEDDING_SCHEMA = "braid.hetero-paired-embeddings.v1"
DEFAULT_OLLAMA_URL = "http://127.0.0.1:11434"


def _unit_rows(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    if not np.isfinite(arr).all():
        raise ValueError("ERR_HETERO_NONFINITE")
    norms = np.linalg.norm(arr, axis=1, keepdims=True)
    if np.any(norms <= 1e-15):
        raise ValueError("ERR_HETERO_ZERO_NORM")
    return arr / norms


def _array_digest(array: np.ndarray) -> str:
    arr = np.ascontiguousarray(np.asarray(array, dtype=np.float64))
    h = hashlib.sha256()
    h.update(b"BRAID-NDARRAY-v1\x00")
    h.update(str(arr.shape).encode("ascii"))
    h.update(b"\x00float64\x00")
    h.update(arr.tobytes(order="C"))
    return h.hexdigest()


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _slug(value: str, max_chars: int = 48) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "-", value).strip("-").lower()
    return (text[:max_chars] or "model")


def _split_for_id(item_id: str) -> str:
    bucket = int(hashlib.sha256(item_id.encode("utf-8")).hexdigest()[:8], 16) % 100
    if bucket < 68:
        return "train"
    if bucket < 84:
        return "validation"
    return "test"


def build_conformance_corpus(count: int = 768, seed: int = 1500) -> List[Dict[str, Any]]:
    """Build a deterministic semantic corpus with explicit decision-critical labels.

    The corpus is intentionally synthetic and auditable. It is a conformance
    instrument, not a claim to represent natural-language distribution.
    """
    if count < 576:
        raise ValueError("ERR_HETERO_CORPUS_TOO_SMALL: use at least 576 examples for a 384D route")

    actors = ["operator", "scheduler", "replica", "auditor", "controller", "worker", "gateway", "archive"]
    actions = ["restart the server", "publish the snapshot", "rotate the key", "promote the replica", "release the batch", "close the session", "apply the patch", "commit the transfer"]
    blockers = ["replication lag", "checksum drift", "temperature", "queue depth", "error rate", "clock skew", "memory pressure", "packet loss"]
    thresholds = [2, 3, 5, 8, 13, 21, 34, 55]
    provenance = ["local audit", "signed operator note", "hardware sensor", "peer report"]
    time_relations = ["after", "before"]
    polarities = [0, 1]

    rows: List[Dict[str, Any]] = []
    for actor in actors:
        for action in actions:
            for blocker in blockers:
                for threshold in thresholds:
                    for provenance_source in provenance:
                        for temporal in time_relations:
                            for negated in polarities:
                                canonical = f"{actor}|{action}|{blocker}|{threshold}|{provenance_source}|{temporal}|{negated}"
                                item_id = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:24]
                                split = _split_for_id(item_id)
                                if negated == 0:
                                    threshold_rule = f"block the operation whenever {blocker} exceeds {threshold}"
                                    compact_rule = f"{blocker}>{threshold} means HOLD"
                                else:
                                    threshold_rule = f"permit the operation only while {blocker} stays below {threshold}"
                                    compact_rule = f"{blocker}<{threshold} means PERMIT"
                                if split == "train":
                                    text = (
                                        f"The {actor} may {action} {temporal} the backup completes. The threshold rule is to {threshold_rule}. "
                                        f"Treat the {provenance_source} as evidence only; the receiver makes the final decision."
                                    )
                                elif split == "validation":
                                    text = (
                                        f"Validation scenario: authorize {actor} to {action} {temporal} backup completion, subject to this condition: "
                                        f"{threshold_rule}. The {provenance_source} supplies evidence, not authority."
                                    )
                                else:
                                    text = (
                                        f"Decision record for {actor}: action={action}. Temporal constraint={temporal} backup completion. "
                                        f"Threshold constraint: {compact_rule}. Provenance comes from {provenance_source}, but acceptance belongs to the receiver."
                                    )
                                rows.append({
                                    "id": item_id,
                                    "text": text,
                                    "split": split,
                                    "labels": {
                                        "temporal": temporal,
                                        "polarity": "block_on_threshold" if negated == 0 else "permit_below_threshold",
                                        "actor": actor,
                                        "action": action,
                                        "blocker": blocker,
                                        "provenance": provenance_source,
                                        "threshold_bucket": str(threshold),
                                    },
                                })

    rng = random.Random(seed)
    rng.shuffle(rows)
    selected = rows[:count]

    # Guarantee enough training points for a 384D PCA while preserving the
    # deterministic hash split. If the sample is unusually imbalanced, extend.
    train_count = sum(row["split"] == "train" for row in selected)
    cursor = count
    while train_count < BRAID_DIMENSION + 16 and cursor < len(rows):
        row = rows[cursor]
        selected.append(row)
        train_count += int(row["split"] == "train")
        cursor += 1

    if train_count < BRAID_DIMENSION + 1:
        raise RuntimeError("ERR_HETERO_TRAIN_SPLIT_TOO_SMALL")
    return selected


def write_corpus(path: Path, rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    header = {"schema": CORPUS_SCHEMA, "version": __version__, "count": len(rows)}
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(header, sort_keys=True, separators=(",", ":")) + "\n")
        for row in rows:
            handle.write(json.dumps(dict(row), sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
    return {"path": str(path), "sha256": _file_sha256(path), "count": len(rows)}


def read_corpus(path: Path) -> List[Dict[str, Any]]:
    path = Path(path)
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        first = handle.readline()
        if not first:
            raise ValueError("ERR_HETERO_EMPTY_CORPUS")
        header = json.loads(first)
        if header.get("schema") != CORPUS_SCHEMA:
            raise ValueError("ERR_HETERO_CORPUS_SCHEMA")
        for line in handle:
            if line.strip():
                row = json.loads(line)
                if not isinstance(row.get("text"), str) or not isinstance(row.get("labels"), dict):
                    raise ValueError("ERR_HETERO_CORPUS_ROW")
                rows.append(row)
    return rows


class OllamaEmbeddingClient:
    """Compatibility shim over the hardened built-in loopback Ollama client."""

    def __init__(self, base_url: str = DEFAULT_OLLAMA_URL, timeout_seconds: float = 180.0):
        try:
            self._client = OllamaClient(base_url, timeout_seconds)
        except ValueError as exc:
            text = str(exc)
            if text == "ERR_OLLAMA_LOOPBACK_REQUIRED":
                raise ValueError("ERR_HETERO_OLLAMA_LOOPBACK_REQUIRED") from exc
            if text.startswith("ERR_OLLAMA_URL"):
                raise ValueError("ERR_HETERO_OLLAMA_URL") from exc
            if text == "ERR_OLLAMA_TIMEOUT":
                raise ValueError("ERR_HETERO_TIMEOUT") from exc
            raise
        self.base_url = self._client.base_url
        self.timeout_seconds = self._client.timeout_seconds

    def embed(self, model: str, texts: Sequence[str], batch_size: int = 16, dimensions: int = BRAID_DIMENSION) -> np.ndarray:
        try:
            return self._client.embed(model, texts, dimensions=dimensions, batch_size=batch_size)
        except ValueError as exc:
            text = str(exc)
            if text == "ERR_OLLAMA_EMBED_INPUT":
                raise ValueError("ERR_HETERO_MODEL_OR_INPUT") from exc
            if text.startswith("ERR_OLLAMA_EMBED_DIM") or text == "ERR_OLLAMA_BRAID_DIMENSION":
                raise ValueError(text.replace("ERR_OLLAMA_EMBED_DIM", "ERR_HETERO_EMBED_DIM").replace("ERR_OLLAMA_BRAID_DIMENSION", "ERR_HETERO_EMBED_DIM")) from exc
            if text == "ERR_OLLAMA_EMBED_NONFINITE":
                raise ValueError("ERR_HETERO_EMBED_NONFINITE") from exc
            raise
        except RuntimeError as exc:
            text = str(exc)
            if text.startswith("ERR_OLLAMA_HTTP"):
                raise RuntimeError(text.replace("ERR_OLLAMA_HTTP", "ERR_HETERO_OLLAMA_HTTP", 1)) from exc
            if text.startswith("ERR_OLLAMA_CONNECT"):
                raise RuntimeError(text.replace("ERR_OLLAMA_CONNECT", "ERR_HETERO_OLLAMA_CONNECT", 1)) from exc
            if text == "ERR_OLLAMA_EMBED_RESPONSE":
                raise RuntimeError("ERR_HETERO_OLLAMA_RESPONSE") from exc
            raise


@dataclass(frozen=True)
class ProjectionAdapter:
    mean: np.ndarray
    components: np.ndarray
    adapter_id: str
    model_revision: str
    backend: str = "ollama:/api/embed"

    def __post_init__(self) -> None:
        mean = np.asarray(self.mean, dtype=np.float64)
        components = np.asarray(self.components, dtype=np.float64)
        if mean.ndim != 1 or components.ndim != 2 or components.shape[1] != mean.size:
            raise ValueError("ERR_HETERO_ADAPTER_SHAPE")
        if not np.isfinite(mean).all() or not np.isfinite(components).all():
            raise ValueError("ERR_HETERO_ADAPTER_NONFINITE")
        object.__setattr__(self, "mean", mean.copy())
        object.__setattr__(self, "components", components.copy())
        self.mean.setflags(write=False)
        self.components.setflags(write=False)

    @property
    def raw_dimension(self) -> int:
        return int(self.mean.size)

    @property
    def braid_dimension(self) -> int:
        return int(self.components.shape[0])

    @property
    def digest(self) -> str:
        meta = {
            "schema": "braid.projection-adapter.v1",
            "adapter_id": self.adapter_id,
            "model_revision": self.model_revision,
            "backend": self.backend,
            "raw_dimension": self.raw_dimension,
            "braid_dimension": self.braid_dimension,
            "mean_sha256": _array_digest(self.mean),
            "components_sha256": _array_digest(self.components),
        }
        return compute_json_artifact_digest("projection_adapter", meta)

    def transform(self, raw_vectors: np.ndarray) -> np.ndarray:
        arr = np.asarray(raw_vectors, dtype=np.float64)
        single = arr.ndim == 1
        if single:
            arr = arr.reshape(1, -1)
        if arr.ndim != 2 or arr.shape[1] != self.raw_dimension:
            raise ValueError("ERR_HETERO_ADAPTER_INPUT_DIM")
        projected = (arr - self.mean) @ self.components.T
        projected = _unit_rows(projected)
        return projected[0] if single else projected

    @classmethod
    def fit(cls, raw_train: np.ndarray, *, model_revision: str, adapter_id: str, braid_dimension: int = BRAID_DIMENSION) -> "ProjectionAdapter":
        arr = np.asarray(raw_train, dtype=np.float64)
        if arr.ndim != 2 or not np.isfinite(arr).all():
            raise ValueError("ERR_HETERO_PCA_INPUT")
        if braid_dimension <= 0 or braid_dimension > min(arr.shape[0] - 1, arr.shape[1]):
            raise ValueError(f"ERR_HETERO_PCA_DIM:{braid_dimension}:{arr.shape}")
        mean = np.mean(arr, axis=0)
        centered = arr - mean
        # NumPy SVD keeps the base package SciPy-free.
        _, _, vt = np.linalg.svd(centered, full_matrices=False)
        components = vt[:braid_dimension]
        return cls(mean=mean, components=components, adapter_id=adapter_id, model_revision=model_revision)


def _split_indices(rows: Sequence[Mapping[str, Any]], split: str) -> np.ndarray:
    return np.asarray([i for i, row in enumerate(rows) if row.get("split") == split], dtype=np.int64)


def save_paired_embeddings(
    path: Path,
    rows: Sequence[Mapping[str, Any]],
    source_model: str,
    target_model: str,
    source_raw: np.ndarray,
    target_raw: np.ndarray,
    corpus_sha256: str,
) -> Dict[str, Any]:
    path = Path(path)
    if source_raw.shape[0] != len(rows) or target_raw.shape[0] != len(rows):
        raise ValueError("ERR_HETERO_PAIR_COUNT")
    ids = np.asarray([row["id"] for row in rows], dtype="U32")
    splits = np.asarray([row["split"] for row in rows], dtype="U16")
    metadata = {
        "schema": PAIRED_EMBEDDING_SCHEMA,
        "version": __version__,
        "source_model": source_model,
        "target_model": target_model,
        "corpus_sha256": corpus_sha256,
        "count": len(rows),
        "source_raw_dimension": int(source_raw.shape[1]),
        "target_raw_dimension": int(target_raw.shape[1]),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        metadata_json=np.asarray(json.dumps(metadata, sort_keys=True, separators=(",", ":"))),
        ids=ids,
        splits=splits,
        source_raw=np.asarray(source_raw, dtype=np.float32),
        target_raw=np.asarray(target_raw, dtype=np.float32),
    )
    return {"path": str(path), "sha256": _file_sha256(path), **metadata}


def load_paired_embeddings(path: Path) -> Dict[str, Any]:
    with np.load(Path(path), allow_pickle=False) as data:
        metadata = json.loads(str(data["metadata_json"].item()))
        if metadata.get("schema") != PAIRED_EMBEDDING_SCHEMA:
            raise ValueError("ERR_HETERO_PAIR_SCHEMA")
        return {
            "metadata": metadata,
            "ids": data["ids"].astype(str),
            "splits": data["splits"].astype(str),
            "source_raw": np.asarray(data["source_raw"], dtype=np.float64),
            "target_raw": np.asarray(data["target_raw"], dtype=np.float64),
        }


def _mean_paired_cosine(mapped: np.ndarray, target: np.ndarray) -> float:
    a = _unit_rows(mapped)
    b = _unit_rows(target)
    return float(np.mean(np.sum(a * b, axis=1)))


def _retrieval_metrics(mapped: np.ndarray, target: np.ndarray) -> Dict[str, float]:
    a = _unit_rows(mapped)
    b = _unit_rows(target)
    sim = a @ b.T
    order = np.argsort(-sim, axis=1)
    n = sim.shape[0]
    correct = np.arange(n)
    top1 = float(np.mean(order[:, 0] == correct))
    k = min(5, n)
    top5 = float(np.mean([correct[i] in order[i, :k] for i in range(n)]))
    ranks = []
    for i in range(n):
        rank = int(np.where(order[i] == i)[0][0]) + 1
        ranks.append(rank)
    mrr = float(np.mean([1.0 / rank for rank in ranks]))
    paired = sim[correct, correct]
    if n > 1:
        negative_mean = float((sim.sum() - paired.sum()) / (n * (n - 1)))
    else:
        negative_mean = 0.0
    return {
        "top1": top1,
        "top5": top5,
        "mrr": mrr,
        "paired_cosine_mean": float(np.mean(paired)),
        "negative_cosine_mean": negative_mean,
        "paired_margin": float(np.mean(paired) - negative_mean),
    }


def _fit_probe(train_x: np.ndarray, train_labels: Sequence[str], alpha: float = 1.0) -> Tuple[np.ndarray, List[str]]:
    classes = sorted(set(str(x) for x in train_labels))
    if len(classes) < 2:
        return np.zeros((train_x.shape[1] + 1, 1), dtype=np.float64), classes
    class_index = {name: idx for idx, name in enumerate(classes)}
    y = np.zeros((len(train_labels), len(classes)), dtype=np.float64)
    for row, label in enumerate(train_labels):
        y[row, class_index[str(label)]] = 1.0
    x = np.column_stack([np.asarray(train_x, dtype=np.float64), np.ones(len(train_x))])
    reg = alpha * np.identity(x.shape[1])
    reg[-1, -1] = 0.0
    w = np.linalg.solve(x.T @ x + reg, x.T @ y)
    return w, classes


def _probe_accuracy(x: np.ndarray, labels: Sequence[str], w: np.ndarray, classes: Sequence[str]) -> float:
    if len(classes) < 2:
        return 1.0
    xx = np.column_stack([np.asarray(x, dtype=np.float64), np.ones(len(x))])
    pred = np.argmax(xx @ w, axis=1)
    class_index = {name: idx for idx, name in enumerate(classes)}
    truth = np.asarray([class_index[str(label)] for label in labels])
    return float(np.mean(pred == truth))


def _semantic_probe_report(
    target_train: np.ndarray,
    target_test: np.ndarray,
    mapped_test: np.ndarray,
    train_rows: Sequence[Mapping[str, Any]],
    test_rows: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
    label_names = sorted(set.intersection(*(set(row["labels"].keys()) for row in train_rows)))
    report: Dict[str, Any] = {}
    mapped_scores = []
    target_scores = []
    for name in label_names:
        train_labels = [str(row["labels"][name]) for row in train_rows]
        test_labels = [str(row["labels"][name]) for row in test_rows]
        w, classes = _fit_probe(target_train, train_labels)
        target_acc = _probe_accuracy(target_test, test_labels, w, classes)
        mapped_acc = _probe_accuracy(mapped_test, test_labels, w, classes)
        retention = mapped_acc / target_acc if target_acc > 1e-12 else 0.0
        report[name] = {
            "classes": len(classes),
            "target_accuracy": target_acc,
            "mapped_source_accuracy": mapped_acc,
            "retention_ratio": retention,
        }
        target_scores.append(target_acc)
        mapped_scores.append(mapped_acc)
    report["summary"] = {
        "target_accuracy_mean": float(np.mean(target_scores)) if target_scores else 0.0,
        "mapped_source_accuracy_mean": float(np.mean(mapped_scores)) if mapped_scores else 0.0,
        "retention_ratio_mean": float(np.mean([report[n]["retention_ratio"] for n in label_names])) if label_names else 0.0,
    }
    return report


def _apply_map_batch(tmap: TransportMap, vectors: np.ndarray) -> np.ndarray:
    """Apply an immutable map to a batch while verifying its digest once."""
    if tmap.compute_digest() != tmap.map_digest:
        raise ValueError("ERR_HETERO_MAP_DIGEST")
    arr = np.asarray(vectors, dtype=np.float64)
    if arr.ndim != 2 or not np.isfinite(arr).all():
        raise ValueError("ERR_HETERO_MAP_BATCH")
    if tmap.algorithm == "nonlinear-elm":
        hidden = np.maximum(0.0, arr @ tmap.elm_W_in + tmap.elm_b_in)
        mapped = hidden @ tmap.R + tmap.t
    else:
        mapped = arr @ tmap.R + tmap.t
    if tmap.normalization_policy == "unit":
        mapped = _unit_rows(mapped)
    return mapped


def _fit_map_candidates(source_train: np.ndarray, target_train: np.ndarray, source_val: np.ndarray, target_val: np.ndarray, source_digest: str, target_digest: str, include_elm: bool) -> Tuple[TransportMap, List[Dict[str, Any]]]:
    candidates: List[Tuple[str, TransportMap]] = []
    candidates.append(("procrustes", TransportMap.fit_procrustes(source_train, target_train, source_digest, target_digest)))
    for alpha in (0.001, 0.01, 0.1, 1.0, 10.0):
        candidates.append((f"ridge:{alpha:g}", TransportMap.fit_ridge(source_train, target_train, source_digest, target_digest, alpha=alpha)))
    if include_elm:
        for alpha in (0.1, 1.0):
            candidates.append((f"elm256:{alpha:g}", TransportMap.fit_nonlinear_elm(source_train, target_train, source_digest, target_digest, hidden_dim=256, alpha=alpha, seed=1500)))

    scored: List[Tuple[float, str, TransportMap, Dict[str, Any]]] = []
    for name, tmap in candidates:
        mapped = _apply_map_batch(tmap, source_val)
        metrics = _retrieval_metrics(mapped, target_val)
        score = metrics["paired_cosine_mean"] + 0.20 * metrics["mrr"] + 0.05 * metrics["top5"]
        entry = {"candidate": name, "score": float(score), **metrics, "map_digest": tmap.map_digest}
        scored.append((score, name, tmap, entry))
    scored.sort(key=lambda item: item[0], reverse=True)
    return scored[0][2], [item[3] for item in scored]


def _gate_artifacts(target_train: np.ndarray, target_validation: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float, float]:
    train = np.asarray(target_train, dtype=np.float64)
    mean = np.mean(train, axis=0)
    centered = train - mean
    _, _, vt = np.linalg.svd(centered, full_matrices=False)
    rank = min(64, vt.shape[0])
    components = vt[:rank]

    def residuals(x: np.ndarray) -> np.ndarray:
        diff = x - mean
        proj = (diff @ components.T) @ components
        return np.linalg.norm(diff - proj, axis=1)

    residual_sample = np.concatenate([residuals(train), residuals(np.asarray(target_validation, dtype=np.float64))])
    residual_ceiling = float(max(0.05, np.percentile(residual_sample, 99) * 1.10))

    variances = np.var(train, axis=0, ddof=1)
    floor = max(1e-6, float(np.median(variances)) * 0.05)
    covariance = np.diag(np.maximum(variances, floor))

    # Mirror the validator's shrinkage formula to derive a measured ceiling.
    gamma = 0.2
    tr_scaled = float(np.trace(covariance)) / float(train.shape[1])
    shrunk = (1.0 - gamma) * covariance + gamma * tr_scaled * np.eye(train.shape[1])
    inv = np.linalg.inv(shrunk)
    sample = np.vstack([train, target_validation])
    diffs = sample - mean
    dists = np.sqrt(np.maximum(0.0, np.einsum("bi,ij,bj->b", diffs, inv, diffs)))
    mahalanobis_ceiling = float(max(3.5, np.percentile(dists, 99) * 1.10))
    return components, mean, covariance, residual_ceiling, mahalanobis_ceiling


def _no_expansion_digest(side: str, model_revision: str) -> str:
    return compute_json_artifact_digest("expansion_adapter", {
        "schema": "braid.expansion-adapter.none.v1",
        "side": side,
        "model_revision": model_revision,
        "status": "not_implemented",
        "reason": "384D target-space transfer is measured directly; generative soft-prefix expansion is a separate claim",
    })


def calibrate_route(
    *,
    rows: Sequence[Mapping[str, Any]],
    source_raw: np.ndarray,
    target_raw: np.ndarray,
    source_model: str,
    target_model: str,
    output_dir: Path,
    corpus_sha256: str,
    include_elm: bool = False,
    sender_node_id: str = "node:intersignal:atlas-a",
    receiver_node_id: str = "node:intersignal:atlas-b",
    signer_key_id: str = "ed25519:atlas-a:2026-01",
    source_model_digest: str | None = None,
    target_model_digest: str | None = None,
    same_space_identity: bool = False,
) -> Dict[str, Any]:
    """Fit adapters/map on train only, select on validation, report held-out test."""
    source_raw = np.asarray(source_raw, dtype=np.float64)
    target_raw = np.asarray(target_raw, dtype=np.float64)
    if source_raw.shape[0] != len(rows) or target_raw.shape[0] != len(rows):
        raise ValueError("ERR_HETERO_PAIR_COUNT")
    if same_space_identity:
        if source_model != target_model:
            raise ValueError("ERR_SAME_SPACE_MODEL_TAG")
        if not source_model_digest or source_model_digest != target_model_digest:
            raise ValueError("ERR_SAME_SPACE_MODEL_DIGEST")
        if source_raw.shape != target_raw.shape or not np.array_equal(source_raw, target_raw):
            raise ValueError("ERR_SAME_SPACE_EMBEDDING_MISMATCH")

    train_idx = _split_indices(rows, "train")
    val_idx = _split_indices(rows, "validation")
    test_idx = _split_indices(rows, "test")
    if min(len(train_idx), len(val_idx), len(test_idx)) <= 0 or len(train_idx) <= BRAID_DIMENSION:
        raise ValueError(f"ERR_HETERO_SPLITS:{len(train_idx)}:{len(val_idx)}:{len(test_idx)}")

    if source_raw.shape[1] == BRAID_DIMENSION:
        source_adapter = ProjectionAdapter(
            mean=np.zeros(BRAID_DIMENSION), components=np.eye(BRAID_DIMENSION),
            model_revision=source_model, adapter_id=f"ollama-embed384:{_slug(source_model)}"
        )
    else:
        source_adapter = ProjectionAdapter.fit(source_raw[train_idx], model_revision=source_model, adapter_id=f"pca384:{_slug(source_model)}")
    if target_raw.shape[1] == BRAID_DIMENSION:
        target_adapter = ProjectionAdapter(
            mean=np.zeros(BRAID_DIMENSION), components=np.eye(BRAID_DIMENSION),
            model_revision=target_model, adapter_id=f"ollama-embed384:{_slug(target_model)}"
        )
    else:
        target_adapter = ProjectionAdapter.fit(target_raw[train_idx], model_revision=target_model, adapter_id=f"pca384:{_slug(target_model)}")

    source_384 = source_adapter.transform(source_raw)
    target_384 = target_adapter.transform(target_raw)

    source_space = RepresentationSpace(
        model_revision=source_model,
        layer="ollama:/api/embed",
        pooling="ollama_embedding",
        dimension=BRAID_DIMENSION,
        dtype="float32",
        normalization="unit",
        adapter_id=source_adapter.adapter_id,
        adapter_digest=source_adapter.digest,
        tokenizer_hash=(f"ollama:{source_model_digest}" if source_model_digest else "provider_bound"),
        semantic_label="heterogeneous_semantic_state",
    )
    target_space = RepresentationSpace(
        model_revision=target_model,
        layer="ollama:/api/embed",
        pooling="ollama_embedding",
        dimension=BRAID_DIMENSION,
        dtype="float32",
        normalization="unit",
        adapter_id=target_adapter.adapter_id,
        adapter_digest=target_adapter.digest,
        tokenizer_hash=(f"ollama:{target_model_digest}" if target_model_digest else "provider_bound"),
        semantic_label="heterogeneous_semantic_state",
    )

    if same_space_identity:
        tmap = TransportMap(
            algorithm="procrustes",
            rotation_matrix=np.eye(BRAID_DIMENSION),
            translation_vector=np.zeros(BRAID_DIMENSION),
            source_space_digest=source_space.compute_digest(),
            target_space_digest=target_space.compute_digest(),
            normalization_policy="unit",
        )
        candidate_report = {
            "selected": "identity",
            "reason": "exact_model_digest_and_representation_match",
        }
    else:
        tmap, candidate_report = _fit_map_candidates(
            source_384[train_idx], target_384[train_idx],
            source_384[val_idx], target_384[val_idx],
            source_space.compute_digest(), target_space.compute_digest(), include_elm,
        )

    mapped_test = _apply_map_batch(tmap, source_384[test_idx])
    mapped_validation = _apply_map_batch(tmap, source_384[val_idx])
    baseline_test = _retrieval_metrics(source_384[test_idx], target_384[test_idx])
    mapped_metrics = _retrieval_metrics(mapped_test, target_384[test_idx])

    train_rows = [rows[int(i)] for i in train_idx]
    test_rows = [rows[int(i)] for i in test_idx]
    probes = _semantic_probe_report(
        target_384[train_idx], target_384[test_idx], mapped_test, train_rows, test_rows,
    )

    pca_components, gate_mean, covariance, residual_ceiling, mahalanobis_ceiling = _gate_artifacts(
        target_384[train_idx], target_384[val_idx]
    )

    # Route promotion is empirical and deliberately narrow. Absolute cosine is
    # not used as a universal semantic law; the gate asks for improvement over
    # the unaligned baseline plus receiver-local behavioral-probe retention.
    cosine_gain = mapped_metrics["paired_cosine_mean"] - baseline_test["paired_cosine_mean"]
    mrr_gain = mapped_metrics["mrr"] - baseline_test["mrr"]
    probe_summary = probes["summary"]
    if same_space_identity:
        promotion_criteria = {
            "route_kind": "same_space_identity",
            "paired_cosine_min": 0.999,
            "mrr_min": 0.999,
            "exact_model_digest_required": True,
        }
        promotion_passed = bool(
            mapped_metrics["paired_cosine_mean"] >= promotion_criteria["paired_cosine_min"]
            and mapped_metrics["mrr"] >= promotion_criteria["mrr_min"]
            and source_model_digest == target_model_digest
        )
    else:
        promotion_criteria = {
            "paired_cosine_gain_min": 0.05,
            "mrr_gain_min": 0.10,
            "mapped_probe_accuracy_min": 0.70,
            "probe_retention_ratio_min": 0.85,
        }
        promotion_passed = bool(
            cosine_gain >= promotion_criteria["paired_cosine_gain_min"]
            and mrr_gain >= promotion_criteria["mrr_gain_min"]
            and probe_summary["mapped_source_accuracy_mean"] >= promotion_criteria["mapped_probe_accuracy_min"]
            and probe_summary["retention_ratio_mean"] >= promotion_criteria["probe_retention_ratio_min"]
        )

    source_slug = _slug(source_model)
    target_slug = _slug(target_model)
    route_id = f"route_{source_slug}_to_{target_slug}_{tmap.map_digest[:10]}"
    source_space_id = f"space_{source_slug}_{source_space.compute_digest()[:10]}"
    target_space_id = f"space_{target_slug}_{target_space.compute_digest()[:10]}"
    map_id = f"map_{tmap.map_digest[:16]}"

    # A target-space probe artifact is bound into the route contract. It is not
    # itself authority and does not substitute for the held-out evaluation.
    probe_vec = pca_components[0]
    probe_vec = probe_vec / np.linalg.norm(probe_vec)
    feature_spec = FeatureSpec(
        feature_spec_id=f"spec_{tmap.map_digest[:12]}",
        target_space_digest=target_space.compute_digest(),
        probes={"target_principal_direction": probe_vec.tolist()},
        weights={"target_principal_direction": 1.0},
        aggregate_threshold=1.25,
        per_probe_thresholds={"target_principal_direction": 1.50},
        version=__version__,
    )

    canonical_space_spec_digest = compute_json_artifact_digest("canonical_space_spec", {
        "schema": "braid.canonical-space.v1",
        "dimension": BRAID_DIMENSION,
        "dtype": "float32",
        "normalization": "unit",
        "semantics": "route_specific_measured",
    })
    quantization_spec_digest = compute_json_artifact_digest("quantization_spec", {
        "schema": "braid.quantization.v1",
        "wire_encoding": "ieee754-binary16-le",
        "source_runtime_dtype": "float32",
        "dimension": BRAID_DIMENSION,
    })

    source_expansion_digest = _no_expansion_digest("source", source_model)
    target_expansion_digest = _no_expansion_digest("target", target_model)
    route_contract = RouteContract(
        route_id=route_id,
        sender_node_id=sender_node_id,
        receiver_node_id=receiver_node_id,
        signer_key_id=signer_key_id,
        source_space_id=source_space_id,
        target_space_id=target_space_id,
        transport_map_id=map_id,
        feature_spec_id=feature_spec.feature_spec_id,
        source_space_digest=source_space.compute_digest(),
        target_space_digest=target_space.compute_digest(),
        source_extraction_adapter_digest=source_adapter.digest,
        source_expansion_adapter_digest=source_expansion_digest,
        target_extraction_adapter_digest=target_adapter.digest,
        target_expansion_adapter_digest=target_expansion_digest,
        transport_map_digest=tmap.map_digest,
        feature_spec_digest=feature_spec.compute_spec_digest(),
        canonical_space_spec_digest=canonical_space_spec_digest,
        quantization_spec_digest=quantization_spec_digest,
        subspace_residual_ceiling=residual_ceiling,
        mahalanobis_ood_ceiling=mahalanobis_ceiling,
        max_ttl_s=3600,
        max_clock_skew_s=60,
        max_age_s=1800,
    )

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    arrays = {
        "source_adapter_mean.npy": source_adapter.mean,
        "source_adapter_components.npy": source_adapter.components,
        "target_adapter_mean.npy": target_adapter.mean,
        "target_adapter_components.npy": target_adapter.components,
        "transport_R.npy": tmap.R,
        "transport_t.npy": tmap.t,
        "target_gate_pca_components.npy": pca_components,
        "target_gate_mean.npy": gate_mean,
        "target_gate_covariance.npy": covariance,
    }
    if tmap.elm_W_in is not None:
        arrays["transport_elm_W_in.npy"] = tmap.elm_W_in
    if tmap.elm_b_in is not None:
        arrays["transport_elm_b_in.npy"] = tmap.elm_b_in

    artifact_hashes: Dict[str, str] = {}
    for name, arr in arrays.items():
        path = output_dir / name
        with path.open("wb") as handle:
            np.save(handle, np.asarray(arr, dtype=np.float64), allow_pickle=False)
        artifact_hashes[name] = _file_sha256(path)

    report = {
        "schema": ROUTE_SCHEMA,
        "version": __version__,
        "status": "empirically_promotable" if promotion_passed else "research_only",
        "source_model": source_model,
        "target_model": target_model,
        "source_model_digest": source_model_digest,
        "target_model_digest": target_model_digest,
        "route_kind": "same_space_identity" if same_space_identity else "heterogeneous_calibrated",
        "backend": "ollama:/api/embed",
        "corpus_sha256": corpus_sha256,
        "paired_sample_count": len(rows),
        "splits": {"train": len(train_idx), "validation": len(val_idx), "test": len(test_idx)},
        "route": {
            "route_id": route_id,
            "sender_node_id": sender_node_id,
            "receiver_node_id": receiver_node_id,
            "signer_key_id": signer_key_id,
            "source_space_id": source_space_id,
            "target_space_id": target_space_id,
            "transport_map_id": map_id,
            "feature_spec_id": feature_spec.feature_spec_id,
            "source_space": source_space.to_dict(),
            "target_space": target_space.to_dict(),
            "source_space_digest": source_space.compute_digest(),
            "target_space_digest": target_space.compute_digest(),
            "source_extraction_adapter_digest": source_adapter.digest,
            "source_expansion_adapter_digest": source_expansion_digest,
            "target_extraction_adapter_digest": target_adapter.digest,
            "target_expansion_adapter_digest": target_expansion_digest,
            "transport_map_digest": tmap.map_digest,
            "feature_spec": feature_spec.to_dict() if hasattr(feature_spec, "to_dict") else {
                "feature_spec_id": feature_spec.feature_spec_id,
                "target_space_digest": feature_spec.target_space_digest,
                "probes": {k: list(v) for k, v in feature_spec.probes.items()},
                "weights": dict(feature_spec.weights),
                "aggregate_threshold": feature_spec.aggregate_threshold,
                "per_probe_thresholds": dict(feature_spec.per_probe_thresholds),
                "version": feature_spec.version,
            },
            "feature_spec_digest": feature_spec.compute_spec_digest(),
            "canonical_space_spec_digest": canonical_space_spec_digest,
            "quantization_spec_digest": quantization_spec_digest,
            "route_contract_digest": route_contract.route_contract_digest,
            "subspace_residual_ceiling": residual_ceiling,
            "mahalanobis_ood_ceiling": mahalanobis_ceiling,
            "max_ttl_s": 3600,
            "max_clock_skew_s": 60,
            "max_age_s": 1800,
        },
        "transport_map": {
            "algorithm": tmap.algorithm,
            "map_digest": tmap.map_digest,
            "normalization_policy": tmap.normalization_policy,
            "candidate_selection": candidate_report,
        },
        "held_out_test": {
            "baseline_unaligned": baseline_test,
            "mapped": mapped_metrics,
            "paired_cosine_gain": float(cosine_gain),
            "mrr_gain": float(mrr_gain),
            "semantic_probes": probes,
        },
        "promotion": {"passed": promotion_passed, "criteria": promotion_criteria},
        "gate_artifacts": {
            "pca_rank": int(pca_components.shape[0]),
            "subspace_residual_ceiling": residual_ceiling,
            "mahalanobis_ood_ceiling": mahalanobis_ceiling,
        },
        "artifacts": artifact_hashes,
        "claims": {
            "heterogeneous_route_measured": not same_space_identity,
            "same_space_identity_verified": same_space_identity,
            "held_out_test_used": True,
            "generative_soft_prefix_expansion": False,
            "semantic_evidence_grants_authority": False,
        },
    }
    route_path = output_dir / "route.json"
    route_path.write_bytes(jcs_serialize(report))
    report["route_json_sha256"] = _file_sha256(route_path)
    return report


def load_route_package(path: Path) -> Dict[str, Any]:
    root = Path(path)
    route_path = root / "route.json"
    report = json.loads(route_path.read_text(encoding="utf-8"))
    if report.get("schema") != ROUTE_SCHEMA:
        raise ValueError("ERR_HETERO_ROUTE_SCHEMA")
    artifacts = report.get("artifacts", {})
    arrays: Dict[str, np.ndarray] = {}
    for name, expected in artifacts.items():
        artifact_path = root / name
        if _file_sha256(artifact_path) != expected:
            raise ValueError(f"ERR_HETERO_ROUTE_ARTIFACT_DIGEST:{name}")
        arrays[name] = np.load(artifact_path, allow_pickle=False)
    report["_root"] = str(root)
    report["_arrays"] = arrays
    return report


def route_source_adapter(package: Mapping[str, Any]) -> ProjectionAdapter:
    arrays = package["_arrays"]
    route = package["route"]
    source_space = route["source_space"]
    adapter = ProjectionAdapter(
        mean=arrays["source_adapter_mean.npy"],
        components=arrays["source_adapter_components.npy"],
        adapter_id=source_space["adapter_id"],
        model_revision=source_space["model_revision"],
    )
    if adapter.digest != route["source_extraction_adapter_digest"]:
        raise ValueError("ERR_HETERO_SOURCE_ADAPTER_DIGEST")
    return adapter


def create_validator_from_route_package(package_path: Path, public_key_hex: str, ledger_path: Path | str) -> Tuple[BraidValidator, TrustedRegistry, ReplayLedger, Dict[str, Any]]:
    package = load_route_package(package_path)
    if package.get("status") != "empirically_promotable":
        raise ValueError("ERR_HETERO_ROUTE_NOT_PROMOTABLE")
    route_meta = package["route"]
    arrays = package["_arrays"]

    source_space = RepresentationSpace.from_strict_dict(route_meta["source_space"])
    target_space = RepresentationSpace.from_strict_dict(route_meta["target_space"])
    map_meta = package["transport_map"]
    tmap = TransportMap(
        algorithm=map_meta["algorithm"],
        rotation_matrix=arrays["transport_R.npy"],
        translation_vector=arrays["transport_t.npy"],
        source_space_digest=route_meta["source_space_digest"],
        target_space_digest=route_meta["target_space_digest"],
        normalization_policy=map_meta.get("normalization_policy", "unit"),
        map_digest=route_meta["transport_map_digest"],
        elm_W_in=arrays.get("transport_elm_W_in.npy"),
        elm_b_in=arrays.get("transport_elm_b_in.npy"),
    )
    feature_meta = route_meta["feature_spec"]
    feature_spec = FeatureSpec(
        feature_spec_id=feature_meta["feature_spec_id"],
        target_space_digest=feature_meta["target_space_digest"],
        probes=feature_meta["probes"],
        weights=feature_meta["weights"],
        aggregate_threshold=feature_meta["aggregate_threshold"],
        per_probe_thresholds=feature_meta["per_probe_thresholds"],
        version=feature_meta.get("version", "1.5.2"),
    )
    route = RouteContract(
        route_id=route_meta["route_id"],
        sender_node_id=route_meta["sender_node_id"],
        receiver_node_id=route_meta["receiver_node_id"],
        signer_key_id=route_meta["signer_key_id"],
        source_space_id=route_meta["source_space_id"],
        target_space_id=route_meta["target_space_id"],
        transport_map_id=route_meta["transport_map_id"],
        feature_spec_id=route_meta["feature_spec_id"],
        source_space_digest=route_meta["source_space_digest"],
        target_space_digest=route_meta["target_space_digest"],
        source_extraction_adapter_digest=route_meta["source_extraction_adapter_digest"],
        source_expansion_adapter_digest=route_meta["source_expansion_adapter_digest"],
        target_extraction_adapter_digest=route_meta["target_extraction_adapter_digest"],
        target_expansion_adapter_digest=route_meta["target_expansion_adapter_digest"],
        transport_map_digest=route_meta["transport_map_digest"],
        feature_spec_digest=route_meta["feature_spec_digest"],
        canonical_space_spec_digest=route_meta["canonical_space_spec_digest"],
        quantization_spec_digest=route_meta["quantization_spec_digest"],
        subspace_residual_ceiling=route_meta["subspace_residual_ceiling"],
        mahalanobis_ood_ceiling=route_meta["mahalanobis_ood_ceiling"],
        max_ttl_s=route_meta["max_ttl_s"],
        max_clock_skew_s=route_meta["max_clock_skew_s"],
        max_age_s=route_meta["max_age_s"],
    )
    if route.route_contract_digest != route_meta["route_contract_digest"]:
        raise ValueError("ERR_HETERO_ROUTE_CONTRACT_DIGEST")

    registry = TrustedRegistry()
    registry.register_signer(AuthorizedSigner(route.signer_key_id, public_key_hex, authorized_route_ids=[route.route_id]))
    registry.register_source_space(route.source_space_id, source_space)
    registry.register_target_space(route.target_space_id, target_space)
    registry.register_transport_map(route.transport_map_id, tmap)
    registry.register_feature_spec(route.feature_spec_id, feature_spec)
    registry.register_route(route)
    registry._pca_models[route.route_id] = PCAModel(
        principal_components=arrays["target_gate_pca_components.npy"],
        mean_vector=arrays["target_gate_mean.npy"],
    )
    registry._cov_models[route.route_id] = CovarianceModel(
        covariance_matrix=arrays["target_gate_covariance.npy"],
        mean_vector=arrays["target_gate_mean.npy"],
    )
    registry.set_local_policy(route.route_id, {"refund_max": 50.0, "capability_ref": "cap_ref_8f9a2b"})
    registry.freeze_registry()

    ledger = ReplayLedger(db_path=str(ledger_path))
    validator = BraidValidator(registry=registry, ledger=ledger, local_node_id=route.receiver_node_id)
    return validator, registry, ledger, package


def create_manifest_for_route(package: Mapping[str, Any], *, session_id: str, sequence_num: int = 1, predecessor_object_digest: str = "0" * 64, capability_ref: str = "cap_ref_8f9a2b") -> Dict[str, Any]:
    import time
    route = package["route"]
    now = int(time.time())
    return {
        "protocol_version": "1.4",
        "message_type": "state_handoff",
        "signature_algorithm": "Ed25519",
        "digest_algorithm": "SHA-256",
        "sender_node_id": route["sender_node_id"],
        "receiver_node_id": route["receiver_node_id"],
        "signer_key_id": route["signer_key_id"],
        "route_id": route["route_id"],
        "session_id": session_id,
        "sequence_num": int(sequence_num),
        "issued_at": now,
        "expires_at": now + min(300, int(route["max_ttl_s"])),
        "predecessor_object_digest": predecessor_object_digest,
        "vector_encoding": "ieee754-binary16-le",
        "vector_length": BRAID_DIMENSION,
        "payload_digest": "0" * 64,
        "source_space_digest": route["source_space_digest"],
        "target_space_digest": route["target_space_digest"],
        "source_extraction_adapter_digest": route["source_extraction_adapter_digest"],
        "source_expansion_adapter_digest": route["source_expansion_adapter_digest"],
        "target_extraction_adapter_digest": route["target_extraction_adapter_digest"],
        "target_expansion_adapter_digest": route["target_expansion_adapter_digest"],
        "transport_map_digest": route["transport_map_digest"],
        "feature_spec_digest": route["feature_spec_digest"],
        "canonical_space_spec_digest": route["canonical_space_spec_digest"],
        "quantization_spec_digest": route["quantization_spec_digest"],
        "route_contract_digest": route["route_contract_digest"],
        "subject_ref": None,
        "capability_ref": capability_ref,
        "requested_constraints": {"refund_max": 50.0},
        "extensions": {
            "heterogeneous_semantic_route": True,
            "route_status": package.get("status", "research_only"),
        },
    }


def source_text_to_braid_vector(package: Mapping[str, Any], text: str, client: OllamaEmbeddingClient) -> np.ndarray:
    source_model = str(package["source_model"])
    raw = client.embed(source_model, [text], batch_size=1)[0]
    adapter = route_source_adapter(package)
    return np.asarray(adapter.transform(raw), dtype=np.float32)


def build_frame_from_text(package_path: Path, text: str, signing_key: Any, *, ollama_url: str = DEFAULT_OLLAMA_URL, session_id: str | None = None) -> Tuple[BraidFrame, bytes, np.ndarray, Dict[str, Any]]:
    """Build a signed route-space frame with an inline Semantic Capsule.

    The 384D payload remains source-route evidence. Heterogeneous receivers do
    not translate its coordinates; they re-embed the explicit capsule locally.
    """
    import uuid
    package = load_route_package(package_path)
    if package.get("status") != "empirically_promotable":
        raise ValueError("ERR_HETERO_ROUTE_NOT_PROMOTABLE")
    client = OllamaEmbeddingClient(ollama_url)
    source_vector = source_text_to_braid_vector(package, text, client)
    source_model = str(package["source_model"])
    source_digest = OllamaClient(ollama_url).model_digest(source_model)
    if source_digest != package.get("source_model_digest"):
        raise ValueError("ERR_OLLAMA_SOURCE_EMBED_DIGEST")
    manifest = create_manifest_for_route(package, session_id=session_id or str(uuid.uuid4()))
    capsule = build_inline_capsule(
        text,
        source_embedding_model=source_model,
        source_embedding_model_digest=source_digest,
        vector_payload_digest=capsule_payload_digest_for_vector(source_vector),
    )
    attach_semantic_capsule(manifest, capsule)
    frame = BraidFrame(manifest, source_vector, signer_private_key=signing_key)
    return frame, frame.to_bytes(), source_vector, package



def build_frame_from_legend(
    package_path: Path,
    legend: Mapping[str, Any],
    signing_key: Any,
    *,
    source_completion_model: str,
    ollama_url: str = DEFAULT_OLLAMA_URL,
    session_id: str | None = None,
) -> Tuple[BraidFrame, bytes, np.ndarray, Dict[str, Any]]:
    """Encode a validated signed Legend into source-space 384D state.

    The completion model creates the Legend outside this function. The route's
    source embedding model encodes the canonical semantic Legend view. The
    signed manifest carries the full bounded Legend plus explicit Ollama adapter
    metadata. No generative hidden-state injection is claimed.
    """
    import uuid

    package = load_route_package(package_path)
    if package.get("status") != "empirically_promotable":
        raise ValueError("ERR_HETERO_ROUTE_NOT_PROMOTABLE")
    normalized_legend = validate_legend(legend)
    if normalized_legend["generator"]["model"] != source_completion_model:
        raise ValueError("ERR_OLLAMA_COMPLETION_MODEL_PROVENANCE")
    client = OllamaClient(ollama_url)
    source_model = str(package["source_model"])
    target_model = str(package["target_model"])
    source_model_digest = client.model_digest(source_model)
    if source_model_digest != package.get("source_model_digest"):
        raise ValueError("ERR_OLLAMA_SOURCE_EMBED_DIGEST")
    raw = client.embed(source_model, [legend_embedding_text(normalized_legend)], dimensions=BRAID_DIMENSION)[0]
    adapter = route_source_adapter(package)
    source_vector = np.asarray(adapter.transform(raw), dtype=np.float32)
    manifest = create_manifest_for_route(package, session_id=session_id or str(uuid.uuid4()))
    attach_ollama_extension(
        manifest,
        legend=normalized_legend,
        source_completion_model=source_completion_model,
        source_embedding_model=source_model,
        target_embedding_model=target_model,
        source_completion_model_digest=normalized_legend["generator"]["model_digest"],
        source_embedding_model_digest=str(package.get("source_model_digest") or ""),
        target_embedding_model_digest=str(package.get("target_model_digest") or ""),
    )
    capsule = build_legend_capsule(
        normalized_legend,
        source_embedding_model=source_model,
        source_embedding_model_digest=source_model_digest,
        vector_payload_digest=capsule_payload_digest_for_vector(source_vector),
    )
    attach_semantic_capsule(manifest, capsule)
    frame = BraidFrame(manifest, source_vector, signer_private_key=signing_key)
    return frame, frame.to_bytes(), source_vector, package

def calibrate_ollama_route(
    *,
    source_model: str,
    target_model: str,
    output_dir: Path,
    corpus_path: Path | None = None,
    ollama_url: str = DEFAULT_OLLAMA_URL,
    include_elm: bool = False,
    count: int = 768,
) -> Dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    if corpus_path is None:
        corpus_path = output_dir / "hetero_conformance_corpus.jsonl"
        corpus_info = write_corpus(corpus_path, build_conformance_corpus(count=count))
    else:
        corpus_path = Path(corpus_path)
        corpus_info = {"path": str(corpus_path), "sha256": _file_sha256(corpus_path)}
    rows = read_corpus(corpus_path)
    texts = [row["text"] for row in rows]
    client = OllamaClient(ollama_url)
    source_digest = client.model_digest(source_model)
    target_digest = client.model_digest(target_model)
    same_space_identity = source_model == target_model and source_digest == target_digest
    if same_space_identity:
        probe = client.embed(source_model, ["BRAID deterministic embedding probe", "BRAID deterministic embedding probe"], dimensions=BRAID_DIMENSION)
        determinism_cosine = float(np.dot(probe[0], probe[1]))
        if determinism_cosine < 0.999999:
            raise ValueError(f"ERR_SAME_SPACE_NONDETERMINISTIC:{determinism_cosine:.9f}")
        source_raw = client.embed(source_model, texts, dimensions=BRAID_DIMENSION)
        target_raw = source_raw.copy()
    else:
        determinism_cosine = None
        source_raw = client.embed(source_model, texts, dimensions=BRAID_DIMENSION)
        target_raw = client.embed(target_model, texts, dimensions=BRAID_DIMENSION)
    pair_info = save_paired_embeddings(
        output_dir / "paired_embeddings.npz", rows, source_model, target_model,
        source_raw, target_raw, corpus_info["sha256"],
    )
    report = calibrate_route(
        rows=rows,
        source_raw=source_raw,
        target_raw=target_raw,
        source_model=source_model,
        target_model=target_model,
        output_dir=output_dir,
        corpus_sha256=corpus_info["sha256"],
        include_elm=include_elm,
        source_model_digest=source_digest,
        target_model_digest=target_digest,
        same_space_identity=same_space_identity,
    )
    report["ollama_model_binding"] = {
        "source_model_digest": source_digest,
        "target_model_digest": target_digest,
        "same_space_identity": same_space_identity,
        "determinism_cosine": determinism_cosine,
    }
    report["corpus"] = corpus_info
    report["paired_embeddings"] = pair_info
    (output_dir / "calibration_report.json").write_text(json.dumps(report, sort_keys=True, indent=2), encoding="utf-8")
    return report
