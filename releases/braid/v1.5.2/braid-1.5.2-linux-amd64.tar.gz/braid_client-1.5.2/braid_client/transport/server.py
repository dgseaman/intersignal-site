from __future__ import annotations

import json
import logging
import os
import socket
import socketserver
import ssl
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .errors import BraidTransportError, PolicyError
from .policy import BindDecision, enforce_bind_policy
from .protocol import Ack, atomic_write, decode_transfer_from_socket, encode_ack, sanitize_filename
from .validator import run_validator

LOGGER = logging.getLogger("braid_transport")


def _ensure_private_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass


@dataclass(frozen=True)
class ReceiverConfig:
    bind: str = "127.0.0.1"
    port: int = 8745
    output_dir: Path = Path("braid-inbox")
    allow_lan: bool = False
    allow_public: bool = False
    insecure_public: bool = False
    tls_cert: Path | None = None
    tls_key: Path | None = None
    client_ca: Path | None = None
    require_client_cert: bool = False
    max_frame_bytes: int = 2 * 1024 * 1024
    socket_timeout_seconds: float = 10.0
    validator_timeout_seconds: float = 20.0
    validator_command: str | None = None
    retain_rejected: bool = True
    audit_log: Path | None = None
    receiver_callback: Callable[..., dict[str, Any]] | None = None

    @property
    def tls_enabled(self) -> bool:
        return self.tls_cert is not None and self.tls_key is not None


class _ThreadingTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class _Handler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server: "_ConfiguredServer" = self.server  # type: ignore[assignment]
        config = server.config
        sock: socket.socket = self.request
        sock.settimeout(config.socket_timeout_seconds)
        digest = ""
        try:
            metadata, payload = decode_transfer_from_socket(sock, config.max_frame_bytes)
            digest = metadata.transport_sha256
            safe_name = sanitize_filename(metadata.filename)
            if config.receiver_callback is not None:
                report = config.receiver_callback(
                    payload,
                    source_transport="network",
                    source_name=safe_name,
                    peer=self.client_address[0],
                )
                reported_accepted = bool(report.get("accepted"))
                stored = bool(report.get("stored"))
                committed = bool(report.get("phase_b_committed"))
                finality = str(report.get("finality") or "")
                invariant_accepted = committed and finality == "committed"
                if reported_accepted != invariant_accepted or committed != (finality == "committed"):
                    ack = Ack(stored, True, False, "ERR_FINALITY_INVARIANT", digest, "quarantine")
                else:
                    reason = str(report.get("reason") or ("RECEIVER_ACCEPTED" if invariant_accepted else "RECEIVER_REJECTED"))
                    if invariant_accepted:
                        destination = "accepted"
                    elif finality == "quarantined":
                        destination = "quarantine"
                    else:
                        destination = "rejected"
                    ack = Ack(stored, True, invariant_accepted, reason, digest, destination)
            else:
                stem = Path(safe_name).stem
                quarantine = config.output_dir / "quarantine" / f"{stem}-{digest[:12]}-{metadata.transfer_id[:8]}.brad"
                _ensure_private_dir(quarantine.parent)
                atomic_write(quarantine, payload)
                validation = run_validator(config.validator_command, quarantine, config.validator_timeout_seconds)
                if validation.ran and validation.accepted:
                    # External validators are non-authoritative prevalidation only.
                    # Without the receiver-owned Phase B transaction, the exact bytes
                    # remain quarantined and MUST NOT produce accepted=True.
                    ack = Ack(True, True, False, "VALIDATED_NOT_COMMITTED", digest, "quarantine")
                elif validation.ran:
                    destination = config.output_dir / "rejected" / quarantine.name
                    if config.retain_rejected:
                        _ensure_private_dir(destination.parent)
                        os.replace(quarantine, destination)
                    else:
                        quarantine.unlink(missing_ok=True)
                        destination = None
                    ack = Ack(config.retain_rejected, True, False, validation.reason, digest, "rejected" if destination else None)
                else:
                    ack = Ack(True, False, False, validation.reason, digest, "quarantine")
            server.audit(
                {
                    "accepted": ack.accepted,
                    "digest": digest,
                    "peer": self.client_address[0],
                    "reason": ack.reason,
                    "stored": ack.stored,
                    "transfer_id": metadata.transfer_id,
                    "validated": ack.validated,
                }
            )
            sock.sendall(encode_ack(ack))
        except (BraidTransportError, OSError, ValueError) as exc:
            reason = str(exc) or exc.__class__.__name__
            server.audit(
                {
                    "accepted": False,
                    "digest": digest,
                    "peer": self.client_address[0] if self.client_address else "unknown",
                    "reason": reason,
                    "stored": False,
                    "validated": False,
                }
            )
            try:
                sock.sendall(encode_ack(Ack(False, False, False, reason, digest)))
            except OSError:
                pass


class _ConfiguredServer(_ThreadingTCPServer):
    def __init__(self, address: tuple[str, int], config: ReceiverConfig, ssl_context: ssl.SSLContext | None):
        self.config = config
        self.ssl_context = ssl_context
        self._audit_lock = threading.Lock()
        super().__init__(address, _Handler)

    def get_request(self) -> tuple[socket.socket, Any]:
        sock, address = super().get_request()
        if self.ssl_context is not None:
            try:
                sock = self.ssl_context.wrap_socket(sock, server_side=True)
            except Exception:
                sock.close()
                raise
        return sock, address

    def audit(self, event: dict[str, Any]) -> None:
        event = {"ts_unix": int(time.time()), **event}
        LOGGER.info("%s", json.dumps(event, sort_keys=True))
        path = self.config.audit_log
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n"
        with self._audit_lock:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()


@dataclass
class TransportServer:
    config: ReceiverConfig
    decision: BindDecision = field(init=False)
    _server: _ConfiguredServer | None = field(default=None, init=False, repr=False)
    _thread: threading.Thread | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        if not (0 <= self.config.port <= 65535):
            raise PolicyError("ERR_PORT_RANGE")
        if self.config.max_frame_bytes <= 0:
            raise PolicyError("ERR_MAX_FRAME_BYTES")
        if (self.config.tls_cert is None) != (self.config.tls_key is None):
            raise PolicyError("ERR_TLS_CERT_KEY_PAIR_REQUIRED")
        if self.config.receiver_callback is not None and self.config.validator_command is not None:
            raise PolicyError("ERR_RECEIVER_CALLBACK_VALIDATOR_CONFLICT")
        self.decision = enforce_bind_policy(
            self.config.bind,
            allow_lan=self.config.allow_lan,
            allow_public=self.config.allow_public,
            tls_enabled=self.config.tls_enabled,
            insecure_public=self.config.insecure_public,
        )

    def _ssl_context(self) -> ssl.SSLContext | None:
        if not self.config.tls_enabled:
            return None
        assert self.config.tls_cert is not None and self.config.tls_key is not None
        context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.load_cert_chain(str(self.config.tls_cert), str(self.config.tls_key))
        if self.config.client_ca is not None:
            context.load_verify_locations(cafile=str(self.config.client_ca))
        if self.config.require_client_cert:
            if self.config.client_ca is None:
                raise PolicyError("ERR_CLIENT_CA_REQUIRED")
            context.verify_mode = ssl.CERT_REQUIRED
        return context

    @property
    def address(self) -> tuple[str, int]:
        if self._server is None:
            return (self.config.bind, self.config.port)
        host, port = self._server.server_address[:2]
        return str(host), int(port)

    def start(self) -> "TransportServer":
        if self._server is not None:
            return self
        _ensure_private_dir(self.config.output_dir)
        self._server = _ConfiguredServer((self.config.bind, self.config.port), self.config, self._ssl_context())
        self._thread = threading.Thread(target=self._server.serve_forever, name="braid-transport", daemon=True)
        self._thread.start()
        return self

    def serve_forever(self) -> None:
        _ensure_private_dir(self.config.output_dir)
        self._server = _ConfiguredServer((self.config.bind, self.config.port), self.config, self._ssl_context())
        self._server.serve_forever()

    def stop(self) -> None:
        if self._server is None:
            return
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._server = None
        self._thread = None

    def __enter__(self) -> "TransportServer":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()
