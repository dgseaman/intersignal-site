from braid_client.cli import main

raise SystemExit(main())
