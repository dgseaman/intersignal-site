"""Braid v1.5.2 integrated network transport.

This module transports opaque, already-signed .brad frame bytes. It does not
create, modify, re-sign, or semantically accept Braid frames.
"""

from braid_client import __version__

from .client import SendResult, send_frame
from .policy import BindScope, classify_bind_scope, enforce_bind_policy
from .server import ReceiverConfig, TransportServer

__all__ = [
    "BindScope",
    "ReceiverConfig",
    "SendResult",
    "TransportServer",
    "classify_bind_scope",
    "enforce_bind_policy",
    "send_frame",
]
