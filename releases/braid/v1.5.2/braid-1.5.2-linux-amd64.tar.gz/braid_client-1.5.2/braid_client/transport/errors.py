class BraidTransportError(Exception):
    """Base error for transport failures."""


class ProtocolError(BraidTransportError):
    """Malformed or unsupported wire data."""


class PolicyError(BraidTransportError):
    """Local bind or receiver policy rejected an operation."""


class ValidationError(BraidTransportError):
    """Receiver-owned validator rejected a frame."""
