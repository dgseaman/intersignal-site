"""Local-only environment detection for the Braid v1.5.2 front door."""
from __future__ import annotations

import importlib.util
import json
import os
import platform
import shlex
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from . import __version__
from .ollama_adapter import (
    OllamaClient, DEFAULT_OLLAMA_URL, _ollama_cloud_config_snapshot,
    has_ollama_remote_marker, is_explicit_cloud_model,
)


def default_workspace() -> Path:
    if platform.system() == "Darwin":
        return Path.home() / "Library" / "Application Support" / "Intersignal" / "Braid"
    return Path.home() / ".braid"


def _private_ipv4_candidates() -> list[str]:
    values: list[str] = []
    if platform.system() == "Darwin":
        for interface in ("en0", "en1", "en2", "bridge0"):
            try:
                proc = subprocess.run(
                    ["/usr/sbin/ipconfig", "getifaddr", interface],
                    capture_output=True, text=True, timeout=0.5, check=False,
                )
                value = proc.stdout.strip()
                if value:
                    values.append(value)
            except (OSError, subprocess.TimeoutExpired):
                pass
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            values.append(item[4][0])
    except OSError:
        pass
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect(("192.0.2.1", 9))
            values.append(sock.getsockname()[0])
        finally:
            sock.close()
    except OSError:
        pass

    unique: list[str] = []
    for value in values:
        if not value or value.startswith("127.") or value in unique:
            continue
        parts = value.split(".")
        if len(parts) != 4:
            continue
        try:
            nums = [int(x) for x in parts]
        except ValueError:
            continue
        is_private = (
            nums[0] == 10
            or (nums[0] == 172 and 16 <= nums[1] <= 31)
            or (nums[0] == 192 and nums[1] == 168)
            or (nums[0] == 169 and nums[1] == 254)
        )
        if is_private:
            unique.append(value)
    return unique


def _cli_argv() -> list[str]:
    """Return an invocation that is actually executable from this installation."""
    override = os.environ.get("BRAID_CLI_COMMAND", "").strip()
    if override:
        return [override]

    # Standalone Braid.app ships a console CLI beside the GUI executable.
    if getattr(sys, "frozen", False):
        executable = Path(sys.executable).resolve()
        sibling = executable.with_name("braid-client")
        if sibling.is_file() and os.access(sibling, os.X_OK):
            return [str(sibling)]
        return [str(executable)]

    argv0 = Path(sys.argv[0]).expanduser()
    if argv0.name == "braid-client" and argv0.exists():
        return [str(argv0.resolve())]
    discovered = shutil.which("braid-client")
    if discovered:
        return [discovered]
    return [sys.executable, "-m", "braid_client.cli"]


def _command(cli: list[str], *parts: str) -> str:
    return " ".join(shlex.quote(str(v)) for v in [*cli, *parts])


def _ollama_snapshot() -> dict[str, Any]:
    result: dict[str, Any] = {
        "endpoint": DEFAULT_OLLAMA_URL,
        "reachable": False,
        "models": [],
        "embedding_candidates": [],
        "completion_candidates": [],
        "rejected_cloud_models": [],
        "classification": "api_show_capabilities",
        "cloud_policy": _ollama_cloud_config_snapshot(),
    }
    try:
        client = OllamaClient(DEFAULT_OLLAMA_URL, timeout_seconds=0.9)
        tags = client.tags()
    except Exception as exc:
        result["error"] = str(exc)[:240]
        return result

    models: list[dict[str, Any]] = []
    embed_candidates: list[str] = []
    completion_candidates: list[str] = []
    rejected_cloud: list[str] = []
    # Keep first-launch responsive even on large or partially unhealthy Ollama libraries.
    # The tags request is already bounded by the client timeout; /api/show probes share
    # an additional wall-clock budget so one bad library cannot stall the front door.
    deadline = time.monotonic() + 2.5
    for item in tags[:32]:
        name = item.get("name") or item.get("model")
        digest = item.get("digest")
        if not isinstance(name, str):
            continue
        if is_explicit_cloud_model(name):
            rejected_cloud.append(name)
            models.append({"name": name, "digest": digest, "capabilities": [], "local_eligible": False, "reason": "explicit_cloud_model"})
            continue
        if has_ollama_remote_marker(item):
            rejected_cloud.append(name)
            models.append({"name": name, "digest": digest, "capabilities": [], "local_eligible": False, "reason": "ollama_remote_marker"})
            continue
        row: dict[str, Any] = {"name": name, "local_eligible": True}
        if isinstance(digest, str):
            row["digest"] = digest
        if time.monotonic() >= deadline:
            row["capabilities"] = []
            row["inspection_skipped"] = "autodetect_time_budget"
            models.append(row)
            continue
        try:
            info = client.show(name)
            if has_ollama_remote_marker(info):
                row["capabilities"] = []
                row["local_eligible"] = False
                row["reason"] = "ollama_remote_marker"
                rejected_cloud.append(name)
                models.append(row)
                continue
            caps = info.get("capabilities")
            caps = sorted({c for c in caps if isinstance(c, str)}) if isinstance(caps, list) else []
            row["capabilities"] = caps
            row["details"] = info.get("details") if isinstance(info.get("details"), dict) else {}
            if "embedding" in caps:
                embed_candidates.append(name)
            if "completion" in caps:
                completion_candidates.append(name)
        except Exception as exc:
            row["capabilities"] = []
            row["inspection_error"] = str(exc)[:160]
        models.append(row)
    result.update({
        "reachable": True,
        "models": models,
        "embedding_candidates": embed_candidates,
        "completion_candidates": completion_candidates,
        "rejected_cloud_models": rejected_cloud,
        "locality_claim": "Braid rejects explicit cloud names and Ollama-reported remote model/host markers; cloud-disable configuration is reported separately.",
    })
    return result


def detect_environment() -> dict[str, Any]:
    workspace = default_workspace()
    lan = _private_ipv4_candidates()
    ollama = _ollama_snapshot()
    embedding_model = (ollama.get("embedding_candidates") or [None])[0]
    completion_model = (ollama.get("completion_candidates") or [None])[0]
    lan_ip = lan[0] if lan else "127.0.0.1"
    cli = _cli_argv()
    route = workspace / "route"
    sender_key = workspace / "sender.key"
    sender_pub = workspace / "sender.pub"
    inbox = workspace / "inbox"
    capsule = workspace / "semantic-capsule.brad"

    commands = [
        {"label": "Local doctor", "command": _command(cli, "doctor")},
        {"label": "Open field UI", "command": _command(cli, "demo", "--port", "0")},
        {"label": "Show environment", "command": _command(cli, "environment")},
        {"label": "LAN discovery", "command": _command(cli, "discover", "--timeout", "3")},
    ]
    if embedding_model:
        qmodel = str(embedding_model)
        commands.extend([
            {
                "label": "Build exact source route",
                "command": _command(cli, "ollama-route", "--embed-model", qmodel, "--output-dir", str(route), "--count", "576"),
            },
            {
                "label": "Create Semantic Capsule",
                "command": _command(cli, "capsule-frame", "--route-package", str(route), "--text", "hello from Braid", "--signing-key", str(sender_key), "--output", str(capsule)),
            },
            {
                "label": "Receive Semantic Capsule on LAN",
                "command": _command(cli, "receive", "--trusted-key", str(sender_pub), "--route-package", str(route), "--bind", "0.0.0.0", "--allow-lan", "--port", "8745", "--output-dir", str(inbox), "--semantic-embed-model", qmodel),
            },
        ])
    if embedding_model:
        commands.append({
            "label": "Send capsule to this node",
            "command": _command(cli, "send", str(capsule), "--host", lan_ip, "--port", "8745"),
        })
    if completion_model:
        commands.append({"label": "Ollama readiness", "command": _command(cli, "ollama-doctor", "--model", str(completion_model), "--embed-model", str(embedding_model or "all-minilm:latest"))})

    return {
        "version": __version__,
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python": platform.python_version(),
            "python_executable": sys.executable,
            "hostname": socket.gethostname(),
        },
        "workspace": str(workspace),
        "lan": {"addresses": lan, "preferred": lan_ip, "receiver_port": 8745},
        "ollama": ollama,
        "camera": {
            "opencv_fallback": importlib.util.find_spec("cv2") is not None,
            "browser_camera_path": True,
            "policy": "native BarcodeDetector first; packaged loopback OpenCV fallback when present",
        },
        "ble": {"available": importlib.util.find_spec("bleak") is not None},
        "route_detected": route.is_dir() and (route / "route.json").is_file(),
        "key_detected": sender_key.is_file(),
        "cli": {"argv": cli, "display": _command(cli)},
        "commands": commands,
        "semantic_rule": "heterogeneous_reembedding_requires_signed_semantic_capsule",
        "bridge_semantic_invention": False,
        "generative_receiver_output_possible": True,
        "autodetect_is_local_only": True,
    }
