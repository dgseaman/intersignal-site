chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "ANALYZE_TEXT") {
    const analysis = analyzeSignal(msg.payload);
    alert(`Signal Score: ${analysis.score}\nFlags: ${analysis.flags.join(", ")}\nAction: ${analysis.action}`);
  }
});

function analyzeSignal(text) {
  const lower = text.toLowerCase();
  let score = 100;
  let flags = [];

  const redFlags = [
    { label: "Emotional bait", patterns: ["just checking in", "miss you"], weight: 25 },
    { label: "Nostalgia artifact request", patterns: ["photo", "video"], weight: 15 },
    { label: "Implied guilt trip", patterns: ["do you remember", "why did you"], weight: 20 },
    { label: "Urgency trap", patterns: ["can we talk", "please respond"], weight: 30 }
  ];

  redFlags.forEach(flag => {
    flag.patterns.forEach(pat => {
      if (lower.includes(pat)) {
        score -= flag.weight;
        flags.push(flag.label);
      }
    });
  });

  let action = "Engage with caution";
  if (score < 70) action = "Silence recommended";
  if (score < 40) action = "Block & Archive";

  return { score, flags, action };
}
