
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("scan").onclick = () => {
    const text = document.getElementById("input").value.toLowerCase();
    const result = analyzeSignal(text);
    document.getElementById("result").textContent =
      `Signal Score: ${result.score}, Flags: ${result.flags.join(', ')}, Action: ${result.action}`;
  };
});

function analyzeSignal(text) {
  let score = 100;
  let flags = [];
  const redFlags = [
    { label: "Emotional bait", patterns: ["just checking in", "miss you"], weight: 25 },
    { label: "Nostalgia artifact request", patterns: ["photo", "video"], weight: 15 },
    { label: "Implied guilt trip", patterns: ["do you remember", "why did you"], weight: 20 },
    { label: "Urgency trap", patterns: ["can we talk", "please respond"], weight: 30 }
  ];

  redFlags.forEach(flag => {
    flag.patterns.forEach(pat => {
      if (text.includes(pat)) {
        score -= flag.weight;
        flags.push(flag.label);
      }
    });
  });

  let action = "Engage with caution";
  if (score < 70) action = "Silence recommended";
  if (score < 40) action = "Block & Archive";

  return { score, flags, action };
}
