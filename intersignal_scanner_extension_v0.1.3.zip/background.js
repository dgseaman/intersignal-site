chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "scanText",
    title: "Scan with Intersignal",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "scanText") {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const text = window.getSelection().toString().toLowerCase();
        const result = (() => {
          let score = 100;
          let flags = [];
          const redFlags = [
            { label: "Emotional bait", patterns: ["just checking in", "miss you"], weight: 25 },
            { label: "Nostalgia artifact request", patterns: ["photo", "video"], weight: 15 },
            { label: "Implied guilt trip", patterns: ["do you remember", "why did you"], weight: 20 },
            { label: "Urgency trap", patterns: ["can we talk", "please respond"], weight: 30 }
          ];
          redFlags.forEach(flag => {
            flag.patterns.forEach(pat => {
              if (text.includes(pat)) {
                score -= flag.weight;
                flags.push(flag.label);
              }
            });
          });
          let action = "Engage with caution";
          if (score < 70) action = "Silence recommended";
          if (score < 40) action = "Block & Archive";
          return { score, flags, action };
        })();

        const oldHud = document.getElementById("intersignal-result-hud");
        if (oldHud) oldHud.remove();

        const hud = document.createElement("div");
        hud.id = "intersignal-result-hud";
        hud.style.position = "fixed";
        hud.style.top = "20px";
        hud.style.right = "20px";
        hud.style.backgroundColor = "#111";
        hud.style.color = "white";
        hud.style.padding = "12px 16px";
        hud.style.borderRadius = "10px";
        hud.style.boxShadow = "0 0 10px rgba(0,0,0,0.5)";
        hud.style.zIndex = 999999;
        hud.style.fontFamily = "monospace";
        hud.innerHTML = `
          <strong>∴ Intersignal Scan</strong><br>
          Signal Score: ${result.score}<br>
          Flags: ${result.flags.join(", ") || "None"}<br>
          Action: ${result.action}
        `;
        document.body.appendChild(hud);

        setTimeout(() => {
          if (hud && !hud.matches(':hover')) {
            hud.remove();
          }
        }, 8000);
      }
    });
  }
});
