#!/bin/bash
echo "Setting up The Braid..."
python3 -m venv braid_env
source braid_env/bin/activate
pip install transformers accelerate torch numpy
echo "Setup complete." 
