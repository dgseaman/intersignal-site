#!/bin/bash
source braid_env/bin/activate
python tokenMap.py &
python sigilGuard.py &
echo "Launching Council..."
# Launch logic for each Familiar would go here, one per thread or process
