(function () {
  function textOf(root) { return (root.innerText||'').replace(/\s+/g,' ').trim(); }
  function uniq(a){ return [...new Set(a)]; }
  function getShadowAnchors(root){ const out=[]; const w=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT); while(w.nextNode()){ const el=w.currentNode; if(el.shadowRoot) out.push(...el.shadowRoot.querySelectorAll('a[href]')); } return out; }
  const txt=textOf(document.body);
  const links=Array.from(document.querySelectorAll('a[href]')).map(a=>a.href);
  const shadowLinks=getShadowAnchors(document.documentElement).map(a=>a.href);
  const canonical=document.querySelector('link[rel=canonical]')?.href||'';
  const og=document.querySelector('meta[property=\"og:url\"]')?.content||'';
  const hosts=uniq(links.concat(shadowLinks,[canonical,og]).filter(Boolean).map(h=>{ try{return new URL(h,location.href).host}catch{return null} }).filter(Boolean));
  const hedges=(txt.match(/\b(might|could|may|reportedly|alleged|unconfirmed|sources say|appears|suggests)\b/gi)||[]).length;
  const quotes=(txt.match(/[“\"][^”\\"]+[”\"]/g)||[]).length;
  const toWords=s=>(s.toLowerCase().match(/\b[a-z]{4,}\b/g)||[]);
  const title=(document.title||'').toLowerCase(); const overlap=uniq(toWords(title)).filter(w=>toWords(txt).includes(w));
  const overlapScore=Math.min(1,overlap.length/8);
  const sourceClarity=Math.min(1,(hosts.length+Math.min(quotes,5))/8);
  const recency=/\b(20\d{2}|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(txt)?0.2:0;
  const integrityScore=Math.round(100*(0.55*sourceClarity+0.35*overlapScore+0.10*recency));
  const topics=[['AI/ML',/\b(ai|artificial intelligence|machine learning|model|neural|summarizer|openai|anthropic|google)\b/i],['Politics',/\b(president|congress|senate|election|policy|regulation|bill|court)\b/i],['Markets',/\b(stocks?|equities|etf|yield|basis|funding|futures|treasury|bond|dow|nasdaq|s&p)\b/i],['Metals',/\b(silver|gold|bullion|comex|spot|miners?|slv|gld)\b/i]];
  const topicTags=topics.filter(t=>t[1].test(txt)).map(t=>({type:'topic',label:t[0]})).slice(0,4);
  const bias=hedges>8?{type:'bias',label:'Heavy Hedging'}:hedges>3?{type:'bias',label:'Some Hedging'}:{type:'bias',label:'Low Hedging'};
  const source=hosts.length>=5?{type:'source',label:'Multi-source'}:hosts.length>=2?{type:'source',label:'Some Sources'}:{type:'source',label:'Thin Sourcing'};
  const drift=overlapScore>=0.75?{type:'neutral',label:'Strong Title Alignment'}:overlapScore>=0.40?{type:'neutral',label:'Moderate Alignment'}:{type:'neutral',label:'Possible Drift'};
  window.__ISIG_RESULT={ integrityScore, diagnostics:{distinctHosts:hosts.length,hosts:hosts.slice(0,12),quotes,hedges,titleOverlapTerms:overlap.slice(0,12)}, tags:[source,bias,drift,...topicTags] };
})();