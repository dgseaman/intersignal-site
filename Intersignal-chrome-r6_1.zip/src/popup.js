const btn=document.getElementById('run');
const banner=document.getElementById('banner');
const statusEl=document.getElementById('status');
const summaryEl=document.getElementById('summary');
const integrityEl=document.getElementById('integrity');
const scoreValEl=document.getElementById('score-val');
const tagsContainer=document.getElementById('tags');
function setStatus(m=''){ statusEl.textContent=m; console.log('[ISIG]',m); }
function showBanner(t){ banner.hidden=false; banner.textContent=t; }
function hideBanner(){ banner.hidden=true; banner.textContent=''; }
function renderTags(tags){ tagsContainer.innerHTML=''; (tags||[]).forEach(t=>{ const el=document.createElement('span'); el.className=`tag ${t.type}`; el.textContent=t.label; tagsContainer.appendChild(el); }); }
async function getActiveTab(){ const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); return tab; }
async function summarize(tabId){
  setStatus('Waiting for local model… (up to 60s)');
  hideBanner();
  const res = await chrome.tabs.sendMessage(tabId,{type:'ISIG_SUMMARIZE'});
  if(res?.error && /not ready|no summarizer/i.test(res.error)){ showBanner('Local summarizer model is still downloading or not exposed yet. Leave Chrome open and retry.'); }
  return res;
}
async function runIntegrity(tabId){ await chrome.scripting.executeScript({target:{tabId}, files:['src/integrity.js']}); const [{result}] = await chrome.scripting.executeScript({target:{tabId}, func:()=>window.__ISIG_RESULT||null}); return result; }
async function ensureMenu(){ try{ await chrome.runtime.sendMessage({type:'ISIG_BUILD_MENU'}); }catch{} }
btn.addEventListener('click', async()=>{
  try{
    await ensureMenu();
    const tab=await getActiveTab();
    setStatus('Summarizing on-device…');
    const sum=await summarize(tab.id);
    summaryEl.textContent = sum?.error ? ('Summarization failed: '+sum.error) : (sum?.summary||'(no summary)');
    setStatus('Scoring integrity…');
    const res=await runIntegrity(tab.id);
    if(res){ integrityEl.textContent=JSON.stringify(res.diagnostics,null,2); scoreValEl.textContent=String(res.integrityScore||'--'); renderTags(res.tags||[]); }
    setStatus('Done.');
  }catch(e){ console.error(e); setStatus('Error: '+(e?.message||String(e))); }
});