function buildMenu(){
  chrome.contextMenus.removeAll(()=>{
    chrome.contextMenus.create({ id:'isig_open_popup', title:'Intersignal: Summarize + Score This Page', contexts:['page'] });
  });
}
chrome.runtime.onInstalled.addListener(buildMenu);
chrome.runtime.onStartup.addListener(buildMenu);
chrome.runtime.onMessage.addListener((msg)=>{ if(msg && msg.type==='ISIG_BUILD_MENU') buildMenu(); });
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'isig_open_popup') return;
  if (chrome.action?.openPopup) { try { await chrome.action.openPopup(); } catch(e) {} }
});