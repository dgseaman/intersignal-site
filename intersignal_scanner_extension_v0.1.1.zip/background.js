chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "scanText",
    title: "Scan with Intersignal",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "scanText") {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: scanSelection,
    });
  }
});

function scanSelection() {
  const selectedText = window.getSelection().toString();
  chrome.runtime.sendMessage({ type: "ANALYZE_TEXT", payload: selectedText });
}