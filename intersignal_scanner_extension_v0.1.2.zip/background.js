chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "scanText",
    title: "Scan with Intersignal",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "scanText") {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const text = window.getSelection().toString().toLowerCase();
        const result = (() => {
          let score = 100;
          let flags = [];
          const redFlags = [
            { label: "Emotional bait", patterns: ["just checking in", "miss you"], weight: 25 },
            { label: "Nostalgia artifact request", patterns: ["photo", "video"], weight: 15 },
            { label: "Implied guilt trip", patterns: ["do you remember", "why did you"], weight: 20 },
            { label: "Urgency trap", patterns: ["can we talk", "please respond"], weight: 30 }
          ];
          redFlags.forEach(flag => {
            flag.patterns.forEach(pat => {
              if (text.includes(pat)) {
                score -= flag.weight;
                flags.push(flag.label);
              }
            });
          });
          let action = "Engage with caution";
          if (score < 70) action = "Silence recommended";
          if (score < 40) action = "Block & Archive";
          return { score, flags, action };
        })();
        console.log("[Intersignal Scan]");
        console.log("Signal Score:", result.score);
        console.log("Flags:", result.flags);
        console.log("Action:", result.action);
      }
    });
  }
});
