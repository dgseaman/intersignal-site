use std::fs::File;
use std::io::{Read, Write};
use std::path::Path;
use ed25519_dalek::{SigningKey, VerifyingKey, Signature, Signer, Verifier};
use rand::rngs::OsRng;

pub struct NodeIdentity {
    pub signing_key: SigningKey,
}

impl NodeIdentity {
    /// Load existing keypair from disk or generate a new one if not found
    pub fn load_or_create<P: AsRef<Path>>(key_path: P) -> Result<Self, String> {
        if key_path.as_ref().exists() {
            Self::load_from_disk(key_path)
        } else {
            let identity = Self::generate();
            identity.save_to_disk(key_path)?;
            Ok(identity)
        }
    }

    /// Generate a fresh Ed25519 keypair
    pub fn generate() -> Self {
        let mut csprng = OsRng;
        let signing_key = SigningKey::generate(&mut csprng);
        Self { signing_key }
    }

    /// Load the 32-byte private key from disk and rebuild the SigningKey
    fn load_from_disk<P: AsRef<Path>>(key_path: P) -> Result<Self, String> {
        let mut file = File::open(key_path).map_err(|e| e.to_string())?;
        let mut buffer = [0u8; 32];
        file.read_exact(&mut buffer).map_err(|e| e.to_string())?;
        let signing_key = SigningKey::from_bytes(&buffer);
        Ok(Self { signing_key })
    }

    /// Save the 32-byte private key bytes to disk (with restrictive permissions on Unix)
    fn save_to_disk<P: AsRef<Path>>(&self, key_path: P) -> Result<(), String> {
        let mut file = File::create(&key_path).map_err(|e| e.to_string())?;
        
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = file.metadata().map_err(|e| e.to_string())?.permissions();
            perms.set_mode(0o600); // Owner read/write only
            file.set_permissions(perms).map_err(|e| e.to_string())?;
        }

        let bytes = self.signing_key.to_bytes();
        file.write_all(&bytes).map_err(|e| e.to_string())?;
        Ok(())
    }

    /// Get the public verifying key
    pub fn public_key(&self) -> VerifyingKey {
        self.signing_key.verifying_key()
    }

    /// Sign an arbitrary message byte slice
    pub fn sign(&self, message: &[u8]) -> Signature {
        self.signing_key.sign(message)
    }

    /// Verify a signature using a public key
    pub fn verify(public_key: &VerifyingKey, message: &[u8], signature: &Signature) -> bool {
        public_key.verify(message, signature).is_ok()
    }
}
