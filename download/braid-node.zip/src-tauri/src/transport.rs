use std::net::SocketAddr;
use std::sync::Arc;
use tokio::net::UdpSocket;
use async_trait::async_trait;
use crate::protocol::{BraidTransport, BraidTransportError};

pub struct UdpTransport {
    pub socket: Arc<UdpSocket>,
}

impl UdpTransport {
    pub fn new(socket: UdpSocket) -> Self {
        Self {
            socket: Arc::new(socket),
        }
    }
}

#[async_trait]
impl BraidTransport for UdpTransport {
    async fn send_to(&self, bytes: &[u8], target: SocketAddr) -> Result<(), BraidTransportError> {
        self.socket.send_to(bytes, target).await
            .map_err(|e| BraidTransportError::Io(e.to_string()))?;
        Ok(())
    }

    async fn recv_from(&self) -> Result<(Vec<u8>, SocketAddr), BraidTransportError> {
        let mut buf = vec![0u8; 65535];
        let (size, src) = self.socket.recv_from(&mut buf).await
            .map_err(|e| BraidTransportError::Io(e.to_string()))?;
        Ok((buf[..size].to_vec(), src))
    }

    fn local_endpoint(&self) -> SocketAddr {
        self.socket.local_addr().unwrap_or_else(|_| "0.0.0.0:0".parse().unwrap())
    }

    fn transport_kind(&self) -> String {
        "UDP_Local_Mesh".to_string()
    }
}
