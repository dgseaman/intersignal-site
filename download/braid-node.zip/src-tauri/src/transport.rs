use std::net::SocketAddr;
use std::sync::Arc;
use tokio::net::UdpSocket;
use crate::protocol::BraidEnvelope;

pub trait BraidTransport {
    async fn send(&self, envelope: &BraidEnvelope, target: &SocketAddr) -> Result<(), String>;
    async fn receive(&self) -> Result<(BraidEnvelope, SocketAddr, usize), String>;
}

pub struct UdpTransport {
    pub socket: Arc<UdpSocket>,
}

impl UdpTransport {
    pub fn new(socket: UdpSocket) -> Self {
        Self {
            socket: Arc::new(socket),
        }
    }
}

impl BraidTransport for UdpTransport {
    async fn send(&self, envelope: &BraidEnvelope, target: &SocketAddr) -> Result<(), String> {
        let serialized = bincode::serialize(envelope).map_err(|e| e.to_string())?;
        
        // Enforce maximum packet size check on transmission
        if serialized.len() > crate::protocol::MAX_PACKET_SIZE {
            return Err(format!(
                "Serialized packet size {} exceeds limit {} bytes",
                serialized.len(),
                crate::protocol::MAX_PACKET_SIZE
            ));
        }

        self.socket.send_to(&serialized, target).await.map_err(|e| e.to_string())?;
        Ok(())
    }

    async fn receive(&self) -> Result<(BraidEnvelope, SocketAddr, usize), String> {
        // Enforce maximum buffer bounds directly to prevent oversized memory allocations on read
        let mut buf = vec![0u8; crate::protocol::MAX_PACKET_SIZE + 1];
        let (size, src) = self.socket.recv_from(&mut buf).await.map_err(|e| e.to_string())?;
        
        // Enforce maximum packet size check before deserialization (CPU exhaustion guard)
        if size > crate::protocol::MAX_PACKET_SIZE {
            return Err(format!("Raw packet size {} exceeds limit {} bytes", size, crate::protocol::MAX_PACKET_SIZE));
        }

        let envelope = bincode::deserialize::<BraidEnvelope>(&buf[..size]).map_err(|e| e.to_string())?;
        Ok((envelope, src, size))
    }
}
