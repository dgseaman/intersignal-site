use std::net::SocketAddr;
use std::sync::Arc;
use tokio::net::TcpListener;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use crate::AppState;

pub async fn start_web_server(state: Arc<AppState>) {
    let port = 8080;
    let addr = format!("127.0.0.1:{}", port);
    let listener = match TcpListener::bind(&addr).await {
        Ok(l) => l,
        Err(_) => {
            // Fallback to random free port if 8080 busy
            TcpListener::bind("127.0.0.1:0").await.expect("Failed to bind web server to any port")
        }
    };

    let bound_addr = listener.local_addr().unwrap();
    println!("Localhost Web Visualizer live at: http://{}", bound_addr);

    loop {
        match listener.accept().await {
            Ok((mut stream, _)) => {
                let state_clone = Arc::clone(&state);
                tokio::spawn(async move {
                    let mut buf = vec![0u8; 1024];
                    if let Ok(size) = stream.read(&mut buf).await {
                        let req_str = String::from_utf8_lossy(&buf[..size]);
                        
                        if req_str.starts_with("GET /api/state ") {
                            // Fetch current daemon state
                            let node_id_hex = crate::format_hex(&state_clone.node_id);
                            
                            // Fetch peers list
                            let peers_list = {
                                let table = state_clone.peer_table.lock().await;
                                table.values()
                                    .filter(|r| r.status != crate::PeerStatus::Stale)
                                    .map(|r| r.observed_addr.to_string())
                                    .collect::<Vec<String>>()
                            };

                            // Fetch latest received vector state
                            let latest_vec = {
                                let vec_guard = state_clone.latest_received_vector.lock().await;
                                vec_guard.clone()
                            };

                            let json_state = serde_json::json!({
                                "node_id": node_id_hex,
                                "local_address": format!("0.0.0.0:{}", state_clone.local_port),
                                "peers": peers_list,
                                "latest_vector": latest_vec,
                            });

                            let body = serde_json::to_string(&json_state).unwrap_or_default();
                            let response = format!(
                                "HTTP/1.1 200 OK\r\n\
                                Content-Type: application/json\r\n\
                                Content-Length: {}\r\n\
                                Access-Control-Allow-Origin: *\r\n\
                                Connection: close\r\n\r\n\
                                {}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else if req_str.starts_with("GET / ") {
                            // Serve embedded HTML
                            let html_body = include_str!("visualizer.html");
                            let response = format!(
                                "HTTP/1.1 200 OK\r\n\
                                Content-Type: text/html\r\n\
                                Content-Length: {}\r\n\
                                Connection: close\r\n\r\n\
                                {}",
                                html_body.len(),
                                html_body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else {
                            // Serve simple 404
                            let body = "Not Found";
                            let response = format!(
                                "HTTP/1.1 404 Not Found\r\n\
                                Content-Length: {}\r\n\
                                Connection: close\r\n\r\n\
                                {}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        }
                        let _ = stream.flush().await;
                    }
                });
            }
            Err(_) => {
                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
            }
        }
    }
}
