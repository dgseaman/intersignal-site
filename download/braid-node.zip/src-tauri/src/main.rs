#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

mod identity;
mod protocol;
mod transport;
mod web;

use identity::NodeIdentity;
use protocol::{
    BraidEnvelope,
    BraidStateDrift,
    BraidDiscoveryBeacon,
    BraidLinkProbe,
    BraidLinkProbeAck,
    BraidStateDriftQuant,
    BraidTransport,
    MSG_STATE_DRIFT,
    MSG_HEARTBEAT,
    MSG_DISCOVERY_BEACON,
    MSG_DISCOVERY_ACK,
    MSG_PEER_GOODBYE,
    MSG_LINK_PROBE,
    MSG_LINK_PROBE_ACK,
    EXPECTED_VECTOR_DIM,
    WIRE_PROTOCOL_VERSION,
    MAX_PACKET_SIZE,
    CAP_STATE_DRIFT,
    CAP_DISCOVERY,
    CAP_UDP_TRANSPORT,
    CAP_VECTOR_384_F32,
    CAP_VECTOR_QINT8,
    SCHEME_ED25519,
    VECTOR_ENCODING_RAW_F32,
    VECTOR_ENCODING_QINT8,
    NodeId,
    IdentityProvider,
    Ed25519LocalIdentityProvider,
    derive_node_id,
};
use transport::UdpTransport;

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use tokio::net::UdpSocket;
use tokio::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};
use serde::{Serialize, Deserialize};
use tauri::Manager; // Critical v1.x import to resolve emit_all & manage traits!
use rand::Rng;

pub const NODE_SOFTWARE_VERSION: &str = "0.6.0-alpha"; // Hardened Alpha Software Version

pub const MAX_PEERS: usize = 128; // Spam/sybil overflow protection limit
pub const MAX_REPLAY_LEDGER_ENTRIES: usize = 4096; // Bounded replay ledger size limit
pub const ACK_RATE_LIMIT_MS: u64 = 10_000; // Only reply to discovery beacons once every 10s per peer

fn format_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect::<Vec<String>>().join("")
}

// =====================================================================
// PEER MESH TOPOLOGY RECORD WITH CAPABILITY NEGOTIATION
// =====================================================================

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq)]
pub enum PeerStatus {
    Verified,
    Active,
    Stale,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PeerRecord {
    pub node_id: NodeId,          
    pub observed_addr: SocketAddr,
    pub status: PeerStatus,
    pub protocol_version: u16,
    pub capabilities: u64,
    pub vector_dim: u16,          
    pub session_id: [u8; 16],
    pub last_seen_ms: u64,
    pub expires_at_ms: u64,
    pub highest_sequence: u64,
    pub round_trip_latency_ms: u64, 
    pub preferred_vector_encoding: u16, // Negotiated capability preferred encoding
}

// =====================================================================
// TAURI SHARED STATE (wrapped in Arc for multi-daemon access)
// =====================================================================

pub struct AppState {
    pub transport: Arc<dyn BraidTransport>, // Dynamic Trait Object (Pillar 2)
    pub identity_provider: Arc<dyn IdentityProvider>,
    pub node_id: NodeId,
    pub session_id: [u8; 16],
    pub sequence_counter: Arc<AtomicU64>,
    pub peer_table: Arc<Mutex<HashMap<NodeId, PeerRecord>>>,
    pub replay_ledger: Arc<Mutex<HashMap::<(NodeId, [u8; 16]), u64>>>,
    pub last_sent_acks: Arc<Mutex<HashMap<NodeId, u64>>>,
    pub local_port: u16,
    pub latest_received_vector: Arc<Mutex<Vec<f32>>>, 
    pub peers: Arc<Mutex<Vec<String>>>,
    pub seed_peers: Vec<SocketAddr>,
}

// =====================================================================
// PEER DISCOVERY VALIDATOR
// =====================================================================

fn validate_beacon(
    envelope: &BraidEnvelope,
    beacon: &BraidDiscoveryBeacon,
) -> Result<(), String> {
    if beacon.session_id != envelope.session_id {
        return Err("Beacon session_id does not match envelope session_id".into());
    }

    if beacon.vector_dim as usize != EXPECTED_VECTOR_DIM {
        return Err(format!("Unsupported vector dimension: {}", beacon.vector_dim));
    }

    if beacon.max_packet_size as usize < 380 {
        return Err("Peer max_packet_size too small for quantized vector state".into());
    }

    // Require CAP_DISCOVERY | CAP_UDP_TRANSPORT
    let required = CAP_DISCOVERY | CAP_UDP_TRANSPORT;
    if beacon.capabilities & required != required {
        return Err("Peer lacks required discovery or UDP transport capabilities".into());
    }

    if beacon.ttl_ms < 5_000 || beacon.ttl_ms > 60_000 {
        return Err("Beacon TTL outside accepted protocol range (5s - 60s)".into());
    }

    Ok(())
}

// =====================================================================
// UNIFIED REPLAY LEDGER VALIDATION HELPER
// =====================================================================

async fn check_and_commit_replay(
    ledger: &Mutex<HashMap<(NodeId, [u8; 16]), u64>>,
    node_id: NodeId,
    session_id: [u8; 16],
    sequence: u64,
    src: SocketAddr,
) -> Result<(), String> {
    let mut guard = ledger.lock().await;
    let key = (node_id, session_id);
    
    if guard.len() >= MAX_REPLAY_LEDGER_ENTRIES && !guard.contains_key(&key) {
        return Err(format!("[DROP] Replay ledger full; rejecting new session from {}", src));
    }
    
    if let Some(highest_seq) = guard.get(&key) {
        if sequence <= *highest_seq {
            return Err(format!(
                "[DROP] Replay threat detected: sequence {} <= highest seen ({})",
                sequence, highest_seq
            ));
        }
    }
    
    guard.insert(key, sequence);
    Ok(())
}

// =====================================================================
// TAURI COMMANDS
// =====================================================================

#[tauri::command]
async fn get_node_info(state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    Ok(serde_json::json!({
        "node_id": format_hex(&state.node_id),
        "local_address": format!("0.0.0.0:{}", state.local_port),
        "software_version": NODE_SOFTWARE_VERSION,
        "wire_version": WIRE_PROTOCOL_VERSION,
    }))
}

#[tauri::command]
async fn get_peers(state: tauri::State<'_, Arc<AppState>>) -> Result<Vec<String>, String> {
    let peer_table = state.peer_table.lock().await;
    let list = peer_table.values()
        .filter(|record| record.status != PeerStatus::Stale)
        .map(|record| record.observed_addr.to_string())
        .collect::<Vec<String>>();
    Ok(list)
}

#[tauri::command]
async fn stream_state_drift(
    latent_vector: Vec<f32>,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<serde_json::Value, String> {
    if latent_vector.is_empty() {
        return Err("Latent vector cannot be empty".to_string());
    }

    if latent_vector.len() != EXPECTED_VECTOR_DIM {
        return Err(format!("Vector dimension must be exactly {}", EXPECTED_VECTOR_DIM));
    }

    if latent_vector.iter().any(|v| !v.is_finite()) {
        return Err("Latent vector contains NaN or Infinity".to_string());
    }

    // Clone target peer records first, then drop lock to avoid holding across await
    let peers_to_send = {
        let peer_table = state.peer_table.lock().await;
        peer_table.values()
            .filter(|r| r.status == PeerStatus::Active || r.status == PeerStatus::Verified)
            .cloned()
            .collect::<Vec<PeerRecord>>()
    };

    let mut sent_count = 0;
    let mut failures = Vec::new();

    for peer in peers_to_send {
        let sequence = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|e| e.to_string())?
            .as_millis() as u64;

        // CAPABILITY NEGOTIATION (Pillar 5): Use 8-bit quantization if peer supports it!
        // FIXED CRYPTO INVARIANT: Set state_vector_encoding inside BraidEnvelope::create BEFORE signing!
        let envelope = if peer.preferred_vector_encoding == VECTOR_ENCODING_QINT8 {
            let quant = BraidStateDriftQuant::quantize(&latent_vector);
            let payload = bincode::serialize(&quant).map_err(|e| e.to_string())?;
            BraidEnvelope::create(
                MSG_STATE_DRIFT,
                VECTOR_ENCODING_QINT8, // Passed explicitly as parameter to secure the signature preimage!
                state.session_id,
                sequence,
                timestamp,
                payload,
                state.identity_provider.as_ref(),
            ).map_err(|e| format!("Quantized signing failure: {}", e))?
        } else {
            let drift = BraidStateDrift { latent_vector: latent_vector.clone() };
            let payload = bincode::serialize(&drift).map_err(|e| e.to_string())?;
            // FIXED COMPILE BLOCKER: Remove duplicate identity_provider argument!
            BraidEnvelope::create(
                MSG_STATE_DRIFT,
                VECTOR_ENCODING_RAW_F32, // Passed explicitly as parameter to secure the signature preimage!
                state.session_id,
                sequence,
                timestamp,
                payload,
                state.identity_provider.as_ref(),
            ).map_err(|e| format!("Standard signing failure: {}", e))?
        };

        let serialized_bytes = bincode::serialize(&envelope).map_err(|e| e.to_string())?;
        match state.transport.send_to(&serialized_bytes, peer.observed_addr).await {
            Ok(_) => {
                sent_count += 1;
            }
            Err(e) => {
                failures.push(format!("{}: {:?}", peer.observed_addr, e));
            }
        }
    }

    Ok(serde_json::json!({
        "sent_count": sent_count,
        "failures": failures,
    }))
}

// =====================================================================
// DAEMON RUNTIME
// =====================================================================

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle();
            tauri::async_runtime::block_on(async move {
                // FLEXIBLE CLI BOOTSTRAPPING ARGUMENTS PARSING (Pillar 4)
                let mut udp_port = 12000;
                let mut web_port = 8080;
                let mut no_web = false;
                let mut seed_peers = Vec::new();
                let mut custom_identity_path = None;
                let mut log_level = "info".to_string();

                let args: Vec<String> = std::env::args().collect();
                let mut i = 1;
                while i < args.len() {
                    match args[i].as_str() {
                        "--port" | "-p" => {
                            if i + 1 < args.len() {
                                if let Ok(p) = args[i+1].parse::<u16>() {
                                    udp_port = p;
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--web-port" | "-w" => {
                            if i + 1 < args.len() {
                                if let Ok(p) = args[i+1].parse::<u16>() {
                                    web_port = p;
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--seed" => {
                            if i + 1 < args.len() {
                                if let Ok(addr) = args[i+1].parse::<SocketAddr>() {
                                    seed_peers.push(addr);
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--no-web" => {
                            no_web = true;
                            i += 1;
                        }
                        "--identity" => {
                            if i + 1 < args.len() {
                                custom_identity_path = Some(std::path::PathBuf::from(&args[i+1]));
                                i += 2;
                            } else { i += 1; }
                        }
                        "--log-level" => {
                            if i + 1 < args.len() {
                                log_level = args[i+1].clone();
                                i += 2;
                            } else { i += 1; }
                        }
                        _ => { i += 1; }
                    }
                }

                println!("[BOOT] Braid DeepBlend v0.6.0-alpha Initializing...");
                println!("[BOOT] Target UDP Port: {}, Web Visualizer Port: {}, No Web: {}, Log Level: {}", udp_port, web_port, no_web, log_level);

                let bind_addr = format!("0.0.0.0:{}", udp_port);
                let socket = match UdpSocket::bind(&bind_addr).await {
                    Ok(s) => s,
                    Err(_) => {
                        UdpSocket::bind("0.0.0.0:0")
                            .await
                            .expect("Failed to bind UDP socket to any port")
                    }
                };

                let local_port = socket.local_addr().unwrap().port();
                let transport = Arc::new(UdpTransport::new(socket));
                let _ = transport.socket.set_broadcast(true);

                // Initialize persistent node identity stored securely in App Data Directory
                let app_data_dir = handle.path_resolver().app_data_dir()
                    .unwrap_or_else(|| std::env::current_dir().unwrap());
                std::fs::create_dir_all(&app_data_dir).unwrap_or_default();
                
                let identity_path = custom_identity_path.unwrap_or_else(|| app_data_dir.join(".braid_identity"));

                // Initialize Ed25519 Local Identity Provider
                let local_identity = NodeIdentity::load_or_create(identity_path).unwrap();
                let identity_provider = Arc::new(Ed25519LocalIdentityProvider::new(local_identity.signing_key.clone()));

                let node_id = identity_provider.node_id();
                let session_id: [u8; 16] = rand::random();
                let sequence_counter = Arc::new(AtomicU64::new(1)); 
                let peer_table = Arc::new(Mutex::new(HashMap::<NodeId, PeerRecord>::new()));
                let replay_ledger = Arc::new(Mutex::new(HashMap::<(NodeId, [u8; 16]), u64>::new()));
                let last_sent_acks = Arc::new(Mutex::new(HashMap::<NodeId, u64>::new()));
                let latest_received_vector = Arc::new(Mutex::new(vec![0.0f32; EXPECTED_VECTOR_DIM]));

                // Define bootstrap targets: fallback to broadcast if no manual seeds provided
                let discovery_targets = if seed_peers.is_empty() {
                    vec![
                        "255.255.255.255:12000".parse::<SocketAddr>().unwrap(),
                        "127.0.0.1:12000".parse::<SocketAddr>().unwrap(),
                    ]
                } else {
                    seed_peers.clone()
                };

                let peers = Arc::new(Mutex::new(
                    discovery_targets.iter().map(|addr| addr.to_string()).collect::<Vec<String>>()
                ));

                // Create shared global state wrapped in Arc for web daemon integration
                // FIXED CAST BLOCKER: Casting UdpTransport as Arc<dyn BraidTransport> resolved cleanly!
                let app_state_arc = Arc::new(AppState {
                    transport: Arc::clone(&transport) as Arc<dyn BraidTransport>, // Dynamic Trait Object (Pillar 2)
                    identity_provider: Arc::clone(&identity_provider) as Arc<dyn IdentityProvider>,
                    node_id,
                    session_id,
                    sequence_counter: Arc::clone(&sequence_counter),
                    peer_table: Arc::clone(&peer_table),
                    replay_ledger: Arc::clone(&replay_ledger),
                    last_sent_acks: Arc::clone(&last_sent_acks),
                    local_port,
                    latest_received_vector: Arc::clone(&latest_received_vector),
                    peers: Arc::clone(&peers),
                    seed_peers: seed_peers.clone(),
                });

                // Spawn Localhost HTTP Web Visualizer if allowed
                if !no_web {
                    let web_state_clone = Arc::clone(&app_state_arc);
                    tokio::spawn(async move {
                        web::start_web_server(web_state_clone, web_port).await;
                    });
                }

                // 1. Spawns background receiver loop - Strict Admission-First Receive Pipeline
                let rx_transport = Arc::clone(&transport);
                let tx_transport_clone = Arc::clone(&transport);
                let local_node_id = node_id;
                let local_session_id = session_id;
                let rx_ledger = Arc::clone(&replay_ledger);
                let rx_peer_table = Arc::clone(&peer_table);
                let rx_sequence_counter = Arc::clone(&sequence_counter);
                let rx_provider_clone = Arc::clone(&identity_provider);
                let rx_app_handle = handle.clone();
                let rx_peers = Arc::clone(&peers);
                let rx_last_sent_acks = Arc::clone(&last_sent_acks);
                let rx_latest_vector = Arc::clone(&latest_received_vector);

                tokio::spawn(async move {
                    loop {
                        match rx_transport.recv_from().await {
                            Ok((bytes, src)) => {
                                let wire_size = bytes.len();
                                let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

                                // Deserialize envelope
                                let envelope: BraidEnvelope = match bincode::deserialize(&bytes) {
                                    Ok(env) => env,
                                    Err(_) => continue,
                                };

                                // [PIPELINE STEP 3] Static envelope constraints: size and clock skew
                                if let Err(e) = envelope.validate_envelope(now_ms, wire_size) {
                                    eprintln!("[DROP] Validation failure from {}: {}", src, e);
                                    continue;
                                }

                                // [PIPELINE STEP 4] Wire protocol version check
                                if envelope.version != WIRE_PROTOCOL_VERSION {
                                    eprintln!("[DROP] Wire protocol version mismatch: expected {}, received {}", WIRE_PROTOCOL_VERSION, envelope.version);
                                    continue;
                                }

                                // [PIPELINE STEP 5] Supported signature scheme check
                                if envelope.signature_scheme != SCHEME_ED25519 {
                                    eprintln!("[DROP] Unsupported signature scheme: {}", envelope.signature_scheme);
                                    continue;
                                }

                                // Enforce codec fields validation before processing
                                if envelope.wire_encoding != protocol::ENCODING_BINCODE {
                                    eprintln!("[DROP] Unsupported wire encoding format: {}", envelope.wire_encoding);
                                    continue;
                                }

                                // Self-filtering: Reject packets from our exact local node/session combination
                                if envelope.node_id == local_node_id && envelope.session_id == local_session_id {
                                    continue;
                                }

                                // [PIPELINE STEP 6 & 7] NodeId derivation check and Cryptographic signature verification
                                if !envelope.verify_signature() {
                                    eprintln!("[DROP] Cryptographic signature INVALID from {}", src);
                                    continue;
                                }

                                // [PIPELINE STEP 8] Known message type check (match explicitly)
                                match envelope.message_type {
                                    MSG_DISCOVERY_BEACON => {
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            // [PIPELINE STEP 9 & 10] Payload codec check & message-specific validation
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery beacon from {}: {}", src, e);
                                                continue;
                                            }

                                            // [PIPELINE STEP 11] Unified Replay check and commit
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // [PIPELINE STEP 12] Peer admission policy with Capability Negotiation (Pillar 5)
                                            let (is_new, should_handshake, clamped_ttl) = {
                                                let mut table = rx_peer_table.lock().await;
                                                if table.len() >= MAX_PEERS && !table.contains_key(&envelope.node_id) {
                                                    eprintln!("[DROP] Peer table full. Rejecting new node.");
                                                    continue;
                                                }

                                                let is_new = !table.contains_key(&envelope.node_id);
                                                let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                                // Record negotiated compatibility
                                                let preferred_vector_encoding = if beacon.capabilities & CAP_VECTOR_QINT8 != 0 {
                                                    VECTOR_ENCODING_QINT8
                                                } else {
                                                    VECTOR_ENCODING_RAW_F32
                                                };

                                                let record = PeerRecord {
                                                    node_id: envelope.node_id,
                                                    observed_addr: src,
                                                    status: PeerStatus::Active,
                                                    protocol_version: envelope.version,
                                                    capabilities: beacon.capabilities,
                                                    vector_dim: beacon.vector_dim,
                                                    session_id: beacon.session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + clamped_ttl as u64,
                                                    highest_sequence: envelope.sequence,
                                                    round_trip_latency_ms: 0,
                                                    preferred_vector_encoding,
                                                };
                                                table.insert(envelope.node_id, record);

                                                if is_new {
                                                    println!(
                                                        "\n[DISCOVERY] Admitted peer [{}] at {} (Advertised port: {}, Preferred codec: {})",
                                                        &format_hex(&envelope.node_id)[..12],
                                                        src,
                                                        beacon.listen_port,
                                                        if preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "INT8" } else { "RAW_F32" }
                                                    );
                                                    let mut flat = rx_peers.lock().await;
                                                    let src_str = src.to_string();
                                                    if !flat.contains(&src_str) {
                                                        flat.push(src_str);
                                                    }
                                                }

                                                let mut acks = rx_last_sent_acks.lock().await;
                                                let last_sent = acks.entry(envelope.node_id).or_insert(0);
                                                let should_handshake = is_new || now_ms - *last_sent > ACK_RATE_LIMIT_MS;
                                                if should_handshake {
                                                    *last_sent = now_ms;
                                                }
                                                (is_new, should_handshake, clamped_ttl)
                                            };

                                            if should_handshake {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                let discovery_payload = BraidDiscoveryBeacon {
                                                    session_id: local_session_id,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    max_packet_size: MAX_PACKET_SIZE as u16,
                                                    listen_port: local_port,
                                                    ttl_ms: clamped_ttl,
                                                };
                                                if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                                                    if let Ok(handshake) = BraidEnvelope::create(
                                                        MSG_DISCOVERY_ACK,
                                                        VECTOR_ENCODING_RAW_F32,
                                                        local_session_id,
                                                        seq,
                                                        now_ms,
                                                        serialized_beacon,
                                                        rx_provider_clone.as_ref(),
                                                    ) {
                                                        let ser_handshake = bincode::serialize(&handshake).unwrap();
                                                        let _ = tx_transport_clone.send_to(&ser_handshake, src).await;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    MSG_DISCOVERY_ACK => {
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery ACK from {}: {}", src, e);
                                                continue;
                                            }

                                            // Unified Replay check and commit
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            let mut table = rx_peer_table.lock().await;
                                            let is_new = !table.contains_key(&envelope.node_id);
                                            let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                            let preferred_vector_encoding = if beacon.capabilities & CAP_VECTOR_QINT8 != 0 {
                                                VECTOR_ENCODING_QINT8
                                            } else {
                                                VECTOR_ENCODING_RAW_F32
                                            };

                                            let record = PeerRecord {
                                                node_id: envelope.node_id,
                                                observed_addr: src,
                                                status: PeerStatus::Active,
                                                protocol_version: envelope.version,
                                                capabilities: beacon.capabilities,
                                                vector_dim: beacon.vector_dim,
                                                session_id: beacon.session_id,
                                                last_seen_ms: now_ms,
                                                expires_at_ms: now_ms + clamped_ttl as u64,
                                                highest_sequence: envelope.sequence,
                                                round_trip_latency_ms: 0,
                                                preferred_vector_encoding,
                                            };
                                            table.insert(envelope.node_id, record);

                                            if is_new {
                                                println!(
                                                    "\n[DISCOVERY] Registered Handshake [{}] at {} (Advertised port: {}, Preferred codec: {})",
                                                    &format_hex(&envelope.node_id)[..12],
                                                    src,
                                                    beacon.listen_port,
                                                    if preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "INT8" } else { "RAW_F32" }
                                                );
                                                let mut flat = rx_peers.lock().await;
                                                let src_str = src.to_string();
                                                if !flat.contains(&src_str) {
                                                    flat.push(src_str);
                                                }
                                            }
                                        }
                                    }
                                    MSG_STATE_DRIFT => {
                                        // Gating check for unsupported state vector encoding (BLOCKER 3 RESOLVED)
                                        if envelope.state_vector_encoding != protocol::VECTOR_ENCODING_RAW_F32
                                            && envelope.state_vector_encoding != protocol::VECTOR_ENCODING_QINT8
                                        {
                                            eprintln!("[DROP] Unsupported state vector encoding: {}", envelope.state_vector_encoding);
                                            continue;
                                        }

                                        // [ADMISSION GATE] Reject state drift from undiscovered or non-active peers!
                                        let expected_dim = {
                                            let table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get(&envelope.node_id) {
                                                if record.status != PeerStatus::Active && record.status != PeerStatus::Verified {
                                                    eprintln!("[DROP] State drift from non-active peer {}", src);
                                                    continue;
                                                }
                                                if record.capabilities & CAP_STATE_DRIFT == 0 {
                                                    eprintln!("[DROP] Peer lacks state drift capability {}", src);
                                                    continue;
                                                }
                                                record.vector_dim as usize
                                            } else {
                                                eprintln!("[DROP] State drift from undiscovered peer {}", src);
                                                continue;
                                            }
                                        };

                                        // Decouple wire format based on negotiated state_vector_encoding (Pillar 3)
                                        // STRICT QINT8 SANITIZING AND VERIFICATION PASS
                                        let latent_vector = if envelope.state_vector_encoding == VECTOR_ENCODING_QINT8 {
                                            if let Ok(quant) = bincode::deserialize::<BraidStateDriftQuant>(&envelope.payload) {
                                                // Validation: length bounds matching expected_dim
                                                if quant.values.len() != expected_dim {
                                                    eprintln!("[DROP] Quantized vector length mismatch: expected {}, received {}", expected_dim, quant.values.len());
                                                    continue;
                                                }
                                                // Validation: scale must be finite and strictly positive
                                                if !quant.scale.is_finite() || quant.scale <= 0.0 {
                                                    eprintln!("[DROP] Quantized vector has invalid scale: {}", quant.scale);
                                                    continue;
                                                }
                                                let dequant = quant.dequantize();
                                                // Validation: dequantized values must remain finite
                                                if dequant.iter().any(|v| !v.is_finite()) {
                                                    eprintln!("[DROP] Dequantized vector contains NaN or Infinity");
                                                    continue;
                                                }
                                                dequant
                                            } else {
                                                continue;
                                            }
                                        } else {
                                            if let Ok(drift) = bincode::deserialize::<BraidStateDrift>(&envelope.payload) {
                                                drift.latent_vector
                                            } else {
                                                continue;
                                            }
                                        };

                                        if latent_vector.len() != expected_dim {
                                            eprintln!("[DROP] Dimension mismatch: expected {}, received {}", expected_dim, latent_vector.len());
                                            continue;
                                        }

                                        if latent_vector.iter().any(|v| !v.is_finite()) {
                                            continue;
                                        }

                                        // Unified Replay check (Only commit after payload fully validated!)
                                        if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.sequence, src).await {
                                            eprintln!("{}", e);
                                            continue;
                                        }

                                        {
                                            let mut vec_guard = rx_latest_vector.lock().await;
                                            *vec_guard = latent_vector.clone();
                                        }

                                        // Extend liveness lease on valid state drift packet arrival
                                        {
                                            let mut table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get_mut(&envelope.node_id) {
                                                record.last_seen_ms = now_ms;
                                                record.expires_at_ms = now_ms + 15_000;
                                                record.highest_sequence = envelope.sequence;
                                                record.status = PeerStatus::Active;
                                            }
                                        }

                                        let hex_node = format_hex(&envelope.node_id);
                                        let payload = serde_json::json!({
                                            "node_id": hex_node,
                                            "timestamp": envelope.timestamp,
                                            "sequence_id": envelope.sequence,
                                            "latent_vector": latent_vector,
                                            "sender_address": src.to_string(),
                                            "byte_size": wire_size,
                                        });
                                        let _ = rx_app_handle.emit_all("udp-packet-received", payload);
                                    }
                                    MSG_PEER_GOODBYE => {
                                        // Unified Replay check
                                        if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.sequence, src).await {
                                            eprintln!("{}", e);
                                            continue;
                                        }

                                        let mut table = rx_peer_table.lock().await;
                                        if table.remove(&envelope.node_id).is_some() {
                                            let hex_node = format_hex(&envelope.node_id);
                                            println!("[GOODBYE] Peer graceful exit: Node [{}] left", &hex_node[..12]);
                                            let mut flat = rx_peers.lock().await;
                                            flat.retain(|addr| *addr != src.to_string());
                                        }
                                    }
                                    MSG_LINK_PROBE => {
                                        // [ADMISSION GATE] Only reply to probes from already admitted peers!
                                        {
                                            let table = rx_peer_table.lock().await;
                                            if !table.contains_key(&envelope.node_id) {
                                                eprintln!("[DROP] Link probe from unadmitted peer {}", src);
                                                continue;
                                            }
                                        }

                                        if let Ok(probe) = bincode::deserialize::<BraidLinkProbe>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Respond with directed LINK_PROBE_ACK immediately
                                            let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                            let ack_payload = BraidLinkProbeAck {
                                                ping_seq: probe.ping_seq,
                                                tx_timestamp_ms: probe.tx_timestamp_ms,
                                                rx_timestamp_ms: now_ms,
                                            };
                                            if let Ok(serialized_ack) = bincode::serialize(&ack_payload) {
                                                if let Ok(ack_env) = BraidEnvelope::create(
                                                    MSG_LINK_PROBE_ACK,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    serialized_ack,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&ack_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, src).await;
                                                }
                                            }
                                        }
                                    }
                                    MSG_LINK_PROBE_ACK => {
                                        // [ADMISSION GATE] Only accept ACKs from admitted peers!
                                        {
                                            let table = rx_peer_table.lock().await;
                                            if !table.contains_key(&envelope.node_id) {
                                                continue;
                                            }
                                        }

                                        if let Ok(ack) = bincode::deserialize::<BraidLinkProbeAck>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Calculate latency and update path health telemetry
                                            let latency = now_ms.saturating_sub(ack.tx_timestamp_ms);
                                            let mut table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get_mut(&envelope.node_id) {
                                                record.round_trip_latency_ms = latency;
                                                record.last_seen_ms = now_ms;
                                                record.expires_at_ms = now_ms + 15_000;
                                            }
                                        }
                                    }
                                    other_type => {
                                        eprintln!("[WARN] Received unsupported message type {} from {}", other_type, src);
                                    }
                                }
                            }
                            Err(_) => {
                                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
                            }
                        }
                    }
                });

                // 2. Spawns background discovery broadcast beacon loop with Jitter (±500ms)
                let tx_discovery_transport = Arc::clone(&transport);
                let tx_targets = discovery_targets;
                let tx_sequence_counter = Arc::clone(&sequence_counter);
                let tx_provider = Arc::clone(&identity_provider);

                tokio::spawn(async move {
                    let base_ms = 3000u64;
                    loop {
                        let jitter = rand::thread_rng().gen_range(-500..=500);
                        let sleep_ms = (base_ms as i32 + jitter) as u64;
                        tokio::time::sleep(tokio::time::Duration::from_millis(sleep_ms)).await;
                        
                        let timestamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        let seq = tx_sequence_counter.fetch_add(1, Ordering::SeqCst);

                        let discovery_payload = BraidDiscoveryBeacon {
                            session_id: local_session_id,
                            capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                            vector_dim: EXPECTED_VECTOR_DIM as u16,
                            max_packet_size: MAX_PACKET_SIZE as u16,
                            listen_port: local_port,
                            ttl_ms: 15000,
                        };

                        if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                            if let Ok(beacon_envelope) = BraidEnvelope::create(
                                MSG_DISCOVERY_BEACON,
                                VECTOR_ENCODING_RAW_F32,
                                local_session_id,
                                seq,
                                timestamp,
                                serialized_beacon,
                                tx_provider.as_ref(),
                            ) {
                                let ser_bytes = bincode::serialize(&beacon_envelope).unwrap();
                                for peer_addr in tx_targets.iter() {
                                    let _ = tx_discovery_transport.send_to(&ser_bytes, *peer_addr).await;
                                }
                            }
                        }
                    }
                });

                // 3. Spawns path health Link Probe thread (loops every 5 seconds)
                let tx_probe_transport = Arc::clone(&transport);
                let tx_probe_table = Arc::clone(&peer_table);
                let tx_probe_sequence = Arc::clone(&sequence_counter);
                let tx_probe_provider = Arc::clone(&identity_provider);
                tokio::spawn(async move {
                    let mut probe_seq = 1u64;
                    loop {
                        tokio::time::sleep(tokio::time::Duration::from_secs(5)).await;
                        let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        
                        // Collect peer coordinates
                        let targets = {
                            let table = tx_probe_table.lock().await;
                            table.values()
                                .filter(|r| r.status == PeerStatus::Active || r.status == PeerStatus::Verified)
                                .map(|r| (r.observed_addr, r.node_id))
                                .collect::<Vec<(SocketAddr, NodeId)>>()
                        };

                        for (addr, _id) in targets {
                            let seq = tx_probe_sequence.fetch_add(1, Ordering::SeqCst);
                            let probe_payload = BraidLinkProbe {
                                ping_seq: probe_seq,
                                tx_timestamp_ms: now_ms,
                            };
                            if let Ok(serialized) = bincode::serialize(&probe_payload) {
                                if let Ok(probe_env) = BraidEnvelope::create(
                                    MSG_LINK_PROBE,
                                    VECTOR_ENCODING_RAW_F32,
                                    local_session_id,
                                    seq,
                                    now_ms,
                                    serialized,
                                    tx_probe_provider.as_ref(),
                                ) {
                                    let ser_bytes = bincode::serialize(&probe_env).unwrap();
                                    let _ = tx_probe_transport.send_to(&ser_bytes, addr).await;
                                }
                            }
                        }
                        probe_seq += 1;
                    }
                });

                // 4. Spawns peer table TTL expiration cleanup loop (runs every 5s)
                let tx_cleanup_peer_table = Arc::clone(&peer_table);
                let tx_cleanup_flat_peers = Arc::clone(&peers);
                tokio::spawn(async move {
                    let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(5));
                    loop {
                        interval.tick().await;
                        let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        
                        let mut expired_peers = Vec::new();
                        {
                            let mut table = tx_cleanup_peer_table.lock().await;
                            table.retain(|sender_id, val| {
                                if now_ms > val.expires_at_ms {
                                    let hex_node = format_hex(sender_id);
                                    println!("[PRUNE] Peer expired (TTL): {} at {}", &hex_node[..12], val.observed_addr);
                                    expired_peers.push(val.observed_addr.to_string());
                                    false
                                } else {
                                    true
                                }
                            });
                        }

                        // Update flat list matching table
                        if !expired_peers.is_empty() {
                            let mut peer_list = tx_cleanup_flat_peers.lock().await;
                            peer_list.retain(|addr| !expired_peers.contains(addr));
                        }
                    }
                });

                // Manage AppState
                handle.manage(app_state_arc);
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_node_info,
            get_peers,
            stream_state_drift
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
