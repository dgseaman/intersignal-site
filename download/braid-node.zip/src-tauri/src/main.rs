#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

mod identity;
mod protocol;
mod transport;
mod web;

use identity::NodeIdentity;
use protocol::{
    BraidEnvelope, BraidStateDrift, BraidDiscoveryBeacon, MSG_TYPE_STATE_DRIFT,
    MSG_TYPE_DISCOVERY_BEACON, MSG_TYPE_DISCOVERY_ACK, EXPECTED_VECTOR_DIM, PROTOCOL_VERSION, MAX_PACKET_SIZE,
    CAP_STATE_DRIFT, CAP_DISCOVERY, CAP_UDP_TRANSPORT, CAP_VECTOR_384_F32, SCHEME_ED25519
};
use transport::{BraidTransport, UdpTransport};

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use tokio::net::UdpSocket;
use tokio::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};
use serde::{Serialize, Deserialize};
use tauri::Manager; // Critical v1.x import to resolve emit_all & manage traits!
use rand::Rng;

pub const MAX_PEERS: usize = 128; // Spam/sybil overflow protection limit
pub const ACK_RATE_LIMIT_MS: u64 = 10_000; // Only reply to discovery beacons once every 10s per peer

fn format_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect::<Vec<String>>().join("")
}

// =====================================================================
// PEER MESH TOPOLOGY RECORD
// =====================================================================

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq)]
pub enum PeerStatus {
    Verified,
    Active,
    Stale,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PeerRecord {
    pub node_id: [u8; 32],
    pub observed_addr: SocketAddr,
    pub status: PeerStatus,
    pub protocol_version: u16,
    pub capabilities: u64,
    pub vector_dim: u16,          // Negotiated dynamic vector dimension
    pub session_id: [u8; 16],
    pub last_seen_ms: u64,
    pub expires_at_ms: u64,
    pub highest_sequence: u64,
}

// =====================================================================
// TAURI SHARED STATE (wrapped in Arc for multi-daemon access)
// =====================================================================

pub struct AppState {
    pub transport: Arc<UdpTransport>,
    pub identity: Arc<NodeIdentity>,
    pub node_id: [u8; 32],
    pub session_id: [u8; 16],
    pub sequence_counter: Arc<AtomicU64>,
    pub peer_table: Arc<Mutex<HashMap<[u8; 32], PeerRecord>>>,
    pub replay_ledger: Arc<Mutex<HashMap<([u8; 32], [u8; 16]), u64>>>,
    pub last_sent_acks: Arc<Mutex<HashMap<[u8; 32], u64>>>,
    pub local_port: u16,
    pub latest_received_vector: Arc<Mutex<Vec<f32>>>, // Real-time state cache for local web visualizer
    pub peers: Arc<Mutex<Vec<String>>>,
}

// =====================================================================
// PEER DISCOVERY VALIDATOR
// =====================================================================

fn validate_beacon(
    envelope: &BraidEnvelope,
    beacon: &BraidDiscoveryBeacon,
) -> Result<(), String> {
    if beacon.session_id != envelope.session_id {
        return Err("Beacon session_id does not match envelope session_id".into());
    }

    if beacon.vector_dim as usize != EXPECTED_VECTOR_DIM {
        return Err(format!("Unsupported vector dimension: {}", beacon.vector_dim));
    }

    if beacon.max_packet_size as usize < 1684 {
        return Err("Peer max_packet_size too small for 384-f32 state drift".into());
    }

    // Require CAP_VECTOR_384_F32 as well since we advertise and depend on it
    let required = CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_STATE_DRIFT | CAP_VECTOR_384_F32;
    if beacon.capabilities & required != required {
        return Err("Peer lacks required discovery, UDP, or StateDrift capabilities".into());
    }

    if beacon.ttl_ms < 5_000 || beacon.ttl_ms > 60_000 {
        return Err("Beacon TTL outside accepted protocol range (5s - 60s)".into());
    }

    Ok(())
}

// =====================================================================
// TAURI COMMANDS
// =====================================================================

#[tauri::command]
async fn get_node_info(state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    Ok(serde_json::json!({
        "node_id": format_hex(&state.node_id),
        "local_address": format!("0.0.0.0:{}", state.local_port),
    }))
}

#[tauri::command]
async fn get_peers(state: tauri::State<'_, Arc<AppState>>) -> Result<Vec<String>, String> {
    let peer_table = state.peer_table.lock().await;
    let list = peer_table.values()
        .filter(|record| record.status != PeerStatus::Stale)
        .map(|record| record.observed_addr.to_string())
        .collect::<Vec<String>>();
    Ok(list)
}

#[tauri::command]
async fn stream_state_drift(
    latent_vector: Vec<f32>,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<serde_json::Value, String> {
    if latent_vector.is_empty() {
        return Err("Latent vector cannot be empty".to_string());
    }

    if latent_vector.len() != EXPECTED_VECTOR_DIM {
        return Err(format!("Vector dimension must be exactly {}", EXPECTED_VECTOR_DIM));
    }

    // Enforce finite values on transmit
    if latent_vector.iter().any(|v| !v.is_finite()) {
        return Err("Latent vector contains NaN or Infinity".to_string());
    }

    let sequence = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_millis() as u64;

    let drift_payload = BraidStateDrift { latent_vector };
    let serialized_payload = bincode::serialize(&drift_payload).map_err(|e| e.to_string())?;

    let envelope = BraidEnvelope::create(
        MSG_TYPE_STATE_DRIFT,
        state.node_id.to_vec(),
        state.session_id,
        sequence,
        timestamp,
        serialized_payload,
        &state.identity.signing_key,
    ).map_err(|e| format!("Signing failure: {}", e))?;

    // Clone target peer records first, then drop lock to avoid holding across await
    let peer_addresses = {
        let peer_table = state.peer_table.lock().await;
        peer_table.values()
            .filter(|r| r.status == PeerStatus::Active || r.status == PeerStatus::Verified)
            .map(|r| r.observed_addr)
            .collect::<Vec<SocketAddr>>()
    };

    let mut sent_count = 0;
    let mut failures = Vec::new();

    for peer_addr in peer_addresses {
        match state.transport.send(&envelope, &peer_addr).await {
            Ok(_) => {
                sent_count += 1;
            }
            Err(e) => {
                failures.push(format!("{}: {}", peer_addr, e));
            }
        }
    }

    Ok(serde_json::json!({
        "sequence_id": sequence,
        "timestamp": timestamp,
        "sent_count": sent_count,
        "failures": failures,
    }))
}

// =====================================================================
// DAEMON RUNTIME
// =====================================================================

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle();
            tauri::async_runtime::block_on(async move {
                let bind_addr = "0.0.0.0:12000";
                let socket = match UdpSocket::bind(bind_addr).await {
                    Ok(s) => s,
                    Err(_) => {
                        UdpSocket::bind("0.0.0.0:0")
                            .await
                            .expect("Failed to bind UDP socket to any port")
                    }
                };

                let local_port = socket.local_addr().unwrap().port();
                let transport = Arc::new(UdpTransport::new(socket));
                let _ = transport.socket.set_broadcast(true);

                // Initialize persistent node identity stored securely in Tauri's App Data Directory
                let app_data_dir = handle.path_resolver().app_data_dir()
                    .unwrap_or_else(|| std::env::current_dir().unwrap());
                std::fs::create_dir_all(&app_data_dir).unwrap_or_default();
                let identity_path = app_data_dir.join(".braid_identity");

                let identity = Arc::new(NodeIdentity::load_or_create(identity_path).unwrap());
                let node_id = identity.public_key().to_bytes();
                
                // Initialize modern Braid v0.4.1 parameters
                let session_id: [u8; 16] = rand::random();
                let sequence_counter = Arc::new(AtomicU64::new(1)); // Start sequence at 1
                let peer_table = Arc::new(Mutex::new(HashMap::<[u8; 32], PeerRecord>::new()));
                let replay_ledger = Arc::new(Mutex::new(HashMap::<([u8; 32], [u8; 16]), u64>::new()));
                let last_sent_acks = Arc::new(Mutex::new(HashMap::<[u8; 32], u64>::new()));
                let latest_received_vector = Arc::new(Mutex::new(vec![0.0f32; EXPECTED_VECTOR_DIM]));

                // Define bootstrap targets
                let discovery_targets = vec![
                    "255.255.255.255:12000".parse::<SocketAddr>().unwrap(),
                    "127.0.0.1:12000".parse::<SocketAddr>().unwrap(),
                ];

                let peers = Arc::new(Mutex::new(vec![
                    "255.255.255.255:12000".to_string(),
                    "127.0.0.1:12000".to_string(),
                ]));

                // Create shared global state wrapped in Arc for web daemon integration
                let app_state_arc = Arc::new(AppState {
                    transport: Arc::clone(&transport),
                    identity: Arc::clone(&identity),
                    node_id,
                    session_id,
                    sequence_counter: Arc::clone(&sequence_counter),
                    peer_table: Arc::clone(&peer_table),
                    replay_ledger: Arc::clone(&replay_ledger),
                    last_sent_acks: Arc::clone(&last_sent_acks),
                    local_port,
                    latest_received_vector: Arc::clone(&latest_received_vector),
                    peers: Arc::clone(&peers),
                });

                // Spawn Localhost HTTP Web Visualizer on port 8080!
                let web_state_clone = Arc::clone(&app_state_arc);
                tokio::spawn(async move {
                    web::start_web_server(web_state_clone).await;
                });

                // 1. Spawns background receiver loop
                let rx_transport = Arc::clone(&transport);
                let tx_transport_clone = Arc::clone(&transport);
                let local_node_id = node_id;
                let rx_ledger = Arc::clone(&replay_ledger);
                let rx_peer_table = Arc::clone(&peer_table);
                let rx_sequence_counter = Arc::clone(&sequence_counter);
                let rx_identity = Arc::clone(&identity);
                let rx_app_handle = handle.clone();
                let rx_peers = Arc::clone(&peers);
                let rx_last_sent_acks = Arc::clone(&last_sent_acks);
                let rx_latest_vector = Arc::clone(&latest_received_vector);

                tokio::spawn(async move {
                    loop {
                        match rx_transport.receive().await {
                            Ok((envelope, src, wire_size)) => {
                                let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

                                // Perform packet validation
                                if let Err(e) = envelope.validate_envelope(now_ms, wire_size) {
                                    eprintln!("[DROP] Validation failure from {}: {}", src, e);
                                    continue;
                                }

                                // Convert sender_id bytes slice safely to array for cryptographic verify & mapping
                                let mut sender_arr = [0u8; 32];
                                if envelope.sender_id.len() == 32 {
                                    sender_arr.copy_from_slice(&envelope.sender_id);
                                } else {
                                    eprintln!("[DROP] Unsupported Node ID key length: {}", envelope.sender_id.len());
                                    continue;
                                }

                                // Self-filter loopbacks
                                if sender_arr == local_node_id {
                                    continue;
                                }

                                // Cryptographic signature integrity check
                                if !envelope.verify_signature() {
                                    eprintln!("[DROP] Cryptographic signature INVALID from {}", src);
                                    continue;
                                }

                                // Replay protection check
                                {
                                    let mut ledger = rx_ledger.lock().await;
                                    
                                    // Bounded Replay Ledger Size Guard (Evicts table under potential overflow attacks)
                                    if ledger.len() >= MAX_REPLAY_LEDGER_ENTRIES {
                                        ledger.clear();
                                    }

                                    let key = (sender_arr, envelope.session_id);
                                    if let Some(highest_seq) = ledger.get(&key) {
                                        if envelope.sequence <= *highest_seq {
                                            eprintln!(
                                                "[DROP] Replay threat detected from {}: Seq {} <= highest seen ({})",
                                                src, envelope.sequence, *highest_seq
                                            );
                                            continue;
                                        }
                                    }
                                    ledger.insert(key, envelope.sequence);
                                }

                                // Match message types safely
                                match envelope.message_type {
                                    MSG_TYPE_DISCOVERY_BEACON => {
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            // Enforce robust protocol-level validation of discovery beacons
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery beacon from {}: {}", src, e);
                                                continue;
                                            }

                                            // Enforce tight locking scope for table modification (drops lock before send.await!)
                                            let (is_new, should_handshake, clamped_ttl) = {
                                                let mut table = rx_peer_table.lock().await;
                                                
                                                // Enforce MAX_PEERS table size ceiling
                                                if table.len() >= MAX_PEERS && !table.contains_key(&sender_arr) {
                                                    eprintln!("[DROP] Peer table full. Rejecting new node at {}", src);
                                                    continue;
                                                }

                                                let is_new = !table.contains_key(&sender_arr);
                                                
                                                // Clamp TTL locally to prevent overflow/exploit bounds
                                                let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                                let record = PeerRecord {
                                                    node_id: sender_arr,
                                                    observed_addr: src,
                                                    status: PeerStatus::Active,
                                                    protocol_version: envelope.version,
                                                    capabilities: beacon.capabilities,
                                                    vector_dim: beacon.vector_dim,
                                                    session_id: beacon.session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + clamped_ttl as u64,
                                                    highest_sequence: envelope.sequence,
                                                };
                                                table.insert(sender_arr, record);

                                                if is_new {
                                                    let hex_node = format_hex(&sender_arr);
                                                    println!(
                                                        "\n[DISCOVERY] Discovered Familiar Node [{}] at {}",
                                                        &hex_node[..12],
                                                        src
                                                    );

                                                    // Update flat list for UI matching
                                                    {
                                                        let mut flat = rx_peers.lock().await;
                                                        let src_str = src.to_string();
                                                        if !flat.contains(&src_str) {
                                                            flat.push(src_str);
                                                        }
                                                    }
                                                }

                                                // Rate-limited bi-directional handshake response (resolves fallback liveness issues)
                                                let mut acks = rx_last_sent_acks.lock().await;
                                                let last_sent = acks.entry(sender_arr).or_insert(0);
                                                let should_handshake = is_new || now_ms - *last_sent > ACK_RATE_LIMIT_MS;
                                                if should_handshake {
                                                    *last_sent = now_ms;
                                                }
                                                (is_new, should_handshake, clamped_ttl)
                                            };

                                            if should_handshake {
                                                // Respond with a directed handshake (consuming from global sequence)
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                let discovery_payload = BraidDiscoveryBeacon {
                                                    session_id,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    max_packet_size: MAX_PACKET_SIZE as u16,
                                                    listen_port: local_port,
                                                    ttl_ms: clamped_ttl,
                                                };
                                                if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                                                    if let Ok(handshake) = BraidEnvelope::create(
                                                        MSG_TYPE_DISCOVERY_ACK, // Respond with clean, non-looping ACK type!
                                                        local_node_id.to_vec(),
                                                        session_id,
                                                        seq,
                                                        now_ms,
                                                        serialized_beacon,
                                                        &rx_identity.signing_key,
                                                    ) {
                                                        // Non-blocking asynchronous send (table and ack locks are already dropped!)
                                                        let _ = tx_transport_clone.send(&handshake, &src).await;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    MSG_TYPE_DISCOVERY_ACK => {
                                        // Discovery ACKs are evaluated and recorded, but never replied to (prevents ping-pongs)
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery ACK from {}: {}", src, e);
                                                continue;
                                            }

                                            let mut table = rx_peer_table.lock().await;
                                            let is_new = !table.contains_key(&sender_arr);
                                            let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                            let record = PeerRecord {
                                                node_id: sender_arr,
                                                observed_addr: src,
                                                status: PeerStatus::Active,
                                                protocol_version: envelope.version,
                                                capabilities: beacon.capabilities,
                                                vector_dim: beacon.vector_dim,
                                                session_id: beacon.session_id,
                                                last_seen_ms: now_ms,
                                                expires_at_ms: now_ms + clamped_ttl as u64,
                                                highest_sequence: envelope.sequence,
                                            };
                                            table.insert(sender_arr, record);

                                            if is_new {
                                                let hex_node = format_hex(&sender_arr);
                                                println!(
                                                    "\n[DISCOVERY] Registered Familiar Node Handshake [{}] at {}",
                                                    &hex_node[..12],
                                                    src
                                                );

                                                // Update flat list for UI matching
                                                {
                                                    let mut flat = rx_peers.lock().await;
                                                    let src_str = src.to_string();
                                                    if !flat.contains(&src_str) {
                                                        flat.push(src_str);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    MSG_TYPE_STATE_DRIFT => {
                                        // Dynamic Vector Dimension check fetched safely from verified peer table record
                                        let expected_dim = {
                                            let table = rx_peer_table.lock().await;
                                            table.get(&sender_arr)
                                                .map(|record| record.vector_dim as usize)
                                                .unwrap_or(EXPECTED_VECTOR_DIM) // default fallback
                                        };

                                        if let Ok(drift) = bincode::deserialize::<BraidStateDrift>(&envelope.payload) {
                                            // Enforce dynamic dimension limit
                                            if drift.latent_vector.len() != expected_dim {
                                                eprintln!(
                                                    "[DROP] Dimension mismatch from {}: expected {}, received {}",
                                                    src, expected_dim, drift.latent_vector.len()
                                                );
                                                continue;
                                            }

                                            if drift.latent_vector.iter().any(|v| !v.is_finite()) {
                                                continue;
                                            }

                                            // Update latest received vector cache for localhost web visualizer
                                            {
                                                let mut vec_guard = rx_latest_vector.lock().await;
                                                *vec_guard = drift.latent_vector.clone();
                                            }

                                            // Extend peer's TTL lease and liveness state on valid state drift packet arrival
                                            {
                                                let mut table = rx_peer_table.lock().await;
                                                if let Some(record) = table.get_mut(&sender_arr) {
                                                    record.last_seen_ms = now_ms;
                                                    record.expires_at_ms = now_ms + 15_000; // extend lease by 15s
                                                    record.highest_sequence = envelope.sequence;
                                                    record.status = PeerStatus::Active;
                                                }
                                            }

                                            let hex_node = format_hex(&sender_arr);
                                            let payload = serde_json::json!({
                                                "node_id": hex_node,
                                                "timestamp": envelope.timestamp,
                                                "sequence_id": envelope.sequence,
                                                "latent_vector": drift.latent_vector,
                                                "sender_address": src.to_string(),
                                                "byte_size": wire_size,
                                            });
                                            let _ = rx_app_handle.emit_all("udp-packet-received", payload);
                                        }
                                    }
                                    other_type => {
                                        eprintln!(
                                            "[WARN] Received unsupported message type {} from {}",
                                            other_type, src
                                        );
                                    }
                                }
                            }
                            Err(_) => {
                                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
                            }
                        }
                    }
                });

                // 2. Spawns background discovery broadcast beacon loop with Jitter (±500ms)
                let tx_discovery_transport = Arc::clone(&transport);
                let tx_targets = discovery_targets;
                let discovery_signing_key = identity.signing_key.clone();
                let tx_sequence_counter = Arc::clone(&sequence_counter);

                tokio::spawn(async move {
                    let base_ms = 3000u64;
                    loop {
                        // Apply random jitter to prevent network collisions/clumping
                        let jitter = rand::thread_rng().gen_range(-500..=500);
                        let sleep_ms = (base_ms as i32 + jitter) as u64;
                        tokio::time::sleep(tokio::time::Duration::from_millis(sleep_ms)).await;
                        
                        let timestamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        let seq = tx_sequence_counter.fetch_add(1, Ordering::SeqCst);

                        let discovery_payload = BraidDiscoveryBeacon {
                            session_id,
                            capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32,
                            vector_dim: EXPECTED_VECTOR_DIM as u16,
                            max_packet_size: MAX_PACKET_SIZE as u16,
                            listen_port: local_port,
                            ttl_ms: 15000,
                        };

                        if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                            if let Ok(beacon_envelope) = BraidEnvelope::create(
                                MSG_TYPE_DISCOVERY_BEACON,
                                node_id.to_vec(),
                                session_id,
                                seq,
                                timestamp,
                                serialized_beacon,
                                &discovery_signing_key,
                            ) {
                                for peer_addr in tx_targets.iter() {
                                    let _ = tx_discovery_transport.send(&beacon_envelope, peer_addr).await;
                                }
                            }
                        }
                    }
                });

                // 3. Spawns peer table TTL expiration cleanup loop (runs every 5s)
                let tx_cleanup_peer_table = Arc::clone(&peer_table);
                let tx_cleanup_flat_peers = Arc::clone(&peers);
                tokio::spawn(async move {
                    let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(5));
                    loop {
                        interval.tick().await;
                        let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        
                        let mut expired_peers = Vec::new();
                        {
                            let mut table = tx_cleanup_peer_table.lock().await;
                            table.retain(|sender_id, val| {
                                if now_ms > val.expires_at_ms {
                                    let hex_node = format_hex(sender_id);
                                    println!("[PRUNE] Peer expired (TTL): {} at {}", &hex_node[..12], val.observed_addr);
                                    expired_peers.push(val.observed_addr.to_string());
                                    false
                                } else {
                                    true
                                }
                            });
                        }

                        // Update flat list matching table
                        if !expired_peers.is_empty() {
                            let mut peer_list = tx_cleanup_flat_peers.lock().await;
                            peer_list.retain(|addr| !expired_peers.contains(addr));
                        }
                    }
                });

                // Manage Tauri state using our fully loaded shared Arc
                handle.manage(app_state_arc);
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_node_info,
            get_peers,
            stream_state_drift
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
