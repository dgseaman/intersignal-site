#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

use serde::{Serialize, Deserialize};
use std::sync::Arc;
use tokio::net::UdpSocket;
use tokio::sync::Mutex;
use tauri::Manager;
use rand::Rng;
use std::time::{SystemTime, UNIX_EPOCH};
use std::net::SocketAddr;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidPacket {
    pub node_id: [u8; 32],
    pub timestamp: u64,
    pub sequence_id: u64,
    pub latent_vector: Vec<f32>,
}

pub struct AppState {
    pub socket: Arc<UdpSocket>,
    pub node_id: [u8; 32],
    pub sequence_counter: Arc<Mutex<u64>>,
    pub peers: Arc<Mutex<Vec<String>>>,
}

fn format_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect::<Vec<String>>().join("")
}

#[tauri::command]
async fn get_node_info(state: tauri::State<'_, AppState>) -> Result<serde_json::Value, String> {
    let local_addr = state.socket.local_addr().map_err(|e| e.to_string())?.to_string();
    Ok(serde_json::json!({
        "node_id": format_hex(&state.node_id),
        "local_address": local_addr,
    }))
}

#[tauri::command]
async fn get_peers(state: tauri::State<'_, AppState>) -> Result<Vec<String>, String> {
    let peers = state.peers.lock().await;
    Ok(peers.clone())
}

#[tauri::command]
async fn add_peer(peer: String, state: tauri::State<'_, AppState>) -> Result<(), String> {
    // Validate peer format by parsing it to a standard SocketAddr
    let addr = peer.trim().parse::<SocketAddr>().map_err(|e| format!("Invalid peer address '{}': {}", peer, e))?;
    let mut peers = state.peers.lock().await;
    let addr_str = addr.to_string();
    if !peers.contains(&addr_str) {
        peers.push(addr_str);
    }
    Ok(())
}

#[tauri::command]
async fn remove_peer(peer: String, state: tauri::State<'_, AppState>) -> Result<(), String> {
    let mut peers = state.peers.lock().await;
    peers.retain(|p| p != &peer);
    Ok(())
}

#[tauri::command]
async fn stream_state_drift(
    latent_vector: Vec<f32>,
    state: tauri::State<'_, AppState>,
) -> Result<serde_json::Value, String> {
    if latent_vector.is_empty() {
        return Err("Latent vector cannot be empty".to_string());
    }

    let mut seq_guard = state.sequence_counter.lock().await;
    let sequence_id = *seq_guard;
    *seq_guard += 1;

    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_millis() as u64;

    let packet = BraidPacket {
        node_id: state.node_id,
        timestamp,
        sequence_id,
        latent_vector,
    };

    let serialized = bincode::serialize(&packet).map_err(|e| e.to_string())?;

    let _ = state.socket.set_broadcast(true);

    let peers = state.peers.lock().await;
    let mut sent_count = 0;
    let mut failures = Vec::new();

    for peer in peers.iter() {
        match state.socket.send_to(&serialized, peer).await {
            Ok(_) => {
                sent_count += 1;
            }
            Err(e) => {
                failures.push(format!("{}: {}", peer, e));
            }
        }
    }

    Ok(serde_json::json!({
        "sequence_id": sequence_id,
        "timestamp": timestamp,
        "sent_count": sent_count,
        "failures": failures,
    }))
}

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle();
            tauri::async_runtime::block_on(async move {
                let bind_addr = "0.0.0.0:12000";
                let socket = match UdpSocket::bind(bind_addr).await {
                    Ok(s) => Arc::new(s),
                    Err(_) => {
                        let fallback_socket = UdpSocket::bind("0.0.0.0:0")
                            .await
                            .expect("Failed to bind UDP socket to any port");
                        Arc::new(fallback_socket)
                    }
                };

                let mut node_id = [0u8; 32];
                rand::thread_rng().fill(&mut node_id);

                let sequence_counter = Arc::new(Mutex::new(0u64));
                let peers = Arc::new(Mutex::new(vec![
                    "255.255.255.255:12000".to_string(),
                    "127.0.0.1:12000".to_string(),
                ]));

                let rx_socket = Arc::clone(&socket);
                let rx_app_handle = handle.clone();
                
                tokio::spawn(async move {
                    let mut buf = vec![0u8; 65535];
                    loop {
                        match rx_socket.recv_from(&mut buf).await {
                            Ok((size, src)) => {
                                let data = &buf[..size];
                                match bincode::deserialize::<BraidPacket>(data) {
                                    Ok(packet) => {
                                        // Self-filter loopbacks / echoed broadcasts
                                        if packet.node_id == node_id {
                                            continue;
                                        }

                                        let hex_node = format_hex(&packet.node_id);
                                        let payload = serde_json::json!({
                                            "node_id": hex_node,
                                            "timestamp": packet.timestamp,
                                            "sequence_id": packet.sequence_id,
                                            "latent_vector": packet.latent_vector,
                                            "sender_address": src.to_string(),
                                            "byte_size": size,
                                        });
                                        let _ = rx_app_handle.emit_all("udp-packet-received", payload);
                                    }
                                    Err(_) => {
                                        // Ignore malformed packets silently
                                    }
                                }
                            }
                            Err(_) => {
                                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
                            }
                        }
                    }
                });

                handle.manage(AppState {
                    socket,
                    node_id,
                    sequence_counter,
                    peers,
                });
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_node_info,
            get_peers,
            add_peer,
            remove_peer,
            stream_state_drift
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
