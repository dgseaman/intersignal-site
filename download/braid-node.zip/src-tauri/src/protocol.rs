use serde::{Serialize, Deserialize};
use ed25519_dalek::{VerifyingKey, Signature};

pub const PROTOCOL_VERSION: u16 = 3; // Braid v0.3.1 / v0.4.1 Protocol Version

pub const MSG_TYPE_STATE_DRIFT: u16 = 1;
pub const MSG_TYPE_HEARTBEAT: u16 = 2; // Reserved for future v0.4 heartbeats
pub const MSG_TYPE_DISCOVERY_BEACON: u16 = 3;
pub const MSG_TYPE_DISCOVERY_ACK: u16 = 4; // Discovery acknowledgement

// Cryptographic and Payload Agnostic Schemes
pub const SCHEME_ED25519: u8 = 0; // Default Ed25519 Signatures
pub const ENCODING_RAW_F32: u8 = 0; // Default Raw F32 Vector array

// Protocol Constants
pub const MAX_PACKET_SIZE: usize = 2048; 
pub const EXPECTED_VECTOR_DIM: usize = 384; 
pub const MAX_TIMESTAMP_DRIFT_SECS: u64 = 60; 

// Capability Bits
pub const CAP_STATE_DRIFT: u64 = 1 << 0;
pub const CAP_DISCOVERY: u64 = 1 << 1;
pub const CAP_UDP_TRANSPORT: u64 = 1 << 2;
pub const CAP_VECTOR_384_F32: u64 = 1 << 3;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidSigningBody {
    pub version: u16,
    pub message_type: u16,
    pub signature_scheme: u8,     // Support for pluggable crypto schemes
    pub payload_encoding: u8,     // Support for multi-format payloads (f32, f16, i8)
    pub sender_id: Vec<u8>,       // Variable-length public verifying key
    pub session_id: [u8; 16],     // Hardens against key restarts sequence reset
    pub sequence: u64,
    pub timestamp: u64,
    pub payload: Vec<u8>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidEnvelope {
    pub version: u16,
    pub message_type: u16,
    pub signature_scheme: u8,
    pub payload_encoding: u8,
    pub sender_id: Vec<u8>,
    pub session_id: [u8; 16],
    pub sequence: u64,
    pub timestamp: u64,
    pub signature: Vec<u8>,       // Variable-length signature payload
    pub payload: Vec<u8>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidStateDrift {
    pub latent_vector: Vec<f32>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidDiscoveryBeacon {
    pub session_id: [u8; 16],
    pub capabilities: u64,
    pub vector_dim: u16,
    pub max_packet_size: u16,
    pub listen_port: u16,
    pub ttl_ms: u32,
}

impl BraidEnvelope {
    /// Create a new signed envelope using BraidSigningBody
    pub fn create(
        message_type: u16,
        sender_id: Vec<u8>,
        session_id: [u8; 16],
        sequence: u64,
        timestamp: u64,
        payload: Vec<u8>,
        signing_key: &ed25519_dalek::SigningKey,
    ) -> Result<Self, String> {
        let body = BraidSigningBody {
            version: PROTOCOL_VERSION,
            message_type,
            signature_scheme: SCHEME_ED25519,
            payload_encoding: ENCODING_RAW_F32,
            sender_id,
            session_id,
            sequence,
            timestamp,
            payload,
        };

        let sig_data = bincode::serialize(&body).map_err(|e| e.to_string())?;
        
        use ed25519_dalek::Signer;
        let signature = signing_key.sign(&sig_data);

        Ok(BraidEnvelope {
            version: body.version,
            message_type: body.message_type,
            signature_scheme: body.signature_scheme,
            payload_encoding: body.payload_encoding,
            sender_id: body.sender_id,
            session_id: body.session_id,
            sequence: body.sequence,
            timestamp: body.timestamp,
            signature: signature.to_bytes().to_vec(),
            payload: body.payload,
        })
    }

    /// Verify signature on the envelope against the signing body
    pub fn verify_signature(&self) -> bool {
        if self.signature_scheme == SCHEME_ED25519 {
            let verifying_key_bytes: Result<[u8; 32], _> = self.sender_id.clone().try_into();
            let signature_bytes: Result<[u8; 64], _> = self.signature.clone().try_into();

            match (verifying_key_bytes, signature_bytes) {
                (Ok(key_arr), Ok(sig_arr)) => {
                    let verifying_key_res = VerifyingKey::from_bytes(&key_arr);
                    let signature = Signature::from_bytes(&sig_arr);

                    match verifying_key_res {
                        Ok(pubkey) => {
                            let body = BraidSigningBody {
                                version: self.version,
                                message_type: self.message_type,
                                signature_scheme: self.signature_scheme,
                                payload_encoding: self.payload_encoding,
                                sender_id: self.sender_id.clone(),
                                session_id: self.session_id,
                                sequence: self.sequence,
                                timestamp: self.timestamp,
                                payload: self.payload.clone(),
                            };
                            
                            if let Ok(data) = bincode::serialize(&body) {
                                use ed25519_dalek::Verifier;
                                pubkey.verify(&data, &signature).is_ok()
                            } else {
                                false
                            }
                        }
                        _ => false,
                    }
                }
                _ => false,
            }
        } else {
            // Unimplemented/Unsupported signature schemes in this build (KMS/HSM plugs)
            false
        }
    }

    /// Validate basic envelope properties: size limit, clock skew, and protocol version
    pub fn validate_envelope(&self, current_time_ms: u64, packet_size: usize) -> Result<(), String> {
        if packet_size > MAX_PACKET_SIZE {
            return Err(format!("Packet exceeds size limit: {} > {} bytes", packet_size, MAX_PACKET_SIZE));
        }

        if self.version != PROTOCOL_VERSION {
            return Err(format!("Unsupported protocol version: {}", self.version));
        }

        // Check clock skew tolerance (±60 seconds)
        let drift = (current_time_ms as i128 - self.timestamp as i128).abs();
        let max_drift = (MAX_TIMESTAMP_DRIFT_SECS * 1000) as i128;
        if drift > max_drift {
            return Err(format!("Timestamp skew exceeded: {} ms (max allowed: {} ms)", drift, max_drift));
        }

        Ok(())
    }
}
