use serde::{Serialize, Deserialize};
use ed25519_dalek::{VerifyingKey, Signature};
use sha2::{Sha256, Digest};

pub const WIRE_PROTOCOL_VERSION: u16 = 5; // Braid Pathfinder Wire Protocol v5

// Message Type Registries
pub const MSG_STATE_DRIFT: u16 = 1;
pub const MSG_HEARTBEAT: u16 = 2; // Reserved for liveness heartbeat
pub const MSG_DISCOVERY_BEACON: u16 = 3;
pub const MSG_DISCOVERY_ACK: u16 = 4;
pub const MSG_PEER_GOODBYE: u16 = 5; // Peer graceful exit
pub const MSG_LINK_PROBE: u16 = 6;   // Path health latency probe
pub const MSG_LINK_PROBE_ACK: u16 = 7; // Path health latency probe reply

// Pluggable Registries
pub const SCHEME_UNKNOWN: u16 = 0;
pub const SCHEME_ED25519: u16 = 1; // Default Ed25519 scheme in v5

// Encodings Namespace
pub const ENCODING_UNKNOWN: u16 = 0;
pub const ENCODING_RAW_F32: u16 = 1; // Default state vector codec
pub const ENCODING_BINCODE: u16 = 1; // Default wire codec

// Protocol Constants
pub const MAX_PACKET_SIZE: usize = 2048; 
pub const EXPECTED_VECTOR_DIM: usize = 384; 
pub const MAX_TIMESTAMP_DRIFT_SECS: u64 = 60; 

// Capability Bits
pub const CAP_STATE_DRIFT: u64 = 1 << 0;
pub const CAP_DISCOVERY: u64 = 1 << 1;
pub const CAP_UDP_TRANSPORT: u64 = 1 << 2;
pub const CAP_VECTOR_384_F32: u64 = 1 << 3;

pub type NodeId = [u8; 32]; // Fixed-size canonical node identity key

// =====================================================================
// NODE IDENTITY HASH DERIVATION (Standardized SHA-256)
// =====================================================================

pub fn derive_node_id(scheme_id: u16, public_material: &[u8]) -> NodeId {
    let mut hasher = Sha256::new();
    hasher.update(b"braid-node-id-v1");
    hasher.update(&scheme_id.to_be_bytes());
    hasher.update(public_material);
    let result = hasher.finalize();
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&result);
    node_id
}

// =====================================================================
// PORTABLE IDENTITY PROVIDER TRAIT
// =====================================================================

pub trait IdentityProvider: Send + Sync {
    fn scheme_id(&self) -> u16;
    fn public_material(&self) -> Vec<u8>;
    fn node_id(&self) -> NodeId;
    fn sign(&self, message: &[u8]) -> Result<Vec<u8>, String>;
}

pub struct Ed25519LocalIdentityProvider {
    pub signing_key: ed25519_dalek::SigningKey,
}

impl Ed25519LocalIdentityProvider {
    pub fn new(signing_key: ed25519_dalek::SigningKey) -> Self {
        Self { signing_key }
    }
}

impl IdentityProvider for Ed25519LocalIdentityProvider {
    fn scheme_id(&self) -> u16 {
        SCHEME_ED25519
    }

    fn public_material(&self) -> Vec<u8> {
        self.signing_key.verifying_key().to_bytes().to_vec()
    }

    fn node_id(&self) -> NodeId {
        derive_node_id(self.scheme_id(), &self.public_material())
    }

    fn sign(&self, message: &[u8]) -> Result<Vec<u8>, String> {
        use ed25519_dalek::Signer;
        let sig = self.signing_key.sign(message);
        Ok(sig.to_bytes().to_vec())
    }
}

// =====================================================================
// WIRE PROTOCOL LAYOUT
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidSigningBody {
    pub version: u16,
    pub message_type: u16,
    pub signature_scheme: u16,
    pub wire_encoding: u16,
    pub state_vector_encoding: u16,
    pub node_id: NodeId,          // Derived from SHA-256 hash of public material
    pub public_material: Vec<u8>, // Pluggable public key details
    pub session_id: [u8; 16],
    pub sequence: u64,
    pub timestamp: u64,
    pub payload: Vec<u8>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidEnvelope {
    pub version: u16,
    pub message_type: u16,
    pub signature_scheme: u16,
    pub wire_encoding: u16,
    pub state_vector_encoding: u16,
    pub node_id: NodeId,
    pub public_material: Vec<u8>,
    pub session_id: [u8; 16],
    pub sequence: u64,
    pub timestamp: u64,
    pub signature: Vec<u8>,       // Variable-length signature payload
    pub payload: Vec<u8>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidStateDrift {
    pub latent_vector: Vec<f32>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidDiscoveryBeacon {
    pub session_id: [u8; 16],
    pub capabilities: u64,
    pub vector_dim: u16,
    pub max_packet_size: u16,
    pub listen_port: u16,
    pub ttl_ms: u32,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidLinkProbe {
    pub ping_seq: u64,
    pub tx_timestamp_ms: u64,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct BraidLinkProbeAck {
    pub ping_seq: u64,
    pub tx_timestamp_ms: u64,
    pub rx_timestamp_ms: u64,
}

impl BraidEnvelope {
    /// Create a new signed envelope using BraidSigningBody and IdentityProvider
    pub fn create(
        message_type: u16,
        session_id: [u8; 16],
        sequence: u64,
        timestamp: u64,
        payload: Vec<u8>,
        provider: &dyn IdentityProvider,
    ) -> Result<Self, String> {
        let body = BraidSigningBody {
            version: WIRE_PROTOCOL_VERSION,
            message_type,
            signature_scheme: provider.scheme_id(),
            wire_encoding: ENCODING_BINCODE,
            state_vector_encoding: ENCODING_RAW_F32,
            node_id: provider.node_id(),
            public_material: provider.public_material(),
            session_id,
            sequence,
            timestamp,
            payload,
        };

        let sig_data = bincode::serialize(&body).map_err(|e| e.to_string())?;
        let signature = provider.sign(&sig_data)?;

        Ok(BraidEnvelope {
            version: body.version,
            message_type: body.message_type,
            signature_scheme: body.signature_scheme,
            wire_encoding: body.wire_encoding,
            state_vector_encoding: body.state_vector_encoding,
            node_id: body.node_id,
            public_material: body.public_material,
            session_id: body.session_id,
            sequence: body.sequence,
            timestamp: body.timestamp,
            signature,
            payload: body.payload,
        })
    }

    /// Verify signature on the envelope against the signing body
    pub fn verify_signature(&self) -> bool {
        // Enforce strict Node ID derivation matching prior to crypto signature evaluation
        let derived_id = derive_node_id(self.signature_scheme, &self.public_material);
        if self.node_id != derived_id {
            eprintln!("[DROP] Derived Node ID does not match declared node_id!");
            return false;
        }

        if self.signature_scheme == SCHEME_ED25519 {
            let verifying_key_bytes: Result<[u8; 32], _> = self.public_material.clone().try_into();
            let signature_bytes: Result<[u8; 64], _> = self.signature.clone().try_into();

            match (verifying_key_bytes, signature_bytes) {
                (Ok(key_arr), Ok(sig_arr)) => {
                    let verifying_key_res = VerifyingKey::from_bytes(&key_arr);
                    let signature = Signature::from_bytes(&sig_arr);

                    match verifying_key_res {
                        Ok(pubkey) => {
                            let body = BraidSigningBody {
                                version: self.version,
                                message_type: self.message_type,
                                signature_scheme: self.signature_scheme,
                                wire_encoding: self.wire_encoding,
                                state_vector_encoding: self.state_vector_encoding,
                                node_id: self.node_id,
                                public_material: self.public_material.clone(),
                                session_id: self.session_id,
                                sequence: self.sequence,
                                timestamp: self.timestamp,
                                payload: self.payload.clone(),
                            };
                            
                            if let Ok(data) = bincode::serialize(&body) {
                                use ed25519_dalek::Verifier;
                                pubkey.verify(&data, &signature).is_ok()
                            } else {
                                false
                            }
                        }
                        _ => false,
                    }
                }
                _ => false,
            }
        } else {
            false
        }
    }

    /// Validate basic envelope properties: size limit, clock skew, and protocol version
    pub fn validate_envelope(&self, current_time_ms: u64, packet_size: usize) -> Result<(), String> {
        if packet_size > MAX_PACKET_SIZE {
            return Err(format!("Packet exceeds size limit: {} > {} bytes", packet_size, MAX_PACKET_SIZE));
        }

        if self.version != WIRE_PROTOCOL_VERSION {
            return Err(format!("Unsupported protocol version: {}", self.version));
        }

        // Check clock skew tolerance (±60 seconds)
        let drift = (current_time_ms as i128 - self.timestamp as i128).abs();
        let max_drift = (MAX_TIMESTAMP_DRIFT_SECS * 1000) as i128;
        if drift > max_drift {
            return Err(format!("Timestamp skew exceeded: {} ms (max allowed: {} ms)", drift, max_drift));
        }

        Ok(())
    }
}

// =====================================================================
// SYSTEM-LEVEL PACKET CEILING TESTING
// =====================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use rand::rngs::OsRng;
    use ed25519_dalek::SigningKey;

    #[test]
    fn signed_384_f32_state_drift_envelope_stays_under_udp_ceiling() {
        let mut csprng = OsRng;
        let signing_key = SigningKey::generate(&mut csprng);
        let provider = Ed25519LocalIdentityProvider::new(signing_key);

        // Populate worst-case f32 vector of exactly 384 dimensions
        let vector = vec![1.2345f32; EXPECTED_VECTOR_DIM];
        let drift = BraidStateDrift { latent_vector: vector };
        let payload = bincode::serialize(&drift).unwrap();

        // Create the signed Braid Pathfinder v5 envelope
        let envelope = BraidEnvelope::create(
            MSG_STATE_DRIFT,
            [255u8; 16],
            999_999u64,
            1_719_876_543_210u64,
            payload,
            &provider,
        ).unwrap();

        let serialized = bincode::serialize(&envelope).unwrap();
        println!("Worst-case signed state drift envelope size: {} bytes", serialized.len());
        
        // Assert the worst-case packet remains under the 2048-byte MTU ceiling!
        assert!(
            serialized.len() < MAX_PACKET_SIZE,
            "Serialized packet size {} exceeds maximum MTU ceiling {}",
            serialized.len(),
            MAX_PACKET_SIZE
        );
    }
}
