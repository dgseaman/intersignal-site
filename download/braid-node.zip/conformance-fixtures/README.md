# Braid Pathfinder v0.6 Conformance Fixtures & Test Vectors

These files serve as language-agnostic cross-verification test vectors. Implementers of Braid clients in Python, Go, TypeScript, C++, or other systems must verify that their cryptographic derivations, key layouts, payload serializations, and signature preimages produce exact matching byte structures to the Rust node.

## Directory Contents

1.  `keys.ed25519.public.hex`: Raw 32-byte Ed25519 public verifying material used to derive the `NodeId`.
2.  `derived_node_id.hex`: Expected derived 32-byte canonical `NodeId` from public key material.
3.  `BraidSigningBody.packed.hex`: Expected deterministic big-endian packed bytes (preimage for signature signing/verification).
4.  `vectors.f32.hex`: Sample raw f32 array (384 float coefficients).
5.  `vectors.qint8.hex`: Calibrated quantized i8 representation showing scale, zero_point, and raw 8-bit vector integers.
