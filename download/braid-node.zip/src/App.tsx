import React, { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/tauri";
import { listen } from "@tauri-apps/api/event";

interface UdpPacketPayload {
  node_id: string;
  timestamp: number;
  sequence_id: number;
  latent_vector: number[];
  sender_address: string;
  byte_size: number;
}

interface NodeInfo {
  node_id: string;
  local_address: string;
  software_version: string;
  wire_version: number;
}

interface StreamResult {
  sequence_id: number;
  timestamp: number;
  sent_count: number;
  failures: string[];
}

export default function App() {
  const [nodeInfo, setNodeInfo] = useState<NodeInfo | null>(null);
  const [peers, setPeers] = useState<string[]>([]);
  const [receivedPackets, setReceivedPackets] = useState<UdpPacketPayload[]>([]);
  const [vector, setVector] = useState<number[]>([]);
  const [vectorDim] = useState<number>(384);
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [lastBroadcastResult, setLastBroadcastResult] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"visualizer" | "raw">("visualizer");

  // Fetch initial info
  useEffect(() => {
    async function loadData() {
      try {
        const info = await invoke<NodeInfo>("get_node_info");
        setNodeInfo(info);
        const peerList = await invoke<string[]>("get_peers");
        setPeers(peerList);
      } catch (err) {
        console.error("Failed to load node data:", err);
      }
    }
    loadData();
    generateRandomVector(vectorDim);
  }, []);

  // Poll for dynamically discovered peers in the background
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const peerList = await invoke<string[]>("get_peers");
        setPeers(peerList);
      } catch (err) {
        console.error("Failed to refresh peers:", err);
      }
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  // Listen for background UDP packets
  useEffect(() => {
    let unlistenFn: (() => void) | null = null;

    async function setupListener() {
      try {
        const unlisten = await listen<UdpPacketPayload>("udp-packet-received", (event) => {
          setReceivedPackets((prev) => {
            const updated = [event.payload, ...prev];
            return updated.slice(0, 100); // keep last 100 packets
          });
        });
        unlistenFn = unlisten;
      } catch (err) {
        console.error("Failed to bind Tauri event listener:", err);
      }
    }

    setupListener();

    return () => {
      if (unlistenFn) {
        unlistenFn();
      }
    };
  }, []);

  const generateRandomVector = (dim: number) => {
    const newVec = Array.from({ length: dim }, () => {
      return parseFloat((Math.random() * 2 - 1).toFixed(4));
    });
    setVector(newVec);
  };

  const handleStreamDrift = async () => {
    setIsBroadcasting(true);
    setLastBroadcastResult(null);
    try {
      const result = await invoke<StreamResult>("stream_state_drift", {
        latentVector: vector,
      });
      if (result.sent_count > 0) {
        setLastBroadcastResult(
          `Successfully broadcast Seq ${result.sequence_id} directly to ${result.sent_count} active peer(s).`
        );
      } else {
        setLastBroadcastResult(
          `Drift queued. Awaiting zero-config peer discovery...`
        );
      }
    } catch (err) {
      setLastBroadcastResult(`Broadcast failed: ${err}`);
    } finally {
      setIsBroadcasting(false);
    }
  };

  // Heatmap rendering utility for latent vector
  const renderHeatmap = (vec: number[], height: number = 80) => {
    if (vec.length === 0) return null;
    return (
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1px",
          background: "#161922",
          padding: "4px",
          borderRadius: "4px",
          maxHeight: `${height}px`,
          overflowY: "auto",
        }}
      >
        {vec.map((val, idx) => {
          const intensity = Math.min(Math.max((Math.abs(val)), 0), 1);
          const color =
            val >= 0
              ? `rgba(57, 219, 219, ${intensity})`  // Teal for positive
              : `rgba(235, 64, 52, ${intensity})`;   // Orange/Red for negative

          return (
            <div
              key={idx}
              title={`Index ${idx}: ${val.toFixed(4)}`}
              style={{
                width: "8px",
                height: "8px",
                backgroundColor: intensity < 0.05 ? "#242835" : color,
                borderRadius: "1px",
              }}
            />
          );
        })}
      </div>
    );
  };

  const getLatency = (timestamp: number): string => {
    const latencyMs = Date.now() - timestamp;
    if (!Number.isFinite(latencyMs)) return "unknown";
    if (latencyMs < 0) return "clock skew";
    if (latencyMs < 1000) {
      return `${latencyMs} ms`;
    }
    return `${(latencyMs / 1000).toFixed(1)} s`;
  };

  // Display all valid peers, including loopback nodes, for frictionless local-demo testing
  const activeUnicastPeers = peers.filter((p) => !p.includes("255.255"));

  const uniqueNodes = new Set(receivedPackets.map((p) => p.node_id));

  return (
    <div style={styles.container}>
      {/* HEADER */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.glowDot}></div>
          <h1 style={styles.title}>BRAID PATHFINDER v0.5</h1>
          <span style={styles.version}>0.5.1</span>
        </div>
        <div style={styles.headerRight}>
          {nodeInfo ? (
            <div style={styles.nodeMeta}>
              <span style={styles.label}>LOCAL PORT:</span>
              <code style={styles.code}>{nodeInfo.local_address.split(":").pop()}</code>
              <span style={{ ...styles.label, marginLeft: "15px" }}>NODE ID:</span>
              <code style={styles.code}>{nodeInfo.node_id.substring(0, 16)}...</code>
            </div>
          ) : (
            <span style={styles.connecting}>Initializing UDP Socket...</span>
          )}
        </div>
      </header>

      {/* DASHBOARD GRID */}
      <div style={styles.dashboard}>
        {/* LEFT COLUMN: Zero-Config Active Mesh Map */}
        <section style={styles.card}>
          <h2 style={styles.cardTitle}>Pathfinder Discovery Map</h2>
          <div style={styles.cardContent}>
            <div style={styles.peerListHeader}>
              <span>Discovered Peering Mesh ({activeUnicastPeers.length})</span>
            </div>
            
            <div style={styles.peerList}>
              {activeUnicastPeers.length === 0 ? (
                <div style={styles.emptyMeshState}>
                  <div style={styles.radarRing}></div>
                  <div style={{ marginTop: "12px", color: "#8a94a6", fontWeight: "600" }}>
                    Awaiting local peers...
                  </div>
                  <div style={{ fontSize: "11px", color: "#56617a", padding: "0 10px", marginTop: "4px" }}>
                    Broadcasting discovery beacons. Start another node on your LAN to auto-connect.
                  </div>
                </div>
              ) : (
                activeUnicastPeers.map((peer, idx) => (
                  <div key={idx} style={styles.peerItem}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <div style={styles.pulseGreen}></div>
                      <code style={styles.peerAddr}>{peer}</code>
                    </div>
                    <span style={styles.syncedLabel}>ACTIVE</span>
                  </div>
                ))
              )}
            </div>

            <div style={styles.note}>
              <strong>Novice-friendly Peering:</strong> Manual target configurations have been fully deprecated. Braid Pathfinder v0.5 automatically propagates and negotiates handshakes with other nodes on your local subnet using cryptographic verification.
            </div>
          </div>
        </section>

        {/* MIDDLE COLUMN: State Generator */}
        <section style={styles.card}>
          <div style={styles.cardHeaderWithControls}>
            <h2 style={styles.cardTitle}>State Drift Generator</h2>
            <div style={styles.dimensionSelector}>
              <span style={styles.miniLabel}>DIM:</span>
              <select disabled style={styles.select}>
                <option value="384">384 f32 (Hardened)</option>
              </select>
            </div>
          </div>

          <div style={styles.cardContent}>
            <div style={styles.tabHeader}>
              <button
                style={activeTab === "visualizer" ? styles.tabActive : styles.tab}
                onClick={() => setActiveTab("visualizer")}
              >
                Latent Heatmap
              </button>
              <button
                style={activeTab === "raw" ? styles.tabActive : styles.tab}
                onClick={() => setActiveTab("raw")}
              >
                Raw f32 Stream
              </button>
            </div>

            <div style={styles.vectorContainer}>
              {activeTab === "visualizer" ? (
                <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                  <div style={styles.heatmapLabel}>
                    Each block represents a dimensional f32 coefficient [-1.0, 1.0]. Teal is positive, red is negative, slate is baseline (0.0).
                  </div>
                  {renderHeatmap(vector, 180)}
                </div>
              ) : (
                <textarea
                  readOnly
                  value={JSON.stringify(vector)}
                  style={styles.textarea}
                />
              )}
            </div>

            <div style={styles.actionRow}>
              <button
                onClick={() => generateRandomVector(vectorDim)}
                style={styles.btnSecondary}
              >
                Randomize State
              </button>
              <button
                onClick={handleStreamDrift}
                disabled={isBroadcasting}
                style={styles.btnPrimary}
              >
                {isBroadcasting ? "Broadcasting..." : "Stream State Drift"}
              </button>
            </div>

            {lastBroadcastResult && (
              <div
                style={
                  lastBroadcastResult.includes("failed")
                    ? styles.statusError
                    : styles.statusSuccess
                }
              >
                {lastBroadcastResult}
              </div>
            )}
          </div>
        </section>

        {/* RIGHT COLUMN: Real-time Ingestion Feed */}
        <section style={styles.card}>
          <h2 style={styles.cardTitle}>Verified Ingestion Feed</h2>
          <div style={styles.cardContent}>
            <div style={styles.feedHeader}>
              <div style={styles.statMini}>
                <span style={styles.statMiniValue}>{receivedPackets.length}</span>
                <span style={styles.statMiniLabel}>Packets Received</span>
              </div>
              <div style={styles.statMini}>
                <span style={styles.statMiniValue}>{uniqueNodes.size}</span>
                <span style={styles.statMiniLabel}>Active Nodes</span>
              </div>
            </div>

            <div style={styles.feed}>
              {receivedPackets.length === 0 ? (
                <div style={styles.feedEmpty}>
                  <div style={styles.radarGlow}></div>
                  <span>Awaiting cryptographically signed state drift...</span>
                </div>
              ) : (
                receivedPackets.map((packet, idx) => {
                  const date = new Date(packet.timestamp);
                  const timeString = `${date.toLocaleTimeString()}.${String(packet.timestamp % 1000).padStart(3, "0")}`;
                  return (
                    <div key={idx} style={styles.feedItem}>
                      <div style={styles.feedItemHeader}>
                        <span style={styles.nodeIdBadge}>
                          Node: {packet.node_id.substring(0, 12)}
                        </span>
                        <span style={styles.latencyBadge}>
                          Latency: {getLatency(packet.timestamp)}
                        </span>
                      </div>

                      <div style={styles.packetDetails}>
                        <div>
                          <strong>From:</strong> <code>{packet.sender_address}</code>
                        </div>
                        <div>
                          <strong>Seq ID:</strong> <code>{packet.sequence_id}</code> |{" "}
                          <strong>Bytes:</strong> <code>{packet.byte_size} B</code>
                        </div>
                        <div style={{ color: "#8a94a6", fontSize: "11px", marginTop: "2px" }}>
                          <strong>Ingested At:</strong> {timeString}
                        </div>
                        <div style={{ color: "#39dbdb", fontWeight: "bold", fontSize: "10px", marginTop: "2px" }}>
                          🔒 CRYPTO SIGNATURE VERIFIED (ED25519)
                        </div>
                      </div>

                      <div style={{ marginTop: "6px" }}>
                        {renderHeatmap(packet.latent_vector, 50)}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </section>
      </div>

      {/* FOOTER STATS */}
      <footer style={styles.footer}>
        <div style={styles.footerBlock}>
          <span>PROTOCOL:</span>
          <strong>IMTP Wire Spec v5 (Zero-Config Handshake Enabled)</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>CRYPTO:</span>
          <strong>Ed25519 Signed Envelopes</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>STATUS:</span>
          <span style={{ color: "#39dbdb" }}>● ACTIVE PEER DISCOVERY</span>
        </div>
      </footer>
    </div>
  );
}

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    width: "100%",
    boxSizing: "border-box",
    backgroundColor: "#0d0e12",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "16px 24px",
    borderBottom: "1px solid #1c202d",
    backgroundColor: "#10121a",
  },
  headerLeft: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  glowDot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
    backgroundColor: "#39dbdb",
    boxShadow: "0 0 10px #39dbdb",
  },
  title: {
    margin: 0,
    fontSize: "16px",
    fontWeight: "700",
    letterSpacing: "1px",
    color: "#ffffff",
  },
  version: {
    fontSize: "11px",
    padding: "2px 6px",
    borderRadius: "3px",
    backgroundColor: "#202430",
    color: "#8a94a6",
    fontWeight: "600",
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
  },
  nodeMeta: {
    display: "flex",
    alignItems: "center",
    fontSize: "12px",
    backgroundColor: "#08090d",
    padding: "6px 12px",
    borderRadius: "6px",
    border: "1px solid #202430",
  },
  label: {
    color: "#56617a",
    marginRight: "6px",
    fontWeight: "600",
  },
  code: {
    color: "#39dbdb",
    fontFamily: "Courier, monospace",
    fontWeight: "700",
  },
  connecting: {
    color: "#ffad47",
    fontSize: "12px",
    fontWeight: "600",
  },
  dashboard: {
    display: "grid",
    gridTemplateColumns: "300px 1fr 340px",
    gap: "16px",
    padding: "16px",
    flex: 1,
    overflow: "hidden",
    boxSizing: "border-box",
  },
  card: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: "#10121a",
    border: "1px solid #1c202d",
    borderRadius: "8px",
    overflow: "hidden",
  },
  cardHeaderWithControls: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 16px 8px 16px",
    borderBottom: "1px solid #1c202d",
  },
  cardTitle: {
    margin: 0,
    fontSize: "13px",
    fontWeight: "700",
    color: "#ffffff",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    padding: "12px 16px 8px 16px",
  },
  cardContent: {
    padding: "16px",
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflowY: "auto",
    boxSizing: "border-box",
  },
  peerForm: {
    display: "flex",
    gap: "8px",
    marginBottom: "16px",
  },
  input: {
    flex: 1,
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#e0e0e0",
    padding: "8px 12px",
    fontSize: "13px",
    outline: "none",
    fontFamily: "Courier, monospace",
  },
  btnPrimary: {
    backgroundColor: "#39dbdb",
    color: "#0d0e12",
    border: "none",
    borderRadius: "4px",
    padding: "8px 16px",
    fontSize: "13px",
    fontWeight: "700",
    cursor: "pointer",
    transition: "background 0.2s",
  },
  btnSecondary: {
    backgroundColor: "#202430",
    color: "#e0e0e0",
    border: "1px solid #33394d",
    borderRadius: "4px",
    padding: "8px 12px",
    fontSize: "13px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "background 0.2s",
  },
  peerListHeader: {
    fontSize: "11px",
    fontWeight: "600",
    color: "#56617a",
    textTransform: "uppercase",
    marginBottom: "8px",
    letterSpacing: "0.5px",
  },
  peerList: {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
    flex: 1,
    overflowY: "auto",
    marginBottom: "12px",
  },
  emptyMeshState: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    border: "1px dashed #202430",
    borderRadius: "6px",
    padding: "24px 10px",
    textAlign: "center",
  },
  radarRing: {
    width: "30px",
    height: "30px",
    borderRadius: "50%",
    border: "2px solid #39dbdb",
    boxShadow: "0 0 10px #39dbdb",
    animation: "pulseRadar 1.5s infinite ease-in-out",
  },
  peerItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#131620",
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid #202430",
  },
  pulseGreen: {
    width: "6px",
    height: "6px",
    borderRadius: "50%",
    backgroundColor: "#39dbdb",
    boxShadow: "0 0 6px #39dbdb",
  },
  peerAddr: {
    fontFamily: "Courier, monospace",
    fontSize: "12px",
    color: "#e0e0e0",
  },
  syncedLabel: {
    fontSize: "9px",
    fontWeight: "700",
    color: "#39dbdb",
    backgroundColor: "rgba(57, 219, 219, 0.05)",
    padding: "2px 6px",
    borderRadius: "3px",
  },
  note: {
    fontSize: "11px",
    color: "#56617a",
    backgroundColor: "#0d0e12",
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid #1a1d29",
    lineHeight: "1.4",
  },
  dimensionSelector: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    padding: "0 16px",
  },
  miniLabel: {
    fontSize: "11px",
    fontWeight: "700",
    color: "#56617a",
  },
  select: {
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    color: "#39dbdb",
    borderRadius: "4px",
    padding: "4px 8px",
    fontSize: "11px",
    fontWeight: "700",
    outline: "none",
    cursor: "pointer",
  },
  tabHeader: {
    display: "flex",
    gap: "8px",
    borderBottom: "1px solid #202430",
    marginBottom: "12px",
  },
  tab: {
    background: "none",
    border: "none",
    color: "#56617a",
    fontSize: "12px",
    fontWeight: "600",
    padding: "6px 12px",
    cursor: "pointer",
    borderBottom: "2px solid transparent",
  },
  tabActive: {
    background: "none",
    border: "none",
    color: "#39dbdb",
    fontSize: "12px",
    fontWeight: "700",
    padding: "6px 12px",
    cursor: "pointer",
    borderBottom: "2px solid #39dbdb",
  },
  vectorContainer: {
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflow: "hidden",
    marginBottom: "16px",
  },
  heatmapLabel: {
    fontSize: "11px",
    color: "#56617a",
    lineHeight: "1.3",
  },
  textarea: {
    width: "100%",
    flex: 1,
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#e0e0e0",
    padding: "10px",
    fontFamily: "Courier, monospace",
    fontSize: "11px",
    resize: "none",
    outline: "none",
  },
  actionRow: {
    display: "flex",
    justifyContent: "space-between",
    gap: "10px",
  },
  statusSuccess: {
    marginTop: "12px",
    fontSize: "12px",
    color: "#39dbdb",
    backgroundColor: "rgba(57, 219, 219, 0.05)",
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid rgba(57, 219, 219, 0.2)",
  },
  statusError: {
    marginTop: "12px",
    fontSize: "12px",
    color: "#ff6358",
    backgroundColor: "rgba(255, 99, 88, 0.05)",
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid rgba(255, 99, 88, 0.2)",
  },
  feedHeader: {
    display: "flex",
    justifyContent: "space-between",
    gap: "8px",
    marginBottom: "12px",
  },
  statMini: {
    flex: 1,
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    padding: "8px",
    borderRadius: "6px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  statMiniValue: {
    fontSize: "16px",
    fontWeight: "700",
    color: "#39dbdb",
  },
  statMiniLabel: {
    fontSize: "9px",
    color: "#56617a",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  feed: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    flex: 1,
    overflowY: "auto",
  },
  feedEmpty: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    gap: "12px",
    color: "#56617a",
    fontSize: "11px",
    textAlign: "center",
    padding: "36px 0",
  },
  radarGlow: {
    width: "40px",
    height: "40px",
    borderRadius: "50%",
    border: "1px solid #202430",
    position: "relative",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  feedItem: {
    backgroundColor: "#131620",
    border: "1px solid #202430",
    borderRadius: "6px",
    padding: "10px",
    display: "flex",
    flexDirection: "column",
  },
  feedItemHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "6px",
  },
  nodeIdBadge: {
    fontSize: "11px",
    fontWeight: "700",
    color: "#ffffff",
    backgroundColor: "#202430",
    padding: "2px 6px",
    borderRadius: "3px",
  },
  latencyBadge: {
    fontSize: "11px",
    color: "#39dbdb",
    fontWeight: "600",
  },
  packetDetails: {
    fontSize: "11px",
    color: "#a4b3cc",
    lineHeight: "1.4",
  },
  footer: {
    display: "flex",
    justifyContent: "space-between",
    padding: "10px 24px",
    borderTop: "1px solid #1c202d",
    backgroundColor: "#0a0a0d",
    fontSize: "11px",
  },
  footerBlock: {
    color: "#8a94a6",
    display: "flex",
    gap: "6px",
  },
};
