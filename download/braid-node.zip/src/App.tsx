import React, { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/tauri";
import { listen } from "@tauri-apps/api/event";

interface UdpPacketPayload {
  node_id: string;
  timestamp: number;
  sequence_id: number;
  latent_vector: number[];
  sender_address: string;
  byte_size: number;
}

interface NodeInfo {
  node_id: string;
  local_address: string;
}

interface StreamResult {
  sequence_id: number;
  timestamp: number;
  sent_count: number;
  failures: string[];
}

export default function App() {
  const [nodeInfo, setNodeInfo] = useState<NodeInfo | null>(null);
  const [peers, setPeers] = useState<string[]>([]);
  const [newPeer, setNewPeer] = useState<string>("");
  const [receivedPackets, setReceivedPackets] = useState<UdpPacketPayload[]>([]);
  const [vector, setVector] = useState<number[]>([]);
  const [vectorDim, setVectorDim] = useState<number>(384);
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [lastBroadcastResult, setLastBroadcastResult] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"visualizer" | "raw">("visualizer");

  // Fetch initial info
  useEffect(() => {
    async function loadData() {
      try {
        const info = await invoke<NodeInfo>("get_node_info");
        setNodeInfo(info);
        const peerList = await invoke<string[]>("get_peers");
        setPeers(peerList);
      } catch (err) {
        console.error("Failed to load node data:", err);
      }
    }
    loadData();
    generateRandomVector(vectorDim);
  }, []);

  // Listen for background UDP packets
  useEffect(() => {
    let unlistenFn: (() => void) | null = null;

    async function setupListener() {
      try {
        const unlisten = await listen<UdpPacketPayload>("udp-packet-received", (event) => {
          setReceivedPackets((prev) => {
            // Deduplicate or append and slice
            const updated = [event.payload, ...prev];
            return updated.slice(0, 100); // keep last 100 packets
          });
        });
        unlistenFn = unlisten;
      } catch (err) {
        console.error("Failed to bind Tauri event listener:", err);
      }
    }

    setupListener();

    return () => {
      if (unlistenFn) {
        unlistenFn();
      }
    };
  }, []);

  const generateRandomVector = (dim: number) => {
    const newVec = Array.from({ length: dim }, () => {
      // Generate floats with 4 decimal places between -1.0000 and 1.0000
      return parseFloat((Math.random() * 2 - 1).toFixed(4));
    });
    setVector(newVec);
  };

  const handleDimensionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const dim = parseInt(e.target.value);
    setVectorDim(dim);
    generateRandomVector(dim);
  };

  const handleAddPeer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPeer.trim()) return;
    try {
      await invoke("add_peer", { peer: newPeer.trim() });
      const updated = await invoke<string[]>("get_peers");
      setPeers(updated);
      setNewPeer("");
    } catch (err) {
      alert(`Failed to add peer: ${err}`);
    }
  };

  const handleRemovePeer = async (peer: string) => {
    try {
      await invoke("remove_peer", { peer });
      const updated = await invoke<string[]>("get_peers");
      setPeers(updated);
    } catch (err) {
      alert(`Failed to remove peer: ${err}`);
    }
  };

  const handleStreamDrift = async () => {
    setIsBroadcasting(true);
    setLastBroadcastResult(null);
    try {
      const result = await invoke<StreamResult>("stream_state_drift", {
        latentVector: vector,
      });
      setLastBroadcastResult(
        `Successfully broadcast Seq ${result.sequence_id} to ${result.sent_count} peer(s).`
      );
    } catch (err) {
      setLastBroadcastResult(`Broadcast failed: ${err}`);
    } finally {
      setIsBroadcasting(false);
    }
  };

  // Heatmap rendering utility for latent vector
  const renderHeatmap = (vec: number[], height: number = 80) => {
    if (vec.length === 0) return null;
    return (
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "1px",
          background: "#161922",
          padding: "4px",
          borderRadius: "4px",
          maxHeight: `${height}px`,
          overflowY: "auto",
        }}
      >
        {vec.map((val, idx) => {
          // Map -1 to 1 to red/blue scale
          const intensity = Math.min(Math.max((Math.abs(val)), 0), 1);
          const color =
            val >= 0
              ? `rgba(57, 219, 219, ${intensity})`  // Teal for positive
              : `rgba(235, 64, 52, ${intensity})`;   // Orange/Red for negative

          return (
            <div
              key={idx}
              title={`Index ${idx}: ${val.toFixed(4)}`}
              style={{
                width: "8px",
                height: "8px",
                backgroundColor: intensity < 0.05 ? "#242835" : color,
                borderRadius: "1px",
              }}
            />
          );
        })}
      </div>
    );
  };

  // Helper to format timestamps nicely
  const formatTime = (ts: number) => {
    const date = new Date(ts);
    return `${date.toLocaleTimeString()}.${String(ts % 1000).padStart(3, "0")}`;
  };

  // Calculate latency estimate for received packets
  const getLatency = (packetTimestamp: number) => {
    const localNow = Date.now();
    const diff = localNow - packetTimestamp;
    if (diff < 0) return "0 ms (sync lock)";
    return `${diff} ms`;
  };

  // Count unique node ids
  const uniqueNodes = new Set(receivedPackets.map((p) => p.node_id));

  return (
    <div style={styles.container}>
      {/* HEADER */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.glowDot}></div>
          <h1 style={styles.title}>BRAID // TURNKEY LOCAL NODE</h1>
          <span style={styles.version}>v0.1</span>
        </div>
        <div style={styles.headerRight}>
          {nodeInfo ? (
            <div style={styles.nodeMeta}>
              <span style={styles.label}>LOCAL PORT:</span>
              <code style={styles.code}>{nodeInfo.local_address.split(":").pop()}</code>
              <span style={styles.label} style={{ marginLeft: "15px" }}>NODE ID:</span>
              <code style={styles.code}>{nodeInfo.node_id.substring(0, 16)}...</code>
            </div>
          ) : (
            <span style={styles.connecting}>Initializing UDP Socket...</span>
          )}
        </div>
      </header>

      {/* DASHBOARD GRID */}
      <div style={styles.dashboard}>
        {/* LEFT COLUMN: Peers & Network */}
        <section style={styles.card}>
          <h2 style={styles.cardTitle}>Local UDP Mesh Topology</h2>
          <div style={styles.cardContent}>
            <form onSubmit={handleAddPeer} style={styles.peerForm}>
              <input
                type="text"
                placeholder="IP:Port (e.g., 127.0.0.1:12001)"
                value={newPeer}
                onChange={(e) => setNewPeer(e.target.value)}
                style={styles.input}
              />
              <button type="submit" style={styles.btnSecondary}>Add Peer</button>
            </form>

            <div style={styles.peerListHeader}>
              <span>Active Target Peers ({peers.length})</span>
            </div>
            <div style={styles.peerList}>
              {peers.length === 0 ? (
                <div style={styles.emptyState}>No peers configured. Broadcaster isolated.</div>
              ) : (
                peers.map((peer, idx) => (
                  <div key={idx} style={styles.peerItem}>
                    <code style={styles.peerAddr}>{peer}</code>
                    <button
                      onClick={() => handleRemovePeer(peer)}
                      style={styles.btnRemove}
                      title="Remove Peer"
                    >
                      ×
                    </button>
                  </div>
                ))
              )}
            </div>

            <div style={styles.note}>
              <strong>Note:</strong> Standard multicast/broadcast uses <code style={styles.inlineCode}>255.255.255.255:12000</code>. To test multiple local instances on one machine, assign each node to a unique port and add them manually.
            </div>
          </div>
        </section>

        {/* MIDDLE COLUMN: State Generator */}
        <section style={styles.card}>
          <div style={styles.cardHeaderWithControls}>
            <h2 style={styles.cardTitle}>State Drift Generator</h2>
            <div style={styles.dimensionSelector}>
              <span style={styles.miniLabel}>DIM:</span>
              <select
                value={vectorDim}
                onChange={handleDimensionChange}
                style={styles.select}
              >
                <option value="128">128 f32</option>
                <option value="384">384 f32</option>
                <option value="512">512 f32</option>
                <option value="768">768 f32</option>
              </select>
            </div>
          </div>

          <div style={styles.cardContent}>
            <div style={styles.tabHeader}>
              <button
                style={activeTab === "visualizer" ? styles.tabActive : styles.tab}
                onClick={() => setActiveTab("visualizer")}
              >
                Latent Heatmap
              </button>
              <button
                style={activeTab === "raw" ? styles.tabActive : styles.tab}
                onClick={() => setActiveTab("raw")}
              >
                Raw f32 Stream
              </button>
            </div>

            <div style={styles.vectorContainer}>
              {activeTab === "visualizer" ? (
                <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                  <div style={styles.heatmapLabel}>
                    Each block represents a dimensional f32 coefficient [-1.0, 1.0]. Teal is positive, red is negative.
                  </div>
                  {renderHeatmap(vector, 180)}
                </div>
              ) : (
                <textarea
                  readOnly
                  value={JSON.stringify(vector)}
                  style={styles.textarea}
                />
              )}
            </div>

            <div style={styles.actionRow}>
              <button
                onClick={() => generateRandomVector(vectorDim)}
                style={styles.btnSecondary}
              >
                Randomize State
              </button>
              <button
                onClick={handleStreamDrift}
                disabled={isBroadcasting}
                style={styles.btnPrimary}
              >
                {isBroadcasting ? "Broadcasting..." : "Stream State Drift"}
              </button>
            </div>

            {lastBroadcastResult && (
              <div
                style={
                  lastBroadcastResult.includes("failed")
                    ? styles.statusError
                    : styles.statusSuccess
                }
              >
                {lastBroadcastResult}
              </div>
            )}
          </div>
        </section>

        {/* RIGHT COLUMN: Real-time Ingestion Feed */}
        <section style={styles.card}>
          <h2 style={styles.cardTitle}>Mesh Ingestion Feed (UDP)</h2>
          <div style={styles.cardContent}>
            <div style={styles.feedHeader}>
              <div style={styles.statMini}>
                <span style={styles.statMiniValue}>{receivedPackets.length}</span>
                <span style={styles.statMiniLabel}>Packets Received</span>
              </div>
              <div style={styles.statMini}>
                <span style={styles.statMiniValue}>{uniqueNodes.size}</span>
                <span style={styles.statMiniLabel}>Active Nodes</span>
              </div>
            </div>

            <div style={styles.feed}>
              {receivedPackets.length === 0 ? (
                <div style={styles.feedEmpty}>
                  <div style={styles.radarGlow}></div>
                  <span>Awaiting decentralized state broadcasts...</span>
                </div>
              ) : (
                receivedPackets.map((packet, idx) => (
                  <div key={idx} style={styles.feedItem}>
                    <div style={styles.feedItemHeader}>
                      <span style={styles.nodeIdBadge}>
                        Node: {packet.node_id.substring(0, 12)}
                      </span>
                      <span style={styles.latencyBadge}>
                        Latency: {getLatency(packet.timestamp)}
                      </span>
                    </div>

                    <div style={styles.packetDetails}>
                      <div>
                        <strong>From:</strong> <code>{packet.sender_address}</code>
                      </div>
                      <div>
                        <strong>Seq ID:</strong> <code>{packet.sequence_id}</code> |{" "}
                        <strong>Bytes:</strong> <code>{packet.byte_size} B</code>
                      </div>
                      <div style={{ color: "#8a94a6" }}>
                        <strong>Ingested At:</strong> {formatTime(packet.timestamp)}
                      </div>
                    </div>

                    <div style={{ marginTop: "6px" }}>
                      {renderHeatmap(packet.latent_vector, 50)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </section>
      </div>

      {/* FOOTER STATS */}
      <footer style={styles.footer}>
        <div style={styles.footerBlock}>
          <span>PROTOCOL:</span>
          <strong>UDP Binary Payload via bincode (Serialization Protocol v1)</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>PHYSICAL BUFFER:</span>
          <strong>65,535 Bytes max packet size</strong>
        </div>
        <div style={styles.footerBlock}>
          <span>STATUS:</span>
          <span style={{ color: "#39dbdb" }}>● ACTIVE LISTENING LOOP</span>
        </div>
      </footer>
    </div>
  );
}

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    width: "100%",
    boxSizing: "border-box",
    backgroundColor: "#0d0e12",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "16px 24px",
    borderBottom: "1px solid #1c202d",
    backgroundColor: "#10121a",
  },
  headerLeft: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  glowDot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
    backgroundColor: "#39dbdb",
    boxShadow: "0 0 10px #39dbdb",
  },
  title: {
    margin: 0,
    fontSize: "16px",
    fontWeight: "700",
    letterSpacing: "1px",
    color: "#ffffff",
  },
  version: {
    fontSize: "11px",
    padding: "2px 6px",
    borderRadius: "3px",
    backgroundColor: "#202430",
    color: "#8a94a6",
    fontWeight: "600",
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
  },
  nodeMeta: {
    display: "flex",
    alignItems: "center",
    fontSize: "12px",
    backgroundColor: "#08090d",
    padding: "6px 12px",
    borderRadius: "6px",
    border: "1px solid #202430",
  },
  label: {
    color: "#56617a",
    marginRight: "6px",
    fontWeight: "600",
  },
  code: {
    color: "#39dbdb",
    fontFamily: "Courier, monospace",
    fontWeight: "700",
  },
  connecting: {
    color: "#ffad47",
    fontSize: "12px",
    fontWeight: "600",
  },
  dashboard: {
    display: "grid",
    gridTemplateColumns: "300px 1fr 340px",
    gap: "16px",
    padding: "16px",
    flex: 1,
    overflow: "hidden",
    boxSizing: "border-box",
  },
  card: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: "#10121a",
    border: "1px solid #1c202d",
    borderRadius: "8px",
    overflow: "hidden",
  },
  cardHeaderWithControls: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 16px 8px 16px",
    borderBottom: "1px solid #1c202d",
  },
  cardTitle: {
    margin: 0,
    fontSize: "13px",
    fontWeight: "700",
    color: "#ffffff",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    padding: "12px 16px 8px 16px",
  },
  cardContent: {
    padding: "16px",
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflowY: "auto",
    boxSizing: "border-box",
  },
  peerForm: {
    display: "flex",
    gap: "8px",
    marginBottom: "16px",
  },
  input: {
    flex: 1,
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#e0e0e0",
    padding: "8px 12px",
    fontSize: "13px",
    outline: "none",
    fontFamily: "Courier, monospace",
  },
  btnPrimary: {
    backgroundColor: "#39dbdb",
    color: "#0d0e12",
    border: "none",
    borderRadius: "4px",
    padding: "8px 16px",
    fontSize: "13px",
    fontWeight: "700",
    cursor: "pointer",
    transition: "background 0.2s",
  },
  btnSecondary: {
    backgroundColor: "#202430",
    color: "#e0e0e0",
    border: "1px solid #33394d",
    borderRadius: "4px",
    padding: "8px 12px",
    fontSize: "13px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "background 0.2s",
  },
  peerListHeader: {
    fontSize: "11px",
    fontWeight: "600",
    color: "#56617a",
    textTransform: "uppercase",
    marginBottom: "8px",
    letterSpacing: "0.5px",
  },
  peerList: {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
    flex: 1,
    overflowY: "auto",
    marginBottom: "12px",
  },
  emptyState: {
    fontSize: "12px",
    color: "#56617a",
    textAlign: "center",
    padding: "24px 0",
    border: "1px dashed #202430",
    borderRadius: "4px",
  },
  peerItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#161922",
    padding: "6px 10px",
    borderRadius: "4px",
    border: "1px solid #202430",
  },
  peerAddr: {
    fontFamily: "Courier, monospace",
    fontSize: "12px",
    color: "#e0e0e0",
  },
  btnRemove: {
    background: "none",
    border: "none",
    color: "#ff6358",
    fontSize: "16px",
    cursor: "pointer",
    padding: "0 4px",
  },
  note: {
    fontSize: "11px",
    color: "#56617a",
    backgroundColor: "#0d0e12",
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid #1a1d29",
    lineHeight: "1.4",
  },
  inlineCode: {
    color: "#39dbdb",
    fontFamily: "Courier, monospace",
  },
  dimensionSelector: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    padding: "0 16px",
  },
  miniLabel: {
    fontSize: "11px",
    fontWeight: "700",
    color: "#56617a",
  },
  select: {
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    color: "#39dbdb",
    borderRadius: "4px",
    padding: "4px 8px",
    fontSize: "11px",
    fontWeight: "700",
    outline: "none",
    cursor: "pointer",
  },
  tabHeader: {
    display: "flex",
    gap: "8px",
    borderBottom: "1px solid #202430",
    marginBottom: "12px",
  },
  tab: {
    background: "none",
    border: "none",
    color: "#56617a",
    fontSize: "12px",
    fontWeight: "600",
    padding: "6px 12px",
    cursor: "pointer",
    borderBottom: "2px solid transparent",
  },
  tabActive: {
    background: "none",
    border: "none",
    color: "#39dbdb",
    fontSize: "12px",
    fontWeight: "700",
    padding: "6px 12px",
    cursor: "pointer",
    borderBottom: "2px solid #39dbdb",
  },
  vectorContainer: {
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflow: "hidden",
    marginBottom: "16px",
  },
  heatmapLabel: {
    fontSize: "11px",
    color: "#56617a",
    lineHeight: "1.3",
  },
  textarea: {
    width: "100%",
    flex: 1,
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    borderRadius: "4px",
    color: "#e0e0e0",
    padding: "10px",
    fontFamily: "Courier, monospace",
    fontSize: "11px",
    resize: "none",
    outline: "none",
  },
  actionRow: {
    display: "flex",
    justifyContent: "space-between",
    gap: "10px",
  },
  statusSuccess: {
    marginTop: "12px",
    fontSize: "12px",
    color: "#39dbdb",
    backgroundColor: "rgba(57, 219, 219, 0.05)",
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid rgba(57, 219, 219, 0.2)",
  },
  statusError: {
    marginTop: "12px",
    fontSize: "12px",
    color: "#ff6358",
    backgroundColor: "rgba(255, 99, 88, 0.05)",
    padding: "8px 12px",
    borderRadius: "4px",
    border: "1px solid rgba(255, 99, 88, 0.2)",
  },
  feedHeader: {
    display: "flex",
    justifyContent: "space-between",
    gap: "8px",
    marginBottom: "12px",
  },
  statMini: {
    flex: 1,
    backgroundColor: "#0d0e12",
    border: "1px solid #202430",
    padding: "8px",
    borderRadius: "6px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  statMiniValue: {
    fontSize: "16px",
    fontWeight: "700",
    color: "#39dbdb",
  },
  statMiniLabel: {
    fontSize: "9px",
    color: "#56617a",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  feed: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    flex: 1,
    overflowY: "auto",
  },
  feedEmpty: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    gap: "12px",
    color: "#56617a",
    fontSize: "11px",
    textAlign: "center",
    padding: "36px 0",
  },
  radarGlow: {
    width: "40px",
    height: "40px",
    borderRadius: "50%",
    border: "1px solid #202430",
    position: "relative",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  feedItem: {
    backgroundColor: "#131620",
    border: "1px solid #202430",
    borderRadius: "6px",
    padding: "10px",
    display: "flex",
    flexDirection: "column",
  },
  feedItemHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "6px",
  },
  nodeIdBadge: {
    fontSize: "11px",
    fontWeight: "700",
    color: "#ffffff",
    backgroundColor: "#202430",
    padding: "2px 6px",
    borderRadius: "3px",
  },
  latencyBadge: {
    fontSize: "11px",
    color: "#39dbdb",
    fontWeight: "600",
  },
  packetDetails: {
    fontSize: "11px",
    color: "#a4b3cc",
    lineHeight: "1.4",
  },
  footer: {
    display: "flex",
    justifyContent: "space-between",
    padding: "10px 24px",
    borderTop: "1px solid #1c202d",
    backgroundColor: "#0a0a0d",
    fontSize: "11px",
  },
  footerBlock: {
    color: "#8a94a6",
    display: "flex",
    gap: "6px",
  },
};
