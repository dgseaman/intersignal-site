# BRAID Pathfinder v5.0 (Autonomous Mesh Node)

Braid Pathfinder v5.0 is a pluggable, secure, and sovereign peer-to-peer state synchronization node. It operates completely cloud-free, allowing local enclaves and edge devices to establish policy-gated neural coordinate synchronizations over physical UDP subnets.

This release represents **Braid Pathfinder v5.0** (Package `0.5.0` / Wire Protocol version `5`).

## Architectural Specifications

1.  **Agnostic Cryptographic Identity**: Decoupled canonical `NodeId` from public key material. `NodeId` is derived as a stable 32-byte Blake3/SHA-256 hash of signature scheme IDs and raw public key bytes.
2.  **IdentityProvider Abstraction**: The core wire protocol is decoupled from local-key signing via a generic `IdentityProvider` trait, enabling future KMS, HSM, and enterprise PKI certificate backends without rewriting packet-construction logic.
3.  **Strict Admission receive Pipeline**: Enforces a strict 14-step validation and admission pipeline (raw MTU size gates, version checks, cryptographic signature verification, dynamic dimension matching, and session-keyed bounded replay ledger guards).
4.  **Graceful Exits & Latency Probes**: Supports direct link health probing via MSG_LINK_PROBE/MSG_LINK_PROBE_ACK packets and instant peer cleanup via signed MSG_PEER_GOODBYE broadcasts.

## Quickstart

```bash
# 1. Install dependencies
npm install

# 2. Compile and run frontend
npm run dev

# 3. Launch Tauri application (Rust backend)
npm run tauri dev
```

For headless CLI monitor, navigate to `http://localhost:8080`.
