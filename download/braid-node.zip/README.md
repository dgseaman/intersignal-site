# Braid Pathfinder v0.6 "DeepBlend" (Autonomous Mesh Node)

Braid DeepBlend v0.6-alpha is a pluggable, secure, and sovereign peer-to-peer state synchronization node. It operates completely cloud-free, allowing local enclaves and edge devices to establish policy-gated neural coordinate synchronizations over physical UDP subnets.

This release represents **Braid Pathfinder v0.6 "DeepBlend"** (Package `0.6.0-alpha` / Wire Protocol version `6`).

## Architectural Specifications

1.  **Agnostic Cryptographic Identity**: Decoupled canonical `NodeId` from public key material. `NodeId` is derived as a stable 32-byte SHA-256 hash of signature scheme IDs and raw public key bytes:
    $$\text{NodeId} = \text{SHA256}(\text{"braid-node-id-v1"} \mathbin{\Vert} \text{scheme\_id} \mathbin{\Vert} \text{public\_material})$$
2.  **Deterministic Canonical Signing Preimage**: The inner signing body is serialized via our new **Deterministic Canonical Binary Protocol (IMTP-CBP v6)** to support stable, cross-language signature preimages. The outer transport envelope remains bincode during this intermediate alpha phase.
3.  **IdentityProvider Abstraction**: The core wire protocol is decoupled from local-key signing via a generic `IdentityProvider` trait, enabling future KMS, HSM, and enterprise PKI certificate backends without rewriting packet-construction logic.
4.  **Strict Admission receive Pipeline**: Enforces a strict 14-step validation and admission pipeline (raw MTU size gates, version checks, cryptographic signature verification, dynamic dimension matching, and session-keyed bounded replay ledger guards).
5.  **Graceful Exits & Latency Probes**: Supports direct link health probing via MSG_LINK_PROBE/MSG_LINK_PROBE_ACK packets and instant peer cleanup via signed MSG_PEER_GOODBYE broadcasts.

## Quickstart

```bash
# 1. Install dependencies
npm install

# 2. Compile and run frontend
npm run dev

# 3. Launch Tauri application (Rust backend)
npm run tauri dev
```

For headless CLI monitor, navigate to `http://localhost:8080`.
