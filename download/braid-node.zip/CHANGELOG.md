# Braid Changelog

## Braid Pathfinder v0.6 "DeepBlend" (v0.6.0-alpha) — July 2, 2026
*   **Decoupled Node Identity**: Shifted from variable-length public keys to a fixed-size, 32-byte hash-derived `NodeId` derived from `SHA-256("braid-node-id-v1" || scheme_id || public_material)`.
*   **Deterministic Preimage Signing**: The inner signing body is serialized via **IMTP-CBP v6** (Deterministic Canonical Binary Protocol) to support stable cross-language signature preimages, while outer transport remains bincode.
*   **IdentityProvider Abstraction**: Created pluggable `IdentityProvider` trait supporting zero-friction integration with Hardware Security Modules (HSM) and cloud Key Management Services (KMS).
*   **Direct Path Health (Probing)**: Added signed periodic `MSG_LINK_PROBE` and `MSG_LINK_PROBE_ACK` messaging to dynamically track round-trip latency and link status of admitted peers.
*   **Graceful Exit (Peer Goodbye)**: Introduced signed `MSG_PEER_GOODBYE` broadcasts to evict shutting-down peers instantly.
*   **Strict Admission Receive Pipeline**: Re-designed receiver sequence to enforce a strict 14-stage validation before ledger sequence commits or peer table admission occurs.
*   **Localhost Web Visualizer**: Exposes a lightweight, async web monitor on `localhost:8080` showing a live 384-dimension latent vector heatmap and current mesh topology.
