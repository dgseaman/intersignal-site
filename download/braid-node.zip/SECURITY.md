# Braid Security Policy & Hardened Controls

Braid is designed from the ground up for absolute OpSec, localized data sovereignty, and hardware-enclosed operations.

## Hardened Security Controls (v0.6-alpha / Wire Protocol 6)

Pathfinder v0.6-alpha establishes a robust, highly resilient cryptographic fence at the physical network boundary:

1.  **Pre-Deserialization Buffer Ceiling**: Receivers enforce a strict `2048` byte UDP packet limit directly on the socket stream. Any buffer reading exceeding this MTU limit is dropped prior to deserialization, defending the host from memory inflation and CPU-exhaustion vectors.
2.  **Stable Hash-Derived Node Identity**: Node IDs are modeled as fixed 32-byte hash structures, derived dynamically from the signature scheme and public key bytes:
    $$\text{NodeId} = \text{SHA256}(\text{"braid-node-id-v1"} \mathbin{\Vert} \text{scheme\_id} \mathbin{\Vert} \text{public\_material})$$
    This prevents key-length formatting exploits and node impersonation attacks.
3.  **Deterministic Preimage Signing (IMTP-CBP v6)**: Preimages are serialized into a strictly ordered, big-endian binary packed representation before crypto-signing, securing signature verification consistency across different language platforms (Rust, Python, Go).
4.  **Strict State Vector Sanitization (QINT8)**: The receiver explicitly rejects unsupported state vector encoding formats. For the experimental `VECTOR_ENCODING_QINT8` path, the node validates that the incoming data length matches expected vector dimensions, asserts that the quantization scale is finite and positive, and verifies that the dequantized output contains only finite float coordinates.
5.  **Session-Keyed Replay Ledger**: Tracks sequence counters keyed by `(NodeId, session_id)` with a hard bounds limit of `MAX_REPLAY_LEDGER_ENTRIES = 4096`. Under sybil attack, the ledger protects established peer sessions by rejecting new unknown peer connections.
6.  **Admission-First Gating**: Admitted peers only. All incoming `STATE_DRIFT`, `LINK_PROBE`, and `LINK_PROBE_ACK` packets are strictly rejected at the socket boundary unless the sender has successfully completed formal discovery handshakes and resides inside the active peer table.

## Reporting Vulnerabilities

Please report verified security flaws or protocol exploits directly to our trust team:
*   Email: `missy@intersignal.ai`
