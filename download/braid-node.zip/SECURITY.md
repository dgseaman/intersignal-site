# Intersignal Security Policy

Braid is designed from the ground up for extreme OpSec, localized data containment, and absolute data sovereignty.

## Hardened Security Controls (v5.0)

*   **Pre-Deserialization Buffer Ceiling**: Receivers enforce a strict 2048-byte UDP packet size limit on the raw socket stream before deserialization, defending against heap overflow or CPU-exhaustion attacks.
*   **Hash-Derived Key Agnosticism**: Standardized a fixed 32-byte hash-derived canonical `NodeId` using `SHA-256("braid-node-id-v1" || scheme_id || public_material)` to prevent identity-formatting exploits or key-length spoofing.
*   **Session-Keyed Replay Ledger**: Sequence ledger checks are keyed by `(NodeId, session_id)` and capped at `MAX_REPLAY_LEDGER_ENTRIES = 4096`. Under size overflow stress, the ledger rejects new sessions rather than globally clearing, protecting active peers from replay injections.
*   **Admission-First Boundary Gate**: Incoming state drift packets are strictly rejected unless the sender already successfully completed signed handshake registration and resides in our verified peer table.
*   **Finite Coordinate Validator**: Any incoming vector containing non-finite float coordinates (NaN or Infinity) is instantly dropped.

## Reporting Vulnerabilities

Please report any verified protocol vulnerabilities directly to our trust team at:
*   Email: `missy@intersignal.ai`
