#!/usr/bin/env python3
"""Package a developer/compatibility wheel bundle (no credentials).
Run from the source root after tests/build: python scripts/package_release.py OUT.
OUT must be a new directory outside this source tree. No deployment is performed.
Normal desktop users receive the native app from packaging/build_desktop.py;
this Python launcher bundle is retained for developer upgrade regression tests.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,stat,zipfile
VERSION='1.9.2'
ROOT=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('out',type=Path);args=parser.parse_args();out=args.out.resolve()
 if out==ROOT or ROOT in out.parents:raise SystemExit('Choose an output outside the source tree.')
 if out.exists():raise SystemExit('Refusing to overwrite existing output.')
 out.mkdir(parents=True)
 def copy(src,dst):
  p=out/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/src,p)
 for name in ('Start Braid.command','Start Braid.cmd','Start Braid.sh','start_braid.py','dependencies.txt','offline_support.py','prepare_offline.py','verify_release.py','START_HERE.md'):copy(Path('release')/name,name)
 for name in ('LICENSE','THIRD_PARTY_NOTICES.md','RELEASE_NOTES.md','MIGRATION_NOTES.md','TEST_RESULTS.md','QA.md','README.md','FOLIO_CONNECTIONS.md'):copy(name,name)
 wheel='braid_client-'+VERSION+'-py3-none-any.whl';copy(Path('dist')/wheel,wheel)
 for folder in ('operator','docs'):
  for p in sorted((ROOT/folder).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:copy(p.relative_to(ROOT),p.relative_to(ROOT))
 (out/'source').mkdir()
 archive=out/'source'/('Braid-Archangel-'+VERSION+'-source.zip')
 excluded={'.git','.pytest_cache','__pycache__','build','dist','evidence','braid_client.egg-info'}
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(ROOT.rglob('*')):
   if not p.is_file() or any(x in excluded for x in p.relative_to(ROOT).parts):continue
   if p.suffix in ('.pyc','.patch','.diff','.pem','.sqlite3'):continue
   z.write(p,'Braid-Archangel-'+VERSION+'-source/'+str(p.relative_to(ROOT)))
 support={name:sha(out/name) for name in ('Start Braid.command','Start Braid.cmd','Start Braid.sh','start_braid.py','dependencies.txt','offline_support.py','prepare_offline.py','verify_release.py')}
 distribution={str(p.relative_to(out)):sha(p) for folder in ('operator','docs') for p in sorted((out/folder).rglob('*')) if p.is_file()}
 source={'path':str(archive.relative_to(out)),'sha256':sha(archive)}
 manifest={'version':VERSION,'folio':'0.3.0','integrated':True,'variant':'developer_compatibility','wheel':wheel,'sha256':sha(out/wheel),'source':source,'support_files':support,'distribution_files':distribution}
 (out/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 identity={'version':VERSION,'codename':'Archangel','variant':'developer_compatibility',
           'status':'local_test_build','wheel_sha256':sha(out/wheel),
           'source_sha256':source['sha256'],'public_rendezvous_deployed_by_this_build':False,
           'physical_two_machine_folio_tested':False,'native_signing':False}
 (out/'RELEASE_ID.json').write_text(json.dumps(identity,indent=2)+'\n')
 (out/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(out))+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt'))
 print(json.dumps({'out':str(out),'wheel_sha256':sha(out/wheel),'source_sha256':sha(archive),'files':sum(p.is_file() for p in out.rglob('*'))},indent=2))
if __name__=='__main__':main()
