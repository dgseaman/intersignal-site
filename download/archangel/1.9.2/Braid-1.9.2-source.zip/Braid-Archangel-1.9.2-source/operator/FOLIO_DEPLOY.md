# Deploy the first-party Folio connection service

This build has no public host. These are examples to review once a server and
DNS record are chosen; no existing server has been modified. The operator must
own the first-party intersignal.org origin and a real Braid download route.
The existing Managed WAN relay is a separate service.

1. Create an unprivileged braidfolio service account on the chosen Linux server.
2. Create /opt/braid-folio/venv with Python 3.10–3.13. Install the exact supplied
   braid_client-1.9.2-py3-none-any.whl and its declared dependencies in that venv.
3. Review braid-folio.service. Keep the service on loopback. Change the origin
   and download arguments together with the chosen first-party host. The unit's
   private state directory is created by systemd. Keep it out of public hosting.
4. Point the chosen DNS record at the server. Review Caddyfile.folio.example and
   merge that site block into the operator's existing TLS proxy configuration.
   Do not replace unrelated site blocks or run the Managed WAN install script.
5. Install/enable the reviewed unit and validate the proxy configuration before
   reloading it. Review ingress capacity and backup the private service state.
6. Open https://CHOSEN-HOST/health. Require status "ok" and download_available true.
   Independently open the real Braid download URL and inspect the package hash.
   The health check reports configuration, not download availability by fetching.
7. In Folio use Check setup at this HTTPS origin. Export a harmless enabled
   edition, host its whole publication folder, and run the two-machine pass in
   FOLIO_CONNECTIONS.md. The loopback development flag is not for public use.

The service queues signed requests, decisions, and deliberately shared cards.
It does not relay Braid note frames or activate a Managed WAN membership. Both
receivers still need direct/private-overlay reachability for a first note.
A 200 health response is only a service check, not completed user acceptance.

Rollback: disable the new service and remove only its reviewed proxy site block.
Preserve its private state and the exact previous wheel before any upgrade.
Never publish its SQLite database or a user's Braid/Folio profile.
