# Braid Archangel 1.9.2 documentation

Start with ../START_HERE.md, ../README.md, ../RELEASE_NOTES.md,
../MIGRATION_NOTES.md, and ../TEST_RESULTS.md. The local Folio module is a major
feature of this release. FOLIO_CONNECTIONS.md describes deliberate invitations.

CHANNELS_GUIDE.md and WAN_PROTOCOL.md remain protocol references. UAT_WAN.md
and ../packaging/QUALIFY_PLATFORMS.md identify further qualification work.
Date-labelled evidence and history/ describe their recorded older builds;
do not treat those results as 1.9.2 passes. operator/ contains fresh-server
operator templates, not actions performed or required by this client upgrade.
