# Braid Archangel 1.9.2 qualification

See [current checklist](../UAT.md), [exact results](../TEST_RESULTS.md), and
[platform qualification](../packaging/QUALIFY_PLATFORMS.md).
