# Braid Archangel 1.9.2 executed verification

See [exact current results](../TEST_RESULTS.md) and [QA summary](../QA.md).
Historical evidence remains under history/ and date-labelled files.
