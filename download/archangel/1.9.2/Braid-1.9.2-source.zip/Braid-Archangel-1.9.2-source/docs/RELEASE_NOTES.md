# Braid Archangel 1.9.2 release notes

See [current release notes](../RELEASE_NOTES.md), [migration notes](../MIGRATION_NOTES.md),
and [exact test results](../TEST_RESULTS.md). Older observations are retained
in history/ and date-labelled evidence files; they are not new release passes.
