"""Create one ZIP with the tested Mac app and 1.9.1-style Windows/Linux launchers.

Python 3.10–3.13 remains a prerequisite for the Windows/Linux launchers.
This recipe does not cross-compile or claim native Windows/Linux qualification.
Run on macOS to preserve the Mac application's signatures and resource forks.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import sys
from compact_macos import compact_app

ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.9.2'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app', type=Path, required=True)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    app, stage, out = (p.resolve() for p in (args.app, args.stage, args.out))
    if platform.system() != 'Darwin' or not app.is_dir() or app.suffix != '.app':
        raise SystemExit('Use macOS and an existing tested Braid.app.')
    if stage.exists() or stage == ROOT or ROOT in stage.parents:
        raise SystemExit('Choose a new staging directory outside the source tree.')
    archive = out / 'Braid-1.9.2.zip'
    source = out / 'Braid-1.9.2-source.zip'
    if archive.exists() or source.exists():
        raise SystemExit('Refusing to overwrite an existing release archive.')
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True)
    package = stage / 'Braid-1.9.2'
    subprocess.run([sys.executable, str(ROOT / 'scripts/package_release.py'), str(package)], check=True)
    # ditto preserves symlinks, modes and the companion CLI's resource signature.
    subprocess.run(['/usr/bin/ditto', str(app), str(package / 'Braid.app')], check=True)
    compact = compact_app(package / 'Braid.app')
    (package / 'MAC_RUNTIME_LAYOUT.json').write_text(json.dumps(compact, indent=2) + '\n')
    subprocess.run(['codesign', '--force', '--deep', '--sign', '-', str(package / 'Braid.app')], check=True)
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(package / 'Braid.app')], check=True)
    shutil.copy2(ROOT / 'packaging/PLATFORMS.md', package / 'PLATFORMS.md')
    manifest_path = package / 'bundle-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    manifest['variant'] = 'mac_native_windows_linux_launchers'
    manifest['platforms'] = {
        'macOS': {'entry': 'Braid.app', 'architecture': 'arm64', 'python_required': False},
        'Windows': {'entry': 'Start Braid.cmd', 'python_required': 'CPython 3.10–3.13'},
        'Linux': {'entry': 'Start Braid.sh', 'python_required': 'CPython 3.10–3.13'},
    }
    manifest['native_windows_linux_binaries'] = False
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    identity_path = package / 'RELEASE_ID.json'
    identity = json.loads(identity_path.read_text())
    identity.update(variant=manifest['variant'], native_signing='macOS ad-hoc; not notarized',
                    native_windows_linux_tested=False, folio_integrated_on_all_entry_points=True)
    identity_path.write_text(json.dumps(identity, indent=2) + '\n')
    # Checksums cover every file, including the native app, excluding this list.
    lines = []
    for path in sorted(package.rglob('*')):
        if path.is_file() and path.name != 'SHA256SUMS.txt':
            lines.append(sha(path) + '  ' + path.relative_to(package).as_posix() + '\n')
    (package / 'SHA256SUMS.txt').write_text(''.join(lines))
    out.mkdir(parents=True, exist_ok=True)
    shutil.copy2(package / manifest['source']['path'], source)
    subprocess.run(['/usr/bin/ditto', '-c', '-k', '--sequesterRsrc', '--keepParent',
                    str(package), str(archive)], check=True)
    result = {'product': 'Braid Archangel 1.9.2', 'folio': '0.3.0',
              'variant': manifest['variant'], 'platforms': manifest['platforms'],
              'zip': {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive)},
              'source': {'file': source.name, 'bytes': source.stat().st_size, 'sha256': sha(source)},
              'wheel_sha256': manifest['sha256'], 'release_qualified': False,
              'mac_shared_runtime_files': compact['shared_files'],
              'mac_uncompressed_duplicate_bytes_removed': compact['uncompressed_duplicate_bytes_removed'],
              'native_windows_linux_tested': False, 'existing_artifacts_overwritten': False}
    (out / 'Braid-1.9.2-manifest.json').write_text(json.dumps(result, indent=2) + '\n')
    (out / 'Braid-1.9.2-SHA256SUMS.txt').write_text(
        result['zip']['sha256'] + '  ' + archive.name + '\n' +
        result['source']['sha256'] + '  ' + source.name + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
