"""Build a self-contained Braid application on its target OS; never deploys."""
from pathlib import Path
import argparse
import json
import os
import platform
import plistlib
import shutil
import subprocess
import sys
from compact_macos import compact_app

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description='Build Braid Archangel 1.9.2')
    parser.add_argument('--output',type=Path,default=ROOT/'dist/desktop')
    parser.add_argument('--work',type=Path,default=ROOT/'build/desktop')
    args=parser.parse_args()
    output=args.output.resolve();work=args.work.resolve()
    work.mkdir(parents=True,exist_ok=True)
    # Collection helpers must resolve this checkout too, even if an older wheel
    # happens to be installed in the developer's build environment.
    env=dict(os.environ,PYINSTALLER_CONFIG_DIR=str(work/'cache'),PYTHONPATH=str(ROOT))
    common=[sys.executable,'-m','PyInstaller','--noconfirm','--clean',
        '--collect-data','braid_client','--collect-all','folio','--collect-all','cv2',
        '--collect-all','bleak','--paths',str(ROOT)]
    desktop=common+['--name','Braid','--hidden-import','release.start_braid',
        '--hidden-import','tkinter','--distpath',str(output),'--workpath',str(work/'gui'),
        '--specpath',str(work/'gui-spec')]
    if platform.system()=='Darwin':
        desktop+=['--windowed','--osx-bundle-identifier','ai.intersignal.braid']
    elif platform.system()=='Windows':
        desktop+=['--windowed']
    desktop+=[str(ROOT/'packaging/desktop_entry.py')]
    subprocess.run(desktop,env=env,check=True)
    cli=common+['--onedir','--console','--name','braid-client','--distpath',str(work/'cli-dist'),
        '--workpath',str(work/'cli'),'--specpath',str(work/'cli-spec'),
        str(ROOT/'packaging/macos/braid_cli_entry.py')]
    subprocess.run(cli,env=env,check=True)
    binary='braid-client.exe' if platform.system()=='Windows' else 'braid-client'
    app=output/'Braid.app' if platform.system()=='Darwin' else output/'Braid'
    executables=app/'Contents/MacOS' if platform.system()=='Darwin' else app
    cli_folder=work/'cli-dist'/'braid-client'
    if platform.system()=='Darwin':
        installed_cli=app/'Contents/Resources/BraidCLI'
        if installed_cli.exists():shutil.rmtree(installed_cli)
        shutil.copytree(cli_folder,installed_cli,symlinks=True)
        wrapper=executables/'braid-client'
        wrapper.write_text('#!/bin/sh\nHERE=$(CDPATH= cd -P "$(dirname "$0")" && pwd)\nexec "$HERE/../Resources/BraidCLI/braid-client" "$@"\n')
        wrapper.chmod(0o755)
    else:
        shutil.copytree(cli_folder,app,symlinks=True,dirs_exist_ok=True)
    if platform.system()=='Darwin':
        path=app/'Contents/Info.plist'
        with path.open('rb') as handle:info=plistlib.load(handle)
        info.update(CFBundleShortVersionString='1.9.2',CFBundleVersion='19200',
            CFBundleDisplayName='Braid',CFBundleName='Braid',LSMinimumSystemVersion='13.0',
            NSCameraUsageDescription='Braid uses the camera only when you explicitly choose optical transport.',
            NSLocalNetworkUsageDescription='Braid exchanges signed state on the local network when you explicitly enable it.',
            NSBluetoothAlwaysUsageDescription='Braid scans for Bluetooth discovery hints only when you explicitly choose sensing.')
        with path.open('wb') as handle:plistlib.dump(info,handle)
    evidence=app/'Contents/Resources/BraidRelease' if platform.system()=='Darwin' else app/'BraidRelease'
    evidence.mkdir(parents=True,exist_ok=True)
    result=subprocess.run([sys.executable,'-m','pip','freeze','--all'],capture_output=True,text=True,check=True)
    (evidence/'build-environment.txt').write_text(result.stdout)
    (evidence/'build-platform.json').write_text(json.dumps({'version':'1.9.2','python':platform.python_version(),
        'platform':platform.platform(),'machine':platform.machine(),'folio':'0.3.0','self_contained':True},indent=2)+'\n')
    for name in ('LICENSE','THIRD_PARTY_NOTICES.md','README.md','START_HERE.md','RELEASE_NOTES.md','MIGRATION_NOTES.md','QA.md','TEST_RESULTS.md'):
        shutil.copy2(ROOT/name,evidence/name)
    if platform.system()=='Darwin':
        compact_app(app)
        identity=os.environ.get('BRAID_CODESIGN_IDENTITY','-')
        subprocess.run(['codesign','--force','--deep','--sign',identity,str(app)],check=True)
        subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
    print(app)


if __name__=='__main__':main()
