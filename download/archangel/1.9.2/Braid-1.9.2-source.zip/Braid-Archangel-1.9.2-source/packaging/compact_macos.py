"""Share byte-identical immutable libraries between the Mac GUI and CLI.

Only the companion CLI's copied binaries and base-library ZIP are replaced.
All targets stay within the .app. No features, modules or runtimes are removed.
The caller must re-sign and verify the app after changing its resource layout.
"""
from pathlib import Path
import hashlib
import os
import stat


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def shareable(path):
    return path.suffix in ('.so', '.dylib') or path.name == 'base_library.zip'


def compact_app(app):
    app = Path(app).resolve()
    cli = app / 'Contents/Resources/BraidCLI'
    copied = cli / '_internal'
    if app.suffix != '.app' or not copied.is_dir():
        raise ValueError('Expected a Braid.app containing the companion CLI runtime.')
    targets = {}
    for path in sorted(app.rglob('*')):
        if cli in path.parents or path.is_symlink() or not path.is_file() or not shareable(path):
            continue
        targets.setdefault((digest(path), stat.S_IMODE(path.stat().st_mode)), path)
    links = []
    saved = 0
    for path in sorted(copied.rglob('*')):
        if path.is_symlink() or not path.is_file() or not shareable(path):
            continue
        target = targets.get((digest(path), stat.S_IMODE(path.stat().st_mode)))
        if target is None:
            continue
        target.resolve().relative_to(app)
        relative = os.path.relpath(target, path.parent)
        size = path.stat().st_size
        # This operates only on a newly staged application, never a user profile.
        path.unlink()
        path.symlink_to(relative)
        if path.resolve() != target.resolve() or digest(path) != digest(target):
            raise RuntimeError('Shared runtime link did not preserve its target.')
        links.append({'path': path.relative_to(app).as_posix(),
                      'target': target.relative_to(app).as_posix(),
                      'sha256': digest(target), 'bytes': size})
        saved += size
    return {'schema': 'braid.macos.shared-runtime.v1', 'shared_files': len(links),
            'uncompressed_duplicate_bytes_removed': saved, 'links': links}
