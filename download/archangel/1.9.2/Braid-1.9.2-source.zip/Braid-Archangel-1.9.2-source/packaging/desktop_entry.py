"""Self-contained Archangel entry. Launching Braid also starts its Folio studio."""
from __future__ import annotations
import argparse
import json
import os
import signal
import sys
from pathlib import Path

from release import start_braid


def main():
    parser = argparse.ArgumentParser(description='Braid Archangel 1.9.2')
    parser.add_argument('--profile', type=Path, default=start_braid.default_profile())
    parser.add_argument('--port', type=int, default=0)
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--stop', action='store_true')
    parser.add_argument('--version', action='store_true')
    args = parser.parse_args()
    if args.version:
        print('Braid Archangel '+start_braid.VERSION)
        return 0
    profile = args.profile.expanduser().resolve()
    if args.stop:
        if not start_braid.request_shutdown(profile):
            raise RuntimeError('No responsive Braid Archangel session found.')
        return 0
    from braid_client.private_files import private_dir
    private_dir(profile)
    ownership = start_braid.acquire_lock(profile/'launcher.lock')
    if ownership is None:
        if start_braid.existing_window(profile, args.no_browser):
            return 0
        raise RuntimeError('This Braid profile is already starting. Try again in a moment.')
    try:
        (profile/'shutdown-requested.json').unlink(missing_ok=True)
        (profile/'session.json').unlink(missing_ok=True)
        start_braid.backup_before_upgrade(profile)
        def stop(signum, frame):
            raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, stop)
        if hasattr(signal, 'SIGBREAK'):
            signal.signal(signal.SIGBREAK, stop)
        return start_braid.client(profile, args.port, args.no_browser)
    finally:
        ownership.close()


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(0)
    except Exception as exc:
        # A native GUI build may have no console; keep startup diagnostics local.
        if sys.stderr:
            print('Braid Archangel could not start: '+str(exc), file=sys.stderr)
        if getattr(sys, 'frozen', False) and not sys.stderr:
            import tkinter.messagebox
            tkinter.messagebox.showerror('Braid Archangel', str(exc))
        raise SystemExit(1)
