# Developer build inputs
These native-package scripts are retained source inputs used by regression tests.
They are not the supported end-user launch path and are not newly notarized or signed installers.
Use the platform launchers in the complete release folder; do not run these scripts to update an installed client.
