"""Archive a tested native app and complete source; never deploy or publish.

Example: python packaging/archive_release.py --app /path/Braid.app \
  --out /path/outputs --stage /path/work/stage --verification /path/verification
On macOS, ditto retains the native bundle's links, modes and resource metadata.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.9.2'
NOTES = ('START_HERE.md', 'README.md', 'RELEASE_NOTES.md', 'MIGRATION_NOTES.md',
         'TEST_RESULTS.md', 'QA.md', 'LICENSE', 'THIRD_PARTY_NOTICES.md')
EXCLUDED = {'.git', '.pytest_cache', '__pycache__', 'build', 'dist', 'evidence',
            'braid_client.egg-info', '.DS_Store'}


def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def source_archive(target):
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(ROOT.rglob('*')):
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED for part in relative.parts) or not path.is_file():
                continue
            if path.is_symlink():
                raise RuntimeError('Source contains an unexpected file link: ' + str(relative))
            if path.suffix in ('.pyc', '.pyo', '.patch', '.diff', '.pem', '.sqlite3', '.db'):
                continue
            archive.write(path, 'Braid-Archangel-' + VERSION + '-source/' + str(relative))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--verification', type=Path, required=True)
    args = parser.parse_args()
    app, out, stage, verification = (p.resolve() for p in
                                   (args.app, args.out, args.stage, args.verification))
    if not app.is_dir() or not verification.is_dir():
        raise SystemExit('Provide a built native application directory and test evidence.')
    if stage.exists() or stage == ROOT or ROOT in stage.parents:
        raise SystemExit('Stage must be a new directory outside the source tree.')
    if platform.system() != 'Darwin' or app.suffix != '.app':
        raise SystemExit('This archive recipe currently qualifies only macOS .app packaging.')
    label = 'Braid-Archangel-' + VERSION + '-macOS-' + platform.machine()
    package = stage / label
    package.mkdir(parents=True)
    out.mkdir(parents=True, exist_ok=True)
    native_zip = out / (label + '.zip')
    source_zip = out / ('Braid-Archangel-' + VERSION + '-source.zip')
    for path in (native_zip, source_zip):
        if path.exists():
            raise SystemExit('Refusing to overwrite archive: ' + str(path))
    # A shell companion's macOS signature may be stored in extended attributes;
    # copying only ordinary file bytes and modes loses that signature.
    subprocess.run(['/usr/bin/ditto', str(app), str(package / 'Braid.app')], check=True)
    for name in NOTES:
        shutil.copy2(ROOT / name, package / name)
        shutil.copy2(ROOT / name, out / name)
    shutil.copy2(ROOT / 'packaging/QUALIFY_PLATFORMS.md', package / 'QUALIFY_PLATFORMS.md')
    shutil.copytree(verification, package / 'verification')
    result_json = verification.parent / 'TEST_RESULTS.json'
    if result_json.is_file():
        shutil.copy2(result_json, package / result_json.name)
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(package / 'Braid.app')], check=True)
    subprocess.run(['/usr/bin/ditto', '-c', '-k', '--sequesterRsrc', '--keepParent',
                    str(package), str(native_zip)], check=True)
    source_archive(source_zip)
    wheel = ROOT / 'dist' / ('braid_client-' + VERSION + '-py3-none-any.whl')
    shutil.copy2(wheel, out / wheel.name)
    identity = {
        'product': 'Braid Archangel ' + VERSION, 'version': VERSION, 'folio': '0.3.0',
        'feature': 'integrated_local_folio', 'normal_journey': 'one native Braid application',
        'built_platform': platform.platform(), 'architecture': platform.machine(),
        'release_qualified': False, 'test_report': 'TEST_RESULTS.md',
        'native_signing': 'ad-hoc; not Developer ID notarized',
        'native_package': {'path': native_zip.name, 'sha256': sha(native_zip)},
        'source_package': {'path': source_zip.name, 'sha256': sha(source_zip)},
        'developer_wheel': {'path': wheel.name, 'sha256': sha(out / wheel.name)},
        'production_deployed': False, 'live_website_modified': False,
    }
    (out / 'RELEASE_MANIFEST.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps(identity, indent=2))


if __name__ == '__main__':
    main()
