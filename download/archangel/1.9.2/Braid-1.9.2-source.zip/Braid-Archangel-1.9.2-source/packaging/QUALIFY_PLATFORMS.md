# Native qualification for Braid Archangel 1.9.2

The delivered native binary was built and exercised on macOS 15.5 arm64.
The source implements platform-aware legacy Folio locations, path-safe profile
handling, protected Windows DACLs, Windows byte-range locks, and native
Windows/Linux build branches. These code paths are tested on the macOS host
with synthetic platform/Windows adapters; this is not native OS qualification.

Build on each actual target host with CPython 3.12 and the pinned
`desktop-requirements.txt` inputs. Run the complete suite unchanged. Run the
frozen application's `tests/native_launch192.py` checks with the produced
`Braid`/`Braid.exe` executable. Verify double-click/start menu or desktop-entry
launch, duplicate launch, stop/restart, paths containing spaces and non-ASCII
text, and migration from the original Folio 0.3.0 profile. Test protected DACLs
on a real Windows account, rather than interpreting POSIX mode bits as ACLs.

On macOS the existing address-change test needs an assigned `127.0.0.2`
loopback alias. This restricted build host has only `127.0.0.1` assigned and
cannot run privileged interface configuration. On an authorized qualification
host, provision the test-only loopback alias before running the unchanged test
and remove it afterward. Do not weaken `address_available`, mock it for an
end-to-end pass, or skip that test to qualify a release.

The browser harness needs permission to start Chromium subprocesses. This host
blocks Chromium's Mach-port bootstrap. The native HTTP/lifecycle checks ran
with the harness's explicit `--http-only` mode; the actual shipped UI was
separately exercised through Codex's browser against the native application.
No blocked browser process is recorded as a passing Chromium harness run.

Native Linux/Windows packages, notarization, Gatekeeper/Finder acceptance,
physical camera/Bluetooth tests, production WAN service qualification, and
physical two-rig/model scenarios remain unclaimed. No infrastructure or live
website deployment is part of this work.
