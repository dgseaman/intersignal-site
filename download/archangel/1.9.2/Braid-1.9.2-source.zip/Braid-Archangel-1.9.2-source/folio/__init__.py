"""Folio: local, human-directed publishing beside Braid."""
__version__ = '0.3.0'
