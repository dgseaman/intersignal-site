"""Loopback-only local UI. Every data API requires a per-session secret."""
from __future__ import annotations
import json
import mimetypes
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from . import __version__
from .braid import BraidBridge
from .core import (ValidationError, ConflictError, strict_json, new_draft, block, import_document,
                   public_body, review_digest, privacy_scan, render_html, context_text, MAX_BYTES)
from .store import Store

STATIC=Path(__file__).parent/'static'

class Server(ThreadingHTTPServer):
    daemon_threads=True;allow_reuse_address=False
    def __init__(self,home,port=0,token=None):
        self.store=Store(home);self.token=token or secrets.token_urlsafe(32);self.bridge=BraidBridge()
        super().__init__(('127.0.0.1',port),Handler)
        self.origin='http://127.0.0.1:'+str(self.server_port)
        self.scheduler_stop=threading.Event()
        self.scheduler=threading.Thread(target=self._schedule,name='folio-stream-scheduler',daemon=True)
        self.scheduler.start()

    def _schedule(self):
        # Cadence operates only while Folio is running. A missing Braid connection
        # produces a visible blocked run; the scheduler never silently reconnects.
        while not self.scheduler_stop.wait(30):
            try:
                for ident in self.store.due_stream_ids():
                    if self.scheduler_stop.is_set():break
                    try:self.store.run_stream(ident,self.bridge)
                    except Exception:
                        try:self.store.record_cycle_error(ident)
                        except Exception:pass  # Storage itself may be unavailable.
            except Exception:pass

    def shutdown(self):
        self.scheduler_stop.set()
        super().shutdown()

class Handler(BaseHTTPRequestHandler):
    server_version='Folio/'+__version__;sys_version=''
    def setup(self):
        super().setup();self.connection.settimeout(15)
    def log_message(self,format,*args):
        pass  # No request/content/token logging.
    def response(self,value,status=200,mime='application/json; charset=utf-8',extra=None):
        body=json.dumps(value,ensure_ascii=False,allow_nan=False).encode() if mime.startswith('application/json') else value
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
        for k,v in (extra or {}).items():self.send_header(k,v)
        self.end_headers()
        try:self.wfile.write(body)
        except (BrokenPipeError,ConnectionResetError):pass
    def gate(self,auth=False):
        if self.headers.get('Host')!='127.0.0.1:'+str(self.server.server_port):
            self.response({'error':'Invalid local Host header.'},403);return False
        origin=self.headers.get('Origin')
        if origin and origin!=self.server.origin:
            self.response({'error':'Cross-origin access is not permitted.'},403);return False
        if self.headers.get('Sec-Fetch-Site')=='cross-site':
            self.response({'error':'Cross-site access is not permitted.'},403);return False
        if auth and not secrets.compare_digest(self.headers.get('X-Folio-Token',''),self.server.token):
            self.response({'error':'Session expired or missing. Relaunch Folio to reopen this local window.'},401);return False
        return True
    def failure(self,exc):
        if isinstance(exc,ConflictError):status=409
        elif isinstance(exc,ValidationError):status=400
        else:status=500
        # Avoid unintentionally returning filesystem paths or source records.
        msg=str(exc) if status<500 else 'Folio could not complete this operation. No success is implied. Check available disk space and try again.'
        self.response({'error':msg},status)
    def do_GET(self):
        path=urlsplit(self.path).path
        if not self.gate(path.startswith('/api/')):return
        try:
            if path in ('/','/index.html','/app.js','/style.css'):
                name={'/':'index.html'}.get(path,path.lstrip('/'))
                mime={'index.html':'text/html; charset=utf-8','app.js':'application/javascript; charset=utf-8','style.css':'text/css; charset=utf-8'}[name]
                return self.response((STATIC/name).read_bytes(),mime=mime)
            if path=='/favicon.ico':return self.response(b'',mime='image/x-icon')
            q=parse_qs(urlsplit(self.path).query);ident=q.get('id',[''])[0]
            if path=='/api/state':return self.response({'app':'intersignal.folio','version':__version__,'drafts':self.server.store.list(),'preferences':self.server.store.preferences()})
            if path=='/api/draft':return self.response(self.server.store.get(ident))
            if path=='/api/streams':
                return self.response({'streams':self.server.store.streams(),'queue':self.server.store.runs(),
                    'connected':bool(self.server.bridge.base),'channels':self.server.bridge.channels})
            if path=='/api/streams/site':
                filename,raw=self.server.store.stream_site(ident)
                return self.response(raw,mime='application/zip',extra={'Content-Disposition':'attachment; filename="'+filename+'"'})
            if path=='/api/publish-kit':return self.response(self.server.store.publish_kit(ident))
            if path=='/api/braid/folio/identity':return self.response(self.server.bridge.public_identity())
            if path=='/api/download':
                record,raw=self.server.store.download(ident)
                return self.response(raw,mime='application/zip',extra={'Content-Disposition':'attachment; filename="'+record['filename']+'"'})
            self.response({'error':'Not found.'},404)
        except Exception as exc:self.failure(exc)
    def do_POST(self):
        if not self.gate(True):return
        try:
            if self.headers.get_content_type()!='application/json':raise ValidationError('JSON request required.')
            try:length=int(self.headers.get('Content-Length','-1'))
            except ValueError:raise ValidationError('Invalid request length.')
            if length<0 or length>MAX_BYTES:raise ValidationError('Request exceeds the 4 MiB limit.')
            d=strict_json(self.rfile.read(length))
            if not isinstance(d,dict):raise ValidationError('Expected a request object.')
            path=urlsplit(self.path).path;s=self.server.store;ident=d.get('id','')
            if not isinstance(ident,str):raise ValidationError('Invalid document identity.')
            if path=='/api/new':
                v=new_draft()
                v['kind']=d.get('kind','conversation')
                if d.get('text'):
                    v['blocks']=[block('note',d['text'],'A little thought')]
                    v['title']=v['blocks'][0]['text'].strip().split('\n')[0][:90] or 'A little thought'
                    while len(v['title'].encode('utf-8'))>300:v['title']=v['title'][:-1]
                    v['kind']='observation'
                value=s.insert(v)
            elif path=='/api/preferences':value=s.save_preferences(d)
            elif path=='/api/sample':
                v=new_draft('A publication you can continue',[
                    block('human','What should travel with a useful conversation?'),
                    block('ai','Not the entire private workspace. A deliberately selected edition, its assumptions, and the question that remains open.'),
                    block('note','Try editing an exchange, excluding a passage, then choosing exactly what belongs in the optional context capsule.')],{'kind':'Synthetic example; not a real recorded conversation'})
                v['subtitle']='A synthetic example for your first five minutes in Folio.'
                v['introduction']='This is sample material, not a real interview or a claim about any model. Replace it with a conversation from Braid or your own writing.'
                v['capsule']['question']='Does a portable, reviewed context packet make it easier for a reader to contribute something useful?'
                value=s.insert(v)
            elif path=='/api/save':value=s.save(ident,d.get('draft',{}),self.server.bridge)
            elif path=='/api/import':value=s.insert(import_document(d.get('content',''),d.get('filename','import.txt')))
            elif path=='/api/preview':
                v=s.get(ident);body=public_body(v);sha=review_digest(v)
                e={'body':body,'content_sha256':sha,'edition_number':len(v['editions'])+1,'published_at':'Not exported'}
                value={'html':render_html(e,preview=True),'public_json':json.dumps(body,ensure_ascii=False,indent=2),
                       'digest':sha,'findings':privacy_scan(v),'context_text':context_text(e),
                       'approved':v.get('approved_digest')==sha,'excluded':sum(not b['include'] for b in v['blocks'])}
            elif path=='/api/approve':value=s.approve(ident,d.get('digest'),d.get('confirmed'))
            elif path=='/api/export':value=s.export(ident,self.server.bridge)
            elif path=='/api/delete':
                if d.get('confirmed') is not True:raise ValidationError('Deletion requires confirmation.')
                value=s.delete(ident,d.get('revision'),self.server.bridge)
            elif path=='/api/streams/save':value=s.save_stream(d.get('stream',{}))
            elif path=='/api/streams/delete':value=s.delete_stream(ident,d.get('revision'))
            elif path=='/api/streams/run':value=s.run_stream(ident,self.server.bridge)
            elif path=='/api/streams/publish':value=s.retry_stream_site(ident)
            elif path=='/api/braid/connect':value=self.server.bridge.connect(d.get('address',''))
            elif path=='/api/braid/check':value=self.server.bridge.connection_check(d.get('rendezvous_url','https://connect.intersignal.org'))
            elif path=='/api/braid/channel':value=self.server.bridge.channel(ident)
            elif path=='/api/braid/import-thread':value=s.insert(self.server.bridge.import_thread(ident))
            elif path=='/api/braid/import-note':value=s.insert(self.server.bridge.import_note(d.get('channel',''),ident,d.get('kind','')))
            elif path=='/api/quit':
                value={'quitting':True};threading.Thread(target=self.server.shutdown,daemon=True).start()
            else:return self.response({'error':'Unknown operation.'},404)
            self.response(value)
        except Exception as exc:self.failure(exc)
