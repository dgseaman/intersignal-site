"""Bounded data model, review binding, and deterministic public exports.

Private source records never participate in the export schema. This is an
editorial privacy boundary, not an automated anonymity guarantee.
"""
from __future__ import annotations
import hashlib
import html
import io
import json
import re
import uuid
import zipfile
from datetime import datetime, timezone
from urllib.parse import urlsplit, urlencode

MAX_BYTES = 4 * 1024 * 1024
MAX_TEXT = 80000
MAX_BLOCKS = 400
KINDS = ('conversation', 'essay', 'question', 'observation')
ROLES = ('human', 'ai', 'note')
CAPSULE_FIELDS = ('background', 'question', 'observations', 'attempted', 'constraints', 'uncertainty')
CAPSULE_LABELS = dict(background='Background', question='Question to investigate',
    observations='Evidence and observations', attempted='Already tried',
    constraints='Scope and constraints', uncertainty='Uncertainty and limitations')
CONNECTION_SCOPES = ('publication_channel', 'messages', 'follow_publications')
DEFAULT_CONNECTION = {'enabled': False, 'source_network_id': '', 'rendezvous_url': 'https://connect.intersignal.org',
                      'allowed_scopes': ['publication_channel', 'messages']}

class ValidationError(ValueError):
    pass

class ConflictError(ValidationError):
    pass

def uid():
    return uuid.uuid4().hex

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')

def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()

def strict_json(raw, max_bytes=MAX_BYTES):
    if len(raw if isinstance(raw, bytes) else raw.encode('utf-8')) > max_bytes:
        if max_bytes==MAX_BYTES:raise ValidationError('File is too large. The import limit is 4 MiB.')
        raise ValidationError('JSON exceeds the permitted size.')
    try:
        scan = raw.decode('utf-8-sig') if isinstance(raw, bytes) else raw
    except UnicodeError as e:
        raise ValidationError('JSON must be UTF-8.') from e
    depth = 0; quoted = False; escaped = False
    for ch in scan:
        if quoted:
            if escaped: escaped = False
            elif ch == chr(92): escaped = True
            elif ch == chr(34): quoted = False
        elif ch == chr(34): quoted = True
        elif ch in '[{':
            depth += 1
            if depth > 64: raise ValidationError('JSON nesting exceeds 64 levels.')
        elif ch in ']}': depth -= 1
    def pairs(items):
        obj = {}
        for k,v in items:
            if k in obj:
                raise ValidationError('Duplicate JSON keys are not accepted.')
            obj[k] = v
        return obj
    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda _: (_ for _ in ()).throw(ValidationError('Nonfinite JSON is not accepted.')))
    except (RecursionError, UnicodeError, json.JSONDecodeError) as e:
        raise ValidationError('Could not read this JSON document.') from e

def text(value, limit=MAX_TEXT):
    if not isinstance(value, str):
        raise ValidationError('Text fields must contain text.')
    if len(value.encode('utf-8')) > limit:
        raise ValidationError('A text field exceeds its byte limit (%s).' % limit)
    if any(ord(c) < 32 and c not in '\n\r\t' for c in value):
        raise ValidationError('Control characters are not accepted in publication text.')
    return value.replace('\r\n', '\n').replace('\r', '\n')

def safe_url(value):
    value = text(value, 4096).strip()
    if not value:
        return ''
    try:
        u = urlsplit(value)
        if u.scheme not in ('http', 'https') or not u.hostname or u.username or u.password or any(c.isspace() for c in value):
            raise ValueError()
        _ = u.port
    except ValueError:
        raise ValidationError('Public links must be http(s) URLs without embedded credentials.')
    return value

def validate_connection(value, publication_id, require_ready=True):
    """Only deliberately chosen public rendezvous metadata can leave a draft."""
    if not isinstance(value, dict) or type(value.get('enabled', False)) is not bool:
        raise ValidationError('Invalid Braid connection settings.')
    enabled = value.get('enabled', False)
    if not isinstance(publication_id, str) or not re.fullmatch('[a-f0-9]{32}', publication_id):
        raise ValidationError('Invalid Folio publication identity.')
    source = text(value.get('source_network_id', ''), 64).strip().lower()
    endpoint = text(value.get('rendezvous_url', ''), 256).strip().rstrip('/')
    scopes = value.get('allowed_scopes', list(DEFAULT_CONNECTION['allowed_scopes']))
    if not isinstance(scopes, list) or len(scopes) > len(CONNECTION_SCOPES) or any(s not in CONNECTION_SCOPES for s in scopes):
        raise ValidationError('Choose only supported Braid connection permissions.')
    scopes = [s for s in CONNECTION_SCOPES if s in scopes]
    if enabled and require_ready:
        if not re.fullmatch('[a-f0-9]{64}', source):
            raise ValidationError('A public Braid network identity is required for connection requests.')
        if not scopes:
            raise ValidationError('Choose at least one Braid connection permission.')
        try:
            u = urlsplit(endpoint)
            host=u.hostname or ''
            first_party = (u.scheme == 'https' and
                (host == 'intersignal.org' or host.endswith('.intersignal.org')) and u.port in (None,443))
            local_demo = (u.scheme in ('http','https') and host in ('127.0.0.1','localhost','::1') and u.port is not None)
            if (not first_party and not local_demo) or u.username or u.password or u.path not in ('', '/') or u.query or u.fragment or any(c.isspace() for c in endpoint):
                raise ValueError()
            _ = u.port
        except ValueError:
            raise ValidationError('Use a first-party HTTPS intersignal.org Braid rendezvous origin (or loopback for a local demonstration).')
    return {'enabled': enabled, 'publication_id': publication_id,
            'source_network_id': source, 'rendezvous_url': endpoint,
            'allowed_scopes': scopes}

def connection_href(edition):
    connection = edition.get('body', {}).get('connection')
    if connection is None:
        return ''
    if not isinstance(connection, dict):
        raise ValidationError('Saved edition connection metadata is invalid.')
    checked = validate_connection(connection, connection.get('publication_id'))
    if not checked['enabled']:
        return ''
    ident = edition.get('edition_id')
    if ident is not None and (not isinstance(ident, str) or not re.fullmatch('[a-f0-9]{32}', ident)):
        raise ValidationError('Saved edition identity is invalid.')
    query = {'publication_id': checked['publication_id'],
             'source_network_id': checked['source_network_id']}
    if ident is not None:
        query['edition_id'] = ident
    return checked['rendezvous_url'] + '/continue?' + urlencode(query)

def connection_view_href(edition):
    connection = edition.get('body', {}).get('connection')
    if connection is None:
        return ''
    checked = validate_connection(connection, connection.get('publication_id'))
    if not checked['enabled'] or edition.get('edition_id') is None:
        return ''
    ident = edition['edition_id']
    if not isinstance(ident,str) or not re.fullmatch('[a-f0-9]{32}',ident):
        raise ValidationError('Saved edition identity is invalid.')
    return checked['rendezvous_url'] + '/v1/events/view.gif?' + urlencode({
        'publication_id':checked['publication_id'], 'edition_id':ident})

def connection_section(edition, include_view=True):
    href = connection_href(edition)
    if not href:
        return ''
    beacon = ('<img src="'+html.escape(connection_view_href(edition),quote=True)+'" alt="" width="1" height="1" '
              'aria-hidden="true" referrerpolicy="no-referrer">') if include_view and connection_view_href(edition) else ''
    return ('<section class="folio-connect" aria-label="Continue on Braid">'
            '<div class="folio-connect-eyebrow">Produced with Braid</div>'
            '<h2>Keep exploring together.</h2>'
            '<p>Request a connection to continue exploring this publication with its source network. '
            'The publisher approves access to a selected scope.</p>'
            '<a class="folio-connect-action" href="' + html.escape(href, quote=True) + '">Continue this on Braid &rarr;</a>'
            '<p class="folio-connect-note">Other Braid channels and private local state are not shared by this request.</p>'
            + beacon +
            '</section>')

def new_draft(title='Untitled folio', blocks=None, private_source=None):
    return dict(id=uid(), revision=0, created_at=now(), updated_at=now(), title=title,
        subtitle='', author='', kind='conversation', introduction='', conclusion='',
        blocks=blocks or [], sources='', parent=None,
        capsule={'enabled':False, 'passage_ids':[], **{k:'' for k in CAPSULE_FIELDS}},
        connection=dict(DEFAULT_CONNECTION, allowed_scopes=list(DEFAULT_CONNECTION['allowed_scopes'])),
        private_source=private_source or {}, approved_digest=None, editions=[])

def block(role, content, speaker=None, original=None):
    return dict(id=uid(), role=role, speaker=speaker or {'human':'You','ai':'Local AI','note':'Editorial note'}[role],
                text=text(content), original=text(content if original is None else original), include=True, source_edited=False)

def validate_draft(incoming, existing):
    if not isinstance(incoming, dict):
        raise ValidationError('Expected a folio object.')
    result = dict(existing)
    for k,limit in [('title',300),('subtitle',2000),('author',300),('introduction',MAX_TEXT),('conclusion',MAX_TEXT),('sources',MAX_TEXT)]:
        result[k] = text(incoming.get(k, ''), limit)
    result['kind'] = incoming.get('kind', 'conversation')
    if result['kind'] not in KINDS:
        raise ValidationError('Unknown publication type.')
    result['theme']=incoming.get('theme',existing.get('theme','paper'))
    if result['theme'] not in ('paper','rose','midnight'):
        raise ValidationError('Choose a publication look: Paper, Rose, or Midnight.')
    blocks = incoming.get('blocks')
    if not isinstance(blocks, list) or len(blocks)>MAX_BLOCKS:
        raise ValidationError('A folio supports up to 400 passages.')
    prior = {b['id']:b for b in existing['blocks']}
    seen = set(); result['blocks'] = []
    for b in blocks:
        if not isinstance(b,dict) or b.get('role') not in ROLES:
            raise ValidationError('Invalid passage.')
        ident = b.get('id')
        if not isinstance(ident,str) or not re.fullmatch('[a-f0-9]{32}',ident) or ident in seen:
            raise ValidationError('Invalid or duplicate passage identifier.')
        seen.add(ident)
        if type(b.get('include')) is not bool:
            raise ValidationError('Each passage requires an explicit inclusion choice.')
        # The immutable imported original cannot be replaced through the editor.
        result['blocks'].append(dict(id=ident, role=b['role'], speaker=text(b.get('speaker',''),300),
            text=text(b.get('text','')), include=b['include'],
            original=prior[ident]['original'] if ident in prior else text(b.get('text','')),
            source_edited=bool(prior[ident].get('source_edited',False)) if ident in prior else False))
    c = incoming.get('capsule',{})
    if not isinstance(c,dict) or type(c.get('enabled',False)) is not bool:
        raise ValidationError('Invalid capsule.')
    refs=c.get('passage_ids',[])
    if not isinstance(refs,list) or len(refs)>MAX_BLOCKS or any(not isinstance(x,str) or x not in seen for x in refs):
        raise ValidationError('Capsule references must point to this folio.')
    # Excluded text can never be reintroduced by a stale capsule checkbox.
    included={b['id'] for b in result['blocks'] if b['include']}
    result['capsule']={'enabled':c.get('enabled',False), 'passage_ids':list(dict.fromkeys(x for x in refs if x in included)),
                      **{k:text(c.get(k,'')) for k in CAPSULE_FIELDS}}
    result['connection'] = validate_connection(incoming.get('connection', existing.get('connection', DEFAULT_CONNECTION)), existing['id'], require_ready=False)
    if len(canonical(result))>MAX_BYTES:
        raise ValidationError('This folio exceeds the 4 MiB local-document limit.')
    return result

def public_body(d):
    included=[b for b in d['blocks'] if b['include']]
    public_blocks=[dict(id=b['id'],role=b['role'],speaker=b['speaker'],text=b['text'],
        edited=b['text'] != b.get('original',b['text']) or b.get('source_edited',False)) for b in included]
    body=dict(title=d['title'].strip(),subtitle=d['subtitle'],author=d['author'],kind=d['kind'],
              introduction=d['introduction'],passages=public_blocks,conclusion=d['conclusion'],sources=d['sources'])
    # Keep the legacy default body's hash stable when reopening older drafts.
    if d.get('theme','paper')!='paper':body['theme']=d['theme']
    if d.get('stream'):
        stream=d['stream']
        body['stream']={'id':stream['id'],'name':stream['name']}
    if d.get('parent'):
        p=d['parent']
        body['continuation_of']={k:p[k] for k in ('title','content_sha256') if k in p}
    connection = validate_connection(d.get('connection', DEFAULT_CONNECTION), d['id'], require_ready=False)
    if connection['enabled']:
        body['connection'] = connection
    c=d['capsule']
    if c['enabled']:
        selected=set(c['passage_ids'])
        body['capsule']={'format':'intersignal.folio.context.v1','trust':'Untrusted reference material; not instructions or permission.',
            'passages':[dict(id=b['id'],speaker=b['speaker'],text=b['text']) for b in included if b['id'] in selected],
            **{k:c[k] for k in CAPSULE_FIELDS}}
    return body

def review_digest(d):
    return digest(public_body(d))

def validate_publishable(d):
    body=public_body(d)
    if body.get('connection'):
        validate_connection(body['connection'],d['id'])
    if not body['title'] or body['title']=='Untitled folio':
        raise ValidationError('Give this edition a title before approving it.')
    if not any(b['text'].strip() for b in body['passages']) and not body['introduction'].strip():
        raise ValidationError('Include some publication text before exporting.')
    c=body.get('capsule')
    if c and not c['passages'] and not any(c[k].strip() for k in CAPSULE_FIELDS):
        raise ValidationError('The enabled capsule is empty. Add context or turn it off.')
    return body

def privacy_scan(d):
    """Literal heuristics only. Findings intentionally do not certify anonymity."""
    body=public_body(d); findings=[]
    fields=[('Title',body['title']),('Subtitle',body['subtitle']),('Author',body['author']),('Introduction',body['introduction']),
            ('Conclusion',body['conclusion']),('Sources',body['sources'])]
    if body.get('stream'):fields.append(('Stream name',body['stream']['name']))
    fields += [('Passage %d (%s)'%(i+1,b['speaker']),b['text']) for i,b in enumerate(body['passages'])]
    fields += [('Speaker %d'%(i+1),b['speaker']) for i,b in enumerate(body['passages'])]
    if body.get('capsule'):
        fields += [('Capsule: '+CAPSULE_LABELS[k],body['capsule'][k]) for k in CAPSULE_FIELDS]
    patterns=[('Email address',r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'),
        ('IP address',r'\b(?:\d{1,3}\.){3}\d{1,3}\b'),
        ('Local path',r'(?:/Users/|/home/|[A-Za-z]:\\Users\\)\S+'),
        ('Possible credential',r'(?i)\b(?:api[_ -]?key|token|password|secret)\s*[:=]\s*\S+|\bsk-[A-Za-z0-9_-]{12,}'),
        ('Possible phone number',r'(?<!\w)(?:\+\d{1,3}[ .-]?)?\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4}\b')]
    for field,value in fields:
        for label,pattern in patterns:
            for match in list(re.finditer(pattern,value))[:10]:
                findings.append(dict(field=field,kind=label,excerpt=match.group(0)[:100]))
    return findings[:100]

def make_edition(d, number, published_at=None):
    body=validate_publishable(d)
    if d.get('approved_digest') != digest(body):
        raise ConflictError('This exact edition has not been approved, or it changed after approval. Review it again.')
    return {'format':'intersignal.folio.edition.v1','edition_id':uid(),'edition_number':number,
            'published_at':published_at or now(),'content_sha256':digest(body),'body':body}

def paragraph(value):
    return '<div class="prose">'+html.escape(value).replace('\n','<br>')+'</div>'

PUBLIC_CSS='''*{box-sizing:border-box}body{margin:0;background:#f7f5ef;color:#242d29;font:18px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}main{max-width:850px;margin:0 auto;padding:65px 36px 80px}header{border-bottom:1px solid #cfd5cb;padding-bottom:30px;margin-bottom:35px}.eyebrow{font:12px/1.5 ui-monospace,monospace;letter-spacing:.14em;text-transform:uppercase;color:#456958}h1{font:normal clamp(32px,6vw,56px)/1.1 Georgia,serif;letter-spacing:-.025em;margin:18px 0}h2{font:normal 30px/1.2 Georgia,serif}h3{font-size:17px}.subtitle{font-size:22px;color:#59665f}.meta,footer,.small{font-size:13px;color:#607068}.passage{border-top:1px solid #d8ddd4;padding:25px 0;break-inside:avoid}.speaker{font:12px ui-monospace,monospace;text-transform:uppercase;letter-spacing:.08em;color:#37694e}.prose{overflow-wrap:anywhere;white-space:normal;margin:15px 0}a{color:#37694e}aside{background:#e9eee5;padding:25px;margin:36px 0;border-radius:8px}footer{border-top:1px solid #cfd5cb;padding-top:22px;margin-top:48px}code{overflow-wrap:anywhere;font-size:12px}a.download{display:inline-block;margin:8px 14px 8px 0}.folio-connect{border-top:1px solid #cfd5cb;margin-top:48px;padding:30px 0 6px}.folio-connect-eyebrow{font:12px/1.5 ui-monospace,monospace;letter-spacing:.14em;text-transform:uppercase;color:#456958}.folio-connect h2{margin:12px 0}.folio-connect p{max-width:620px}.folio-connect-action{display:inline-block;margin:5px 0 12px;font-weight:600;text-decoration:none;border-bottom:1px solid currentColor}.folio-connect-note{font-size:13px;color:#607068}@media print{body{background:white}main{padding:10px}.download{display:none}}'''

PUBLIC_CSS += """body{background:#f5f1e9;color:#302e3a}main{max-width:820px}header{position:relative;border-color:#d8cedc;padding-bottom:38px}.eyebrow,.speaker{color:#7b518c}h1{font-family:Georgia,serif;font-size:clamp(38px,7vw,68px);letter-spacing:-.045em}header:before{content:'✳';display:block;font-size:32px;color:#b47358;margin-bottom:24px}.passage{border-color:#ded5dc}.prose{line-height:1.85}.subtitle{color:#77707c}a{color:#71507e}aside{background:#eae2ee;border-radius:4px}.folio-connect{background:#eae2ee;border:0;padding:30px;border-radius:8px}.folio-connect-action{background:#71507e;color:#fff;padding:12px 20px;border-radius:6px;border:0}.folio-connect-note{color:#68616e}@media(max-width:520px){main{padding:36px 22px}header:before{margin-bottom:12px}}"""
THEME_CSS={
    'paper':'',
    'rose':'body{background:#f9ece8;color:#4e333d}a,.eyebrow,.speaker{color:#944f68}aside,.folio-connect{background:#f0dce2}.folio-connect-action{background:#944f68;color:white}.subtitle,.meta,footer,.small,.folio-connect-note{color:#795b68}',
    'midnight':'body{background:#242b41;color:#f1ecdf}a,.eyebrow,.speaker{color:#d8c2ec}aside,.folio-connect{background:#303951}.folio-connect-action{background:#d8c2ec;color:#252b41}.subtitle,.meta,footer,.small,.folio-connect-note{color:#c4bed1}header,.passage,footer{border-color:#48506a}'
}
def edition_theme(edition):
    theme=edition.get('body',{}).get('theme','paper')
    if theme not in THEME_CSS:raise ValidationError('Saved edition publication look is invalid.')
    return theme

def render_html(edition, preview=False):
    b=edition['body']; esc=html.escape
    connection=b.get('connection')
    image_source=''
    if connection is not None:
        checked=validate_connection(connection,connection.get('publication_id'))
        if checked['enabled'] and not preview:
            image_source='; img-src '+checked['rendezvous_url']
    out=['<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
         '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\''+esc(image_source,quote=True)+'">',
         '<title>'+esc(b['title'])+'</title><meta name="description" content="'+esc(b['subtitle'],quote=True)+'"><meta property="og:type" content="article"><meta property="og:title" content="'+esc(b['title'],quote=True)+'"><meta property="og:description" content="'+esc(b['subtitle'],quote=True)+'"><style>'+PUBLIC_CSS+THEME_CSS[edition_theme(edition)]+'</style></head><body><main>',
         '<header><div class="eyebrow">Folio / '+esc(b['stream']['name'] if b.get('stream') else b['kind'])+'</div><h1>'+esc(b['title'])+'</h1>']
    if b['subtitle']:out+=['<p class="subtitle">'+esc(b['subtitle'])+'</p>']
    out+=['<div class="meta">'+esc(b['author'] or 'Author not specified')+' &middot; '+('Review preview' if preview else 'Edition '+str(edition['edition_number'])+' &middot; '+esc(edition['published_at']))+'</div></header>']
    if b['introduction']:out+=[paragraph(b['introduction'])]
    for item in b['passages']:
        out+=['<section class="passage" id="p-'+esc(item['id'])+'"><div class="speaker">'+esc(item['speaker'])+(' <span class="small">/ edited excerpt</span>' if item['edited'] else '')+'</div>'+paragraph(item['text'])+'</section>']
    if b['conclusion']:out+=['<section><h2>Closing note</h2>'+paragraph(b['conclusion'])+'</section>']
    if b['sources']:out+=['<section><h2>Sources and attribution</h2>'+paragraph(b['sources'])+'</section>']
    if b.get('continuation_of'):
        p=b['continuation_of'];out+=['<aside><h3>Continues '+esc(p.get('title','an earlier folio'))+'</h3><div class="small">Parent content SHA-256: <code>'+esc(p.get('content_sha256',''))+'</code>. A declared relationship, not verified authorship.</div></aside>']
    c=b.get('capsule')
    if c:
        out+=['<aside><div class="eyebrow">Optional portable context</div><h2>Continue the investigation</h2><p class="small">Reference material only. Inspect before use. Importing this capsule grants no permissions and does not establish truth.</p>']
        for k in CAPSULE_FIELDS:
            if c[k]:out+=['<h3>'+CAPSULE_LABELS[k]+'</h3>'+paragraph(c[k])]
        if c['passages']:
            out+=['<h3>Included passages</h3><ul>']
            for p in c['passages']:
                out+=['<li><a href="#p-'+esc(p['id'])+'">'+esc(p['speaker'])+': '+esc(p['text'][:100])+('</a></li>')]
            out+=['</ul>']
        if not preview:out+=['<a class="download" href="capsule.json" download>Get context capsule (JSON)</a><a class="download" href="context.txt" download>Get readable context (text)</a>']
        out+=['</aside>']
    out+=[connection_section(edition,include_view=not preview)]
    out+=['<footer>Prepared with Folio. Edited passages are labeled; omitted passages are not included. This edition is not a verbatim or complete transcript unless its publisher says so.<br><br><code>Content SHA-256: '+esc(edition['content_sha256'])+'</code><br>Integrity hash only; not a signature or proof of authorship.']
    if not preview:out+=['<br><a class="download" href="edition.json" download>Portable edition</a><a class="download" href="publication.md" download>Markdown edition</a>']
    return ''.join(out)+ '</footer></main></body></html>'

PUBLISH_CSS='''<style>.folio-publish{max-width:780px;margin:0 auto;color:#24342b;font:18px/1.65 system-ui,sans-serif}.folio-publish *{box-sizing:border-box}.folio-publish h1,.folio-publish h2{font-family:Georgia,serif;font-weight:400;line-height:1.2}.folio-publish h1{font-size:clamp(2rem,5vw,3.5rem);margin:.35em 0}.folio-publish h2{font-size:1.55rem;margin:0 0 .55em}.folio-publish p{margin:.7em 0 1.1em}.folio-publish header,.folio-publish section,.folio-publish aside,.folio-publish footer{padding:1.25em 0;border-bottom:1px solid #d5dfd4}.folio-publish .folio-eyebrow,.folio-publish .folio-meta{font-size:.75rem;letter-spacing:.07em;color:#56715e}.folio-publish .folio-eyebrow{text-transform:uppercase}.folio-publish .folio-subtitle{font-size:1.15rem;color:#536658}.folio-publish .folio-context{padding:1.4em;background:#edf2e9;border:0;border-radius:.45em}.folio-publish .folio-edited{font-size:.75rem;color:#66776c}.folio-publish .folio-connect{margin-top:1.5em}.folio-publish .folio-connect-eyebrow{font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;color:#56715e}.folio-publish .folio-connect-action{display:inline-block;font-weight:600;text-decoration:underline;color:#37694e}.folio-publish .folio-connect-note{font-size:.75rem;color:#66776c}.folio-publish code{overflow-wrap:anywhere;font-size:.72rem}</style>'''

def render_publish_kit(edition):
    """CMS-ready fragments from one immutable, reviewed public edition.

    No draft data, relative files, scripts, global CSS, or full-document tags enter
    these fragments. A host's own editor can supply its typography for plain_html.
    """
    if not isinstance(edition,dict) or edition.get('format')!='intersignal.folio.edition.v1':
        raise ValidationError('Saved edition format is not supported.')
    b=edition.get('body')
    if not isinstance(b,dict) or digest(b)!=edition.get('content_sha256'):
        raise ValidationError('Saved edition content hash does not match.')
    if not isinstance(b.get('passages'),list) or len(b['passages'])>MAX_BLOCKS:
        raise ValidationError('Saved edition passages are invalid.')
    esc=html.escape
    def value(obj,key):
        item=obj.get(key,'')
        if not isinstance(item,str):raise ValidationError('Saved edition text is invalid.')
        return item
    def para(s):return '<p>'+esc(s).replace('\n','<br>')+'</p>'
    parts=['<article class="folio-publish">','<header>']
    label=value(b,'kind')
    stream=b.get('stream')
    if stream is not None:
        if not isinstance(stream,dict):raise ValidationError('Saved edition stream is invalid.')
        label=value(stream,'name') or label
    title=value(b,'title')
    parts+=['<p class="folio-eyebrow">Folio / '+esc(label)+'</p>','<h1>'+esc(title)+'</h1>']
    if b.get('subtitle'):parts+=['<p class="folio-subtitle">'+esc(value(b,'subtitle')).replace('\n','<br>')+'</p>']
    parts+=['<p class="folio-meta">'+esc(value(b,'author') or 'Author not specified')+' · Edition '+esc(str(edition.get('edition_number','')))+' · '+esc(str(edition.get('published_at','')))+'</p>','</header>']
    if b.get('introduction'):parts+=['<section aria-label="Introduction">',para(value(b,'introduction')),'</section>']
    for item in b['passages']:
        if not isinstance(item,dict) or type(item.get('edited')) is not bool:
            raise ValidationError('Saved edition passage is invalid.')
        ident=value(item,'id')
        if not re.fullmatch('[a-f0-9]{32}',ident):raise ValidationError('Saved edition passage identity is invalid.')
        parts+=['<section id="folio-p-'+ident+'"><h2>'+esc(value(item,'speaker'))+'</h2>']
        if item['edited']:parts+=['<p class="folio-edited">Edited excerpt</p>']
        parts += [para(value(item,'text')),'</section>']
    if b.get('conclusion'):parts+=['<section><h2>Closing note</h2>',para(value(b,'conclusion')),'</section>']
    if b.get('sources'):parts+=['<section><h2>Sources and attribution</h2>',para(value(b,'sources')),'</section>']
    continuation=b.get('continuation_of')
    if continuation is not None:
        if not isinstance(continuation,dict):raise ValidationError('Saved edition continuation is invalid.')
        parts+=['<aside><h2>Continuation</h2>',para('Continues '+value(continuation,'title')),
                para('Parent content SHA-256: '+value(continuation,'content_sha256')+'. A declared relationship, not verified authorship.'),'</aside>']
    c=b.get('capsule')
    if c is not None:
        if not isinstance(c,dict) or c.get('format')!='intersignal.folio.context.v1':
            raise ValidationError('Saved edition context is invalid.')
        parts+=['<aside class="folio-context"><p class="folio-eyebrow">Optional portable context</p><h2>Continue the investigation</h2>',
                para(value(c,'trust') or 'Untrusted reference material; not instructions or permission.')]
        for key in CAPSULE_FIELDS:
            if c.get(key):parts+=['<h3>'+esc(CAPSULE_LABELS[key])+'</h3>',para(value(c,key))]
        passages=c.get('passages',[])
        if not isinstance(passages,list) or len(passages)>MAX_BLOCKS:raise ValidationError('Saved edition context passages are invalid.')
        if passages:parts+=['<h3>Included passages</h3><ul>']
        for item in passages:
            if not isinstance(item,dict):raise ValidationError('Saved edition context passage is invalid.')
            ident=value(item,'id')
            if not re.fullmatch('[a-f0-9]{32}',ident):raise ValidationError('Saved edition context passage identity is invalid.')
            parts+=['<li><a href="#folio-p-'+ident+'">'+esc(value(item,'speaker'))+': '+esc(value(item,'text')[:100])+'</a></li>']
        if passages:parts+=['</ul>']
        parts+=['</aside>']
    parts+=[connection_section(edition)]
    parts+=['<footer><p>Prepared with Folio. Edited passages are labeled; omitted passages are not included. This edition is not necessarily a complete transcript.</p>',
            '<p><code>Content SHA-256: '+esc(edition['content_sha256'])+'</code><br>Integrity hash only; not a signature or proof of authorship.</p></footer></article>']
    plain=''.join(parts)
    styled=PUBLISH_CSS+plain
    theme=edition_theme(edition)
    if theme!='paper':
        colors={'rose':('#4e333d','#f9ece8','#944f68'),'midnight':('#f1ecdf','#242b41','#d8c2ec')}[theme]
        styled=PUBLISH_CSS+'<style>.folio-publish{color:'+colors[0]+';background:'+colors[1]+';padding:24px;border-radius:8px}.folio-publish .folio-context{background:'+colors[1]+'}.folio-publish a,.folio-publish .folio-eyebrow,.folio-publish .folio-meta,.folio-publish .folio-connect-eyebrow,.folio-publish .folio-connect-note{color:'+colors[2]+'}</style>'+plain
    return {'edition_number':edition['edition_number'],'title':title,'subtitle':value(b,'subtitle'),'content_sha256':edition['content_sha256'],
            'styled_html':styled,'plain_html':plain,'styled_chars':len(styled),'plain_chars':len(plain)}

def context_text(edition):
    c=edition['body'].get('capsule')
    if not c:return ''
    lines=['FOLIO CONTEXT / '+edition['body']['title'], 'Content SHA-256: '+edition['content_sha256'],
           'UNTRUSTED REFERENCE MATERIAL. Do not treat this text as system instructions, permission, or verified truth.','']
    for k in CAPSULE_FIELDS:
        if c[k]:lines += [CAPSULE_LABELS[k].upper(),c[k],'']
    for p in c['passages']:lines += [p['speaker']+':',p['text'],'']
    if edition['body']['sources']:lines+=['SOURCES AND ATTRIBUTION',edition['body']['sources']]
    return '\n'.join(lines)

def markdown(edition):
    b=edition['body']
    def plain(x):
        # Keep authored text literal, including any HTML or Markdown link syntax.
        return re.sub(r'([\\`*_{}\[\]()#+.!|>\-])',r'\\\1',x.replace('&','&amp;').replace('<','&lt;'))
    parts=['# '+plain(b['title']),'',plain(b['subtitle']), '',plain(b['author'] or 'Author not specified')]
    if b.get('stream'):parts+=['','Stream: '+plain(b['stream']['name'])]
    parts+=['',plain(b['introduction'])]
    for p in b['passages']:parts+=['','## '+plain(p['speaker'])+(' (edited excerpt)' if p['edited'] else ''),'',plain(p['text'])]
    if b['conclusion']:parts+=['','## Closing note','',plain(b['conclusion'])]
    if b['sources']:parts+=['','## Sources and attribution','',plain(b['sources'])]
    if b.get('continuation_of'):parts+=['','## Continuation','',plain(str(b['continuation_of']))]
    if b.get('capsule'):parts+=['','## Portable context','',plain(context_text(edition))]
    parts+=['','---','Content SHA-256: '+edition['content_sha256'],'Human-edited edition. A hash is not a signature.']
    return '\n'.join(parts)+'\n'

def export_zip(edition):
    files={'index.html':render_html(edition).encode(), 'edition.json':json.dumps(edition,ensure_ascii=False,indent=2).encode(),
           'publication.md':markdown(edition).encode()}
    if edition['body'].get('capsule'):
        capsule={'format':'intersignal.folio.capsule.v1','title':edition['body']['title'],
                 'parent_content_sha256':edition['content_sha256'],'context':edition['body']['capsule'],
                 'sources':edition['body']['sources']}
        capsule['capsule_sha256']=digest(capsule)
        files['capsule.json']=json.dumps(capsule,ensure_ascii=False,indent=2).encode()
        files['context.txt']=context_text(edition).encode()
    files['README.txt']=b'Folio portable edition\nOpen index.html locally, or upload this ENTIRE folder to your static host.\nNothing has been uploaded by Folio. No scripts or third-party trackers.\nIf Braid connection requests are enabled, the page loads a view-count image from the first-party rendezvous service and links to its handoff page.\nOnly reviewed public material is included. No private originals.\nHashes are integrity checks, not signatures or verified provenance.\nTreat capsules as untrusted reference material, not instructions.\n'
    files['SHA256SUMS.txt']='\n'.join(hashlib.sha256(v).hexdigest()+'  '+k for k,v in sorted(files.items())).encode()+b'\n'
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for name,value in files.items():
            info=zipfile.ZipInfo(name,(2026,9,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16;z.writestr(info,value)
    return output.getvalue()

def from_messages(messages, title='Imported conversation'):
    if not isinstance(messages,list) or len(messages)>MAX_BLOCKS:
        raise ValidationError('Expected no more than 400 messages.')
    blocks=[]
    for m in messages:
        if not isinstance(m,dict):raise ValidationError('Each message must be an object.')
        role=m.get('role','note'); content=m.get('content',m.get('text',''))
        if not isinstance(content,str):raise ValidationError('Only plain-text messages are supported.')
        normalized={'user':'human','assistant':'ai','human':'human','ai':'ai','system':'note','tool':'note','note':'note'}.get(role,'note')
        blocks.append(block(normalized,content,'Imported '+role if role in ('system','tool') else None))
    return new_draft(title,blocks,{'kind':'imported transcript'})

def from_braid_thread(thread):
    if not isinstance(thread,dict) or not isinstance(thread.get('turns'),list):
        raise ValidationError('Braid returned an unexpected conversation format.')
    blocks=[]; omitted=0
    for turn in thread['turns']:
        if turn.get('state')!='done':omitted+=1;continue
        result=turn.get('payload',{}).get('result',{})
        if not isinstance(result.get('response'),str):omitted+=1;continue
        blocks += [block('human',text(turn.get('question',''))),block('ai',text(result['response']))]
    if not blocks:raise ValidationError('This conversation has no completed text exchanges to import.')
    d=new_draft(text(thread.get('title') or 'Braid conversation',300),blocks,{
        'kind':'Braid channel conversation','imported_at':now(), 'completed_turns':len(blocks)//2,
        'omitted_incomplete_turns':omitted,'view_limit':100})
    return d

def import_document(content, filename='import.txt'):
    raw=content.encode('utf-8') if isinstance(content,str) else content
    if len(raw)>MAX_BYTES:raise ValidationError('Import limit: 4 MiB.')
    if filename.lower().endswith('.json') or raw.lstrip()[:1] in (b'{',b'['):
        data=strict_json(raw)
        if isinstance(data,dict) and data.get('format')=='intersignal.folio.edition.v1':
            b=data.get('body')
            if not isinstance(b,dict) or digest(b)!=data.get('content_sha256'):
                raise ValidationError('Edition content hash does not match. Nothing was imported.')
            if not isinstance(b.get('passages'),list) or len(b['passages'])>MAX_BLOCKS:
                raise ValidationError('Invalid edition passages.')
            blocks=[block(p.get('role','note'),text(p.get('text','')),text(p.get('speaker',''),300)) for p in b['passages'] if isinstance(p,dict) and p.get('role') in ROLES]
            if len(blocks)!=len(b['passages']):raise ValidationError('Unsupported edition passage.')
            for dest, source in zip(blocks,b['passages']):dest['source_edited']=source.get('edited') is True
            if b.get('introduction'):blocks.insert(0,block('note',text(b['introduction']),'Original opening note'))
            if b.get('conclusion'):blocks.append(block('note',text(b['conclusion']),'Original closing note'))
            d=new_draft(text('Continuation: '+b.get('title',''),300),blocks,{'kind':'Imported public edition'})
            d['parent']={'title':text(b.get('title',''),300),'content_sha256':data['content_sha256']}
            d['introduction']='';d['sources']=text(b.get('sources',''))
            c=b.get('capsule')
            if c:
                if not isinstance(c,dict) or c.get('format')!='intersignal.folio.context.v1':raise ValidationError('Unsupported context format.')
                # Imported context is visible and opt-in for any NEW publication.
                notes='\n\n'.join(CAPSULE_LABELS[k]+':\n'+text(c.get(k,'')) for k in CAPSULE_FIELDS if c.get(k))
                if notes:d['blocks'].append(block('note',notes,'Imported context - inspect before use'))
            if len(d['blocks'])>MAX_BLOCKS:raise ValidationError('Too many passages after importing context.')
            return d
        if isinstance(data,dict) and data.get('format')=='intersignal.folio.capsule.v1':
            original=dict(data);check=original.pop('capsule_sha256',None)
            if digest(original)!=check:raise ValidationError('Capsule hash does not match. Nothing was imported.')
            c=data.get('context',{}); blocks=[]
            if not isinstance(c,dict) or c.get('format')!='intersignal.folio.context.v1':raise ValidationError('Unsupported context format.')
            for k in CAPSULE_FIELDS:
                if c.get(k):blocks.append(block('note',CAPSULE_LABELS[k]+':\n'+text(c[k]),'Imported context'))
            passages=c.get('passages',[])
            if not isinstance(passages,list) or len(passages)>MAX_BLOCKS:raise ValidationError('Invalid capsule passages.')
            for p in passages:
                if not isinstance(p,dict):raise ValidationError('Invalid capsule passage.')
                blocks.append(block('note',text(p.get('text','')),text(p.get('speaker','Imported context'),300)))
            if len(blocks)>MAX_BLOCKS:raise ValidationError('Too many imported passages.')
            d=new_draft(text('Continue: '+data.get('title',''),300),blocks,{'kind':'Imported context capsule'})
            d['parent']={'title':text(data.get('title',''),300),'content_sha256':text(data.get('parent_content_sha256',''),64)}
            d['sources']=text(data.get('sources',''));return d
        if isinstance(data,dict) and 'turns' in data:return from_braid_thread(data)
        messages=data if isinstance(data,list) else data.get('messages') if isinstance(data,dict) else None
        if messages is not None:return from_messages(messages)
        raise ValidationError('Unsupported JSON. Use a Folio edition/capsule, Braid conversation view, or {"messages": [{"role":"user","content":"..."}]}.')
    try: decoded=raw.decode('utf-8-sig')
    except UnicodeError as e:raise ValidationError('Use a UTF-8 text or JSON file.') from e
    if not decoded.strip():raise ValidationError('This file is empty.')
    return new_draft('Imported text',[block('note',text(decoded),'Source text')],{'kind':'Imported text'})
