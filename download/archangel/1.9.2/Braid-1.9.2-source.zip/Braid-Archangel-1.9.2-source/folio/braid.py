"""Braid adapter: bounded local views and explicit Folio registration.

Never imports Braid's Python code in production. No direct SQLite or signing-key
access, generic policy changes, message sends, field access, or port scanning.
"""
from __future__ import annotations
import json
import os
import platform
import threading
from pathlib import Path
from urllib import request, error
from urllib.parse import urlsplit
from .core import ValidationError, strict_json, text, MAX_BYTES, from_braid_thread, new_draft, block, validate_connection

class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValidationError('Braid redirected the request. Redirects are not permitted.')

def validate_base(value):
    try:
        u=urlsplit(value.strip())
        if (u.scheme!='http' or u.hostname!='127.0.0.1' or not u.port or not 1024<=u.port<=65535
            or u.username or u.password or u.path not in ('','/') or u.query or u.fragment):
            raise ValueError()
        return 'http://127.0.0.1:'+str(u.port)
    except (ValueError,AttributeError):
        raise ValidationError('Use the running Braid UI address: http://127.0.0.1:PORT (port 1024-65535). Only numeric loopback is accepted.')

def profile_candidates():
    home=Path.home()
    bases=[home/'Library'/'Application Support'/'Intersignal'/'Braid'] if platform.system()=='Darwin' else [home/'.braid']
    return [b/x for b in bases for x in ('messenger','messenger-a4')]

class BraidBridge:
    def __init__(self):
        self.base=None; self.csrf=None; self.version=None; self.channels=[]
        self.lock=threading.RLock()
        self.opener=request.build_opener(request.ProxyHandler({}),NoRedirect())

    def _read(self, base, route, data=None, csrf=None):
        allowed={('/api/messenger/channel','view'),('/api/messenger/chat','view')}
        if data is not None and (route,data.get('action')) not in allowed:
            raise ValidationError('This adapter permits only channel and conversation views.')
        if data is None and route!='/api/messenger/state':
            raise ValidationError('This adapter permits only the Braid state read.')
        headers={'Accept':'application/json','Origin':base}
        body=None
        if data is not None:
            body=json.dumps(data).encode();headers.update({'Content-Type':'application/json','X-Braid-CSRF':csrf or ''})
        req=request.Request(base+route,data=body,headers=headers)
        try:
            with self.opener.open(req,timeout=6) as response:
                if response.headers.get_content_type()!='application/json':raise ValidationError('This address did not return Braid JSON.')
                raw=response.read(MAX_BYTES+1)
            value=strict_json(raw)
            if not isinstance(value,dict):raise ValidationError('Unexpected Braid response.')
            if value.get('error'):raise ValidationError('Braid reported: '+text(str(value.get('message') or value['error']),1000))
            return value
        except (error.URLError,TimeoutError,OSError) as exc:
            raise ValidationError('Braid is not reachable at this address. Start Braid, then reconnect Folio. '+str(exc)[:180]) from exc

    def connect(self, address=''):
        # A failed explicit selection must not leave an older connection active.
        with self.lock:
            self.base=self.csrf=self.version=None;self.channels=[]
            candidates=[]
            if address:
                candidates=[(validate_base(address),None)]
            else:
                for profile in profile_candidates():
                    session=profile/'session.json'
                    if session.is_file():
                        try:
                            if session.stat().st_size>16384:continue
                            s=strict_json(session.read_bytes())
                            candidates.append((validate_base('http://127.0.0.1:'+str(s['port'])),profile))
                        except (OSError,KeyError,ValidationError):continue
            if not candidates:raise ValidationError('No running Braid session found in the standard profile. Start Braid, or enter its exact local UI address.')
            last=None
            for base,profile in candidates:
                try:
                    s=self._read(base,'/api/messenger/state')
                    if s.get('codename')!='Archangel' or not isinstance(s.get('csrf'),str) or not isinstance(s.get('channels'),list):
                        raise ValidationError('This is not a supported Braid Archangel session.')
                    if profile is not None and Path(s.get('inbox_path','')).resolve()!=(profile/'inbox').resolve():
                        raise ValidationError('The running Braid session belongs to a different profile.')
                    version=str(s.get('version',''))
                    if not version.startswith(('1.8.','1.9.')):raise ValidationError('Folio expects the Braid 1.8/1.9 Channel view API. Tested against 1.9.1.')
                    self.base=base;self.csrf=s['csrf'];self.version=version
                    # Neither the CSRF token nor the full state reaches the browser or disk.
                    channels=[{'id':str(c['id']),'name':text(c['descriptor'].get('name','Channel'),300),
                               'description':text(c['descriptor'].get('description',''),2000)} for c in s['channels']]
                    self.channels=channels
                    return {'connected':True,'version':version,'channels':channels,'address':base}
                except (ValidationError,KeyError,TypeError) as exc:last=exc
            raise ValidationError(str(last))

    def _folio_api(self, route, data=None):
        if (route, data is None) not in {
            ('/api/messenger/folio/identity', True),
            ('/api/messenger/folio/publication', False),
            ('/api/messenger/folio/readiness', False),
        }:
            raise ValidationError('Unsupported Braid Folio operation.')
        with self.lock:
            if not self.base:
                raise ValidationError('Connect Folio to Braid before enabling connection requests.')
            headers={'Accept':'application/json','Origin':self.base}
            body=None
            if data is not None:
                body=json.dumps(data,ensure_ascii=False).encode()
                headers.update({'Content-Type':'application/json','X-Braid-CSRF':self.csrf or ''})
            req=request.Request(self.base+route,data=body,headers=headers)
            try:
                with self.opener.open(req,timeout=8) as response:
                    if response.headers.get_content_type()!='application/json':
                        raise ValidationError('Braid did not return JSON for the Folio operation.')
                    raw=response.read(MAX_BYTES+1)
                value=strict_json(raw)
                if not isinstance(value,dict):raise ValidationError('Unexpected Braid Folio response.')
                if value.get('error'):raise ValidationError('Braid reported: '+text(str(value.get('message') or value['error']),1000))
                return value
            except (error.URLError,TimeoutError,OSError) as exc:
                raise ValidationError('Braid is unavailable for Folio connection requests. Start Braid and reconnect Folio. '+str(exc)[:180]) from exc

    def public_identity(self):
        value=self._folio_api('/api/messenger/folio/identity')
        source=text(value.get('source_network_id',''),64).strip().lower()
        if len(source)!=64 or any(c not in '0123456789abcdef' for c in source):
            raise ValidationError('Braid returned an invalid public network identity.')
        return {'source_network_id':source}

    def connection_check(self, rendezvous):
        checked=validate_connection({'enabled':True,'source_network_id':'a'*64,
            'rendezvous_url':rendezvous,'allowed_scopes':['publication_channel']},'a'*32)
        value=self._folio_api('/api/messenger/folio/readiness',{'rendezvous_url':checked['rendezvous_url']})
        return {'ready':value.get('ready') is True,'download_available':value.get('download_available') is True}

    def register_publication(self, connection, edition_id=None, enabled=True, deleted=False):
        checked=validate_connection(connection,connection.get('publication_id'))
        source=self.public_identity()['source_network_id']
        if source!=checked['source_network_id']:
            raise ValidationError('The connected Braid identity does not match this Folio publication. Connect the correct Braid network.')
        data={'publication_id':checked['publication_id'],
              'offered_scopes':checked['allowed_scopes'],
              'requests_enabled':bool(enabled),
              'deleted':bool(deleted),
              'rendezvous_url':checked['rendezvous_url']}
        if edition_id is not None:data['edition_id']=edition_id
        response=self._folio_api('/api/messenger/folio/publication',data)
        if response.get('source_network_id')!=source or not isinstance(response.get('publication'),dict):
            raise ValidationError('Braid did not confirm a signed Folio publication registration.')
        return {'registered':True,'source_network_id':source}

    def view(self, kind, ident):
        if kind not in ('channel','chat'):raise ValidationError('Unsupported Braid read.')
        ident=text(ident,128)
        with self.lock:
            if not self.base:raise ValidationError('Connect to Braid first.')
            return self._read(self.base,'/api/messenger/'+kind,{'action':'view','id' if kind=='channel' else 'thread':ident},self.csrf)

    def channel(self, ident):
        v=self.view('channel',ident)
        notes=[]
        for n in v.get('notes',[]):
            if isinstance(n.get('text'),str):notes.append({'id':n['id'],'kind':'note','title':n.get('title') or 'Local note', 'text':text(n['text']),'state':str(n.get('state',''))})
        for n in v.get('objects',[]):
            if n.get('indexed') and isinstance(n.get('text'),str):
                notes.append({'id':n['object_digest'],'kind':'object','title':'Indexed field material','text':text(n['text']),'state':'indexed'})
        return {'threads':[{'id':str(t['id']),'title':text(t.get('title','Conversation'),300)} for t in v.get('threads',[])],
                'notes':notes,'notice':'Braid returns at most 100 conversations, notes, and objects per view. Folio does not query the database for older material.'}

    def import_thread(self, ident):
        return from_braid_thread(self.view('chat',ident))

    def import_note(self, channel, ident, kind):
        items=self.channel(channel)['notes']
        n=next((x for x in items if x['id']==ident and x['kind']==kind),None)
        if n is None:raise ValidationError('This material is no longer in the Channel view. Reload and select again.')
        return new_draft(n['title'],[block('note',n['text'],'Selected Braid material')],{'kind':'Selected Braid Channel material'})
