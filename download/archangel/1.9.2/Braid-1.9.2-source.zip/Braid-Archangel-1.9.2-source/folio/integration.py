"""Archangel-owned Folio surface. No socket, profile discovery, or Braid keys.

The narrow port exposes bounded source views, public identity, readiness, and
public publication registration. Private Folio records never cross this port.
"""
from __future__ import annotations
import copy
import html
import json
import os
import secrets
import shutil
import sqlite3
import sys
import threading
from pathlib import Path
from urllib.parse import urlsplit

from .braid import BraidBridge
from .core import ValidationError, ConflictError, review_digest, strict_json, text
from .lifecycle import lock_profile
from .server import Handler, STATIC
from .store import Store, private_dir, private_write


def legacy_home(system=None, home=None, environ=None):
    system = system or sys.platform
    home = Path(home) if home is not None else Path.home()
    env = os.environ if environ is None else environ
    if system == 'darwin':
        return home/'Library'/'Application Support'/'Intersignal'/'Folio'
    if system == 'win32':
        return Path(env.get('LOCALAPPDATA', str(home/'AppData'/'Local')))/'Intersignal'/'Folio'
    return Path(env.get('XDG_DATA_HOME', str(home/'.local'/'share')))/'intersignal'/'folio'


def standard_braid_profile(home):
    base = (Path.home()/'Library'/'Application Support'/'Intersignal'/'Braid'
            if sys.platform == 'darwin' else Path.home()/'.braid')
    return Path(home).resolve() in {(base/n).resolve() for n in ('messenger', 'messenger-a4')}


def migrate_profile(destination, source):
    """Copy a consistent legacy snapshot once. Never modify or merge databases."""
    destination, source = Path(destination), Path(source)
    if destination.exists() or not (source/'folio.sqlite3').is_file():
        return False
    if source.is_symlink() or (source/'folio.sqlite3').is_symlink():
        raise ValidationError('Legacy Folio storage must be an ordinary local folder.')
    owned = lock_profile(source/'session.lock')
    if owned is None:
        raise ValidationError('Close the standalone Folio compatibility app before the first Archangel migration. Your library has not been changed.')
    staging = destination.with_name('.folio-migration-'+secrets.token_hex(8))
    try:
        private_dir(staging)
        private_dir(staging/'exports')
        original = sqlite3.connect((source/'folio.sqlite3').resolve().as_uri()+'?mode=ro', uri=True)
        snapshot = sqlite3.connect(staging/'folio.sqlite3')
        try:
            original.backup(snapshot)
            if snapshot.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise ValidationError('The legacy Folio database needs repair. The original was retained.')
        finally:
            snapshot.close()
            original.close()
        from .private_files import secure_path
        secure_path(staging/'folio.sqlite3')
        exports = source/'exports'
        if exports.exists():
            if exports.is_symlink():
                raise ValidationError('Legacy exports cannot be a linked directory.')
            for archive in exports.iterdir():
                if archive.is_symlink() or not archive.is_file():
                    raise ValidationError('Legacy exports must contain ordinary files.')
                private_write(staging/'exports'/archive.name, archive.read_bytes())
        private_write(staging/'migration.json', json.dumps({
            'schema':'folio.archangel-migration.v1', 'from_version':'0.3.0',
            'to_product':'Braid Archangel 1.9.2', 'source':str(source),
            'method':'SQLite backup and byte-preserved exports; original retained',
            'legacy_broadcast':'retained in storage; human review required in Archangel',
        }, indent=2).encode())
        os.rename(staging, destination)
        return True
    finally:
        owned.close()
        if staging.exists():
            shutil.rmtree(staging)


class InternalBraidPort(BraidBridge):
    """Allowlisted in-process adapter; generic writes/sends/keys are unavailable."""
    def __init__(self, service, origin):
        super().__init__()
        self.__service = service
        self.base = origin
        self.version = self._read(origin, '/api/messenger/state')['version']
        self.connect()

    def _bounded(self, value):
        return strict_json(json.dumps(value, ensure_ascii=False, allow_nan=False).encode())

    def _read(self, base, route, data=None, csrf=None):
        service = self.__service
        if service.closed:
            raise ValidationError('Braid Archangel is closing. Reopen Braid to continue.')
        if data is None and route == '/api/messenger/state':
            return self._bounded({'version':self.version if self.version else self.product_version(),
                'channels':service.channel_list()})
        if not isinstance(data, dict) or data.get('action') != 'view':
            raise ValidationError('Only bounded Braid source views are available to Folio.')
        if route == '/api/messenger/channel' and set(data) == {'action', 'id'}:
            value = service.channel_action('view', {'id':text(data['id'],128)})
        elif route == '/api/messenger/chat' and set(data) == {'action', 'thread'}:
            value = service.chat_action('view', {'thread':text(data['thread'],128)})
        else:
            raise ValidationError('Unsupported internal Braid operation.')
        return self._bounded(value)

    @staticmethod
    def product_version():
        from braid_client import __version__
        return __version__

    def connect(self, address=''):
        with self.lock:
            if address and address.rstrip('/') != self.base:
                raise ValidationError('Folio belongs to this running Braid instance. Open another Braid profile to use its studio.')
            value = self._read(self.base, '/api/messenger/state')
            self.channels = [{'id':str(c['id']), 'name':text(c['descriptor'].get('name','Channel'),300),
                'description':text(c['descriptor'].get('description',''),2000)} for c in value['channels']]
            return {'connected':True,'integrated':True,'version':self.version,'channels':self.channels,'address':self.base}

    def _folio_api(self, route, data=None):
        with self.lock:
            service = self.__service
            if service.closed:
                raise ValidationError('Braid Archangel is closing.')
            if route == '/api/messenger/folio/identity' and data is None:
                value = service.folio_identity()
            elif route == '/api/messenger/folio/readiness' and isinstance(data,dict) and set(data) == {'rendezvous_url'}:
                value = service.folio_readiness(copy.deepcopy(data))
            elif route == '/api/messenger/folio/publication' and isinstance(data,dict) and not set(data)-{
                    'publication_id','offered_scopes','requests_enabled','deleted','rendezvous_url','edition_id'}:
                value = service.folio_publication(copy.deepcopy(data))
            else:
                raise ValidationError('Unsupported internal Folio registration operation.')
            return self._bounded(value)


class IntegratedStore(Store):
    def __init__(self, home):
        super().__init__(home, require_human_review=True)
        # Legacy Broadcast approvals are indistinguishable from human approvals.
        # Keep the saved records intact, but require a review in this studio.
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS archangel_reviews (draft TEXT PRIMARY KEY, digest TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS archangel_review_history (draft TEXT NOT NULL, digest TEXT NOT NULL, PRIMARY KEY (draft,digest))')

    def _reviewed(self, draft):
        with self.db() as db:
            row = db.execute('SELECT digest FROM archangel_reviews WHERE draft=?', (draft['id'],)).fetchone()
        return bool(row and row[0] == review_digest(draft))

    def get(self, ident):
        value = super().get(ident)
        if not self._reviewed(value):
            value['approved_digest'] = None
        return value

    def list(self):
        items = super().list()
        for item in items:
            item['approved'] = self.get(item['id']).get('approved_digest') is not None
        return items

    def approve(self, ident, expected_digest, confirmed):
        with self.lock:
            value = super().approve(ident, expected_digest, confirmed)
            with self.db() as db:
                db.execute('INSERT OR REPLACE INTO archangel_reviews VALUES (?,?)', (ident, expected_digest))
                db.execute('INSERT OR IGNORE INTO archangel_review_history VALUES (?,?)', (ident, expected_digest))
            return value

    def export(self, ident, bridge=None):
        with self.lock:
            if not self._reviewed(super().get(ident)):
                raise ConflictError('Review and explicitly approve this edition in Folio before exporting.')
            return super().export(ident, bridge)

    def save_stream(self, incoming):
        if not isinstance(incoming,dict):
            raise ValidationError('Expected stream settings.')
        if incoming.get('mode') == 'broadcast':
            raise ValidationError('Braid Archangel requires explicit Folio review and approval for every edition. Use Review queue.')
        return super().save_stream(incoming)

    def _public_stream(self, value):
        result = super()._public_stream(value)
        if result.get('mode') == 'broadcast':
            result['legacy_mode'] = 'broadcast'
            result['mode'] = 'review'
            result['broadcast_ack'] = False
        result['requires_human_review'] = True
        return result

    def stream_site(self, ident):
        # Rebuilding a legacy site is a publication action too. Never copy a
        # Broadcast archive to a public folder without a review of that body.
        with self.lock, self.db() as db:
            for row in db.execute('SELECT data FROM stream_runs WHERE stream=?', (ident,)):
                run = json.loads(row['data'])
                if run.get('status') in ('released','delivery_failed') and run.get('edition_id'):
                    record, _ = self.download(run['edition_id'])
                    reviewed = db.execute('SELECT 1 FROM archangel_review_history WHERE draft=? AND digest=?',
                        (run.get('draft_id'),record['content_sha256'])).fetchone()
                    if not reviewed:
                        raise ConflictError('Review legacy stream editions in Folio before rebuilding their public site. Existing archives and site files have been retained.')
            return super().stream_site(ident)


class FolioSurface:
    """One Braid server owns this module's lifecycle and private capability."""
    def __init__(self, service, port):
        self.server_port = port
        self.origin = 'http://127.0.0.1:'+str(port)
        self.home = service.home/'folio'
        candidate = os.environ.get('BRAID_FOLIO_LEGACY_HOME')
        if candidate or standard_braid_profile(service.home):
            migrate_profile(self.home, Path(candidate) if candidate else legacy_home())
        private_dir(self.home)
        self.ownership = lock_profile(self.home/'session.lock')
        if self.ownership is None:
            raise ValidationError('This Folio library is already in use. Close its compatibility launcher before starting Braid.')
        try:
            self.store = IntegratedStore(self.home)
            self.bridge = InternalBraidPort(service, self.origin)
            self.token = secrets.token_urlsafe(32)
            self.stop = threading.Event()
            self.scheduler = threading.Thread(target=self._schedule, name='archangel-folio-review-queue', daemon=True)
            self.scheduler.start()
        except Exception:
            self.ownership.close()
            raise

    def _schedule(self):
        while not self.stop.wait(30):
            try:
                self.bridge.connect()
                for ident in self.store.due_stream_ids():
                    if self.stop.is_set():
                        break
                    try:
                        self.store.run_stream(ident, self.bridge)
                    except Exception:
                        self.store.record_cycle_error(ident)
            except Exception:
                pass

    def handoff(self, data):
        if self.stop.is_set():
            raise ValidationError('Braid Archangel is closing.')
        kind = data.get('kind')
        if kind == 'conversation':
            draft = self.bridge.import_thread(data.get('id',''))
        elif kind in ('note','object'):
            draft = self.bridge.import_note(data.get('channel',''), data.get('id',''), kind)
        else:
            raise ValidationError('Select a Braid conversation, note, or indexed object.')
        saved = self.store.insert(draft)
        return {'draft_id':saved['id'], 'url':'/folio?draft='+saved['id'], 'approved':False}

    def handle(self, request):
        # Reuse Folio's independent gates, limits, approval and export handlers.
        handler = Handler.__new__(Handler)
        handler.__dict__.update(request.__dict__)
        handler.server = self
        handler.path = request.path[len('/folio'):] or '/'
        if handler.path.startswith('?'):
            handler.path = '/'+handler.path
        path = urlsplit(handler.path).path
        if self.stop.is_set():
            return handler.response({'error':'Braid Archangel is closing.'},503)
        if request.command == 'GET' and path in ('/','/index.html'):
            if not handler.gate():
                return
            content = (STATIC/'integrated.html').read_text('utf-8')
            content = content.replace('<head>', '<head><meta name="folio-integrated" content="true"><meta name="folio-session" content="'+html.escape(self.token,quote=True)+'">')
            content = content.replace('href="/style.css"','href="/folio/style.css"').replace('src="/app.js"','src="/folio/app.js"')
            return handler.response(content.encode(),mime='text/html; charset=utf-8')
        if request.command == 'GET':
            return handler.do_GET()
        if path == '/api/quit':
            if not handler.gate(True):
                return
            return handler.response({'returned_to_braid':True})
        return handler.do_POST()

    def close(self):
        if getattr(self, '_closed', False):
            return
        self._closed = True
        self.stop.set()
        self.scheduler.join()  # Drains bounded local observations before releasing ownership.
        self.token = ''
        self.ownership.close()
