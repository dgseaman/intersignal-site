# Integrated Folio 0.3.0 in Braid Archangel 1.9.2

See TEST_RESULTS.md for current results. The predecessor integration report
is retained at docs/history/1.9.1-QA_FOLIO_0_3.md and describes that earlier
build and deployment only. No deployment was performed by this release.
