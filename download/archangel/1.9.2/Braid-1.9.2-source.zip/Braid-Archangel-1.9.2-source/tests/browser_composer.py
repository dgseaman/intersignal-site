"""Actual shipping HTML/JS; explicit API outcome fixtures, no real transfers."""
import copy, hashlib, json, shutil, sys, tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('baseline',type=Path,help='Extracted original a6 source root')
parser.add_argument('output',type=Path)
args=parser.parse_args()
SOURCE=Path(__file__).resolve().parents[1]
BASE=args.baseline.resolve()/'braid_client'/'static'
FIX=SOURCE/'braid_client'/'static'
OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(SOURCE))
from braid_client.messenger import MessengerService
from cryptography.hazmat.primitives.asymmetric import ed25519
with tempfile.TemporaryDirectory() as t:
 d=MessengerService(ed25519.Ed25519PrivateKey.generate(),Path(t)/'inbox',Path(t)/'home');template=d.snapshot();d.close()
A='a'*64;B='b'*64;OLD='old_delta_handoff_0123456789'
text='spend no more than 500 credits on our second server today'
delta=json.dumps({'schema':'braid.semantic-delta-material.v1','atoms':[{'text':text,'relation':'novel'}],'automatic_supersession':False},separators=(',',':'))
old={'handoff_id':OLD,'source':delta,'review':delta,'title':'Delta: '+text,'recipients':[A],'mode':'review','kind':'delta','object_digest':'e'*64,'method':'Exact signed delta material. Editing requires an ordinary summary instead.'}
received={'id':'in-existing','direction':'in','peer':A,'text':text,'title':text,'stage':'indexed','created':1788777360,'unread':False,'archived':False,'payload':{'kind':'context','object_digest':'e'*64,'phase_b_committed':True,'field_indexed':True}}
base=copy.deepcopy(template)
base.update(settings={**template['settings'],'name':'Composer regression fixture'},peers=[{'id':A,'name':'Linux fixture','capabilities':[],'presence':{'reachable':True,'checked':1788777360}}],messages=[received],draft=copy.deepcopy(old),deliveries=[],channels=[],jobs=[],field={'indexed_atom_count':1,'indexed_object_count':1})
state={};calls=[];checks=[];errors=[];accept_dialog=True;fail_draft=False;pending_job=None;send_outcomes={}
def reset(draft=old, deliveries=None, peers=None):
 global state,calls,send_outcomes,fail_draft,accept_dialog,pending_job
 state=copy.deepcopy(base);state['draft']=copy.deepcopy(draft);state['deliveries']=copy.deepcopy(deliveries or []);
 if peers:state['peers']=peers
 calls=[];send_outcomes={};fail_draft=False;accept_dialog=True;pending_job=None

def api(path,data):
 global state
 path=path.split('/api/messenger/')[-1];data=data or {};calls.append({'path':path,'data':copy.deepcopy(data)})
 if path=='state':
  result=copy.deepcopy(state)
  result['deliveries']=[d for d in state['deliveries'] if d['handoff']==(state['draft'] or {}).get('handoff_id')]
 elif path=='draft':
  if fail_draft:return {'__error':'Simulated draft write failure'}
  state['draft']=copy.deepcopy(data.get('draft'));result={'saved':True}
 elif path=='message':
  result={'ok':True}
 elif path=='send':
  peer=data['peer'];stage=send_outcomes.get(peer,['indexed']).pop(0)
  result={'stage':stage,'message_id':'out-'+str(sum(c['path']=='send' for c in calls))}
  state['deliveries']=[d for d in state['deliveries'] if not(d['handoff']==data['handoff_id'] and d['peer']==peer)]
  state['deliveries'].append({'handoff':data['handoff_id'],'peer':peer,'stage':stage,'result':result})
  if pending_job is not None:result={'job_id':'fixture-job'}
 elif path.startswith('job?'):
  result=pending_job or {'status':'done','kind':'send','result':{'stage':'indexed','message_id':'out-job'}}
 elif path=='summary':
  result={'summary':data['text'],'method':'local_ollama_completion'}
 else:result={}
 return json.loads(json.dumps(result))
def check(name,condition):
 if not condition:raise AssertionError(name)
 checks.append(name);print('PASS',name,flush=True)
def sends():return [c['data'] for c in calls if c['path']=='send']
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path=shutil.which('chromium'),args=['--no-sandbox'])
 page=None
 def load(root=FIX,width=1220,height=880):
  global page
  if page:page.close()
  page=browser.new_page(viewport={'width':width,'height':height})
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('dialog',lambda d:d.accept() if accept_dialog else d.dismiss())
  page.expose_function('composerAPI',api)
  html=(root/'messenger.html').read_text().replace('__BRAID_VERSION__','1.9.2' if root==FIX else '1.7.0a6')
  for name in [n for n in ['messenger','channels','wan'] if (root/(n+'.js')).exists()]:
   html=html.replace('<link rel="stylesheet" href="/static/'+name+'.css">','<style>'+(root/(name+'.css')).read_text()+'</style>')
   html=html.replace('<script src="/static/'+name+'.js"></script>','')
  page.set_content(html)
  page.evaluate('''() => {
   window.fetch=async(url,options={})=>{const r=await window.composerAPI(String(url),options.body?JSON.parse(options.body):null);return new Response(JSON.stringify(r.__error?{message:r.__error}:r),{status:r.__error?500:200,headers:{'Content-Type':'application/json'}});};
   if(!crypto.randomUUID)Object.defineProperty(crypto,'randomUUID',{value:()=>Array.from(crypto.getRandomValues(new Uint8Array(16))).map(x=>x.toString(16).padStart(2,'0')).join('')});
  }''')
  for name in [n for n in ['messenger','channels','wan'] if (root/(n+'.js')).exists()]:page.add_script_tag(content=(root/(name+'.js')).read_text())
  page.wait_for_function("document.querySelector('#localName').textContent==='Composer regression fixture'")
 def close():
  page.click('[aria-label="Close composer"]');page.wait_for_function("!document.querySelector('#composeDialog').open")
 def resume():
  page.click('[data-folder="drafts"]');page.click('[data-draft]');page.wait_for_function("document.querySelector('#composeDialog').open")
 def blank():
  return page.locator('#sourceText').input_value()=='' and page.locator('#reviewText').input_value()=='' and page.locator('#composeTitle').input_value()=='' and page.locator('#writeSection').is_visible() and page.locator('#sourceText').is_editable()
 reset();load(BASE);page.click('#composeButton')
 check('Baseline reproduced: Share summary resumes old signed delta',page.locator('#reviewText').input_value()==delta and page.locator('#reviewSection').is_visible())
 close();page.click('#composeButton')
 check('Baseline reproduced: close then reopen repeats old delta',page.locator('#reviewText').input_value()==delta and len(sends())==0)
 # Verify a source-supported temporary route without deleting any records.
 close();page.click('[data-folder="inbox"]');page.click('[data-message="in-existing"]');page.click('[data-read-action="share"]')
 check('Baseline workaround: Share onward opens editable ordinary source',page.locator('#writeSection').is_visible() and page.locator('#sourceText').input_value()==text and page.locator('#sourceText').is_editable() and len(sends())==0)
 (OUT/'baseline-reproduction.json').write_text(json.dumps({'observations':checks[:3],'note':'Close itself worked in this Chromium fixture. A distinct Safari-specific failure to dismiss was not reproduced.'},indent=2))
 reset();load();page.click('#composeButton')
 check('Main Share summary opens blank, editable Write step',blank())
 check('Opening blank preserves prior saved delta and sends nothing',state['draft']==old and not sends())
 close();check('Closing blank preserves prior saved draft',state['draft']==old)
 page.click('#composeButton');page.keyboard.press('Escape');page.wait_for_function("!document.querySelector('#composeDialog').open")
 check('Escape dismisses blank without deleting or sending',state['draft']==old and not sends())
 resume();check('Drafts explicitly resumes exact read-only delta',page.locator('#reviewText').input_value()==delta and page.locator('#reviewText').get_attribute('readonly') is not None)
 page.click('#newHandoff');page.wait_for_function("!document.querySelector('#writeSection').hidden")
 check('New message available before send and clears delta mode',blank() and state['draft']['handoff_id']==OLD and not sends())
 page.fill('#sourceText','A completely new project note.');page.fill('#composeTitle','Fresh ordinary message');page.click('#useExact');page.click('#sendButton')
 page.wait_for_function("!document.querySelector('#composeDialog').open")
 check('Fresh send uses new identity and no old delta linkage',len(sends())==1 and sends()[0]['kind']=='context' and sends()[0]['object_digest']=='' and sends()[0]['text']=='A completely new project note.' and sends()[0]['handoff_id']!=OLD)
 check('Success clears draft while original received note remains',state['draft'] is None and state['messages']==[received])
 page.click('#composeButton');check('Next compose stays empty after successful send',blank());close()
 # A second ordinary summary path must not inherit the prior reviewed data.
 page.click('#composeButton');page.fill('#sourceText','Summarize only this new text.');page.click('#summarizeButton');page.wait_for_function("!document.querySelector('#reviewSection').hidden && !document.querySelector('#saveDraft').disabled")
 check('Make summary receives only fresh source',page.locator('#reviewText').input_value()=='Summarize only this new text.')
 close();resume();check('Saved ordinary draft explicitly resumes',page.locator('#reviewText').input_value()=='Summarize only this new text.')
 close();page.keyboard.press('n');check('Keyboard N starts blank instead of resuming',blank());close()
 # Failed preparation: discard the draft, keep durable attempted history.
 failed=[{'handoff':OLD,'peer':A,'stage':'failed'}]
 reset(deliveries=failed);load();resume();page.click('#newHandoff');page.wait_for_function("!document.querySelector('#writeSection').hidden")
 check('Fresh composer does not clear old failed delivery record',blank() and state['deliveries']==failed and not sends());close();resume();page.click('#discardDraft');page.wait_for_function("!document.querySelector('#composeDialog').open")
 check('Discard removes draft only, retaining messages and delivery state',state['draft'] is None and state['deliveries']==failed and state['messages']==[received] and not sends())
 page.evaluate('window.BraidDesktop.refresh()');page.wait_for_timeout(100)
 check('No late close event resurrects discarded draft',state['draft'] is None)
 # Declining replacement does not destroy either the saved draft or entered text.
 reset();load();page.click('#composeButton');page.fill('#sourceText','New text not yet saved.');accept_dialog=False;page.click('#saveDraft');page.wait_for_timeout(120)
 check('Declined draft replacement retains old draft and current text',state['draft']==old and page.locator('#composeDialog').evaluate('(e)=>e.open') and page.locator('#sourceText').input_value()=='New text not yet saved.')
 page.click('#useExact');page.click('#sendButton');page.wait_for_function("!document.querySelector('#saveDraft').disabled")
 check('Declined replacement before send makes zero send requests',not sends() and state['draft']==old)
 accept_dialog=True;page.click('#discardDraft');page.wait_for_function("!document.querySelector('#composeDialog').open")
 check('Discarding unsaved new message preserves different saved draft',state['draft']==old and not sends())
 # Current draft remains available when saving fails.
 reset(draft=None);load();page.click('#composeButton');page.fill('#sourceText','Preserve me through a local error.');fail_draft=True;page.click('[aria-label="Close composer"]');page.wait_for_function("document.querySelector('#toast').textContent.includes('Simulated')")
 check('Failed save keeps text visible for recovery',page.locator('#composeDialog').evaluate('(e)=>e.open') and page.locator('#sourceText').input_value()=='Preserve me through a local error.')
 fail_draft=False;close();check('Save can recover after transient local error',state['draft']['source']=='Preserve me through a local error.')
 # Partial / unknown locks remain a resumed-draft concern, not a blank-composer state.
 two=[base['peers'][0],{**base['peers'][0],'id':B,'name':'Mac fixture'}]
 draft={**old,'kind':'context','object_digest':'','source':text,'review':text,'recipients':[A,B]}
 locked=[{'handoff':OLD,'peer':A,'stage':'indexed'},{'handoff':OLD,'peer':B,'stage':'outcome_unknown'}]
 reset(draft=draft,deliveries=locked,peers=two);load();resume()
 check('Explicitly resumed accepted and unknown recipients stay locked',page.locator('#recipientList input[value="'+A+'"]').is_disabled() and page.locator('#recipientList input[value="'+B+'"]').is_disabled() and page.locator('#sendButton').is_disabled())
 page.keyboard.press('Control+Enter');check('Disabled shortcut cannot resend unknown delivery',not sends())
 close();page.click('#composeButton');check('New blank composer does not inherit delivery locks',blank() and not page.locator('#recipientList input[value="'+A+'"]').is_disabled() and state['deliveries']==locked and not sends());close()
 # Retrying rejected peer only, via explicit Drafts resume.
 partial=[{'handoff':OLD,'peer':A,'stage':'indexed'},{'handoff':OLD,'peer':B,'stage':'rejected'}]
 reset(draft=draft,deliveries=partial,peers=two);load();resume();page.click('#sendButton');page.wait_for_function("!document.querySelector('#composeDialog').open")
 check('Retry still targets only explicit rejection on same handoff',len(sends())==1 and sends()[0]['peer']==B and sends()[0]['handoff_id']==OLD)
 # Close during a job, attempt new, then finish. No background result leaks into new form.
 reset(draft=None);load();page.click('#composeButton');page.fill('#sourceText','One in-flight note.');page.click('#useExact');pending_job={'kind':'send','status':'running'};page.click('#sendButton');page.wait_for_function("document.querySelector('#saveDraft').disabled")
 page.click('[aria-label="Close composer"]');page.wait_for_function("!document.querySelector('#composeDialog').open")
 page.click('#composeButton');check('New composer is blocked while prior send still running',not page.locator('#composeDialog').evaluate('(e)=>e.open') and len(sends())==1)
 pending_job=None;page.wait_for_function("!document.querySelector('#saveDraft').disabled")
 page.click('#composeButton');check('New composer is blank after prior in-flight send finishes',blank() and len(sends())==1)
 page.screenshot(path=str(OUT/'composer-fix-desktop.png'),full_page=True)
 for width in [320,390,768,1024,1280]:
  page.set_viewport_size({'width':width,'height':900});page.wait_for_timeout(50)
  good=page.evaluate("document.documentElement.scrollWidth<=innerWidth && document.querySelector('#composeDialog').scrollWidth<=document.querySelector('#composeDialog').clientWidth")
  check('Blank composer horizontal fit at '+str(width),good)
  if width==390:page.screenshot(path=str(OUT/'composer-fix-mobile.png'),full_page=True)
 check('No JavaScript page errors',not errors)
 result={'passed':True,'checks':checks,'check_count':len(checks),'javascript_errors':errors,'method':'Shipping HTML/CSS/JS executed in Chromium offline document. Explicit synthetic API outcomes and secure-context UUID shim; not a native Safari or physical multi-rig test.'}
 (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('TOTAL',len(checks),flush=True);browser.close()
