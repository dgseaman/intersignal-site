"""Real rc1 -> 1.9.2 installed launchers, disposable local profile.
Synthetic activated-but-paused WAN configuration. No production API or keys.
Usage: python tests/upgrade_rc1_smoke.py RC1_RELEASE NEW_RELEASE OUT
"""
from pathlib import Path
import sys,os,subprocess,tempfile,json,time,urllib.request,hashlib,sqlite3,platform
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization
old,new,out=map(lambda x:Path(x).resolve(),sys.argv[1:4]);out.mkdir(parents=True,exist_ok=True)
checks=[];env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
def check(name,condition):
 assert condition,name;checks.append(name);print('PASS',name,flush=True)
def command(root,profile,*args):
 return subprocess.run([sys.executable,str(root/'start_braid.py'),'--profile',str(profile),*args],env=env,cwd='/tmp',text=True,capture_output=True,timeout=120)
def start(root,profile,log):
 return subprocess.Popen([sys.executable,str(root/'start_braid.py'),'--profile',str(profile),'--no-browser','--offline','--use-existing-env'],env=env,cwd='/tmp',stdout=log,stderr=subprocess.STDOUT)
def get(url,data=None,csrf=''):
 req=urllib.request.Request(url,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json','X-Braid-CSRF':csrf})
 with urllib.request.urlopen(req,timeout=10) as r:return json.load(r)
def ready(process,profile):
 for _ in range(1200):
  if process.poll() is not None:raise AssertionError('launcher exited '+str(process.returncode))
  try:
   port=json.loads((profile/'session.json').read_text())['port'];url=f'http://127.0.0.1:{port}';return url,get(url+'/api/messenger/state')
  except (OSError,ValueError,KeyError):time.sleep(.1)
 raise AssertionError('not ready')
with tempfile.TemporaryDirectory(prefix='braid-rc1-upgrade-') as temp, (out/'run.txt').open('w') as log:
 profile=Path(temp)/'profile';process=start(old,profile,log)
 try:
  url,state=ready(process,profile);check('actual rc1 launcher',state['version']=='1.9.0rc1')
  request=get(url+'/api/messenger/wan',{'action':'request'},state['csrf'])
  check('rc1 WAN identity available',request['device']==state['fingerprint'])
  identity=(profile/'identity.pem').read_bytes();wan_key=(profile/'wan/encryption.key').read_bytes()
  draft={'handoff_id':'upgrade_rc1_draft_test','kind':'summary','mode':'write','title':'Preserved draft','source':'A deliberate note.','review':'','recipients':[]}
  get(url+'/api/messenger/draft',{'draft':draft},state['csrf'])
  channel=get(url+'/api/messenger/channel',{'action':'create','name':'Upgrade test'},state['csrf'])
  blocked=command(new,profile,'--no-browser','--offline')
  check('new launcher refuses old active instance',blocked.returncode!=0 and 'older window was not reopened' in blocked.stderr)
  check('no new runtime on refused launch',not list(profile.glob('runtime-1.9.2*')))
  check('rc1 keeps running after refusal',process.poll() is None)
  stopped=command(old,profile,'--stop');check('rc1 cooperative shutdown',stopped.returncode==0 and process.wait(timeout=30)==0)
  # Test-only synthetic persisted activation: never transmitted or made active.
  pub=ed25519.Ed25519PrivateKey.generate().public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw).hex()
  config={'member':'LOCAL-UPGRADE-FIXTURE','operator_key':pub,'relay_url':'https://relay.intersignal.org','ca_pem':''}
  prefs={'enabled':False,'receive_notes':True,'routes':{},'query_grants':{}}
  with sqlite3.connect(profile/'messenger.sqlite3') as db:
   db.execute('INSERT OR REPLACE INTO kv(key,value) VALUES (?,?)',('wan19_config',json.dumps(config)))
   db.execute('INSERT OR REPLACE INTO kv(key,value) VALUES (?,?)',('wan19_preferences',json.dumps(prefs)))
  process=start(new,profile,log);url,state=ready(process,profile)
  check('actual new installed version',state['version']=='1.9.2')
  check('existing signing identity unchanged',(profile/'identity.pem').read_bytes()==identity)
  check('existing WAN encryption identity unchanged',(profile/'wan/encryption.key').read_bytes()==wan_key)
  check('activated profile retained without reimport',state['wan']['configured'] and state['wan']['member']==config['member'])
  check('WAN preferences including receive choice retained',state['wan']['preferences']==prefs)
  check('saved draft retained',state['draft']==draft)
  check('Channel identity retained',state['channels'][0]['id']==channel['id'])
  check('separate new runtime installed',bool(list(profile.glob('runtime-1.9.2*'))))
  check('new scoped snapshot recorded',json.loads((profile/'archangel-upgrade.json').read_text())['version']=='1.9.2')
  with urllib.request.urlopen(url+'/static/wan.css',timeout=5) as r:css=r.read().decode()
  check('new scoped grid served from installed wheel','grid-template-rows: auto minmax(0, 1fr) auto' in css)
  with urllib.request.urlopen(url+'/static/messenger.js',timeout=5) as r:js=r.read().decode()
  check('receipt export and clock guidance installed','Save receipt JSON' in js and 'function clockGuidance' in js)
  stopped=command(new,profile,'--stop');check('new cooperative shutdown',stopped.returncode==0 and process.wait(timeout=30)==0)
 finally:
  if process.poll() is None:
   try:command(new,profile,'--stop');process.wait(timeout=25)
   except Exception:process.kill();process.wait()
(out/'upgrade.json').write_text(json.dumps({'passed':True,'count':len(checks),'checks':checks,'platform':platform.platform(),'python':platform.python_version(),'method':'Real installed rc1 and 1.9.2 launchers on a disposable profile on the recorded host; explicit host dependencies, synthetic paused activation; no production enrollment or frozen native binary.'},indent=2)+'\n')
