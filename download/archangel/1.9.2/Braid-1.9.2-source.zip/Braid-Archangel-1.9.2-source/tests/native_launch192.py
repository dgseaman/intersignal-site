"""Actual frozen application HTTP/lifecycle and optional Chromium UI on a disposable profile."""
from pathlib import Path
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
import urllib.request
import urllib.error
import io
import zipfile
import re

from playwright.sync_api import sync_playwright

binary=Path(sys.argv[1]).resolve()
output=Path(sys.argv[2]).resolve();output.mkdir(parents=True,exist_ok=True)
checks=[]
errors=[]
def check(name,value):
    assert value,name
    checks.append(name);print('PASS '+name,flush=True)

opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def request(base,path,data=None,headers=None):
    fields=headers or {}
    raw=None
    if data is not None:
        raw=json.dumps(data).encode();fields={**fields,'Content-Type':'application/json'}
    with opener.open(urllib.request.Request(base+path,data=raw,headers=fields),timeout=8) as response:
        body=response.read()
        return json.loads(body) if response.headers.get_content_type()=='application/json' else body

def ready(profile,process):
    for _ in range(120):
        if process.poll() is not None:raise RuntimeError('Native Braid exited with '+str(process.returncode))
        try:
            session=json.loads((profile/'session.json').read_text())
            base='http://127.0.0.1:'+str(session['port'])
            state=request(base,'/api/messenger/state')
            return base,state
        except (OSError,ValueError):time.sleep(.1)
    raise RuntimeError('Native startup timeout')

def rejected(base,path,data,headers,expected):
    try:request(base,path,data,headers)
    except urllib.error.HTTPError as error:
        return error.code==expected
    return False

with tempfile.TemporaryDirectory(prefix='Braid native 192 spaces ') as temporary:
    profile=Path(temporary)/'Braid profile'
    env=dict(os.environ);env.pop('BRAID_FOLIO_LEGACY_HOME',None)
    # The frozen binary must operate without a Python discovery path.
    env['PATH']='/usr/bin:/bin'
    log=(output/'native-process.log').open('w')
    process=subprocess.Popen([str(binary),'--profile',str(profile),'--no-browser'],env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        base,state=ready(profile,process)
        csrf={'X-Braid-CSRF':state['csrf']}
        html=request(base,'/folio').decode()
        token=re.search(r'name="folio-session" content="([^"]+)"',html).group(1)
        check('one native launch starts Braid and /folio',state['version']=='1.9.2' and 'Braid Archangel 1.9.2' in html)
        check('no separate Python runtime installation',not list(profile.glob('runtime-*')))
        check('distinct studio capability',token!=state['csrf'])
        import sqlite3
        with sqlite3.connect(profile/'folio/folio.sqlite3') as db:
            check('frozen module includes review-history protection',db.execute("SELECT name FROM sqlite_master WHERE name='archangel_review_history'").fetchone() is not None)
        other=subprocess.run([str(binary),'--profile',str(profile),'--no-browser'],env=env,capture_output=True,text=True,timeout=12)
        check('duplicate native launch reuses running application',other.returncode==0 and json.loads((profile/'session.json').read_text())['pid']==process.pid)
        channel=request(base,'/api/messenger/channel',{'action':'create','name':'Publishing fixture'},csrf)
        note=request(base,'/api/messenger/channel',{'action':'note','channel':channel['id'],'title':'A private idea','text':'A useful idea to review before sharing.'},csrf)
        folio_headers={'X-Folio-Token':token}
        sentinel='NATIVE_PRIVATE_SENTINEL_192'
        private=request(base,'/folio/api/new',{'text':sentinel},folio_headers)
        private['title']='Native approval fixture'
        private['blocks'][0]['text']='A deliberately public sentence.'
        saved=request(base,'/folio/api/save',{'id':private['id'],'draft':private},folio_headers)
        preview=request(base,'/folio/api/preview',{'id':private['id']},folio_headers)
        check('frozen preview excludes private originals',sentinel not in json.dumps(preview))
        check('frozen export refuses unapproved editions',rejected(base,'/folio/api/export',{'id':private['id']},folio_headers,409))
        check('frozen approval requires confirmation',rejected(base,'/folio/api/approve',{'id':private['id'],'digest':preview['digest'],'confirmed':False},folio_headers,400))
        request(base,'/folio/api/approve',{'id':private['id'],'digest':preview['digest'],'confirmed':True},folio_headers)
        edition=request(base,'/folio/api/export',{'id':private['id']},folio_headers)
        archive=request(base,'/folio/api/download?id='+edition['id'],headers=folio_headers)
        with zipfile.ZipFile(io.BytesIO(archive)) as zip:
            check('frozen export excludes privacy sentinel',all(sentinel.encode() not in zip.read(name) for name in zip.namelist()))
        changed=request(base,'/folio/api/draft?id='+private['id'],headers=folio_headers)
        changed['title']='A changed edition'
        changed=request(base,'/folio/api/save',{'id':private['id'],'draft':changed},folio_headers)
        check('frozen public edit invalidates approval',changed['approved_digest'] is None and rejected(base,'/folio/api/export',{'id':private['id']},folio_headers,409))
        check('private Folio sentinel does not enter Braid state',sentinel not in json.dumps(request(base,'/api/messenger/state')))
        if '--http-only' in sys.argv:
            result=request(base,'/api/messenger/folio/draft',{'kind':'note','id':note['id'],'channel':channel['id']},csrf)
            draft_id=result['draft_id']
            draft=request(base,'/folio/api/draft?id='+draft_id,headers={'X-Folio-Token':token})
            check('native direct handoff creates an unapproved draft',draft['title']=='A private idea' and draft['approved_digest'] is None)
        else:
            with sync_playwright() as playwright:
                browser=playwright.chromium.launch(headless=True)
                page=browser.new_page(viewport={'width':1280,'height':900})
                page.on('pageerror',lambda error:errors.append(str(error)))
                page.goto(base+'/');page.wait_for_function('window.BraidDesktop.getState()!==null')
                check('sidebar identifies one product',page.title()=='Braid Archangel 1.9.2')
                page.screenshot(path=str(output/'01-braid-sidebar.png'),full_page=True)
                page.click('#folioStudio');page.wait_for_selector('#shelf-empty')
                check('sidebar opens integrated studio',page.url==base+'/folio' and page.locator('#braid-connect').is_hidden())
                page.screenshot(path=str(output/'02-folio-studio.png'),full_page=True)
                page.click('#quit');page.wait_for_function('window.BraidDesktop?.getState()!==null')
                page.click('[data-channel="'+channel['id']+'"]')
                page.click('[data-channel-tab="notes"]')
                page.click('[data-folio-note="'+note['id']+'"]')
                page.wait_for_selector('#f-title');draft_id=page.url.split('draft=')[1]
                check('Publish with Folio opens its private draft',page.locator('#f-title').input_value()=='A private idea')
                page.screenshot(path=str(output/'03-private-draft.png'),full_page=True)
                page.click('[data-view="review"]')
                page.wait_for_selector('#approve')
                check('draft has explicit review step',page.locator('#approve').is_visible())
                page.screenshot(path=str(output/'04-review.png'),full_page=True)
                for width in (1280,800,390):
                    page.set_viewport_size({'width':width,'height':900});page.goto(base+'/folio')
                    page.wait_for_selector('#shelf')
                    check('studio layout fits '+str(width)+'px',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
                    page.screenshot(path=str(output/('studio-'+str(width)+'.png')),full_page=True)
                check('no browser JavaScript errors',not errors)
                browser.close()
        request(base,'/api/messenger/shutdown',{},csrf)
        process.wait(15)
        check('shutdown closes Braid and Folio',process.returncode==0 and not (profile/'session.json').exists())
        process=subprocess.Popen([str(binary),'--profile',str(profile),'--no-browser'],env=env,stdout=log,stderr=subprocess.STDOUT)
        base,state=ready(profile,process)
        html=request(base,'/folio').decode();new_token=re.search(r'name="folio-session" content="([^"]+)"',html).group(1)
        saved=request(base,'/folio/api/draft?id='+draft_id,headers={'X-Folio-Token':new_token})
        check('restart retains Folio draft',saved['title']=='A private idea' and saved['approved_digest'] is None)
        check('restart rotates studio token',new_token!=token)
        stop=subprocess.run([str(binary),'--stop','--profile',str(profile)],env=env,capture_output=True,text=True,timeout=10)
        process.wait(15)
        check('native stop command drains both surfaces',stop.returncode==0 and process.returncode==0)
    finally:
        if process.poll() is None:process.terminate();process.wait(15)
        log.close()

(output/'native-results.json').write_text(json.dumps({'passed':True,'count':len(checks),'checks':checks,
    'platform':platform.platform(),'architecture':platform.machine(),'binary':str(binary),
    'method':__doc__,'javascript_errors':errors,'browser_checks_run':'--http-only' not in sys.argv},indent=2)+'\n')
