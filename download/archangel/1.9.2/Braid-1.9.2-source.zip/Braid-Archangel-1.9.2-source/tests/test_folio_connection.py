"""Two independent Braid profiles, one public request queue, scoped normal-channel delivery."""
import copy
import json
import socket
import threading
import uuid
import urllib.request
import urllib.error

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519

import braid_client.messenger as core
from braid_client.folio_rendezvous import RendezvousServer, RendezvousStore, ReferralError
from braid_client.messenger import MessengerService
from braid_client.messenger_http import MessengerHTTPServer, MessengerHandler
from braid_client.semantic_capsule import SemanticCapsuleHandoffConfig
from braid_client.semantic_transfer import build_frame_from_text
from tests.test_v1_5_2_semantic_capsule import FakeOllama, SOURCE
from tests.test_v1_7_0a4_messenger import route, free_port


@pytest.fixture
def folio_pair(tmp_path, monkeypatch, route):
    monkeypatch.setenv('BRAID_FOLIO_TEST_LOOPBACK', '1')
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        port = probe.getsockname()[1]
    base = f'http://127.0.0.1:{port}'
    store = RendezvousStore(tmp_path/'rendezvous', base_url=base,
        download_url='https://intersignal.org/braid', allow_loopback_http=True)
    server = RendezvousServer(('127.0.0.1', port), store)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    fake = FakeOllama()
    monkeypatch.setattr(core, 'SemanticCapsuleHandoffConfig',
        lambda **kw: SemanticCapsuleHandoffConfig(base_url=fake.url, timeout_seconds=5, **kw))
    monkeypatch.setattr(core, 'build_frame_from_text',
        lambda path, text, key, **kw: build_frame_from_text(path, text, key, ollama_url=fake.url, **kw))
    peers = []
    for label in ('publisher', 'reader'):
        service = MessengerService(ed25519.Ed25519PrivateKey.generate(),
            tmp_path/label/'inbox', tmp_path/label/'desk')
        service.save_settings({'name':label, 'host':'127.0.0.1', 'port':free_port(),
            'embed_model':SOURCE, 'route_path':str(route)})
        peers.append(service)
    try:
        yield (*peers, store, base)
    finally:
        for service in peers:
            service.close()
        fake.close()
        server.shutdown(); server.server_close(); worker.join(2)


def test_publication_request_approval_and_scoped_note(folio_pair):
    publisher, reader, store, base = folio_pair
    publication_id = uuid.uuid4().hex
    registration = publisher.folio_publication({'publication_id':publication_id,
        'offered_scopes':['messages','publication_channel'], 'requests_enabled':True,
        'rendezvous_url':base})
    referral = store.referral(publication_id)
    assert referral['publication'] == registration['publication']
    assert 'name' not in str(referral).lower()
    assert 'host' not in str(referral).lower()
    reader.folio_import_referral(referral)
    request = reader.folio_send_request({'publication_id':publication_id,
        'requested_scope':['messages','publication_channel'],
        'message':'I would like to compare notes.', 'publication_url':''})
    unsigned_request = copy.deepcopy(reader.folio_requests('out')[0]['request'])
    unsigned_request.pop('signature')
    with pytest.raises(ReferralError):
        store.create_request(unsigned_request)
    assert reader.folio_send_request({'publication_id':publication_id,
        'requested_scope':['messages'], 'message':'second', 'publication_url':''})['duplicate']
    incoming = publisher.folio_refresh_inbox()
    assert len(incoming) == 1
    assert incoming[0]['request']['publication_id'] == publication_id
    assert 'card' not in incoming[0]['request']
    with pytest.raises(ValueError, match='Confirm'):
        publisher.folio_decide({'request_id':request['request_id'], 'decision':'accepted',
            'granted_scope':['messages'], 'confirmed':False})
    accepted = publisher.folio_decide({'request_id':request['request_id'],
        'decision':'accepted', 'granted_scope':['messages','publication_channel'],
        'confirmed':True})
    checked = reader.folio_check_request(request['request_id'])
    assert checked['channel_id'] == accepted['channel_id']
    assert reader.channel_list()[0]['id'] == accepted['channel_id']
    assert reader.channel(accepted['channel_id'])['policy']['receive_from'] == []

    # A relationship does not disclose either local route or rig name until a
    # second explicit card-sharing decision on each machine.
    assert publisher.folio_inspect_peer_card(request['request_id'])['available'] is False
    with pytest.raises(ValueError, match='Confirm sharing'):
        reader.folio_share_card(request['request_id'])
    publisher.folio_share_card(request['request_id'], confirmed=True)
    reader.folio_share_card(request['request_id'], confirmed=True)
    for owner, other in ((publisher, reader), (reader, publisher)):
        inspection = owner.folio_inspect_peer_card(request['request_id'])['inspection']
        assert inspection['id'] == other.fingerprint
        with pytest.raises(ValueError, match='BINDING'):
            owner.folio_approve_peer_card(request['request_id'], inspection['inspection_id'],
                '0'*64, True)
        owner.folio_approve_peer_card(request['request_id'], inspection['inspection_id'],
            other.fingerprint, True)
        contact = next(c for c in owner.contacts() if c['id'] == other.fingerprint)
        assert contact['folio_only'] is True
    channel = publisher.channel(accepted['channel_id'])
    assert channel['policy']['send_to'] == [reader.fingerprint]
    assert channel['policy']['receive_from'] == [reader.fingerprint]
    assert reader.channel(accepted['channel_id'])['policy']['send_to'] == [publisher.fingerprint]
    assert reader.channel(accepted['channel_id'])['policy']['receive_from'] == [publisher.fingerprint]
    assert not channel['policy']['use_in_chat']
    with pytest.raises(ValueError, match='ERR_FOLIO_PUBLICATION_SCOPE_REQUIRED'):
        publisher.send(reader.fingerprint, 'private unrelated summary', handoff_id=uuid.uuid4().hex)
    _, unscoped, _, _ = core.build_frame_from_text(reader.settings['route_path'],
        'An unrelated handoff must not enter the publisher field.', reader.key)
    rejected = publisher.receive(unscoped, source_transport='file')
    assert rejected['reason'] == 'ERR_FOLIO_PUBLICATION_SCOPE_REQUIRED'
    assert publisher.messages() == []
    reader.start_listener()
    note = publisher.new_note(channel['id'], 'A deliberately shared Folio note.')
    result = publisher.publish_note(note['id'], confirmed=True)
    assert result['state'] == 'shared'
    assert reader.channel_view(channel['id'])['objects'][0]['indexed']
    counts = store.analytics(publisher._folio_auth())['events']
    assert sum(row['count'] for row in counts if row['event'] == 'first_message_exchanged') == 1
    second = publisher.new_note(channel['id'], 'A second deliberately shared note.')
    assert publisher.publish_note(second['id'], confirmed=True)['state'] == 'shared'
    counts = store.analytics(publisher._folio_auth())['events']
    assert sum(row['count'] for row in counts if row['event'] == 'first_message_exchanged') == 1


def test_disabled_publication_and_unsigned_request_are_rejected(folio_pair):
    publisher, reader, store, base = folio_pair
    publication_id = uuid.uuid4().hex
    publisher.folio_publication({'publication_id':publication_id,
        'offered_scopes':['publication_channel'], 'requests_enabled':True,
        'rendezvous_url':base})
    referral = store.referral(publication_id)
    reader.folio_import_referral(referral)
    publisher.folio_publication({'publication_id':publication_id,
        'offered_scopes':['publication_channel'], 'requests_enabled':False,
        'rendezvous_url':base})
    with pytest.raises(ReferralError, match='ERR_FOLIO_PUBLICATION_DISABLED'):
        store.referral(publication_id)
    with pytest.raises(urllib.error.HTTPError) as closed:
        urllib.request.urlopen(base + '/continue?publication_id=' + publication_id +
            '&source_network_id=' + publisher.fingerprint)
    assert b'closed connection requests' in closed.value.read()
    publisher.folio_publication({'publication_id': publication_id,
        'offered_scopes': ['publication_channel'], 'requests_enabled': False,
        'deleted': True, 'rendezvous_url': base})
    with pytest.raises(ReferralError, match='ERR_FOLIO_PUBLICATION_DELETED'):
        store.referral(publication_id)
    with pytest.raises(ValueError, match='ERR_FOLIO_REQUESTS_DISABLED'):
        reader.folio_send_request({'publication_id':publication_id,
            'requested_scope':['publication_channel'], 'message':'', 'publication_url':''})
    forged = copy.deepcopy(referral['publication'])
    forged.pop('signature')
    with pytest.raises(ReferralError):
        store.register(forged)


def test_multiple_publications_and_expired_request_retry(folio_pair):
    publisher, reader, store, base = folio_pair
    publication_ids = [uuid.uuid4().hex for _ in range(2)]
    for ident in publication_ids:
        publisher.folio_publication({'publication_id': ident,
            'offered_scopes': ['publication_channel'], 'requests_enabled': True,
            'rendezvous_url': base})
        reader.folio_import_referral(store.referral(ident))
    first = reader.folio_send_request({'publication_id': publication_ids[0],
        'requested_scope': ['publication_channel'], 'message': '', 'publication_url': ''})
    reader.folio_send_request({'publication_id': publication_ids[1],
        'requested_scope': ['publication_channel'], 'message': '', 'publication_url': ''})
    assert {r['publication_id'] for r in publisher.folio_refresh_inbox()} == set(publication_ids)
    with store.db() as db:
        db.execute('UPDATE requests SET expires=1 WHERE id=?', (first['request_id'],))
    assert reader.folio_check_request(first['request_id'])['status'] == 'expired'
    retry = reader.folio_send_request({'publication_id': publication_ids[0],
        'requested_scope': ['publication_channel'], 'message': 'Trying again', 'publication_url': ''})
    assert retry['request_id'] != first['request_id']
    assert {r['id'] for r in publisher.folio_refresh_inbox()} >= {retry['request_id']}


def test_local_braid_http_exposes_folio_controls(folio_pair):
    publisher, _reader, _store, base = folio_pair
    server = MessengerHTTPServer(('127.0.0.1', 0), MessengerHandler)
    server.messenger = publisher
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    origin = f'http://127.0.0.1:{server.server_port}'
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(origin + '/') as response:
            assert b'Folio connections' in response.read()
        with opener.open(origin + '/static/folio.js') as response:
            assert b'Send connection request' in response.read()
        with opener.open(origin + '/api/messenger/folio/state') as response:
            assert json.load(response)['identity']['source_network_id'] == publisher.fingerprint
        body = json.dumps({'publication_id': uuid.uuid4().hex,
            'offered_scopes': ['publication_channel'], 'requests_enabled': True,
            'rendezvous_url': base}).encode()
        request = urllib.request.Request(origin + '/api/messenger/folio/publication', body,
            headers={'Content-Type': 'application/json', 'X-Braid-CSRF': publisher.csrf,
                     'Origin': origin}, method='POST')
        with opener.open(request) as response:
            assert json.load(response)['source_network_id'] == publisher.fingerprint
    finally:
        server.shutdown(); server.server_close(); worker.join(2)


def test_server_duplicate_without_local_history_is_explicit(folio_pair):
    publisher, reader, store, base = folio_pair
    publication_id = uuid.uuid4().hex
    publisher.folio_publication({'publication_id': publication_id,
        'offered_scopes': ['publication_channel'], 'requests_enabled': True,
        'rendezvous_url': base})
    reader.folio_import_referral(store.referral(publication_id))
    reader.folio_send_request({'publication_id': publication_id,
        'requested_scope': ['publication_channel'], 'message': '', 'publication_url': ''})
    with reader._db() as db:
        db.execute("DELETE FROM fc_requests WHERE direction='out'")
    with pytest.raises(ValueError, match='already has a pending request'):
        reader.folio_send_request({'publication_id': publication_id,
            'requested_scope': ['publication_channel'], 'message': '', 'publication_url': ''})
    assert reader.folio_requests('out') == []


def test_link_import_and_readiness(folio_pair):
    publisher,reader,store,base=folio_pair
    ident=uuid.uuid4().hex;edition=uuid.uuid4().hex
    publisher.folio_publication({'publication_id':ident,'offered_scopes':['publication_channel','messages'],'requests_enabled':True,'rendezvous_url':base})
    assert reader.folio_readiness({'rendezvous_url':base})=={'ready':True,'download_available':True}
    link=base+'/continue?publication_id='+ident+'&source_network_id='+publisher.fingerprint+'&edition_id='+edition
    imported=reader.folio_import_link({'url':link})
    assert imported['publication_id']==ident and imported['source_network_id']==publisher.fingerprint and imported['edition_id']==edition
    assert reader.folio_requests()==[] and reader.contacts()==[]
    with pytest.raises(ValueError,match='does not match'):
        reader.folio_import_link({'url':link.replace(publisher.fingerprint,'f'*64)})


def test_link_import_rejects_arbitrary_targets_before_io(folio_pair,monkeypatch):
    publisher,reader,store,base=folio_pair
    def forbidden(*args,**kwargs):raise AssertionError('URL validation must run before network I/O')
    monkeypatch.setattr('braid_client.folio_connection.urllib.request.build_opener',forbidden)
    query='?publication_id='+'a'*32+'&source_network_id='+'b'*64
    targets=['https://evil.test/continue'+query,'https://connect.intersignal.org.evil.test/continue'+query,
        'https://user:password@connect.intersignal.org/continue'+query,base+'/api/messenger/state'+query,
        base+'/continue'+query+'&publication_id='+'c'*32,base+'/continue'+query+'&extra=1',
        base+'/continue'+query+'#local',base+'/continue?publication_id=bad&source_network_id='+'b'*64]
    for link in targets:
        with pytest.raises(ValueError):reader.folio_import_link({'url':link})


def test_link_import_refuses_redirect(folio_pair,monkeypatch):
    publisher,reader,store,base=folio_pair
    import braid_client.folio_connection as fc
    handler=fc._NoRedirect()
    with pytest.raises(ValueError,match='REDIRECT'):
        handler.redirect_request(None,None,302,'Moved',{},'https://evil.test/secret')


def test_card_progress_is_recorded_only_after_confirmation(folio_pair):
    publisher,reader,store,base=folio_pair
    ident=uuid.uuid4().hex
    publisher.folio_publication({'publication_id':ident,'offered_scopes':['messages'],'requests_enabled':True,'rendezvous_url':base})
    reader.folio_import_link({'url':base+'/continue?publication_id='+ident+'&source_network_id='+publisher.fingerprint})
    request=reader.folio_send_request({'publication_id':ident,'requested_scope':['messages']})
    publisher.folio_refresh_inbox();publisher.folio_decide({'request_id':request['request_id'],'decision':'accepted','granted_scope':['messages'],'confirmed':True});reader.folio_check_request(request['request_id'])
    assert reader.folio_requests()[0]['card_shared'] is False
    with pytest.raises(ValueError,match='Confirm sharing'):reader.folio_share_card(request['request_id'])
    assert reader.folio_requests()[0]['card_shared'] is False
    reader.folio_share_card(request['request_id'],confirmed=True)
    assert reader.folio_requests()[0]['card_shared'] is True
