"""Production UI with explicit synthetic API fixtures (not a physical WAN run)."""
import copy,json,os,shutil,sys,tempfile,time
from pathlib import Path
from playwright.sync_api import sync_playwright
sys.path.insert(0,str(Path(__file__).parents[1]))
from cryptography.hazmat.primitives.asymmetric import ed25519
from braid_client.messenger import MessengerService
from braid_client.channel_protocol import create_channel_descriptor
ROOT=Path(__file__).parents[1];STATIC=ROOT/'braid_client/static';OUT=Path(sys.argv[1]);OUT.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as temp:
 d=MessengerService(ed25519.Ed25519PrivateKey.generate(),Path(temp)/'inbox',Path(temp)/'home');state=d.snapshot();d.close()
key=ed25519.Ed25519PrivateKey.generate();ch=create_channel_descriptor(key,'Cobalt','Project notes')
PEER='a'*64;CHANNEL=ch['id'];calls=[];checks=[];errors=[]
state['settings']['name']='Traveler - UI fixture'
state['peers']=[dict(id=PEER,name='Home rig - UI fixture',wan={'protocol':'managed-wan.v1','encryption_key':'b'*64},capabilities=['managed-wan.v1','channels.v1'],presence=None)]
state['channels']=[dict(id=CHANNEL,descriptor=ch,revision=1,note_count=0,policy=dict(send_to=[PEER],receive_from=[PEER],use_in_chat=True,mode='manual',keywords=[],paused=False,archived=False,hourly_limit=6))]
state['messages']=[dict(id='out-fixture',direction='out',peer=PEER,title='WAN receipt fixture',text='Project Cobalt has a 500-credit limit.',stage='queued',created=time.time(),unread=False,archived=False,payload=dict(transport='managed_wan',wan_request_id='c'*32,relay_stored=True,receiver_confirmed=False,wan_pending=True,kind='summary'))]
results={}
def bridge(path,data):
 global state
 name=path.split('/api/messenger/')[-1];data=data or {};calls.append((name,copy.deepcopy(data)))
 if name=='state':return copy.deepcopy(state)
 if name=='wan':
  a=data.get('action')
  if a=='settings':
   if data['preferences']['enabled'] and not state['wan']['configured']:return {'__error':'Activate membership first.'}
   state['wan']['preferences'].update(data['preferences']);return copy.deepcopy(state['wan'])
  if a=='inspect-activation':return dict(member='UI-DEMO',operator_fingerprint='d'*64,relay_url='https://relay.intersignal.org',device=state['fingerprint'])
  if a=='activate':
   if data['operator_fingerprint']!='d'*64 or not data['confirmed']:return {'__error':'Compare the operator fingerprint.'}
   state['wan'].update(configured=True,member='UI-DEMO',status=dict(devices=2,device_limit=2,expires=time.time()+86400,month_bytes=10,month_limit=1024**3),connected=True);return {'activated':True}
  if a=='peers':return {'peers':[dict(device=PEER,name='Home rig - UI fixture',online=True,last_seen=time.time(),card_available=True)]}
  if a=='ask':return {'wan_request_id':'e'*32,'receiver_confirmed':False,'relay_stored':True,'wan_pending':True}
  if a in ('result','check-query'):return dict(id='e'*32,state='answered',result={'response':'The shared note states 500 credits for the second server.','answered_on':'Home rig - UI fixture','shared_note_count':1,'supplied_notes':[{'text':'Spend no more than 500 credits on the second server.'}],'generation_source':'fixture'})
  if a=='check':
   state['messages'][0]['stage']='indexed';state['messages'][0]['payload'].update(phase_b_committed=True,field_indexed=True,wan_pending=False);return {'state':'indexed'}
  if a=='requests':return {'requests':[dict(id='e'*32,peer=PEER,state='answered',expires=time.time()+300,created=time.time())]}
  if a=='clear':state['wan']['configured']=False;state['wan']['preferences'].update(enabled=False,receive_notes=False,routes={},query_grants={});return state['wan']
  return {}
 if name=='draft':state['draft']=data.get('draft');return {'saved':True}
 if name=='message':return {'ok':True}
 return {}
def check(name,value):
 assert value,name;checks.append(name);print('PASS',name,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1000});page.on('pageerror',lambda err:errors.append(str(err)));page.on('dialog',lambda d:d.accept());page.expose_function('fixtureAPI',bridge)
 html=(STATIC/'messenger.html').read_text().replace('__BRAID_VERSION__','1.9.2')
 for name in ('messenger','channels','wan'):
  html=html.replace('<link rel="stylesheet" href="/static/'+name+'.css">','<style>'+(STATIC/(name+'.css')).read_text()+'</style>')
  html=html.replace('<script src="/static/'+name+'.js"></script>','')
 page.set_content(html)
 page.evaluate('''() => {window.fetch=async(url,opts={})=>{const r=await window.fixtureAPI(String(url),opts.body?JSON.parse(opts.body):null);return new Response(JSON.stringify(r.__error?{message:r.__error}:r),{status:r.__error?400:200});};if(!crypto.randomUUID)Object.defineProperty(crypto,'randomUUID',{value:()=>Array.from(crypto.getRandomValues(new Uint8Array(16))).map(x=>x.toString(16).padStart(2,'0')).join('')});}''')
 for name in ('messenger','channels','wan'):page.add_script_tag(content=(STATIC/(name+'.js')).read_text())
 page.wait_for_function("document.getElementById('localName').textContent.includes('Traveler')")
 check('full release badge',page.locator('.version[title]').inner_text()=='1.9.2')
 check('LAN receiving status is explicitly separate',page.locator('#listenLabel').inner_text()=='LAN receiving paused')
 page.click('#composeButton');check('new composer still blank',page.input_value('#sourceText')=='' and page.input_value('#composeTitle')=='');page.click('[aria-label="Close composer"]')
 page.click('#wanButton');page.wait_for_selector('#wanDialog',state='visible');check('WAN modal opens',page.locator('#wanDialog').is_visible())
 check('unactivated default',not page.is_checked('#wanEnabled') and not page.is_checked('#wanReceive'))
 page.check('#wanEnabled');page.click('#wanSave');page.wait_for_function("document.getElementById('wanStatus').textContent.includes('Activate')");check('activation required before enable',not state['wan']['preferences']['enabled'])
 with tempfile.TemporaryDirectory() as temp:
  file=Path(temp)/'fixture.braidmember';file.write_text('{}');page.set_input_files('#wanActivationFile',str(file))
  page.wait_for_selector('#wanActivationReview',state='visible');check('activation needs explicit fingerprint',page.input_value('#wanOperatorFingerprint')=='' and not page.is_checked('#wanConfirm'))
  page.fill('#wanOperatorFingerprint','d'*64);page.check('#wanConfirm');page.click('#wanActivate');page.wait_for_function("document.getElementById('wanEntitlement').textContent.includes('2 / 2')")
 check('activated member does not silently enable WAN',not state['wan']['preferences']['enabled'])
 page.check('#wanEnabled');page.check('#wanReceive');page.select_option('[data-wan-route]', 'relay');page.check('[data-grant-peer]');page.click('#wanSave')
 page.wait_for_function("window.BraidDesktop.getState().wan.preferences.enabled")
 check('explicit path saved',state['wan']['preferences']['routes'][PEER]=='relay')
 check('explicit query grant saved',state['wan']['preferences']['query_grants'][PEER]==[CHANNEL])
 page.click('#wanDiscover');page.wait_for_selector('[data-inspect-wan]');check('discovery still requires review',page.locator('[data-inspect-wan]').inner_text()=='Review rig')
 page.locator('#wanQuestion').fill('What is the second server limit?');page.click('#wanAsk');page.wait_for_selector('#wanAnswer',state='visible')
 check('remote answer labels source rig', 'Answered on Home rig' in page.locator('#wanAnswer').inner_text())
 check('remote exact-note count shown','1 shared note' in page.locator('#wanAnswer').inner_text())
 page.click('#wanAnswerEvidence summary');check('remote evidence expandable','second server' in page.locator('#wanAnswerRaw').inner_text())
 sends_before=sum(n=='wan' and d.get('action')=='ask' for n,d in calls);page.click('#wanCheckQuestion');page.wait_for_timeout(100)
 check('check does not resend question',sum(n=='wan' and d.get('action')=='ask' for n,d in calls)==sends_before)
 page.click('#wanLoadHistory');page.wait_for_function("document.getElementById('wanQueryHistory').options.length===2");check('history selectable',page.locator('#wanQueryHistory option').count()==2)
 page.locator('#wanQuestion').scroll_into_view_if_needed();page.screenshot(path=str(OUT/'remote-question-desktop.png'))
 page.locator('#wanDialog .modal-body').evaluate('(el)=>el.scrollTop=0');page.screenshot(path=str(OUT/'away-from-home-desktop.png'))
 for width in (320,390,768,1024,1440):
  page.set_viewport_size({'width':width,'height':900});page.wait_for_timeout(50)
  check('document horizontal fit '+str(width),page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  check('WAN modal horizontal fit '+str(width),page.locator('#wanDialog').evaluate('(e)=>e.scrollWidth<=e.clientWidth+2'))
  if width==390:page.locator('#wanDialog .modal-body').evaluate('(el)=>el.scrollTop=0');page.screenshot(path=str(OUT/'away-from-home-mobile.png'))
 page.set_viewport_size({'width':1440,'height':1000});page.click('#closeWan');page.click('[data-folder="sent"]');page.click('[data-message="out-fixture"]')
 check('relay storage not acceptance','Queued at relay' in page.locator('#readingPane').inner_text() and 'Unconfirmed' in page.locator('#readingPane').inner_text())
 page.click('[data-wan-check]');page.wait_for_function("window.BraidDesktop.getState().messages[0].stage==='indexed'")
 check('signed response updates same receipt',state['messages'][0]['id']=='out-fixture' and state['messages'][0]['stage']=='indexed')
 check('WAN check never invokes ordinary send',not any(n=='send' for n,d in calls))
 page.click('#wanButton');page.wait_for_selector('#wanDialog',state='visible');page.press('#wanDialog','Escape');check('escape closes WAN modal',not page.locator('#wanDialog').is_visible())
 page.click('#composeButton');check('blank composer after WAN operations',page.input_value('#sourceText')=='' and page.input_value('#composeTitle')=='')
 check('no JavaScript exceptions',not errors)
 (OUT/'browser.json').write_text(json.dumps({'passed':True,'checks':checks,'errors':errors,'method':'Production HTML/CSS/JS in offline Chromium with explicit synthetic API; not a physical relay/browser integration or native Safari test.'},indent=2))
 browser.close()
