"""Live local integration, privacy boundaries, migration, and platform paths."""
import copy
import io
import json
import os
import threading
import urllib.request
import urllib.error
import zipfile
from pathlib import Path, PureWindowsPath
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519
from braid_client.messenger_http import create_messenger_server
from folio.core import new_draft, block, review_digest, ConflictError, ValidationError
from folio.store import Store
from folio.integration import IntegratedStore, InternalBraidPort, legacy_home, migrate_profile
from folio.lifecycle import lock_profile
from tests.test_folio_connection import folio_pair
from tests.test_v1_7_0a4_messenger import route


@pytest.fixture
def app(tmp_path, monkeypatch):
    home = tmp_path/'Braid profile with spaces'
    monkeypatch.setenv('BRAID_MESSENGER_HOME', str(home))
    monkeypatch.delenv('BRAID_FOLIO_LEGACY_HOME', raising=False)
    key = ed25519.Ed25519PrivateKey.generate()
    server = create_messenger_server(('127.0.0.1',0), key, home/'inbox')
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    base = 'http://127.0.0.1:'+str(server.server_port)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def call(path, data=None, token=None, headers=None):
        fields = dict(headers or {})
        if data is not None:
            fields['Content-Type']='application/json'
        if token is not None:
            fields['X-Folio-Token']=token
        if path.startswith('/api/messenger/') and data is not None:
            fields.setdefault('X-Braid-CSRF', server.messenger.csrf)
        request = urllib.request.Request(base+path,
            data=json.dumps(data).encode() if data is not None else None, headers=fields)
        try:
            response=opener.open(request,timeout=10)
        except urllib.error.HTTPError as exc:
            response=exc
        with response:
            return response.status, response.read(), dict(response.headers)
    yield server, call, home
    server.shutdown()
    server.server_close()
    worker.join(5)
    assert not server.folio.scheduler.is_alive()


def decoded(call,path,data=None,**kw):
    status, body, headers = call(path,data,**kw)
    return status,json.loads(body)


@pytest.mark.parametrize('path',['/folio','/folio/','/folio/index.html','/folio/app.js','/folio/style.css'])
def test_one_server_folio_routes(app,path):
    server,call,home=app
    status,body,headers=call(path)
    assert status==200
    assert len(body)>100
    assert 'no-store' in headers['Cache-Control']
    assert headers['Referrer-Policy']=='no-referrer'
    assert server.folio.server_port==server.server_port
    assert (home/'folio/folio.sqlite3').exists()
    if path in ('/folio','/folio/','/folio/index.html'):
        assert b'Braid Archangel 1.9.2' in body
        assert b'Connect to Braid' not in body
        assert b'name="folio-session"' in body
        assert b'/folio/app.js' in body


def test_folio_capability_and_origin_are_independent(app):
    server,call,_=app
    assert server.folio.token!=server.messenger.csrf
    assert decoded(call,'/folio/api/state')[0]==401
    assert decoded(call,'/folio/api/state',token=server.messenger.csrf)[0]==401
    assert decoded(call,'/folio/api/state',token=server.folio.token)[0]==200
    for headers in ({'Host':'evil.invalid'},{'Origin':'https://evil.invalid'},{'Sec-Fetch-Site':'cross-site'}):
        assert call('/folio/api/state',token=server.folio.token,headers=headers)[0]==403
    for path in ('/folio/../folio.sqlite3','/folio/api/private-files','/folio/%2e%2e/identity.pem','/folio/exports'):
        assert call(path,token=server.folio.token)[0]==404


def test_direct_note_handoff_is_private_unapproved_and_durable(app):
    server,call,home=app
    service=server.messenger
    channel=service.create_channel('Local research')
    note=service.channel_action('note',{'channel':channel['id'],'title':'Selected thought','text':'A useful idea.'})
    status,result=decoded(call,'/api/messenger/folio/draft',{'kind':'note','id':note['id'],'channel':channel['id']})
    assert status==200 and result['approved'] is False
    assert result['url']=='/folio?draft='+result['draft_id']
    draft=server.folio.store.get(result['draft_id'])
    assert draft['title']=='Selected thought'
    assert draft['blocks'][0]['text']=='A useful idea.'
    assert draft['approved_digest'] is None and draft['editions']==[]
    assert IntegratedStore(home/'folio').get(draft['id'])==draft
    assert not any((home/'folio/exports').iterdir())


def test_direct_conversation_handoff_uses_completed_turns_only(app):
    server,call,_=app
    service=server.messenger
    channel=service.create_channel('Local conversation')
    thread=service.chat_action('new',{'channel':channel['id']})
    from braid_client.channel_protocol import canonical
    with service._db() as db:
        for number,state in enumerate(('done','running')):
            ident=str(number)*32
            payload={'result':{'response':'Completed answer.'}} if state=='done' else {}
            db.execute('INSERT INTO c6_turns VALUES (?,?,?,?,?,?)',
                (ident,thread['id'],'Completed question?' if state=='done' else 'UNFINISHED_SENTINEL',state,1+number,canonical(payload).decode()))
    status,result=decoded(call,'/api/messenger/folio/draft',{'kind':'conversation','id':thread['id']})
    assert status==200
    draft=server.folio.store.get(result['draft_id'])
    assert [b['text'] for b in draft['blocks']]==['Completed question?','Completed answer.']
    assert 'UNFINISHED_SENTINEL' not in json.dumps(draft)
    assert draft['approved_digest'] is None


def test_invalid_handoff_and_braid_csrf_do_not_create_drafts(app):
    server,call,_=app
    assert decoded(call,'/api/messenger/folio/draft',{'kind':'note','id':'missing','channel':'missing'},headers={'X-Braid-CSRF':server.folio.token})[0]==403
    assert decoded(call,'/api/messenger/folio/draft',{'kind':'all-state','id':'anything'})[0]==400
    assert server.folio.store.list()==[]


def test_approval_invalidation_immutable_edition_and_privacy_sentinel(app,monkeypatch):
    server,call,home=app
    sentinel='PRIVATE_FOLIO_SENTINEL_DO_NOT_EXPORT_192'
    first=block('human','Publishable question?')
    first['original']=sentinel
    excluded=block('note',sentinel);excluded['include']=False
    draft=new_draft('Reviewed edition',[first,excluded],{'kind':'Private local source','original':sentinel})
    saved=server.folio.store.insert(draft)
    token=server.folio.token
    def operation(route,payload):
        return decoded(call,'/folio/api/'+route,payload,token=token)
    assert operation('export',{'id':saved['id']})[0]==409
    code,preview=operation('preview',{'id':saved['id']})
    assert code==200 and sentinel not in json.dumps(preview)
    assert operation('approve',{'id':saved['id'],'digest':preview['digest'],'confirmed':False})[0]==400
    code,approved=operation('approve',{'id':saved['id'],'digest':preview['digest'],'confirmed':True})
    assert code==200
    code,edition=operation('export',{'id':saved['id']})
    assert code==200
    _,archive=server.folio.store.download(edition['id'])
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        assert all(sentinel.encode() not in z.read(n) for n in z.namelist())
    assert sentinel not in json.dumps(server.messenger.snapshot())
    assert sentinel not in json.dumps(server.messenger.folio_identity())
    assert sentinel.encode() not in (home/'messenger.sqlite3').read_bytes()
    changed=server.folio.store.get(saved['id']);changed['title']='Changed public title'
    code,changed=operation('save',{'id':saved['id'],'draft':changed})
    assert code==200 and changed['approved_digest'] is None
    assert operation('export',{'id':saved['id']})[0]==409
    assert server.folio.store.download(edition['id'])[1]==archive
    assert sentinel in json.dumps(server.folio.store.get(saved['id']))


def test_internal_port_has_no_generic_networking_or_authority(app,monkeypatch):
    server,_,_=app
    port=server.folio.bridge
    monkeypatch.setattr(port.opener,'open',Mock(side_effect=AssertionError('Internal adapter must not connect via HTTP')))
    assert port.connect()['connected']
    assert port.public_identity()['source_network_id']==server.messenger.fingerprint
    for route,data in [('/api/messenger/send',{'action':'send'}),('/api/messenger/channel',{'action':'publish'}),('/api/messenger/state',{})]:
        with pytest.raises(ValidationError):port._read(port.base,route,data)
    with pytest.raises(ValidationError):port._folio_api('/api/messenger/approve-card',{})
    with pytest.raises(ValidationError):port.connect('http://127.0.0.1:9999')
    assert server.messenger.contacts()==[]


def test_close_studio_returns_to_braid_without_stopping(app):
    server,call,_=app
    assert decoded(call,'/folio/api/quit',{},token=server.folio.token)==(200,{'returned_to_braid':True})
    assert decoded(call,'/api/messenger/state')[0]==200
    assert not server.folio.stop.is_set()


def test_legacy_copy_preserves_originals_editions_and_preferences(tmp_path):
    source=tmp_path/'legacy library';destination=tmp_path/'Braid'/'folio';destination.parent.mkdir()
    old=Store(source)
    draft=old.insert(new_draft('Legacy title',[block('human','Original question?')]))
    old.approve(draft['id'],review_digest(draft),True)
    record=old.export(draft['id']);archive=old.download(record['id'])[1]
    old.save_preferences({'mood':'rose','pin':{'id':draft['id'],'enabled':True}})
    original=(source/'folio.sqlite3').read_bytes()
    assert migrate_profile(destination,source)
    assert (source/'folio.sqlite3').read_bytes()==original
    copied=IntegratedStore(destination)
    assert copied.get(draft['id'])['title']=='Legacy title'
    assert copied.preferences()['mood']=='rose'
    assert copied.preferences()['pins']==[draft['id']]
    assert copied.download(record['id'])[1]==archive
    assert copied.get(draft['id'])['approved_digest'] is None
    with pytest.raises(ConflictError):copied.export(draft['id'])
    approved=copied.approve(draft['id'],review_digest(copied.get(draft['id'])),True)
    assert copied.export(draft['id'])['id']==record['id']
    assert not migrate_profile(destination,source)
    assert (source/'folio.sqlite3').read_bytes()==original


def test_busy_legacy_profile_is_not_copied(tmp_path):
    source=tmp_path/'legacy';destination=tmp_path/'folio'
    Store(source)
    ownership=lock_profile(source/'session.lock')
    try:
        with pytest.raises(ValidationError,match='Close the standalone'):
            migrate_profile(destination,source)
        assert not destination.exists()
    finally:ownership.close()


def test_integrated_streams_never_auto_approve_legacy_broadcast(tmp_path):
    from tests.test_stream_workflow_fixture192 import FakeBridge, settings
    source=Store(tmp_path/'folio')
    stream=source.save_stream(settings(mode='broadcast',tag='share',site_directory=str(tmp_path)))
    integrated=IntegratedStore(source.home)
    run=integrated.run_stream(stream['id'],FakeBridge('#share A safe result.'))
    assert run['status']=='review' and 'edition_id' not in run
    assert integrated.get(run['draft_id'])['approved_digest'] is None
    assert source._get_stream(stream['id'])['mode']=='broadcast'
    assert integrated.streams()[0]['mode']=='review'
    assert not (tmp_path/('folio-stream-'+stream['id'])).exists()
    with pytest.raises(ValidationError,match='explicit Folio review'):
        integrated.save_stream(settings(mode='broadcast',tag='share',site_directory=str(tmp_path)))


def test_legacy_site_rebuild_requires_review_and_reviewed_editions_remain_immutable(tmp_path):
    from tests.test_stream_workflow_fixture192 import FakeBridge, settings
    old=Store(tmp_path/'folio')
    stream=old.save_stream(settings(mode='broadcast',tag='share',site_directory=str(tmp_path)))
    run=old.run_stream(stream['id'],FakeBridge('#share A safe legacy edition.'))
    assert run['status']=='released'
    archive=old.download(run['edition_id'])[1]
    integrated=IntegratedStore(old.home)
    with pytest.raises(ConflictError,match='Review legacy stream editions'):
        integrated.retry_stream_site(stream['id'])
    draft=integrated.get(run['draft_id'])
    integrated.approve(draft['id'],review_digest(draft),True)
    assert integrated.retry_stream_site(stream['id'])['site_updated']
    updated=integrated.get(draft['id']);updated['title']='A new draft title'
    integrated.save(updated['id'],updated)
    assert integrated.get(draft['id'])['approved_digest'] is None
    assert integrated.stream_site(stream['id'])[1]
    assert integrated.download(run['edition_id'])[1]==archive


@pytest.mark.parametrize('system,env,suffix',[
    ('darwin',{},'Library/Application Support/Intersignal/Folio'),
    ('linux',{},'.local/share/intersignal/folio'),
    ('linux',{'XDG_DATA_HOME':'/custom/data'},'/custom/data/intersignal/folio'),
    ('win32',{},'AppData/Local/Intersignal/Folio'),
    ('win32',{'LOCALAPPDATA':'C:/Users/Fixture/AppData/Local'},'C:/Users/Fixture/AppData/Local/Intersignal/Folio'),
])
def test_legacy_platform_paths(system,env,suffix,tmp_path):
    value=legacy_home(system,tmp_path,env)
    assert value.as_posix().endswith(suffix)


def test_windows_acl_and_lock_code_paths_are_exercised(tmp_path,monkeypatch):
    import folio.private_files as pf
    import folio.lifecycle as lifecycle
    import sys
    folder=tmp_path/'private';folder.mkdir()
    mock_acl=Mock()
    monkeypatch.setattr(pf,'os',SimpleNamespace(name='nt'))
    monkeypatch.setattr(pf,'_windows_acl',mock_acl)
    pf.secure_path(folder,directory=True)
    mock_acl.assert_called_once_with(None,folder,True)
    windows=SimpleNamespace(LK_NBLCK=1,locking=Mock())
    monkeypatch.setitem(sys.modules,'msvcrt',windows)
    monkeypatch.setattr(lifecycle,'os',SimpleNamespace(name='nt'))
    owned=lifecycle.lock_profile(tmp_path/'win-session.lock')
    try:windows.locking.assert_called_once_with(owned.fileno(),1,1)
    finally:owned.close()


def test_shutdown_and_restart_preserve_library_rotate_token_and_release_lock(tmp_path,monkeypatch):
    home=tmp_path/'restart profile';monkeypatch.setenv('BRAID_MESSENGER_HOME',str(home))
    key=ed25519.Ed25519PrivateKey.generate()
    first=create_messenger_server(('127.0.0.1',0),key,home/'inbox')
    draft=first.folio.store.insert(new_draft('Keep this',[block('note','A private thought.')]))
    token=first.folio.token
    first.server_close()
    assert not first.folio.scheduler.is_alive()
    second=create_messenger_server(('127.0.0.1',0),key,home/'inbox')
    try:
        assert second.folio.token!=token
        assert second.folio.store.get(draft['id'])==draft
    finally:second.server_close()


def test_integrated_invitation_keeps_acceptance_cards_fingerprints_and_scopes_explicit(folio_pair):
    from folio.integration import FolioSurface
    publisher,reader,rendezvous,base=folio_pair
    studio=FolioSurface(publisher,54321)
    sentinel='PRIVATE_REGISTRATION_SENTINEL_192'
    try:
        public=block('note','A reviewed publication.')
        public['original']=sentinel
        draft=new_draft('Integrated publication',[public],{'kind':'Local original','text':sentinel})
        draft['connection']={'enabled':True,'source_network_id':publisher.fingerprint,
            'rendezvous_url':base,'allowed_scopes':['publication_channel','messages']}
        saved=studio.store.insert(draft)
        with pytest.raises(ConflictError):studio.store.export(saved['id'],studio.bridge)
        assert publisher.folio_requests()==[] and reader.contacts()==[]
        studio.store.approve(saved['id'],review_digest(saved),True)
        edition=studio.store.export(saved['id'],studio.bridge)
        with zipfile.ZipFile(io.BytesIO(studio.store.download(edition['id'])[1])) as z:
            assert all(sentinel.encode() not in z.read(n) for n in z.namelist())
        assert sentinel not in json.dumps(rendezvous.referral(saved['id']))
        link=base+'/continue?publication_id='+saved['id']+'&source_network_id='+publisher.fingerprint+'&edition_id='+edition['id']
        referral=reader.folio_import_link({'url':link})
        assert referral['publication_id']==saved['id']
        assert reader.contacts()==[] and reader.folio_requests()==[]
        request=reader.folio_send_request({'publication_id':saved['id'],'requested_scope':['publication_channel','messages'],'message':'Discuss this edition.','publication_url':''})
        publisher.folio_refresh_inbox()
        with pytest.raises(ValueError,match='Confirm'):
            publisher.folio_decide({'request_id':request['request_id'],'decision':'accepted','granted_scope':['messages'],'confirmed':False})
        publisher.folio_decide({'request_id':request['request_id'],'decision':'accepted','granted_scope':['publication_channel','messages'],'confirmed':True})
        result=reader.folio_check_request(request['request_id'])
        assert reader.contacts()==[]
        assert reader.channel(result['channel_id'])['policy']['receive_from']==[]
        with pytest.raises(ValueError,match='Confirm sharing'):reader.folio_share_card(request['request_id'])
        publisher.folio_share_card(request['request_id'],confirmed=True)
        reader.folio_share_card(request['request_id'],confirmed=True)
        for owner,other in ((publisher,reader),(reader,publisher)):
            inspection=owner.folio_inspect_peer_card(request['request_id'])['inspection']
            with pytest.raises(ValueError,match='BINDING'):
                owner.folio_approve_peer_card(request['request_id'],inspection['inspection_id'],'0'*64,True)
            owner.folio_approve_peer_card(request['request_id'],inspection['inspection_id'],other.fingerprint,True)
            assert next(c for c in owner.contacts() if c['id']==other.fingerprint)['folio_only'] is True
        with pytest.raises(ValueError,match='ERR_FOLIO_PUBLICATION_SCOPE_REQUIRED'):
            publisher.send(reader.fingerprint,'Unrelated private text',handoff_id='a'*32)
        assert sentinel not in json.dumps(publisher.snapshot())
    finally:studio.close()
