"""Regression checks for a complete, self-consistent 1.9.2 distribution."""
from pathlib import Path
from unittest.mock import patch
import pytest
import braid_client
from release import start_braid

def test_package_and_launcher_versions_match():
    assert braid_client.__version__ == start_braid.VERSION == '1.9.2'
    assert start_braid.WHEEL == 'braid_client-1.9.2-py3-none-any.whl'

def test_sidebar_identifies_full_release():
    html=(Path(__file__).parents[1]/'braid_client/static/messenger.html').read_text()
    assert 'title="1.9.2 - Archangel">1.9.2</span>' in html

@pytest.mark.parametrize('running',['1.9.0rc1','1.8.1','1.8.0','1.7.0a6','1.7.0a6+composer1','1.7.0a7'])
def test_different_running_version_is_not_opened(running,tmp_path):
    with patch.object(start_braid,'session_url',return_value=('http://127.0.0.1:8745',{'version':running},None)), patch.object(start_braid.webbrowser,'open') as open_browser:
        with pytest.raises(RuntimeError,match='older window was not reopened'):
            start_braid.existing_window(tmp_path,False)
        open_browser.assert_not_called()

def test_same_running_version_is_reused(tmp_path):
    with patch.object(start_braid,'session_url',return_value=('http://127.0.0.1:8745',{'version':'1.9.2'},None)), patch.object(start_braid.webbrowser,'open') as open_browser:
        assert start_braid.existing_window(tmp_path,False)
        open_browser.assert_called_once_with('http://127.0.0.1:8745')

def test_same_running_version_honors_no_browser(tmp_path):
    with patch.object(start_braid,'session_url',return_value=('http://127.0.0.1:8745',{'version':'1.9.2'},None)), patch.object(start_braid.webbrowser,'open') as open_browser:
        assert start_braid.existing_window(tmp_path,True)
        open_browser.assert_not_called()

def test_unavailable_session_does_not_open_browser(tmp_path):
    with patch.object(start_braid,'session_url',side_effect=OSError('no session')), patch.object(start_braid.webbrowser,'open') as open_browser:
        assert not start_braid.existing_window(tmp_path,False)
        open_browser.assert_not_called()

def test_wrong_installed_package_is_refused_before_serve(tmp_path):
    with patch.object(braid_client,'__version__','1.8.0'), patch('braid_client.server.serve_http_app') as serve:
        with pytest.raises(RuntimeError,match='does not match'):
            start_braid.client(tmp_path,0,True)
        serve.assert_not_called()

def test_source_has_no_patch_payloads():
    root=Path(__file__).parents[1]
    assert not list(root.rglob('*.patch'))
    assert not list(root.rglob('*.diff'))
