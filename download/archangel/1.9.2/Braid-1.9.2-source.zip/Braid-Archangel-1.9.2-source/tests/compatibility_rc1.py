"""Explicit compatibility suite: BRAID_RC1_WHEEL=/path/to/old.whl pytest -q this_file.
Actual rc1 relay subprocess, current clients; TLS/crypto real, model fixture only.
"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import os,sys,socket,subprocess,time,ssl,http.client,json,uuid
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.x509.oid import NameOID
from braid_client.wan_relay import RelayStore
from tests.test_v1_7_0a6_channels import pair,route,policy
from tests import test_v1_9_wan as shared
fleet=shared.fleet

@pytest.fixture
def server(tmp_path):
    wheel=Path(os.environ['BRAID_RC1_WHEEL'])
    assert wheel.name=='braid_client-1.9.0rc1-py3-none-any.whl'
    store=RelayStore(tmp_path/'relay')
    key=ed25519.Ed25519PrivateKey.generate()
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')])
    now=datetime.now(timezone.utc)
    import ipaddress
    cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
        .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(days=1))
        .not_valid_after(now+timedelta(days=1)).add_extension(x509.SubjectAlternativeName([
          x509.DNSName('localhost'),x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),False)
        .add_extension(x509.BasicConstraints(ca=True,path_length=None),True).sign(key,None))
    cp=tmp_path/'test.crt';kp=tmp_path/'test.key'
    cp.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    kp.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    env={**os.environ,'PYTHONPATH':str(wheel),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
    version=subprocess.check_output([sys.executable,'-c','import braid_client;print(braid_client.__version__)'],env=env,cwd=tmp_path,text=True).strip()
    assert version=='1.9.0rc1'
    log=(tmp_path/'relay-log.txt').open('w')
    process=subprocess.Popen([sys.executable,'-m','braid_client.wan_relay','--state',str(tmp_path/'relay'),'serve','--bind','127.0.0.1','--port',str(port),'--tls-cert',str(cp),'--tls-key',str(kp)],env=env,cwd=tmp_path,stdout=log,stderr=subprocess.STDOUT)
    ctx=ssl.create_default_context(cadata=cp.read_text());ctx.minimum_version=ssl.TLSVersion.TLSv1_3
    try:
        for _ in range(60):
            assert process.poll() is None
            try:
                c=http.client.HTTPSConnection('127.0.0.1',port,context=ctx,timeout=1)
                c.request('GET','/braid/v1/health');r=c.getresponse();data=json.loads(r.read());c.close()
                if r.status==200 and data['protocol']==1:break
            except OSError:time.sleep(.1)
        else:raise AssertionError('rc1 relay did not start')
        yield store,f'https://127.0.0.1:{port}',cp.read_text(),None
    finally:
        process.terminate();process.wait(timeout=10);log.close()

def test_new_clients_exchange_note_using_actual_rc1_relay(fleet):
    shared.test_note_through_real_tls_not_lan(fleet)

def test_channel_note_and_remote_answer_using_actual_rc1_relay(fleet,monkeypatch):
    shared.test_remote_answer_has_actual_shared_note_evidence(fleet,monkeypatch)

def test_rc1_relay_clock_rejection_then_deliberate_fresh_send(fleet,monkeypatch):
    a,b,f,store=fleet
    r=a.send(b.fingerprint,'Clock guard test only.','Clock test',handoff_id=uuid.uuid4().hex)
    v=b.wan.client().call('poll')['envelope']
    before=int(time.time())
    with monkeypatch.context() as m:
        m.setattr('braid_client.mcp_core.protocol.time.time',lambda:before-8)
        b.wan._process(v)
    b.wan._upload_replies();a.wan.refresh_pending()
    incoming=b.messages()[0]
    assert incoming['stage']=='rejected'
    assert incoming['payload']['source_transport']=='managed_wan'
    assert incoming['payload']['phase_b_committed'] is False
    assert 'ERR_FUTURE_TIMESTAMP' in incoming['payload']['reason']
    assert a.wan.outcome(r['receipt']['wan_request_id'])['state']=='rejected'
    # Explicitly new work after restoring time. Not an automatic retry.
    fresh=a.send(b.fingerprint,'A separately authorized fresh note.','Fresh clock test',handoff_id=uuid.uuid4().hex)
    shared.pump(b);a.wan.refresh_pending()
    assert a.wan.outcome(fresh['receipt']['wan_request_id'])['state']=='indexed'
    rejected=[m for m in b.messages() if m['stage']=='rejected']
    assert len(rejected)==1 and rejected[0]['id']==incoming['id']
