"""Mac packaging shares exact library bytes, with links contained in the app."""
from pathlib import Path
import importlib.util
import os
import pytest

spec=importlib.util.spec_from_file_location('braid_compact_macos',Path(__file__).parents[1]/'packaging/compact_macos.py')
compact=importlib.util.module_from_spec(spec);spec.loader.exec_module(compact)


def fixture(tmp_path):
    app=tmp_path/'Braid package with spaces'/'Braid.app'
    gui=app/'Contents/Frameworks';cli=app/'Contents/Resources/BraidCLI/_internal'
    gui.mkdir(parents=True);cli.mkdir(parents=True)
    return app,gui,cli


def put(path,payload,mode=0o644):
    path.write_bytes(payload);path.chmod(mode);return path


def test_identical_compiled_library_uses_relative_internal_link(tmp_path):
    app,gui,cli=fixture(tmp_path)
    target=put(gui/'libpython.dylib',b'compiled-library-bytes')
    copied=put(cli/'libpython.dylib',target.read_bytes())
    result=compact.compact_app(app)
    assert result['shared_files']==1
    assert result['uncompressed_duplicate_bytes_removed']==len(target.read_bytes())
    assert copied.is_symlink() and not copied.readlink().is_absolute()
    assert copied.resolve()==target.resolve()
    assert copied.read_bytes()==b'compiled-library-bytes'
    assert target.is_file() and not target.is_symlink()


def test_different_bytes_are_retained(tmp_path):
    app,gui,cli=fixture(tmp_path)
    put(gui/'module.so',b'GUI version');copied=put(cli/'module.so',b'CLI version')
    assert compact.compact_app(app)['shared_files']==0
    assert not copied.is_symlink() and copied.read_bytes()==b'CLI version'


def test_different_permissions_are_retained(tmp_path):
    app,gui,cli=fixture(tmp_path)
    put(gui/'module.so',b'same',0o600);copied=put(cli/'module.so',b'same',0o755)
    assert compact.compact_app(app)['shared_files']==0
    assert not copied.is_symlink() and copied.stat().st_mode&0o777==0o755


def test_arbitrary_data_and_entry_points_are_not_relinked(tmp_path):
    app,gui,cli=fixture(tmp_path)
    for name in ('config.json','private-original.txt','braid-client','module.py','PYZ.pyz'):
        put(gui/name,b'same');put(cli/name,b'same')
    assert compact.compact_app(app)['shared_files']==0
    assert all(not p.is_symlink() for p in cli.iterdir())


def test_existing_gui_symlink_is_not_a_target(tmp_path):
    app,gui,cli=fixture(tmp_path)
    outside=put(tmp_path/'outside.dylib',b'same')
    (gui/'module.dylib').symlink_to(outside);copied=put(cli/'module.dylib',b'same')
    assert compact.compact_app(app)['shared_files']==0
    assert not copied.is_symlink()


def test_repeated_compaction_preserves_links(tmp_path):
    app,gui,cli=fixture(tmp_path)
    target=put(gui/'module.so',b'same');copied=put(cli/'module.so',b'same')
    assert compact.compact_app(app)['shared_files']==1
    assert compact.compact_app(app)['shared_files']==0
    assert copied.resolve()==target.resolve() and copied.read_bytes()==b'same'


def test_non_app_or_missing_cli_is_rejected(tmp_path):
    with pytest.raises(ValueError,match='companion CLI'):
        compact.compact_app(tmp_path/'other')
