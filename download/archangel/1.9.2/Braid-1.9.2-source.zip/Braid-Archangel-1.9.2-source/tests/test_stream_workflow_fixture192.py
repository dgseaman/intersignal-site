"""Synthetic source fixture shared with integrated stream boundary tests."""


class FakeBridge:
    def __init__(self, text):
        self.text=text

    def channel(self, ident):
        assert ident=='chosen-channel'
        return {'notes':[{'id':'note-one','kind':'note','title':'Selected note','text':self.text}],'threads':[]}


def settings(mode='review',tag='',site_directory=''):
    return {'name':'Review fixture','mode':mode,'cadence_hours':24,'template':'daily',
        'broadcast_ack':mode=='broadcast','site_directory':site_directory,
        'scope':{'channels':['chosen-channel'],'notes':True,'objects':False,'conversations':False,'tag':tag},
        'privacy':{'rules':[], **{k:True for k in ('redact_emails','redact_phones','redact_addresses',
            'redact_credentials','redact_paths','redact_ip','redact_financial')}}}
