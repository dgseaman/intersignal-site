"""1.9.2 layout/diagnostic checks. Production assets, synthetic local API. Not native Safari."""
import copy,json,os,shutil,sys,tempfile,time
from pathlib import Path
from playwright.sync_api import sync_playwright
sys.path.insert(0,str(Path(__file__).parents[1]))
from cryptography.hazmat.primitives.asymmetric import ed25519
from braid_client.messenger import MessengerService
from braid_client.channel_protocol import create_channel_descriptor
ROOT=Path(__file__).parents[1];STATIC=ROOT/'braid_client/static';OUT=Path(sys.argv[1]);OUT.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as temp:
 d=MessengerService(ed25519.Ed25519PrivateKey.generate(),Path(temp)/'inbox',Path(temp)/'home');state=d.snapshot();d.close()
key=ed25519.Ed25519PrivateKey.generate();ch=create_channel_descriptor(key,'Cobalt','Project notes')
PEER='a'*64;CHANNEL=ch['id'];calls=[];checks=[];errors=[]
state['settings']['name']='Traveler - UI fixture'
state['peers']=[dict(id=PEER,name='Home rig - UI fixture',wan={'protocol':'managed-wan.v1','encryption_key':'b'*64},capabilities=['managed-wan.v1','channels.v1'],presence=None)]
state['channels']=[dict(id=CHANNEL,descriptor=ch,revision=1,note_count=0,policy=dict(send_to=[PEER],receive_from=[PEER],use_in_chat=True,mode='manual',keywords=[],paused=False,archived=False,hourly_limit=6))]
state['messages']=[dict(id='out-fixture',direction='out',peer=PEER,title='WAN receipt fixture',text='Project Cobalt has a 500-credit limit.',stage='queued',created=time.time(),unread=False,archived=False,payload=dict(transport='managed_wan',wan_request_id='c'*32,relay_stored=True,receiver_confirmed=False,wan_pending=True,kind='summary'))]
results={}
def bridge(path,data):
 global state
 name=path.split('/api/messenger/')[-1];data=data or {};calls.append((name,copy.deepcopy(data)))
 if name=='state':return copy.deepcopy(state)
 if name=='wan':
  a=data.get('action')
  if a=='settings':
   if data['preferences']['enabled'] and not state['wan']['configured']:return {'__error':'Activate membership first.'}
   state['wan']['preferences'].update(data['preferences']);return copy.deepcopy(state['wan'])
  if a=='inspect-activation':return dict(member='UI-DEMO',operator_fingerprint='d'*64,relay_url='https://relay.intersignal.org',device=state['fingerprint'])
  if a=='activate':
   if data['operator_fingerprint']!='d'*64 or not data['confirmed']:return {'__error':'Compare the operator fingerprint.'}
   state['wan'].update(configured=True,member='UI-DEMO',status=dict(devices=2,device_limit=2,expires=time.time()+86400,month_bytes=10,month_limit=1024**3),connected=True);return {'activated':True}
  if a=='peers':return {'peers':[dict(device=PEER,name='Home rig - UI fixture',online=True,last_seen=time.time(),card_available=True)]}
  if a=='ask':return {'wan_request_id':'e'*32,'receiver_confirmed':False,'relay_stored':True,'wan_pending':True}
  if a in ('result','check-query'):return dict(id='e'*32,state='answered',result={'response':'The shared note states 500 credits for the second server.','answered_on':'Home rig - UI fixture','shared_note_count':1,'supplied_notes':[{'text':'Spend no more than 500 credits on the second server.'}],'generation_source':'fixture'})
  if a=='check':
   state['messages'][0]['stage']='indexed';state['messages'][0]['payload'].update(phase_b_committed=True,field_indexed=True,wan_pending=False);return {'state':'indexed'}
  if a=='requests':return {'requests':[dict(id='e'*32,peer=PEER,state='answered',expires=time.time()+300,created=time.time())]}
  if a=='clear':state['wan']['configured']=False;state['wan']['preferences'].update(enabled=False,receive_notes=False,routes={},query_grants={});return state['wan']
  return {}
 if name=='draft':state['draft']=data.get('draft');return {'saved':True}
 if name=='message':return {'ok':True}
 return {}
def check(name,value):
 assert value,name;checks.append(name);print('PASS',name,flush=True)

with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1280,'height':800},accept_downloads=True)
 page.on('pageerror',lambda err:errors.append(str(err)))
 page.on('dialog',lambda d:d.accept())
 page.expose_function('fixtureAPI',bridge)
 html=(STATIC/'messenger.html').read_text()
 for name in ('messenger','channels','wan'):
  html=html.replace('<link rel="stylesheet" href="/static/'+name+'.css">','<style>'+(STATIC/(name+'.css')).read_text()+'</style>')
  html=html.replace('<script src="/static/'+name+'.js"></script>','')
 page.set_content(html)
 page.evaluate('''() => {window.fetch=async(url,opts={})=>{const r=await window.fixtureAPI(String(url),opts.body?JSON.parse(opts.body):null);return new Response(JSON.stringify(r.__error?{message:r.__error}:r),{status:r.__error?400:200});};if(!crypto.randomUUID)Object.defineProperty(crypto,'randomUUID',{value:()=>Array.from(crypto.getRandomValues(new Uint8Array(16))).map(x=>x.toString(16).padStart(2,'0')).join('')});}''')
 for name in ('messenger','channels','wan'):page.add_script_tag(content=(STATIC/(name+'.js')).read_text())
 page.wait_for_function("window.BraidDesktop.getState() !== null")
 page.click('#wanButton');page.wait_for_selector('#wanDialog',state='visible')
 check('free client membership invitation visible',page.locator('#wanMembership').is_visible())
 check('membership link is official and no opener',page.locator('#wanMembership a').get_attribute('href')=='https://intersignal.org/#membership' and 'noopener' in page.locator('#wanMembership a').get_attribute('rel'))
 check('opening has not activated or enabled WAN',not state['wan']['configured'] and not state['wan']['preferences']['enabled'] and not any(n=='wan' and d.get('action')=='activate' for n,d in calls))
 check('keyboard reachable scroll area',page.locator('#wanDialog .modal-body').get_attribute('tabindex')=='0')
 sizes=[]
 for width,height in [(1440,1000),(1280,800),(1024,768),(768,600),(390,844),(320,480),(1024,400),(720,500)]:
  page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(60)
  geometry=page.locator('#wanDialog').evaluate('''d=>{const body=d.querySelector('.modal-body'),head=d.querySelector('.modal-head'),foot=d.querySelector('.modal-foot');const r=x=>{const b=x.getBoundingClientRect();return {x:b.x,y:b.y,width:b.width,height:b.height,bottom:b.bottom}};return {dialog:r(d),body:r(body),head:r(head),foot:r(foot),client:body.clientHeight,scroll:body.scrollHeight,overflow:d.scrollWidth-d.clientWidth,display:getComputedStyle(d).display}}''')
  sizes.append({'viewport':[width,height],**geometry});g=geometry
  check(f'dialog in viewport {width}x{height}',g['dialog']['x']>=0 and g['dialog']['y']>=0 and g['dialog']['bottom']<=height+1 and g['dialog']['width']<=width)
  check(f'substantial body {width}x{height}',g['body']['height']>=min(160,height*.33) and g['display']=='grid' and g['overflow']<=2)
  check(f'no overlapping header/footer {width}x{height}',g['body']['y']>=g['head']['bottom']-1 and g['body']['bottom']<=g['foot']['y']+1)
  body=page.locator('#wanDialog .modal-body');body.evaluate('b=>b.scrollTop=b.scrollHeight')
  check(f'body scrolls without footer loss {width}x{height}',body.evaluate('b=>b.scrollTop>0') and page.locator('#wanDone').is_visible())
  page.locator('#wanSave').scroll_into_view_if_needed()
  visible=page.locator('#wanSave').evaluate('''e=>{let b=e.getBoundingClientRect(),p=e.closest('.modal-body').getBoundingClientRect();return b.top>=p.top-1&&b.bottom<=p.bottom+1}''')
  check(f'save control reachable {width}x{height}',visible)
  if width==390:
   body.evaluate('b=>b.scrollTop=0');page.screenshot(path=str(OUT/'away-from-home-narrow.png'))
 page.set_viewport_size({'width':1280,'height':800})
 page.locator('#wanDialog .modal-body').evaluate('b=>b.scrollTop=0')
 page.screenshot(path=str(OUT/'away-from-home-free-desktop.png'))
 # Reproduce long review/readability without claiming browser-specific native execution.
 page.check('#wanEnabled');page.click('#wanSave')
 page.wait_for_function("document.getElementById('wanStatus').textContent.includes('Activate')")
 first_error=page.inner_text('#wanStatus');page.evaluate('window.BraidDesktop.refresh()');page.wait_for_timeout(4200)
 check('action error survives normal refresh',page.inner_text('#wanStatus')==first_error)
 with tempfile.TemporaryDirectory() as tmp:
  file=Path(tmp)/'fixture.braidmember';file.write_text('{}')
  page.set_input_files('#wanActivationFile',str(file));page.wait_for_selector('#wanActivationReview',state='visible')
  check('activation inspection is not enrollment',not state['wan']['configured'])
  file.write_text('{invalid')
  page.set_input_files('#wanActivationFile',str(file));page.wait_for_timeout(150)
  check('failed import clears old preview',not page.locator('#wanActivationReview').is_visible() and page.inner_text('#wanActivationDetails')=='')
  check('file picker resets after error',page.input_value('#wanActivationFile')=='')
  file.write_text('{}');page.set_input_files('#wanActivationFile',str(file));page.wait_for_selector('#wanActivationReview',state='visible')
  check('same file can be deliberately selected again',page.input_value('#wanOperatorFingerprint')=='' and not page.is_checked('#wanConfirm'))
  page.fill('#wanOperatorFingerprint','d'*64);page.check('#wanConfirm');page.click('#wanActivate')
  page.wait_for_function("window.BraidDesktop.getState().wan.configured")
 check('activated member does not see signup callout',not page.locator('#wanMembership').is_visible())
 check('activation still leaves WAN paused',not state['wan']['preferences']['enabled'])
 page.locator('#wanDialog .modal-body').evaluate('b=>b.scrollTop=0');page.screenshot(path=str(OUT/'away-from-home-activated-desktop.png'))
 for reason in ['ERR_FUTURE_TIMESTAMP: Timestamp in future','ERR_WAN_CLOCK','ERR_WAN_RESPONSE_CLOCK','ERR_WAN_EXPIRED_OR_FUTURE','ERR_EXPIRED: expired']:
  guidance=page.evaluate('(reason)=>window.BraidDesktop.clockGuidance({reason})',reason)
  check('actionable clock guidance '+reason.split(':')[0],bool(guidance) and ('clock' in guidance.lower() or 'time' in guidance))
 check('ordinary note text never triggers diagnostic',page.evaluate("window.BraidDesktop.clockGuidance({manifest:{content:'ERR_FUTURE_TIMESTAMP'},text:'ERR_EXPIRED'})")=='')
 check('membership expiry is not diagnosed as clock failure',page.evaluate("window.BraidDesktop.clockGuidance({error:'ERR_WAN_MEMBERSHIP_EXPIRED'})")=='')
 state['wan']['error']='ERR_WAN_RESPONSE_CLOCK'
 page.evaluate('window.BraidDesktop.refresh()');page.wait_for_timeout(100)
 check('WAN clock explanation appears',page.locator('#wanClockHint').is_visible() and 'Clock check' in page.inner_text('#wanClockHint'))
 page.click('#closeWan')
 rejection={'accepted':False,'accepted_and_indexed':False,'phase_b_committed':False,'stored':True,'finality':'rejected','result_summary':'REJECTED_BEFORE_PHASE_B','source_transport':'managed_wan','reason':'ERR_FUTURE_TIMESTAMP: Timestamp in future beyond clock skew: 1789087123 (Now: 1789087115)','transport_sha256':'6'*64,'receipt_path':'/test-fixture/inbox/rejected/record.json'}
 state['messages']=[dict(id='clock-test',direction='in',peer=PEER,title='Clock rejection - synthetic fixture',text='A harmless test note.',stage='rejected',created=time.time(),unread=False,archived=False,payload=rejection)]
 page.evaluate('window.BraidDesktop.refresh()');page.wait_for_timeout(100);page.click('[data-folder="inbox"]');page.click('[data-message="clock-test"]')
 reader=page.inner_text('#readingPane')
 check('rejected store not represented as accepted', 'not accepted state' in reader and 'Not accepted' in reader)
 check('receipt explains sender ahead not definitive wrong clock', 'sender timestamp is ahead' in reader and 'both rigs' in reader)
 check('receipt displays recorded WAN path','Recorded transport: Managed WAN' in reader)
 page.click('#readingPane details summary')
 before=list(calls)
 with page.expect_download() as info:page.click('[data-read-action="save-receipt"]')
 download=info.value;payload=Path(download.path()).read_text()
 check('download is exact current receipt JSON',json.loads(payload)==rejection)
 check('save receipt makes no API request',calls==before)
 check('receipt filename safe',download.suggested_filename=='Braid-receipt-clock-test.json')
 check('receipt remains rejected after export',state['messages'][0]['stage']=='rejected')
 page.screenshot(path=str(OUT/'clock-receipt-desktop.png'))
 page.click('#wanButton');page.wait_for_selector('#wanDialog',state='visible');page.press('#wanDialog','Escape');page.wait_for_selector('#wanDialog',state='hidden')
 check('Escape closes the WAN dialog',not page.locator('#wanDialog').is_visible())
 page.click('#wanButton');page.wait_for_selector('#wanDialog',state='visible');page.click('#wanDone');page.wait_for_selector('#wanDialog',state='hidden')
 check('Done closes the WAN dialog',not page.locator('#wanDialog').is_visible())
 page.click('#composeButton')
 check('composer still opens blank',page.input_value('#sourceText')=='' and page.input_value('#composeTitle')=='')
 check('no JavaScript exceptions',not errors)
 (OUT/'browser.json').write_text(json.dumps({'passed':True,'count':len(checks),'checks':checks,'errors':errors,'geometry':sizes,'method':'Production HTML/CSS/JS rendered in system Chromium on Linux with synthetic API bridge. Not native Safari/Edge or a phone browser; WebKit installation was unavailable because external DNS/download failed.'},indent=2))
 browser.close()
