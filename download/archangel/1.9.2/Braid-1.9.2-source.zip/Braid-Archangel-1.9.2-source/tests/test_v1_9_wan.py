"""1.9 WAN: real TLS/crypto/storage, explicit deterministic local-model fixtures.
No production relay, real user identity, or physical network is touched.
"""
import base64, copy, hashlib, http.client, json, socket, ssl, threading, time, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pytest
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519,x25519
from braid_client import wan_protocol as p
from braid_client.wan_relay import RelayStore,RelayHTTPServer,_expiry
from braid_client.managed_wan import RelayClient,WanController
from tests.test_v1_7_0a6_channels import pair,route,linked,policy,approve
from tests.test_v1_5_2_semantic_capsule import COMPLETE

@pytest.fixture
def keys():return ed25519.Ed25519PrivateKey.generate(),ed25519.Ed25519PrivateKey.generate(),x25519.X25519PrivateKey.generate(),x25519.X25519PrivateKey.generate()

def packet(keys,**kw):
 a,b,ax,bx=keys
 return p.seal(a,p.fingerprint(p.public_hex(b)),p.public_hex(bx),'FMTEST',{'kind':'test','text':'private amber'},**kw)

def test_sealed_roundtrip_ciphertext_and_randomization(keys):
 a,b,ax,bx=keys;x=packet(keys);y=packet(keys)
 assert x['ciphertext']!=y['ciphertext'] and x['ephemeral_key']!=y['ephemeral_key']
 assert b'private amber' not in p.canonical(x)
 assert p.open_packet(x,p.public_hex(a),bx,p.fingerprint(p.public_hex(b)),'FMTEST')['text']=='private amber'

@pytest.mark.parametrize('field,value',[('member','OTHER'),('recipient','a'*64),('sender','a'*64),('ephemeral_key','a'*64),('nonce','0'*24),('expires',2),('ciphertext','YQ=='),('suite','wrong'),('signature','0'*128)])
def test_packet_tamper(keys,field,value):
 a,b,ax,bx=keys;x=packet(keys);x[field]=value
 with pytest.raises(Exception):p.open_packet(x,p.public_hex(a),bx,p.fingerprint(p.public_hex(b)),'FMTEST')

@pytest.mark.parametrize('mode',['key','member','recipient','signature'])
def test_wrong_recipient_authority(keys,mode):
 a,b,ax,bx=keys;x=packet(keys)
 with pytest.raises(Exception):p.open_packet(x,p.public_hex(b) if mode=='signature' else p.public_hex(a),ax if mode=='key' else bx,'e'*64 if mode=='recipient' else p.fingerprint(p.public_hex(b)),'OTHER' if mode=='member' else 'FMTEST')

@pytest.mark.parametrize('raw',[b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":1e999}',b'{"x":"\\ud800"}',b'\xff',b'['*30+b'0'+b']'*30,b'{"x":9223372036854775809999}'])
def test_strict_json(raw):
 with pytest.raises((ValueError,UnicodeError)):p.strict_json(raw)

@pytest.mark.parametrize('url',['http://relay.intersignal.org','https://evil.test','https://relay.intersignal.org.evil.test','https://user:pass@relay.intersignal.org','https://relay.intersignal.org/admin','https://127.0.0.1','https://relay.intersignal.org:22','https://relay.intersignal.org?secret=yes'])
def test_endpoint_restrictions(url):
 with pytest.raises(ValueError):p.relay_url(url)

def test_expiry_and_scope(keys):
 a,b,ax,bx=keys
 x=packet(keys,now=int(time.time())-20,ttl=1)
 with pytest.raises(ValueError):p.verify_packet(x,p.public_hex(a))
 assert p.verify_packet(x,p.public_hex(a),allow_expired=True)
 assert _expiry('2027-01-01T12:00:00+02:00')==_expiry('2027-01-01T10:00:00Z')

@pytest.fixture
def server(tmp_path):
 store=RelayStore(tmp_path/'relay')
 k=ed25519.Ed25519PrivateKey.generate();name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')]);now=datetime.now(timezone.utc)
 import ipaddress
 cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(k.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(days=1)).not_valid_after(now+timedelta(days=1)).add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost'),x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),critical=False).add_extension(x509.BasicConstraints(ca=True,path_length=None),critical=True).sign(k,None))
 cp=tmp_path/'cert.pem';kp=tmp_path/'key.pem';cp.write_bytes(cert.public_bytes(serialization.Encoding.PEM));kp.write_bytes(k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
 ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.minimum_version=ssl.TLSVersion.TLSv1_3;ctx.load_cert_chain(cp,kp)
 http=RelayHTTPServer(('127.0.0.1',0),store,ctx);t=threading.Thread(target=http.serve_forever,daemon=True);t.start()
 url=f'https://127.0.0.1:{http.server_address[1]}'
 yield store,url,cp.read_text(),http
 http.shutdown();http.server_close();t.join(2)

@pytest.fixture
def fleet(pair,server,monkeypatch):
 a,b,f=pair;store,url,ca,http=server
 monkeypatch.setattr(WanController,'start',lambda self:None)
 store.member('FMTEST',expires=int(time.time())+3600)
 for d in (a,b):
  d.wan.test_loopback=True
  activation=store.issue(d.wan.activation_request(),'FMTEST',url,ca_pem=ca,test_loopback=True)
  d.wan.activate(activation,True,p.fingerprint(store.public))
  d.wan.update_preferences({'enabled':True,'receive_notes':True})
  d.wan.publish_card()
 # Pair fixture exchanged the newly advertised 1.9 encryption keys already.
 a.wan.update_preferences({'routes':{b.fingerprint:'relay'}})
 b.wan.update_preferences({'routes':{a.fingerprint:'relay'}})
 return a,b,f,store

def pump(receiver):
 v=receiver.wan.client().call('poll')['envelope'];assert v
 receiver.wan._process(v);receiver.wan._upload_replies()
 return v

def test_activation_defaults_and_card_discovery(fleet):
 a,b,f,store=fleet
 assert a.wan.preferences['query_grants']=={}
 s=a.wan.discover();assert s['peers'][0]['device']==b.fingerprint
 assert a.wan.snapshot()['status']['device_limit']==2
 inspect=a.wan.inspect_peer(b.fingerprint);assert inspect['id']==b.fingerprint and inspect['signature_valid']
 assert 'enrollment_token' not in json.dumps(a.snapshot())

@pytest.mark.parametrize('mode',['wrong-device','wrong-fingerprint','unconfirmed','altered','expired'])
def test_activation_binding_rejects(fleet,server,mode):
 a,b,f,store=fleet;_,url,ca,_=server
 v=store.issue(a.wan.activation_request(),'FMTEST',url,ca_pem=ca,test_loopback=True)
 target=b if mode=='wrong-device' else a
 if mode=='altered':v['member']='OTHER'
 if mode=='expired':
  v.pop('signature');v['expires']=1;v=p.signed(store.key,v,b'BRAID-MEMBER-ACTIVATION-v1\0')
 with pytest.raises(ValueError):target.wan.activate(v,mode!='unconfirmed','0'*64 if mode=='wrong-fingerprint' else p.fingerprint(store.public))

def test_two_device_cap_and_revocation(fleet,server,keys):
 a,b,f,store=fleet;_,url,ca,_=server;k,_,x,_=keys
 activation=store.issue(p.join_request(k,p.public_hex(x),'third'),'FMTEST',url,ca_pem=ca,test_loopback=True)
 c=RelayClient({'member':'FMTEST','relay_url':url,'operator_key':store.public,'ca_pem':ca},k,test_loopback=True)
 with pytest.raises(ValueError,match='DEVICE_LIMIT'):c.call('enroll',{'enrollment_token':activation['enrollment_token']})
 store.revoke_device('FMTEST',b.fingerprint)
 with pytest.raises(ValueError,match='NOT_ENROLLED'):b.wan.client().call('status')
 assert c.call('enroll',{'enrollment_token':activation['enrollment_token']})['enrolled']

def test_note_through_real_tls_not_lan(fleet):
 a,b,f,store=fleet
 assert a.listener is None and b.listener is None
 r=a.send(b.fingerprint,'Project Cobalt is amber.','WAN note',handoff_id=uuid.uuid4().hex)
 assert r['stage']=='queued' and not r['receipt']['receiver_confirmed']
 assert len(b.messages())==0
 v=pump(b);assert b.messages()[0]['stage']=='indexed'
 a.wan.refresh_pending();out=a.messages()[0]
 assert out['stage']=='indexed' and out['payload']['receiver_signature_verified']
 with store.db() as db:
  raw=bytes(db.execute('SELECT envelope FROM packets').fetchone()[0])
 assert b'Project Cobalt' not in raw
 assert a.wan.outcome(r['receipt']['wan_request_id'])['state']=='indexed'
 # Relay redelivery is not re-ingested and does not produce another incoming note.
 b.wan._process(v);assert len(b.messages())==1

def test_channel_wan_permission_and_delivery(fleet):
 a,b,f,store=fleet;c=a.create_channel('Cobalt');b.import_channel(c['descriptor'],confirmed=True)
 policy(a,c,send_to=[b.fingerprint],use_in_chat=True);policy(b,c,receive_from=[a.fingerprint],use_in_chat=True)
 n=a.new_note(c['id'],'Project Cobalt is amber.');r=a.publish_note(n['id'],confirmed=True)
 assert r['payload']['outcomes'][0]['stage']=='queued'
 pump(b);a.wan.refresh_pending()
 assert a.get_note(n['id'])['state']=='shared'
 assert len(b.channel_scope(c['id'],True)[0])==1

@pytest.mark.parametrize('reason',['paused','removed','channel-denied'])
def test_receiver_denial_and_missing_approval(fleet,reason):
 a,b,f,store=fleet
 if reason=='channel-denied':
  c=a.create_channel('Closed');b.import_channel(c['descriptor'],confirmed=True);policy(a,c,send_to=[b.fingerprint]);n=a.new_note(c['id'],'Private amber');r=a.publish_note(n['id'],confirmed=True)['payload']['outcomes'][0]
 else:r=a.send(b.fingerprint,'Private amber','test',handoff_id=uuid.uuid4().hex)
 if reason=='paused':b.wan.update_preferences({'receive_notes':False})
 if reason=='removed':
  b.remove_contact(a.fingerprint)
  v=b.wan.client().call('poll')['envelope']
  with pytest.raises(ValueError):b.wan._process(v)
  assert not b.messages();return
 pump(b);a.wan.refresh_pending()
 assert a.messages()[0]['stage']=='rejected' and not any(m['stage']=='indexed' for m in b.messages())

def test_after_commit_failure_stays_unknown(fleet,monkeypatch):
 a,b,f,store=fleet;orig=b.receive
 def fail(raw,**kw):orig(raw,**kw);raise OSError('simulated after commit')
 monkeypatch.setattr(b,'receive',fail)
 r=a.send(b.fingerprint,'amber','test',handoff_id=uuid.uuid4().hex)
 pump(b);a.wan.refresh_pending()
 assert len(b.messages())==1 and a.messages()[0]['stage']=='outcome_unknown'

def test_lost_enqueue_response_no_resend(fleet,monkeypatch):
 a,b,f,store=fleet;original=a.wan.client
 class Drop:
  def call(self,action,data=None):
   r=original().call(action,data)
   if action=='enqueue':raise TimeoutError('reply lost')
   return r
 monkeypatch.setattr(a.wan,'client',lambda:Drop())
 hid=uuid.uuid4().hex;r=a.send(b.fingerprint,'amber','test',handoff_id=hid)
 assert r['stage']=='outcome_unknown'
 assert a.send(b.fingerprint,'amber','test',handoff_id=hid)['already_recorded']
 with store.db() as db:assert db.execute('SELECT COUNT(*) FROM packets').fetchone()[0]==1
 pump(b);a.wan.refresh_pending();assert a.messages()[0]['stage']=='indexed'

def test_membership_and_cross_account(fleet,server,keys):
 a,b,f,store=fleet;_,url,ca,_=server;k,_,x,_=keys
 store.member('OTHER',expires=int(time.time())+3600)
 activation=store.issue(p.join_request(k,p.public_hex(x),'other'),'OTHER',url,ca_pem=ca,test_loopback=True)
 c=RelayClient(dict(member='OTHER',relay_url=url,operator_key=store.public,ca_pem=ca),k,test_loopback=True)
 c.call('enroll',{'enrollment_token':activation['enrollment_token']})
 assert c.call('peers')['peers']==[]
 envelope=p.seal(k,b.fingerprint,b.wan.encryption_public,'OTHER',{'kind':'test'})
 with pytest.raises(ValueError,match='NOT_ENROLLED'):c.call('enqueue',{'envelope':envelope})
 store.set_member_enabled('FMTEST',False)
 with pytest.raises(ValueError,match='INACTIVE'):a.wan.client().call('status')
 store.set_member_enabled('FMTEST',True);assert a.wan.client().call('status')['status']['devices']==2

def test_request_replay_and_signature(fleet):
 a,b,f,store=fleet;req=p.make_request(a.key,'FMTEST','status',{})
 store.apply(req)
 with pytest.raises(ValueError,match='REPLAY'):store.apply(req)
 req=p.make_request(a.key,'FMTEST','status',{});req['device']=b.fingerprint
 with pytest.raises(ValueError,match='SIGNATURE'):store.apply(req)
 with pytest.raises(ValueError,match='CLOCK'):store.apply(p.make_request(a.key,'FMTEST','status',{},now=1))

def query_setup(fleet,monkeypatch):
 a,b,f,store=fleet;c=b.create_channel('Home research');a.import_channel(c['descriptor'],confirmed=True)
 policy(b,c,send_to=[a.fingerprint],use_in_chat=True)
 b.settings['completion_model']=COMPLETE
 import braid_client.channel_chat as cc
 real=cc.query_channel_chat
 monkeypatch.setattr(cc,'query_channel_chat',lambda **kw:real(**kw,base_url=f.url))
 b.wan.update_preferences({'query_grants':{a.fingerprint:[c['id']]}})
 return a,b,f,store,c

def test_remote_query_real_model_adapter_and_count(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'Tell me about this channel.');pump(b);a.wan.refresh_pending()
 result=a.wan.outcome(r['wan_request_id'])
 assert result['state']=='answered' and result['result']['shared_note_count']==0
 assert result['result']['answered_on']=='Linux fixture' and len(f.server.chat_messages)==1
 assert result['result']['remote_execution'] is True
 assert 'completion_draft' not in result['result'] and 'enrollment_token' not in str(result)

@pytest.mark.parametrize('mode',['no-grant','not-send-to','chat-disabled','archived','paused'])
def test_remote_query_permissions(fleet,monkeypatch,mode):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 if mode=='no-grant':b.wan.update_preferences({'query_grants':{}})
 if mode=='not-send-to':policy(b,c,send_to=[])
 if mode=='chat-disabled':policy(b,c,use_in_chat=False)
 if mode=='archived':policy(b,c,archived=True)
 if mode=='paused':policy(b,c,paused=True)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'hello');pump(b);a.wan.refresh_pending()
 assert a.wan.outcome(r['wan_request_id'])['state']=='rejected' and not f.server.chat_messages

def test_revoke_query_during_generation(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 import braid_client.channel_chat as cc;orig=cc.query_channel_chat
 def revoke(**kw):
  r=orig(**kw);b.wan.update_preferences({'query_grants':{}});return r
 monkeypatch.setattr(cc,'query_channel_chat',revoke)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'hello');pump(b);a.wan.refresh_pending()
 # The receiver withholds all cached answer material after scope revocation.
 assert a.wan.outcome(r['wan_request_id'])['state']=='queued'
 with b._db() as db:assert db.execute('SELECT state FROM wan19_in').fetchone()[0]=='withheld'

def test_revoke_publisher_before_reply_export(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'hello')
 v=b.wan.client().call('poll')['envelope'];b.wan._process(v)
 policy(b,c,use_in_chat=False)
 b.wan._upload_replies();a.wan.refresh_pending()
 assert a.wan.outcome(r['wan_request_id'])['state']=='queued'

def test_bad_reply_never_becomes_success(fleet):
 a,b,f,store=fleet;r=a.send(b.fingerprint,'amber','test',handoff_id=uuid.uuid4().hex)
 envelope=b.wan.client().call('poll')['envelope'];body={'kind':'reply','operation':'frame','request_id':envelope['id'],'request_sha256':hashlib.sha256(p.canonical(envelope)).hexdigest(),'result':{'transport_sha256':'0'*64,'phase_b_committed':True,'accepted':True,'stored':True,'field_indexed':True}}
 response=p.seal(b.key,a.fingerprint,a.wan.encryption_public,'FMTEST',body)
 b.wan.client().call('reply',{'id':envelope['id'],'envelope':response})
 with pytest.raises(ValueError,match='FRAME_DIGEST'):a.wan.refresh_pending()
 assert a.messages()[0]['stage']=='queued'

def test_relay_not_a_generic_proxy(server):
 store,url,ca,relay_http=server
 ctx=ssl.create_default_context(cadata=ca);c=http.client.HTTPSConnection('127.0.0.1',relay_http.server_address[1],context=ctx)
 c.request('GET','/api/messenger/state');r=c.getresponse();assert r.status==404;r.read();c.close()
 c=http.client.HTTPSConnection('127.0.0.1',relay_http.server_address[1],context=ctx)
 c.request('POST',p.API+'/rpc','{}',{'Content-Type':'application/json','Origin':'https://evil.test'});r=c.getresponse();assert r.status==403;r.read();c.close()

def test_remote_answer_has_actual_shared_note_evidence(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 policy(a,c,send_to=[b.fingerprint]);policy(b,c,receive_from=[a.fingerprint])
 phrase='Spend no more than 500 credits on the second server today.'
 n=a.new_note(c['id'],phrase);a.publish_note(n['id'],confirmed=True);pump(b);a.wan.refresh_pending()
 r=a.wan.ask_remote(b.fingerprint,c['id'],phrase);pump(b);a.wan.refresh_pending()
 answer=a.wan.outcome(r['wan_request_id'])['result']
 assert answer['shared_note_count']==1 and answer['supplied_notes'][0]['text']==phrase
 assert phrase in f.server.chat_messages[-1][-1]['content']
 assert answer['receiver_signature_verified'] is True

def test_restart_preserves_cached_reply_without_reexecuting(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'hello');v=b.wan.client().call('poll')['envelope'];b.wan._process(v)
 count=len(f.server.chat_messages);b.wan.close();b.wan=WanController(b,test_loopback=True)
 b.wan._process(v);assert len(f.server.chat_messages)==count
 b.wan._upload_replies();a.wan.refresh_pending();assert a.wan.outcome(r['wan_request_id'])['state']=='answered'

def test_interrupted_incoming_not_executed_again(fleet):
 a,b,f,store=fleet;r=a.send(b.fingerprint,'amber','x',handoff_id=uuid.uuid4().hex);v=b.wan.client().call('poll')['envelope']
 with b._db() as db:db.execute("INSERT INTO wan19_in(id,peer,sha,state,envelope,response,created) VALUES (?,?,?,?,?,?,?)",(v['id'],a.fingerprint,hashlib.sha256(p.canonical(v)).hexdigest(),'processing',p.canonical(v).decode(),'{}',time.time()))
 b.wan.close();b.wan=WanController(b,test_loopback=True);b.wan._process(v);b.wan._upload_replies();a.wan.refresh_pending()
 assert not b.messages() and a.messages()[0]['stage']=='outcome_unknown'

def test_outer_sender_cannot_borrow_inner_signer(fleet):
 from braid_client.messenger import build_frame_from_text
 a,b,f,store=fleet
 frame,raw,_,_=build_frame_from_text(Path(b.settings['route_path']),'amber',b.key)
 r=a.wan._persist_out(b.fingerprint,'frame',{'kind':'frame','frame':base64.b64encode(raw).decode(),'transport_sha256':hashlib.sha256(raw).hexdigest()})
 v=pump(b)
 assert not b.messages()
 with b._db() as db:row=db.execute('SELECT response FROM wan19_in WHERE id=?',(v['id'],)).fetchone()
 reply=p.open_packet(p.strict_json(row['response']),b.public_key,a.wan.key,a.fingerprint,'FMTEST')
 assert reply['result']['phase_b_committed'] is False

def test_suspension_preserves_lan(fleet):
 a,b,f,store=fleet;store.set_member_enabled('FMTEST',False)
 a.wan.update_preferences({'enabled':False,'routes':{b.fingerprint:'lan'}});b.start_listener()
 r=a.send(b.fingerprint,'amber','still local',handoff_id=uuid.uuid4().hex)
 assert r['stage']=='indexed' and b.messages()[0]['stage']=='indexed'

def test_queue_and_account_quota(fleet):
 a,b,f,store=fleet
 store.member('FMTEST',expires=int(time.time())+3600,month_limit=1)
 with pytest.raises(ValueError,match='BANDWIDTH'):a.wan.client().call('enqueue',{'envelope':p.seal(a.key,b.fingerprint,b.wan.encryption_public,'FMTEST',{'kind':'x'})})
 store.member('FMTEST',expires=int(time.time())+3600,queue_limit=1)
 with pytest.raises(ValueError,match='QUEUE_LIMIT'):a.wan.client().call('enqueue',{'envelope':p.seal(a.key,b.fingerprint,b.wan.encryption_public,'FMTEST',{'kind':'x'})})

def test_operator_key_loss_fails_closed(server):
 store,_,_,_=server;(store.root/'operator-signing.pem').unlink()
 with pytest.raises(ValueError,match='refusing silent rotation'):RelayStore(store.root)

def test_envelope_expiry_is_not_rejection(fleet):
 a,b,f,store=fleet
 v=p.seal(a.key,b.fingerprint,b.wan.encryption_public,'FMTEST',{'kind':'x'},ttl=1)
 a.wan.client().call('enqueue',{'envelope':v});time.sleep(1.05)
 assert b.wan.client().call('poll')['envelope'] is None
 result=a.wan.client().call('result',{'id':v['id']})
 assert result['state']=='unconfirmed' and result['receiver_confirmed'] is False

def test_pinned_encryption_key_cannot_silently_change(fleet):
 a,b,f,store=fleet;card=b.export_card();card.pop('signature');card['wan']['encryption_key']=p.public_hex(x25519.X25519PrivateKey.generate());card=p.signed(b.key,card,b'BRAID-RIG-CARD-v1\0')
 with pytest.raises(ValueError,match='encryption identity changed'):a.inspect_card(card)

def test_control_response_binding(keys):
 a,b,ax,bx=keys;r=p.make_request(a,'FMTEST','status',{});other=p.make_request(a,'FMTEST','status',{})
 v=p.server_response(b,r,{'ok':True});assert p.check_response(v,p.public_hex(b),r)['ok']
 with pytest.raises(ValueError,match='BINDING'):p.check_response(v,p.public_hex(b),other)

def test_low_order_encryption_key_refused(keys):
 with pytest.raises(ValueError):p.rig_wan({'wan':{'protocol':p.CAPABILITY,'encryption_key':'0'*64}})

def test_new_endpoint_csrf_and_local_only(pair):
 from braid_client.messenger_http import MessengerHTTPServer,MessengerHandler
 a,b,f=pair;h=MessengerHTTPServer(('127.0.0.1',0),MessengerHandler);h.messenger=a
 t=threading.Thread(target=h.serve_forever,daemon=True);t.start()
 try:
  conn=http.client.HTTPConnection('127.0.0.1',h.server_address[1]);conn.request('POST','/api/messenger/wan','{"action":"status"}',{'Content-Type':'application/json'});r=conn.getresponse();assert r.status==403;r.read();conn.close()
  conn=http.client.HTTPConnection('127.0.0.1',h.server_address[1]);conn.request('POST','/api/messenger/wan','{"action":"status"}',{'Content-Type':'application/json','X-Braid-CSRF':a.csrf});r=conn.getresponse();assert r.status==200 and not json.loads(r.read())['configured'];conn.close()
 finally:h.shutdown();h.server_close();t.join(2)

def test_pause_still_works_after_peer_revocation(fleet):
 a,b,f,store=fleet;a.remove_contact(b.fingerprint)
 result=a.wan.update_preferences({'enabled':False})
 assert not result['preferences']['enabled'] and result['preferences']['routes']=={}

def test_offline_no_fallback_to_lan(fleet,monkeypatch):
 a,b,f,store=fleet
 import braid_client.messenger as core
 monkeypatch.setattr(core,'send_frame',lambda *a,**kw:pytest.fail('Silent LAN fallback'))
 a.wan.update_preferences({'enabled':False})
 r=a.send(b.fingerprint,'amber','off',handoff_id=uuid.uuid4().hex)
 assert r['stage']=='failed' and not b.messages()

def test_query_failure_does_not_expose_paths(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 import braid_client.channel_chat as cc
 def fail(**kw):raise RuntimeError('/private/home/person/secretfile was unavailable')
 monkeypatch.setattr(cc,'query_channel_chat',fail)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'hello');pump(b);a.wan.refresh_pending()
 result=a.wan.outcome(r['wan_request_id'])
 assert result['state']=='rejected' and '/private/home' not in str(result['result'])
 assert '/private/home' in b.wan.live['intake_error']

def test_receiver_rechecks_ttl_even_with_malicious_relay(fleet):
 a,b,f,store=fleet;v=p.seal(a.key,b.fingerprint,b.wan.encryption_public,'FMTEST',{'kind':'query','channel':'f'*64,'question':'hello'},ttl=86400)
 with pytest.raises(ValueError,match='REQUEST_TTL'):b.wan._process(v)
 assert not f.server.chat_messages

def test_tls_certificate_verification_required(fleet,server):
 a,b,f,store=fleet;_,url,ca,h=server
 c=RelayClient({'member':'FMTEST','relay_url':url,'operator_key':store.public},a.key,test_loopback=True)
 with pytest.raises(ssl.SSLError):c.call('status')

def test_duplicate_packet_does_not_charge_again(fleet):
 a,b,f,store=fleet;v=p.seal(a.key,b.fingerprint,b.wan.encryption_public,'FMTEST',{'kind':'x'})
 a.wan.client().call('enqueue',{'envelope':v});before=a.wan.client().call('status')['status']['month_bytes']
 a.wan.client().call('enqueue',{'envelope':v});after=a.wan.client().call('status')['status']['month_bytes']
 assert before==after
 with store.db() as db:assert db.execute('SELECT COUNT(*) FROM packets').fetchone()[0]==1

def test_activation_reissue_invalidates_previous_token(fleet,server):
 a,b,f,store=fleet;_,url,ca,_=server
 old=store.issue(a.wan.activation_request(),'FMTEST',url,ca_pem=ca,test_loopback=True)
 new=store.issue(a.wan.activation_request(),'FMTEST',url,ca_pem=ca,test_loopback=True)
 with pytest.raises(ValueError,match='ENROLLMENT'):a.wan.client().call('enroll',{'enrollment_token':old['enrollment_token']})
 assert a.wan.client().call('enroll',{'enrollment_token':new['enrollment_token']})['enrolled']

def test_maintenance_retention(server):
 store,_,_,_=server
 with store.db() as db:db.execute('INSERT INTO packets(member,id,sender,recipient,sha,envelope,expires,created) VALUES (?,?,?,?,?,?,?,?)',('expired','a'*32,'b'*64,'c'*64,'d'*64,b'{}',int(time.time())-86401,time.time()-90000))
 store.maintenance()
 assert store.summary()['retained_packets']==0

def test_missing_optional_wan_key_does_not_break_lan(fleet):
 a,b,f,store=fleet;a.wan.close();(a.home/'wan'/'encryption.key').unlink()
 a.wan=WanController(a,test_loopback=True)
 assert not a.wan.preferences['enabled'] and 'key unavailable' in a.wan.snapshot()['error']
 assert a.export_card().get('wan') is None
 a.wan.update_preferences({'routes':{b.fingerprint:'lan'}})
 b.start_listener();r=a.send(b.fingerprint,'amber','local works',handoff_id=uuid.uuid4().hex)
 assert r['stage']=='indexed'


def test_lower_device_limit_refuses_unrevoked_surplus(fleet,server,keys):
 a,b,f,store=fleet;_,url,ca,_=server;k,_,x,_=keys
 store.member('FMTEST',devices=3,expires=int(time.time())+3600)
 v=store.issue(p.join_request(k,p.public_hex(x),'third'),'FMTEST',url,ca_pem=ca,test_loopback=True)
 c=RelayClient(dict(member='FMTEST',relay_url=url,operator_key=store.public,ca_pem=ca),k,test_loopback=True);c.call('enroll',{'enrollment_token':v['enrollment_token']})
 with pytest.raises(ValueError,match='Revoke surplus'):store.member('FMTEST',devices=2,expires=int(time.time())+3600)


def test_check_query_fetches_without_reexecution(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'What can you establish?');pump(b)
 with store.db() as db:before=db.execute('SELECT COUNT(*) FROM packets').fetchone()[0]
 out=a.wan.check_query(r['wan_request_id']);assert out['state']=='answered'
 assert len(f.server.chat_messages)==1
 assert a.wan.check_query(r['wan_request_id'])['state']=='answered'
 with store.db() as db:assert db.execute('SELECT COUNT(*) FROM packets').fetchone()[0]==before


def test_withheld_query_is_never_reexecuted(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch)
 r=a.wan.ask_remote(b.fingerprint,c['id'],'What can you establish?')
 env=b.wan.client().call('poll')['envelope'];b.wan._process(env)
 b.wan.update_preferences({'query_grants':{}});b.wan._upload_replies()
 with b._db() as db:assert db.execute('SELECT state FROM wan19_in').fetchone()[0]=='withheld'
 b.wan.update_preferences({'query_grants':{a.fingerprint:[c['id']]}})
 def forbidden(*args,**kw):raise AssertionError('Query reexecuted after withholding')
 monkeypatch.setattr('braid_client.channel_chat.query_channel_chat',forbidden)
 b.wan._process(env)
 with b._db() as db:assert db.execute('SELECT state FROM wan19_in').fetchone()[0]=='withheld'


def test_real_background_polling_completes_without_lan(pair,server):
 a,b,f=pair;store,url,ca,_=server
 store.member('BACKGROUND',expires=int(time.time())+3600)
 for d in (a,b):
  d.wan.test_loopback=True
  activation=store.issue(d.wan.activation_request(),'BACKGROUND',url,ca_pem=ca,test_loopback=True)
  d.wan.activate(activation,True,p.fingerprint(store.public))
  d.wan.update_preferences({'enabled':True,'receive_notes':True})
 a.wan.update_preferences({'routes':{b.fingerprint:'relay'}})
 assert a.listener is None and b.listener is None
 r=a.send(b.fingerprint,'Background relay test amber.','background',handoff_id=uuid.uuid4().hex)
 deadline=time.monotonic()+40
 while time.monotonic()<deadline:
  if a.wan.outcome(r['receipt']['wan_request_id'])['state']=='indexed':break
  time.sleep(.2)
 assert a.wan.outcome(r['receipt']['wan_request_id'])['state']=='indexed'
 assert b.messages()[0]['stage']=='indexed'
 a.wan.update_preferences({'enabled':False});b.wan.update_preferences({'enabled':False})


@pytest.mark.parametrize('headers,body',[
 (['Content-Length: 2','Content-Length: 2'],'{}'),
 (['Content-Length: 2','Transfer-Encoding: chunked'],'{}'),
 (['Content-Length: 999999999'],'{}'),
 (['Content-Length: 13'],'{"x":1,"x":2}'),
 (['Content-Length: 2','Origin: https://outside.invalid'],'{}'),
])
def test_real_relay_http_rejects_ambiguous_or_browser_request(server,headers,body):
 store,url,ca,http=server;ctx=ssl.create_default_context(cadata=ca)
 with ctx.wrap_socket(socket.create_connection(http.server_address,timeout=5),server_hostname='localhost') as sock:
  req='POST '+p.API+'/rpc HTTP/1.0\r\nHost: localhost\r\nContent-Type: application/json\r\n'+'\r\n'.join(headers)+'\r\n\r\n'+body
  sock.sendall(req.encode());data=sock.recv(4096)
  assert b'403' in data.split(b'\r\n',1)[0]
 with store.db() as db:assert db.execute('SELECT COUNT(*) FROM packets').fetchone()[0]==0


def test_explicit_query_check_paused_does_not_contact_relay(fleet,monkeypatch):
 a,b,f,store,c=query_setup(fleet,monkeypatch);r=a.wan.ask_remote(b.fingerprint,c['id'],'hello')
 a.wan.update_preferences({'enabled':False})
 monkeypatch.setattr(a.wan,'client',lambda:(_ for _ in ()).throw(AssertionError('network while paused')))
 with pytest.raises(ValueError,match='paused'):a.wan.check_query(r['wan_request_id'])


def test_disconnect_never_replays_or_blocks_next_activation(fleet,server):
 a,b,f,store=fleet;_,url,ca,_=server
 sent=a.send(b.fingerprint,'old account queued note','old',handoff_id=uuid.uuid4().hex)
 envelope=b.wan.client().call('poll')['envelope'];b.wan._process(envelope)
 a.wan.clear_activation(True);b.wan.clear_activation(True)
 assert a.wan.outcome(sent['receipt']['wan_request_id'])['state']=='activation_changed'
 assert a.messages()[0]['stage']=='outcome_unknown'
 with b._db() as db:
  row=db.execute('SELECT state,response FROM wan19_in').fetchone();assert row['state']=='withheld' and row['response']=='{}'
 store.member('NEWACCOUNT',expires=int(time.time())+3600)
 for d in (a,b):
  v=store.issue(d.wan.activation_request(),'NEWACCOUNT',url,ca_pem=ca,test_loopback=True)
  d.wan.activate(v,True,p.fingerprint(store.public));d.wan.update_preferences({'enabled':True,'receive_notes':True})
 a.wan.update_preferences({'routes':{b.fingerprint:'relay'}})
 r=a.send(b.fingerprint,'new account note','new',handoff_id=uuid.uuid4().hex)
 pump(b);a.wan.refresh_pending()
 assert a.wan.outcome(r['receipt']['wan_request_id'])['state']=='indexed'
 assert len(b.messages())==2


def test_signed_delta_uses_same_wan_acceptance_path(fleet):
 a,b,f,store=fleet
 seed=a.send(b.fingerprint,'Project Cobalt launch color is amber.','seed',handoff_id=uuid.uuid4().hex)
 pump(b);a.wan.refresh_pending()
 source=b.messages()[0]['payload']['object_digest']
 delta=b.field_action('delta',{'object_digest':source})
 sent=b.send(a.fingerprint,delta['text'],'delta back',kind='delta',object_digest=source,handoff_id=uuid.uuid4().hex)
 assert sent['stage']=='queued'
 pump(a);b.wan.refresh_pending()
 assert b.wan.outcome(sent['receipt']['wan_request_id'])['state']=='indexed'
 assert any(m['direction']=='in' and m['stage']=='indexed' for m in a.messages())
