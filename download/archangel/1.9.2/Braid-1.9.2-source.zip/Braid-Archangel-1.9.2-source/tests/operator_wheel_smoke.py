"""Installed operator CLI on temporary local state, NOT a droplet deployment."""
import datetime,hashlib,json,os,pathlib,subprocess,sys,tempfile,venv
wheel=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
checks=[]
def check(n,c):
 assert c,n
 checks.append(n);print('PASS',n,flush=True)
env={**os.environ};env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
with tempfile.TemporaryDirectory(prefix='braid-operator-') as tmp:
 root=pathlib.Path(tmp);runtime=root/'venv';venv.EnvBuilder(with_pip=True,system_site_packages=True).create(runtime);py=runtime/'bin/python'
 subprocess.run([str(py),'-m','pip','install','--no-index','--no-deps',str(wheel)],cwd=root,env=env,check=True,stdout=subprocess.DEVNULL)
 base=[str(runtime/'bin/braid-relay'),'--state',str(root/'state')]
 def run(*args):return subprocess.run(base+list(args),cwd=root,env=env,capture_output=True,text=True,timeout=20)
 r=run('status');check('installed relay entry point',r.returncode==0);fp=json.loads(r.stdout)['operator_fingerprint']
 until=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=7)).isoformat()
 r=run('member','INTERNAL','--devices','2','--expires',until);check('create internal two-device membership',r.returncode==0 and json.loads(r.stdout)['members'][0]['max_devices']==2)
 code="from cryptography.hazmat.primitives.asymmetric import ed25519,x25519;from braid_client import wan_protocol as p;from pathlib import Path;k=ed25519.Ed25519PrivateKey.generate();x=x25519.X25519PrivateKey.generate();Path('device.braidjoin').write_bytes(p.canonical(p.join_request(k,p.public_hex(x),'Operator test device')))"
 subprocess.run([str(py),'-c',code],cwd=root,env=env,check=True)
 r=run('issue','INTERNAL','--request',str(root/'device.braidjoin'),'--out',str(root/'activation.braidmember'))
 check('device-bound activation CLI',r.returncode==0 and (root/'activation.braidmember').exists())
 check('private activation file mode',((root/'activation.braidmember').stat().st_mode&0o777)==0o600)
 activation=json.loads((root/'activation.braidmember').read_text());check('production hostname in activation',activation['relay_url']=='https://relay.intersignal.org')
 check('refuses activation overwrite',run('issue','INTERNAL','--request',str(root/'device.braidjoin'),'--out',str(root/'activation.braidmember')).returncode!=0)
 r=run('suspend','INTERNAL');check('suspend membership',r.returncode==0 and json.loads(r.stdout)['members'][0]['enabled']==0)
 r=run('member','INTERNAL','--devices','3','--expires',until);check('capacity update does not undo suspension',r.returncode==0 and json.loads(r.stdout)['members'][0]['enabled']==0)
 r=run('resume','INTERNAL');check('explicit resume',r.returncode==0 and json.loads(r.stdout)['members'][0]['enabled']==1)
 r=run('revoke-device','INTERNAL',activation['device']);check('device revocation CLI',r.returncode==0)
 check('operator identity retained',json.loads(run('status').stdout)['operator_fingerprint']==fp)
 check('refuses public unencrypted listener',run('serve','--bind','0.0.0.0').returncode!=0)
 (out/'operator-smoke.json').write_text(json.dumps({'passed':True,'checks':checks,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'method':'Actual wheel/console entry point in explicit host-linked temporary venv, local temporary account state. No production network, real member, systemd install, provider bill, or private input.'},indent=2))
