"""1.9.2 regression: unchanged temporal gate, optional WAN, source boundaries."""
from pathlib import Path
from unittest.mock import patch
import pytest
from braid_client.mcp_core.protocol import ReplayLedger
from braid_client.messenger import MessengerService
from cryptography.hazmat.primitives.asymmetric import ed25519

@pytest.mark.parametrize('ahead,expected', [(0,True),(5,True),(6,False),(8,False)])
def test_future_timestamp_allowance_still_five_seconds(tmp_path,ahead,expected):
    ledger=ReplayLedger(str(tmp_path/'replay.db'))
    with patch('braid_client.mcp_core.protocol.time.time',return_value=1789087115):
        ok,why=ledger.check_replay_phase_a('receiver','signer','route','new-session',1,
                                         1789087115+ahead,1789087415+ahead)
    assert ok is expected
    if not expected: assert 'ERR_FUTURE_TIMESTAMP' in why
    assert ledger.clock_skew==5

def test_lan_control_does_not_grant_wan(tmp_path):
    desk=MessengerService(ed25519.Ed25519PrivateKey.generate(),tmp_path/'inbox',tmp_path/'home')
    try:
        assert desk.wan.preferences['enabled'] is False
        assert desk.wan.preferences['receive_notes'] is False
        assert desk.wan.preferences['query_grants']=={}
        assert not desk.wan.config
        # Stopping the listener is safe whether it was never started or stopped before.
        desk.stop_listener()
        assert desk.wan.preferences['enabled'] is False
        assert desk.wan.preferences['query_grants']=={}
    finally: desk.close()

def test_wan_dialog_has_definite_scoped_geometry():
    css=(Path(__file__).parents[1]/'braid_client/static/wan.css').read_text()
    assert '#wanDialog[open]' in css
    assert 'grid-template-rows: auto minmax(0, 1fr) auto' in css
    assert 'height: min(860px, calc(100dvh - 32px))' in css
    assert '#wanDialog > .modal-foot { position: static; }' in css

def test_receipt_export_is_local_not_send():
    js=(Path(__file__).parents[1]/'braid_client/static/messenger.js').read_text()
    fn=js.split('function saveReceipt(message)',1)[1].split('function renderReader',1)[0]
    assert 'message.payload' in fn and 'new Blob' in fn
    assert not any(x in fn for x in ('fetch(', 'await api(', 'job(', 'enrollment_token'))

# Real signed/encrypted receiver replies; no acceptance-gate stubbing.
from tests.test_v1_9_wan import fleet,server
from tests.test_v1_7_0a6_channels import pair,route
from braid_client import wan_protocol as p
import hashlib,uuid

@pytest.mark.parametrize('changes,expected', [
    ({},'rejected'),
    ({'phase_a_validated':None},'outcome_unknown'),
    ({'field_indexed':None},'outcome_unknown'),
    ({'accepted_and_indexed':None},'outcome_unknown'),
    ({'result_summary':'transport_unproven'},'outcome_unknown'),
    ({'phase_b_committed':None},'outcome_unknown'),
    ({'accepted':None},'outcome_unknown'),
    ({'field_indexed':True},'outcome_unknown'),
    ({'accepted_and_indexed':True},'outcome_unknown'),
    ({'stored':False,'field_indexed':True},'outcome_unknown'),
])
def test_authenticated_rejected_store_finality(fleet,changes,expected):
    a,b,f,store=fleet
    sent=a.send(b.fingerprint,'A harmless finality test.','Finality',handoff_id=uuid.uuid4().hex)
    envelope=b.wan.client().call('poll')['envelope']
    frame_hash=sent['receipt']['transport_sha256']
    report={'accepted':False,'stored':True,'phase_a_validated':False,'phase_b_committed':False,
            'field_indexed':False,'accepted_and_indexed':False,
            'result_summary':'REJECTED_BEFORE_PHASE_B','reason':'ERR_FUTURE_TIMESTAMP',
            'transport_sha256':frame_hash,**changes}
    body={'kind':'reply','operation':'frame','request_id':envelope['id'],
          'request_sha256':hashlib.sha256(p.canonical(envelope)).hexdigest(),'result':report}
    reply=p.seal(b.key,a.fingerprint,a.wan.encryption_public,'FMTEST',body)
    b.wan.client().call('reply',{'id':envelope['id'],'envelope':reply})
    a.wan.refresh_pending()
    result=a.wan.outcome(sent['receipt']['wan_request_id'])
    assert result['state']==expected
    assert result['result']['receiver_signature_verified'] is True
    assert a.messages()[0]['payload']['transport_sha256']==frame_hash
    # Never automatic: a status read has not created a second outbound packet.
    with store.db() as db:assert db.execute('SELECT COUNT(*) FROM packets').fetchone()[0]==1
