#!/bin/sh
# Folio 0.3.0: no installs, no network, no Braid profile mutation during discovery.
set -eu
HERE=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
PROBE='import sys, sqlite3, ssl
if sys.version_info < (3,10):
    raise SystemExit("Folio needs Python 3.10 or newer")
print("Python " + sys.version.split()[0] + " at " + sys.executable)'
try_python() {
    candidate=$1
    shift
    [ -f "$candidate" ] && [ -x "$candidate" ] || return 1
    if info=$("$candidate" -I -c "$PROBE" 2>&1); then
        printf 'Folio selected %s (via %s)\n' "$info" "$candidate"
        if [ "$#" -eq 1 ] && [ "$1" = '--runtime-info' ]; then exit 0; fi
        # Once selected, application errors must not trigger another launch.
        exec "$candidate" -I "$HERE/start_folio.py" "$@"
    fi
    return 1
}
[ -f "$HERE/start_folio.py" ] || { printf '%s\n' 'Keep this launcher with the complete Folio folder.' >&2; exit 1; }
if [ -n "${FOLIO_PYTHON:-}" ]; then
    candidate=$(command -v "$FOLIO_PYTHON" 2>/dev/null || true)
    [ -n "$candidate" ] || candidate=$FOLIO_PYTHON
    try_python "$candidate" "$@" || {
        printf '%s\n' 'FOLIO_PYTHON is not a usable Python 3.10+ runtime with sqlite3 and ssl. No fallback, download or installation was attempted.' >&2
        exit 1
    }
fi
for name in python3 python3.14 python3.13 python3.12 python3.11 python3.10 python; do
    candidate=$(command -v "$name" 2>/dev/null || true)
    if [ -n "$candidate" ]; then try_python "$candidate" "$@" || :; fi
done
# Finder often has a smaller PATH. Check only standard interpreter locations.
for version in 3.14 3.13 3.12 3.11 3.10; do
    for directory in /opt/homebrew/bin "/opt/homebrew/opt/python@$version/bin" \
        /usr/local/bin "/usr/local/opt/python@$version/bin" \
        "/Library/Frameworks/Python.framework/Versions/$version/bin" \
        /opt/local/bin "${HOME:-/nonexistent}/.local/bin" "${HOME:-/nonexistent}/.pyenv/shims"; do
        try_python "$directory/python$version" "$@" || :
    done
done
printf '%s\n' 'Folio needs an existing Python 3.10+ installation with sqlite3 and ssl.' \
    'It can use the Python installation already used by Braid. Set FOLIO_PYTHON to its executable if discovery misses it.' \
    'No software was downloaded or installed. No Braid data was changed.' >&2
exit 1
