"""Folio discovery requests with explicit Braid-side acceptance.

The rendezvous stores signed requests while a publisher is offline. It has no
authority to approve peers, import rig cards, or reveal channel state. Contact
cards are handled only after a separate, explicit exchange.
"""
from __future__ import annotations

import json
import os
import secrets
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit, parse_qs
from typing import Any

from . import wan_protocol as wire
from .channel_protocol import validate_channel_descriptor
from .folio_protocol import (AUTH_DOMAIN, AUTH_TYPE, DECISION_DOMAIN, DECISION_TYPE,
    PUBLICATION_DOMAIN, PUBLICATION_TYPE, REQUEST_DOMAIN, REQUEST_LIFETIME,
    FIRST_MESSAGE_DOMAIN,
    REQUEST_TYPE, CARD_DOMAIN, _id, publication_url, scopes, validate_card_share,
    validate_decision, validate_publication, validate_referral, validate_request)

DEFAULT_RENDEZVOUS = 'https://connect.intersignal.org'


def rendezvous_url(value: Any) -> str:
    if not isinstance(value, str) or len(value) > 256:
        raise ValueError('ERR_FOLIO_RENDEZVOUS_URL')
    parsed = urlsplit(value)
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/'):
        raise ValueError('ERR_FOLIO_RENDEZVOUS_URL')
    host = parsed.hostname or ''
    if parsed.scheme == 'https' and (host == 'intersignal.org' or host.endswith('.intersignal.org')) and parsed.port in (None, 443):
        return value.rstrip('/')
    if os.environ.get('BRAID_FOLIO_TEST_LOOPBACK') == '1' and parsed.scheme in ('http', 'https') and host in ('127.0.0.1', 'localhost', '::1'):
        return value.rstrip('/')
    raise ValueError('Use a first-party HTTPS Folio connection service.')


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('ERR_FOLIO_RENDEZVOUS_REDIRECT')


def _post(base: str, path: str, payload: dict, *, limit: int = 32768) -> dict:
    base = rendezvous_url(base)
    raw = wire.canonical(payload)
    if len(raw) > wire.MAX_CARD + 16384:
        raise ValueError('ERR_FOLIO_REQUEST_SIZE')
    request = urllib.request.Request(base + path, data=raw,
        headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, method='POST')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    try:
        with opener.open(request, timeout=8) as response:
            body = response.read(limit + 1)
            if len(body) > limit:
                raise ValueError('ERR_FOLIO_RENDEZVOUS_RESPONSE_SIZE')
            result = wire.strict_json(body, limit=limit)
            if not isinstance(result, dict):
                raise ValueError('ERR_FOLIO_RENDEZVOUS_RESPONSE')
            return result
    except urllib.error.HTTPError as exc:
        body = exc.read(2048)
        try:
            result = wire.strict_json(body, limit=2048)
            reason = result.get('error') or result.get('message')
        except Exception:
            reason = None
        raise ValueError(str(reason or 'ERR_FOLIO_RENDEZVOUS_HTTP')[:300]) from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise ValueError('ERR_FOLIO_RENDEZVOUS_UNAVAILABLE') from exc


class FolioConnectionMixin:
    def folio_readiness(self, data: dict) -> dict:
        base=rendezvous_url(data.get('rendezvous_url') or DEFAULT_RENDEZVOUS)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),_NoRedirect())
        try:
            with opener.open(base+'/health',timeout=4) as response:
                result=wire.strict_json(response.read(4097),limit=4096)
            if not isinstance(result,dict) or result.get('status')!='ok':
                raise ValueError('Invalid connection service response.')
            return {'ready':True,'download_available':result.get('download_available') is True}
        except (OSError,ValueError,urllib.error.URLError):
            return {'ready':False,'download_available':False}

    def folio_import_link(self, data: dict) -> dict:
        """Fetch only a bounded, signed referral at an allowlisted service origin.

        The link is a reference, never authority to send a request or share a card.
        Redirects, arbitrary URLs, and extra query keys are rejected before I/O.
        """
        value=data.get('url')
        if not isinstance(value,str) or len(value)>2048 or any(c.isspace() for c in value):
            raise ValueError('Paste the complete Continue this on Braid link.')
        try:
            url=urlsplit(value)
            base=rendezvous_url(url.scheme+'://'+url.netloc)
            query=parse_qs(url.query,keep_blank_values=True,strict_parsing=True)
            if url.path!='/continue' or url.fragment or set(query)-{'publication_id','source_network_id','edition_id'} or any(len(v)!=1 for v in query.values()):
                raise ValueError()
            ident=_id(query.get('publication_id',[''])[0],32)
            source=_id(query.get('source_network_id',[''])[0],64)
            edition=query.get('edition_id',[''])[0]
            if edition:_id(edition,32)
        except (ValueError,TypeError):
            raise ValueError('Use a complete Folio connection link from an Intersignal service.') from None
        route='/v1/referrals/'+ident+'.braidref'+('?edition_id='+edition if edition else '')
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),_NoRedirect())
        try:
            with opener.open(base+route,timeout=6) as response:
                referral=wire.strict_json(response.read(16385),limit=16384)
        except (OSError,urllib.error.URLError):
            raise ValueError('The invitation is unavailable. Check that the publisher still allows requests and try again.') from None
        checked=validate_referral(referral)
        if (checked['publication']['publication_id']!=ident or checked['publication']['source_network_id']!=source
                or checked.get('edition_id','')!=edition or rendezvous_url(checked.get('rendezvous_url'))!=base):
            raise ValueError('The signed invitation does not match this connection link.')
        return self.folio_import_referral(checked)

    def _init_folio(self):
        with self._db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS fc_publications (
                    id TEXT PRIMARY KEY, registration TEXT NOT NULL, rendezvous TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS fc_referrals (
                    id TEXT PRIMARY KEY, referral TEXT NOT NULL, rendezvous TEXT NOT NULL, created REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS fc_requests (
                    id TEXT PRIMARY KEY, direction TEXT NOT NULL, publication_id TEXT NOT NULL,
                    peer TEXT NOT NULL, status TEXT NOT NULL, request TEXT NOT NULL,
                    decision TEXT, rendezvous TEXT NOT NULL, channel_id TEXT,
                    created REAL NOT NULL);
                CREATE INDEX IF NOT EXISTS fc_requests_direction ON fc_requests(direction,status,created);
                CREATE TABLE IF NOT EXISTS fc_channels (
                    publication_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS fc_card_shares (
                    request_id TEXT PRIMARY KEY, shared_at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS fc_first_messages (
                    request_id TEXT PRIMARY KEY, payload TEXT NOT NULL,
                    rendezvous TEXT NOT NULL, recorded INTEGER NOT NULL DEFAULT 0);
            ''')

    def folio_identity(self) -> dict:
        return {'source_network_id': self.fingerprint, 'publisher_public_key': self.public_key}

    def folio_publication(self, data: dict) -> dict:
        """Publisher-signed capability; Folio calls this before enabled export."""
        publication_id = _id(data.get('publication_id'), 32)
        offered = scopes(data.get('offered_scopes'))
        enabled = data.get('requests_enabled')
        if type(enabled) is not bool:
            raise ValueError('ERR_FOLIO_REQUESTS_ENABLED')
        deleted = data.get('deleted', False)
        if type(deleted) is not bool or (deleted and enabled):
            raise ValueError('ERR_FOLIO_PUBLICATION_FLAGS')
        base = rendezvous_url(data.get('rendezvous_url') or DEFAULT_RENDEZVOUS)
        with self.lock, self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            previous = db.execute('SELECT registration,rendezvous FROM fc_publications WHERE id=?', (publication_id,)).fetchone()
            if previous and previous['rendezvous'] != base:
                raise ValueError('ERR_FOLIO_RENDEZVOUS_CHANGED')
            if previous:
                old = json.loads(previous['registration'])
                # Repeated export of the same capability is idempotent.
                if (old['requests_enabled'] == enabled and old['offered_scopes'] == offered
                        and old.get('deleted', False) == deleted):
                    registration = old
                else:
                    registration = wire.signed(self.key, {
                        'type': PUBLICATION_TYPE, 'version': 1, 'publication_id': publication_id,
                        'source_network_id': self.fingerprint, 'publisher_public_key': self.public_key,
                        'offered_scopes': offered, 'requests_enabled': enabled,
                        'revision': old['revision'] + 1, 'created_at': int(time.time()),
                        'deleted': deleted, 'expires_at': 0}, PUBLICATION_DOMAIN)
            else:
                registration = wire.signed(self.key, {
                    'type': PUBLICATION_TYPE, 'version': 1, 'publication_id': publication_id,
                    'source_network_id': self.fingerprint, 'publisher_public_key': self.public_key,
                    'offered_scopes': offered, 'requests_enabled': enabled,
                    'revision': 1, 'created_at': int(time.time()),
                    'deleted': deleted, 'expires_at': 0}, PUBLICATION_DOMAIN)
            validate_publication(registration)
            response = _post(base, '/v1/publications', {'publication': registration})
            if not isinstance(response.get('publication'), dict) or response['publication'].get('publication_id') != publication_id:
                raise ValueError('ERR_FOLIO_REGISTRATION_UNCONFIRMED')
            db.execute('INSERT OR REPLACE INTO fc_publications VALUES (?,?,?)',
                (publication_id, wire.canonical(registration).decode(), base))
        return {'publication': registration, 'rendezvous_url': base, 'source_network_id': self.fingerprint}

    def folio_import_referral(self, referral: dict) -> dict:
        r = validate_referral(referral)
        base = rendezvous_url(r.get('rendezvous_url'))
        pub = r['publication']
        if not pub['requests_enabled'] or pub.get('deleted') or (pub.get('expires_at') and pub['expires_at'] <= time.time()):
            raise ValueError('ERR_FOLIO_REQUESTS_DISABLED')
        with self._db() as db:
            db.execute('INSERT OR REPLACE INTO fc_referrals VALUES (?,?,?,?)',
                (pub['publication_id'], wire.canonical(r).decode(), base, time.time()))
        return {'publication_id': pub['publication_id'], 'source_network_id': pub['source_network_id'],
            'offered_scopes': pub['offered_scopes'], 'edition_id': r.get('edition_id', ''),
            'rendezvous_url': base, 'requester_id': self.fingerprint}

    def _referral(self, publication_id: str) -> tuple[dict, str]:
        with self._db() as db:
            row = db.execute('SELECT referral,rendezvous FROM fc_referrals WHERE id=?', (publication_id,)).fetchone()
        if not row:
            raise ValueError('Import the publication referral file first.')
        return validate_referral(json.loads(row['referral'])), row['rendezvous']

    def folio_send_request(self, data: dict) -> dict:
        publication_id = _id(data.get('publication_id'), 32)
        referral, base = self._referral(publication_id)
        publication = referral['publication']
        selected = scopes(data.get('requested_scope'))
        if not set(selected).issubset(publication['offered_scopes']):
            raise ValueError('ERR_FOLIO_SCOPE_NOT_OFFERED')
        message = data.get('message', '')
        if not isinstance(message, str) or len(message.encode('utf-8')) > 500 or any(ord(c) < 32 and c not in '\n\t' for c in message):
            raise ValueError('ERR_FOLIO_MESSAGE')
        url = publication_url(data.get('publication_url', ''))
        with self._db() as db:
            prior = db.execute("SELECT * FROM fc_requests WHERE direction='out' AND publication_id=? AND status!='expired' ORDER BY created DESC LIMIT 1", (publication_id,)).fetchone()
        if prior:
            return {'request_id': prior['id'], 'status': prior['status'], 'duplicate': True}
        now = int(time.time())
        request = wire.signed(self.key, {
            'type': REQUEST_TYPE, 'version': 1, 'request_id': secrets.token_hex(16),
            'publication_id': publication_id, 'source_network_id': publication['source_network_id'],
            'requester_id': self.fingerprint, 'requester_public_key': self.public_key,
            'requested_scope': selected, 'message': message, 'publication_url': url,
            'referral_id': referral.get('referral_id', ''), 'created_at': now,
            'expires_at': now + REQUEST_LIFETIME}, REQUEST_DOMAIN)
        validate_request(request, publication=publication)
        # Persist exact signed bytes before network action. An uncertain submit is
        # never rebuilt with a fresh request ID by an automatic retry.
        with self._db() as db:
            db.execute('INSERT INTO fc_requests VALUES (?,?,?,?,?,?,?,?,?,?)',
                (request['request_id'], 'out', publication_id, publication['source_network_id'],
                 'submission_unknown', wire.canonical(request).decode(), None, base, None, time.time()))
        response = _post(base, '/v1/requests', {'request': request})
        if response.get('status') == 'duplicate' and response.get('request_id') != request['request_id']:
            with self._db() as db:
                db.execute('DELETE FROM fc_requests WHERE id=? AND status=?',
                           (request['request_id'], 'submission_unknown'))
            existing = response.get('existing_status', 'pending')
            raise ValueError('This Braid identity already has a ' + str(existing) +
                             ' request for this publication. Open its original Braid profile to review it.')
        if response.get('request_id') != request['request_id'] or response.get('status') not in ('pending', 'duplicate'):
            raise ValueError('ERR_FOLIO_REQUEST_UNCONFIRMED')
        with self._db() as db:
            db.execute("UPDATE fc_requests SET status='pending' WHERE id=?", (request['request_id'],))
        return {'request_id': request['request_id'], 'status': 'pending', 'duplicate': response['status'] == 'duplicate'}

    def _folio_auth(self, *, request_id: str = '') -> dict:
        body = {'type': AUTH_TYPE, 'version': 1, 'timestamp': int(time.time()),
            'nonce': secrets.token_hex(16)}
        if request_id:
            body.update(request_id=_id(request_id, 32), requester_id=self.fingerprint,
                requester_public_key=self.public_key)
        else:
            body.update(source_network_id=self.fingerprint, publisher_public_key=self.public_key)
        return wire.signed(self.key, body, AUTH_DOMAIN)

    def folio_refresh_inbox(self) -> list[dict]:
        with self._db() as db:
            publications = db.execute('SELECT id,registration,rendezvous FROM fc_publications').fetchall()
        for pubrow in publications:
            pub = validate_publication(json.loads(pubrow['registration']))
            response = _post(pubrow['rendezvous'], '/v1/inbox',
                {'auth': self._folio_auth()}, limit=2 * 1024 * 1024)
            requests = response.get('requests')
            if not isinstance(requests, list) or len(requests) > 100:
                raise ValueError('ERR_FOLIO_INBOX_RESPONSE')
            for candidate in requests:
                if not isinstance(candidate, dict) or candidate.get('publication_id') != pub['publication_id']:
                    continue
                try:
                    req = validate_request(candidate, publication=pub)
                except ValueError as exc:
                    if str(exc) == 'ERR_FOLIO_REQUEST_EXPIRED':
                        continue
                    raise
                if req['publication_id'] != pub['publication_id']:
                    raise ValueError('ERR_FOLIO_INBOX_PUBLICATION')
                with self._db() as db:
                    db.execute('INSERT OR IGNORE INTO fc_requests VALUES (?,?,?,?,?,?,?,?,?,?)',
                        (req['request_id'], 'in', pub['publication_id'], req['requester_id'],
                         'pending', wire.canonical(req).decode(), None, pubrow['rendezvous'], None, time.time()))
        try:
            self.folio_flush_events()
        except Exception:
            pass
        return self.folio_requests('in')

    def folio_requests(self, direction: str = '') -> list[dict]:
        if direction not in ('', 'in', 'out'):
            raise ValueError('ERR_FOLIO_DIRECTION')
        with self._db() as db:
            rows = db.execute('SELECT * FROM fc_requests WHERE direction=? ORDER BY created DESC LIMIT 100', (direction,)).fetchall() if direction else db.execute('SELECT * FROM fc_requests ORDER BY created DESC LIMIT 100').fetchall()
            shared={r['request_id'] for r in db.execute('SELECT request_id FROM fc_card_shares')}
        return [{**dict(row), 'request': json.loads(row['request']),
                 'card_shared':row['id'] in shared,
                 'decision': json.loads(row['decision']) if row['decision'] else None} for row in rows]

    def _folio_channel(self, publication_id: str) -> dict:
        with self._db() as db:
            row = db.execute('SELECT channel_id FROM fc_channels WHERE publication_id=?', (publication_id,)).fetchone()
        if row:
            return self.channel(row['channel_id'])
        channel = self.create_channel('Folio ' + publication_id[:12], 'Publication-specific discussion')
        with self._db() as db:
            db.execute('INSERT OR IGNORE INTO fc_channels VALUES (?,?)', (publication_id, channel['id']))
        return channel

    def folio_decide(self, data: dict) -> dict:
        request_id = _id(data.get('request_id'), 32)
        decision_kind = data.get('decision')
        if decision_kind not in ('accepted', 'declined'):
            raise ValueError('ERR_FOLIO_DECISION')
        with self._db() as db:
            row = db.execute("SELECT * FROM fc_requests WHERE id=? AND direction='in'", (request_id,)).fetchone()
            if not row:
                raise ValueError('ERR_FOLIO_REQUEST_NOT_FOUND')
            if row['status'] != 'pending':
                raise ValueError('ERR_FOLIO_REQUEST_ALREADY_DECIDED')
            pubrow = db.execute('SELECT registration FROM fc_publications WHERE id=?', (row['publication_id'],)).fetchone()
        if not pubrow:
            raise ValueError('ERR_FOLIO_PUBLICATION_NOT_FOUND')
        pub = validate_publication(json.loads(pubrow['registration']))
        request = validate_request(json.loads(row['request']), publication=pub)
        if decision_kind == 'accepted' and (not pub['requests_enabled'] or pub.get('deleted')):
            raise ValueError('ERR_FOLIO_REQUESTS_DISABLED')
        if data.get('confirmed') is not True:
            raise ValueError('Confirm the exact publication permission before deciding.')
        granted = scopes(data.get('granted_scope'), allow_empty=decision_kind == 'declined') if decision_kind == 'accepted' else []
        if not set(granted).issubset(request['requested_scope']):
            raise ValueError('ERR_FOLIO_SCOPE_ESCALATION')
        channel = self._folio_channel(request['publication_id']) if decision_kind == 'accepted' else None
        decision = wire.signed(self.key, {
            'type': DECISION_TYPE, 'version': 1, 'request_id': request_id,
            'publication_id': request['publication_id'], 'source_network_id': self.fingerprint,
            'requester_id': request['requester_id'], 'decision': decision_kind,
            'granted_scope': granted, 'channel_descriptor': channel['descriptor'] if channel else None,
            'created_at': int(time.time())}, DECISION_DOMAIN)
        validate_decision(decision, {**request, '_publisher_public_key': self.public_key})
        response = _post(row['rendezvous'], '/v1/decisions', {'decision': decision})
        if response.get('request_id') != request_id or response.get('status') != decision_kind:
            raise ValueError('ERR_FOLIO_DECISION_UNCONFIRMED')
        with self._db() as db:
            db.execute('UPDATE fc_requests SET status=?,decision=?,channel_id=? WHERE id=?',
                (decision_kind, wire.canonical(decision).decode(), channel['id'] if channel else None, request_id))
        return {'request_id': request_id, 'status': decision_kind,
            'granted_scope': granted, 'channel_id': channel['id'] if channel else None,
            'card_exchange_required': decision_kind == 'accepted'}

    def folio_check_request(self, request_id: str) -> dict:
        request_id = _id(request_id, 32)
        with self._db() as db:
            row = db.execute("SELECT * FROM fc_requests WHERE id=? AND direction='out'", (request_id,)).fetchone()
        if not row:
            raise ValueError('ERR_FOLIO_REQUEST_NOT_FOUND')
        request = json.loads(row['request'])
        referral, _ = self._referral(row['publication_id'])
        response = _post(row['rendezvous'], '/v1/status', {'auth': self._folio_auth(request_id=request_id)})
        if response.get('request_id') != request_id or response.get('status') not in ('pending', 'accepted', 'declined', 'expired'):
            raise ValueError('ERR_FOLIO_STATUS_UNCONFIRMED')
        status = response['status']
        decision = response.get('decision')
        channel_id = None
        if status in ('accepted', 'declined'):
            validated = validate_decision(decision,
                {**request, '_publisher_public_key': referral['publication']['publisher_public_key']})
            if validated['decision'] != status:
                raise ValueError('ERR_FOLIO_STATUS_DECISION_MISMATCH')
            if status == 'accepted':
                channel = self.import_channel(validated['channel_descriptor'], confirmed=True)
                channel_id = channel['id']
                with self._db() as db:
                    db.execute('INSERT OR IGNORE INTO fc_channels VALUES (?,?)',
                        (request['publication_id'], channel_id))
            decision = validated
        with self._db() as db:
            db.execute('UPDATE fc_requests SET status=?,decision=?,channel_id=? WHERE id=?',
                (status, wire.canonical(decision).decode() if decision else None, channel_id, request_id))
        try:
            self.folio_flush_events()
        except Exception:
            pass
        return {'request_id': request_id, 'status': status, 'decision': decision,
            'channel_id': channel_id, 'card_exchange_required': status == 'accepted'}

    def folio_contact_approved(self, peer: str):
        """Grant only the publication channels approved by a human decision.

        Existing channel policies, unrelated notes, and use_in_chat remain untouched.
        """
        with self._db() as db:
            rows = db.execute("SELECT * FROM fc_requests WHERE peer=? AND status='accepted'", (peer,)).fetchall()
        for row in rows:
            if not row['decision'] or not row['channel_id']:
                continue
            decision = json.loads(row['decision'])
            allowed = set(decision['granted_scope'])
            ch = self.channel(row['channel_id'])
            policy = ch['policy']
            send = set(policy['send_to'])
            receive = set(policy['receive_from'])
            if row['direction'] == 'in':
                if allowed & {'follow_publications', 'messages', 'publication_channel'}:
                    send.add(peer)
                if allowed & {'messages', 'publication_channel'}:
                    receive.add(peer)
            else:
                if allowed & {'messages', 'publication_channel'}:
                    send.add(peer)
                if allowed & {'follow_publications', 'messages', 'publication_channel'}:
                    receive.add(peer)
            if send != set(policy['send_to']) or receive != set(policy['receive_from']):
                self.update_channel(ch['id'], {'send_to': sorted(send), 'receive_from': sorted(receive)}, ch['revision'])

    def folio_allowed_channels(self, peer: str) -> set[str]:
        """Publication channels explicitly accepted for this Folio peer."""
        with self._db() as db:
            rows = db.execute("SELECT channel_id FROM fc_requests WHERE peer=? AND status='accepted' AND channel_id IS NOT NULL", (peer,)).fetchall()
        return {row['channel_id'] for row in rows}

    def folio_note_shared(self, channel_id: str, peer: str, note_id: str) -> None:
        """Report only the first confirmed note's metadata for this relationship."""
        with self._db() as db:
            rows = db.execute("SELECT * FROM fc_requests WHERE channel_id=? AND peer=? AND status='accepted'",
                              (channel_id, peer)).fetchall()
        for row in rows:
            event = wire.signed(self.key, {
                'type':'braid_folio_first_message', 'version':1,
                'request_id':row['id'], 'publication_id':row['publication_id'],
                'sender_id':self.fingerprint, 'sender_public_key':self.public_key,
                'recipient_id':peer, 'note_id':note_id, 'created_at':int(time.time())
            }, FIRST_MESSAGE_DOMAIN)
            with self._db() as db:
                db.execute('INSERT OR IGNORE INTO fc_first_messages VALUES (?,?,?,0)',
                           (row['id'], wire.canonical(event).decode(), row['rendezvous']))
        self.folio_flush_events()

    def folio_flush_events(self) -> None:
        with self._db() as db:
            rows = db.execute('SELECT * FROM fc_first_messages WHERE recorded=0').fetchall()
        for row in rows:
            response = _post(row['rendezvous'], '/v1/events/first-message',
                             {'event':json.loads(row['payload'])})
            if response.get('request_id') != row['request_id'] or response.get('recorded') is not True:
                raise ValueError('ERR_FOLIO_EVENT_UNCONFIRMED')
            with self._db() as db:
                db.execute('UPDATE fc_first_messages SET recorded=1 WHERE request_id=?',
                           (row['request_id'],))

    def folio_approve_peer_card(self, request_id: str, inspection_id: str,
                                fingerprint: str, confirmed: bool) -> dict:
        """Approve a reviewed card with Folio-only transport authority."""
        row = self._accepted_request(request_id)
        pending = self.pending.get(inspection_id)
        if not pending or pending['info']['id'] != row['peer'] or fingerprint != row['peer']:
            raise ValueError('ERR_FOLIO_CARD_REQUEST_BINDING')
        if confirmed is not True:
            raise ValueError('Confirm the exact Folio peer fingerprint before approving the card.')
        return self.approve_card(inspection_id, fingerprint, True, folio_only=True)

    def _accepted_request(self, request_id: str):
        request_id = _id(request_id, 32)
        with self._db() as db:
            row = db.execute("SELECT * FROM fc_requests WHERE id=? AND status='accepted'", (request_id,)).fetchone()
        if not row or not row['decision']:
            raise ValueError('This connection has not been accepted.')
        return row

    def folio_share_card(self, request_id: str, *, confirmed: bool = False) -> dict:
        """Deliberately disclose the existing signed card only after acceptance."""
        row = self._accepted_request(request_id)
        if confirmed is not True:
            raise ValueError('Confirm sharing this rig card, including its name, local address, and model route.')
        card = self.export_card()
        if card['fingerprint'] != self.fingerprint:
            raise ValueError('ERR_FOLIO_CARD_IDENTITY')
        share = wire.signed(self.key, {
            'type': 'braid_folio_card_share', 'version': 1,
            'request_id': row['id'], 'party_id': self.fingerprint,
            'party_public_key': self.public_key, 'card': card,
            'created_at': int(time.time())}, CARD_DOMAIN)
        response = _post(row['rendezvous'], '/v1/cards', {'share': share})
        if response.get('request_id') != row['id']:
            raise ValueError('ERR_FOLIO_CARD_SHARE_UNCONFIRMED')
        with self._db() as db:
            db.execute('INSERT OR REPLACE INTO fc_card_shares VALUES (?,?)',(row['id'],time.time()))
        return {'request_id': row['id'], 'shared': True, 'disclosed_fields':
            ['rig_name', 'local_address', 'signed_route', 'tls_certificate']}

    def folio_inspect_peer_card(self, request_id: str) -> dict:
        row = self._accepted_request(request_id)
        auth = self._folio_auth(request_id=row['id']) if row['direction'] == 'out' else self._folio_auth()
        response = _post(row['rendezvous'], '/v1/cards/inbox',
            {'auth': auth, 'request_id': row['id']}, limit=wire.MAX_CARD + 16384)
        share = response.get('share')
        if share is None:
            return {'request_id': row['id'], 'available': False,
                'message': 'The other party has not shared a rig card yet.'}
        request = json.loads(row['request'])
        share = validate_card_share(share, request)
        if share['party_id'] != row['peer']:
            raise ValueError('ERR_FOLIO_CARD_SHARE_BINDING')
        card = share['card']
        inspected = self.inspect_card(card)
        return {'request_id': row['id'], 'available': True, 'inspection': inspected,
            'warning': 'Compare this full fingerprint with the accepted Folio peer before approving their rig card.'}
