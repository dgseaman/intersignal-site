"""Member activation, outbound-only relay agent and explicit remote channel queries.

No generic HTTP proxy, shell, remote filesystem, or public desktop UI. WAN note
intake enters MessengerService.receive with the original signed BRAD bytes.
"""
from __future__ import annotations
import base64
import hashlib
import http.client
import json
import secrets
import ssl
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlsplit
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from . import wan_protocol as p
from .private_files import private_dir, atomic_private_write
from .mcp_core.protocol import BraidFrame


class RelayClient:
    def __init__(self, config:dict, key, *, test_loopback=False):
        self.config=config;self.key=key
        self.base=p.relay_url(config['relay_url'],test_loopback=test_loopback)
        self.context=ssl.create_default_context()
        if config.get('ca_pem'): self.context=ssl.create_default_context(cadata=config['ca_pem'])
        self.context.minimum_version=ssl.TLSVersion.TLSv1_3
    def call(self, action:str, data:dict|None=None):
        request=p.make_request(self.key,self.config['member'],action,data or {})
        u=urlsplit(self.base);conn=http.client.HTTPSConnection(u.hostname,u.port or 443,timeout=12,context=self.context)
        def interrupt():
            try:
                if conn.sock: conn.sock.shutdown(2)
            except OSError: pass
            conn.close()
        deadline=threading.Timer(25, interrupt);deadline.daemon=True;deadline.start()
        try:
            raw=p.canonical(request)
            conn.request('POST',p.API+'/rpc',raw,{'Content-Type':'application/json','User-Agent':'Braid-Archangel/1.9'})
            response=conn.getresponse()
            length=response.getheader('Content-Length')
            if length and (not length.isdigit() or int(length)>p.MAX_HTTP):raise ValueError('ERR_WAN_RESPONSE_SIZE')
            body=response.read(p.MAX_HTTP+1)
            result=p.strict_json(body)
            if response.status!=200:raise ValueError(str(result.get('error','ERR_WAN_HTTP'))[:240])
            return p.check_response(result,self.config['operator_key'],request)
        finally:deadline.cancel();conn.close()


class WanController:
    def __init__(self,desk,*,client_factory=RelayClient,test_loopback=False):
        self.desk=desk;self.client_factory=client_factory;self.test_loopback=test_loopback
        self.guard=threading.RLock();self.stop_event=threading.Event();self.wake=threading.Event()
        self.processing=set();self.executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='braid-wan-intake')
        self.config=desk.get_value('wan19_config') or {}
        self.preferences=desk.get_value('wan19_preferences') or {'enabled':False,'receive_notes':False,'routes':{},'query_grants':{}}
        self.live={'connected':False,'error':None,'last_contact':None,'status':None,'peers':[]}
        self.registered=False;self.thread=None;self.peers_due=0.0
        root=desk.home/'wan';private_dir(root)
        keyfile=root/'encryption.key'
        self.key=None;self.encryption_public=None
        try:
            if not keyfile.exists():
                if self.config:raise ValueError('Existing WAN encryption key is missing.')
                atomic_private_write(keyfile,x25519.X25519PrivateKey.generate().private_bytes_raw())
            self.key=x25519.X25519PrivateKey.from_private_bytes(keyfile.read_bytes())
            self.encryption_public=p.public_hex(self.key)
        except (OSError,ValueError):
            # A damaged optional WAN identity must not disable free LAN/field use.
            # Do not silently generate a replacement under an enrolled identity.
            self.preferences={**self.preferences,'enabled':False}
            self.live['error']='WAN encryption key unavailable. Restore wan/encryption.key from the complete private profile backup, then restart. LAN remains available.'
        with desk._db() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS wan19_out(id TEXT PRIMARY KEY,peer TEXT,kind TEXT,sha TEXT,
                envelope TEXT,expires INTEGER,message_id TEXT,state TEXT,result TEXT,created REAL);
            CREATE TABLE IF NOT EXISTS wan19_in(id TEXT PRIMARY KEY,peer TEXT,sha TEXT,state TEXT,
                envelope TEXT,response TEXT,created REAL);
            ''')
            columns={row[1] for row in db.execute('PRAGMA table_info(wan19_in)')}
            if 'scope' not in columns:db.execute("ALTER TABLE wan19_in ADD COLUMN scope TEXT NOT NULL DEFAULT '{}'")
            # No interrupted operation is executed again. Its cached response will
            # disclose uncertainty, even when an underlying commit may exist.
            db.execute("UPDATE wan19_in SET state='interrupted' WHERE state='processing'")
        # Messenger starts the worker only after assigning this controller.

    def client(self):
        if not self.config:raise ValueError('Activate membership on this rig first.')
        return self.client_factory(self.config,self.desk.key,test_loopback=self.test_loopback)

    def snapshot(self):
        with self.guard:
            return {'configured':bool(self.config),'relay_url':self.config.get('relay_url',p.DEFAULT_RELAY),
                'member':self.config.get('member'),'operator_fingerprint':p.fingerprint(self.config['operator_key']) if self.config else None,
                'preferences':json.loads(p.canonical(self.preferences)),**json.loads(p.canonical(self.live)),
                'meaning':'Relay connectivity is not receiver acceptance. LAN and retained notes remain independent of membership.'}

    def activation_request(self):
        if not self.key:raise ValueError('Restore the WAN encryption key before requesting activation.')
        return p.join_request(self.desk.key,self.encryption_public,self.desk.settings['name'])

    def inspect_activation(self,activation:dict):
        if not isinstance(activation,dict):raise ValueError('Choose a signed member activation file.')
        if len(p.canonical(activation))>32768:raise ValueError('Activation file too large.')
        raw=p.verified(activation,activation.get('operator_key',''),b'BRAID-MEMBER-ACTIVATION-v1\0')
        if set(raw)!={'schema','member','device','encryption_key','relay_url','operator_key','enrollment_token','expires','ca_pem'} or raw['schema']!='intersignal.braid.member-activation.v1':raise ValueError('Unsupported activation file.')
        if raw['device']!=self.desk.fingerprint or raw['encryption_key']!=self.encryption_public:
            raise ValueError('This activation belongs to a different rig. Save an activation request on THIS rig.')
        p.member_id(raw['member']);p.relay_url(raw['relay_url'],test_loopback=self.test_loopback)
        if type(raw['expires']) is not int or raw['expires']<=time.time():raise ValueError('Activation expired; request a fresh one.')
        if not isinstance(raw['ca_pem'],str) or len(raw['ca_pem'])>16384:raise ValueError('Invalid relay CA.')
        if not isinstance(raw['enrollment_token'],str) or not 20<=len(raw['enrollment_token'])<=100:raise ValueError('Invalid activation token.')
        if self.config and (self.config['operator_key']!=raw['operator_key'] or self.config['member']!=raw['member'] or self.config['relay_url']!=raw['relay_url']):
            raise ValueError('This changes the relay or membership authority. Disconnect and clear activation explicitly first.')
        return {'member':raw['member'],'relay_url':raw['relay_url'],'device':raw['device'],
            'operator_fingerprint':p.fingerprint(raw['operator_key']),'expires':raw['expires'],
            'note':'Compare the operator fingerprint with Intersignal support through a trusted channel. A self-signature alone is not identity proof.'}

    def activate(self,activation:dict,confirmed:bool,operator_fingerprint:str):
        if self.processing:raise ValueError('Wait for active WAN work to finish before changing activation.')
        review=self.inspect_activation(activation)
        if confirmed is not True or not secrets.compare_digest(operator_fingerprint,review['operator_fingerprint']):raise ValueError('Review and confirm the exact relay operator fingerprint.')
        config={k:activation[k] for k in ('member','relay_url','operator_key','ca_pem')}
        client=self.client_factory(config,self.desk.key,test_loopback=self.test_loopback)
        result=client.call('enroll',{'enrollment_token':activation['enrollment_token']})
        # Token is not retained or returned. The registered rig authenticates every
        # subsequent request with its own existing Ed25519 identity.
        with self.guard:
            self.config=config;self.desk.set_value('wan19_config',config)
            self.live.update(connected=True,error=None,last_contact=time.time(),status=result['status'])
            self.registered=False
        return {'activated':True,'status':result['status'],'next':'Enable away-from-home access; approve rigs before sharing.'}

    def update_preferences(self,data:dict):
        allowed={'enabled','receive_notes','routes','query_grants'}
        if not isinstance(data,dict) or set(data)-allowed:raise ValueError('Unknown WAN setting.')
        with self.guard:
            new={**self.preferences,**data};contacts={c['id']:c for c in self.desk.contacts()}
            if 'routes' not in data:new['routes']={k:v for k,v in new['routes'].items() if k in contacts}
            if 'query_grants' not in data:new['query_grants']={k:v for k,v in new['query_grants'].items() if k in contacts}
            for field in ('enabled','receive_notes'):
                if type(new[field]) is not bool:raise ValueError('WAN switches must be booleans.')
            if not isinstance(new['routes'],dict) or len(new['routes'])>16:raise ValueError('Invalid route choices.')
            for peer,route in new['routes'].items():
                if (peer not in contacts and route!='lan') or route not in ('lan','relay'):raise ValueError('Choose an approved rig and an explicit LAN or relay path.')
                if route=='relay' and not contacts[peer].get('wan'):raise ValueError('Approve this rig\'s fresh 1.9 card before enabling its relay path.')
            grants=new['query_grants']
            if not isinstance(grants,dict) or len(grants)>16:raise ValueError('Invalid remote query grants.')
            channels={c['id'] for c in self.desk.channel_list()}
            for peer,ids in grants.items():
                if peer not in contacts or not isinstance(ids,list) or len(ids)>64 or any(c not in channels for c in ids):raise ValueError('Remote queries require approved rigs and existing channels.')
            if new['enabled'] and not self.key:raise ValueError('Restore the WAN encryption key first. LAN remains available.')
            if new['enabled'] and not self.config:raise ValueError('Activate membership first. LAN remains available without it.')
            new['routes']={k:v for k,v in new['routes'].items() if k in contacts}
            self.preferences=new;self.desk.set_value('wan19_preferences',new)
            if not new['enabled']:self.live['connected']=False
        if new['enabled']:self.start()
        self.wake.set()
        return self.snapshot()

    def clear_activation(self,confirmed:bool):
        if confirmed is not True:raise ValueError('Confirm removal of local membership activation.')
        if self.processing:raise ValueError('Pause access and wait for the active operation before clearing activation.')
        with self.guard:
            self.preferences={**self.preferences,'enabled':False,'receive_notes':False,'routes':{},'query_grants':{}}
            self.desk.set_value('wan19_preferences',self.preferences)
            self.config={};self.desk.set_value('wan19_config',{})
            self.live={'connected':False,'error':None,'last_contact':None,'status':None,'peers':[]};self.registered=False
            with self.desk._db() as db:
                pending=db.execute("SELECT * FROM wan19_out WHERE state IN ('prepared','queued','unknown')").fetchall()
                db.execute("UPDATE wan19_out SET state='activation_changed' WHERE state IN ('prepared','queued','unknown')")
                db.execute("UPDATE wan19_in SET state='withheld',response='{}' WHERE state='ready'")
            for row in pending:
                self._message_outcome(row,'outcome_unknown',{'wan_request_id':row['id'],
                    'reason':'ERR_WAN_ACTIVATION_CLEARED','status':'transport_unproven'})
        return self.snapshot()

    def route(self,peer):return self.preferences['routes'].get(peer,'lan')

    def contact(self,peer):
        contact=next((c for c in self.desk.contacts() if c['id']==peer),None)
        if not contact or not contact.get('wan') or p.CAPABILITY not in contact.get('capabilities',[]):raise ValueError('Approve a current 1.9 rig card for this WAN destination.')
        return contact

    def preflight(self,peer):
        if self.desk.closed or not self.preferences['enabled'] or not self.config:raise ValueError('Away-from-home access is off or not activated. No alternate transport was selected.')
        contact=self.contact(peer)
        if self.live.get('status') and self.live['status']['expires']<=time.time():raise ValueError('Membership expired. LAN and existing notes are unaffected.')
        return contact

    def discover(self):
        result=self.client().call('peers');self.live.update(peers=result['peers'],status=result['status'],last_contact=time.time(),error=None,connected=True)
        return result

    def inspect_peer(self,peer):
        p.hex64(peer);card=self.client().call('card',{'peer':peer})['card']
        if card.get('fingerprint')!=peer:raise ValueError('Relay supplied a different rig identity.')
        # Same cryptographic/card/route checks and explicit approval used on LAN.
        return self.desk.inspect_card(card)

    def publish_card(self):
        card=self.desk.export_card()
        result=self.client().call('publish-card',{'card':card});self.registered=True
        return result

    def start(self):
        with self.guard:
            if self.thread and self.thread.is_alive():return
            self.thread=threading.Thread(target=self._loop,daemon=True,name='braid-wan-poll');self.thread.start()

    def close(self):
        self.stop_event.set();self.wake.set();self.executor.shutdown(wait=False,cancel_futures=True)
        if self.thread:self.thread.join(timeout=2)

    def _loop(self):
        failures=0
        while not self.stop_event.is_set():
            try:
                if self.preferences['enabled'] and self.config and not self.desk.closed:
                    self.tick();failures=0
                delay=5.0 if self.processing else 15.0
            except Exception as exc:
                self.live.update(connected=False,error=str(exc)[:250]);failures+=1
                delay=min(60,2**min(failures,6)) + secrets.randbelow(1000)/1000
            self.wake.wait(delay);self.wake.clear()

    def tick(self):
        if not self.preferences['enabled'] or not self.config or self.desk.closed:return
        if not self.registered:
            self.publish_card()
        self._upload_replies()
        self.refresh_pending()
        if time.monotonic()>self.peers_due:
            self.discover();self.peers_due=time.monotonic()+60
        with self.guard:capacity=not self.processing
        result=self.client().call('poll' if capacity else 'status')
        self.live.update(connected=True,last_contact=time.time(),error=None,status=result['status'])
        envelope=result.get('envelope')
        if envelope:
            with self.guard:
                if envelope['id'] in self.processing:return
                self.processing.add(envelope['id'])
            self.executor.submit(self._process_guarded,envelope)

    def _persist_out(self,peer,kind,body,*,message_id='',ttl=300):
        contact=self.preflight(peer)
        ident=uuid.uuid4().hex
        envelope=p.seal(self.desk.key,peer,contact['wan']['encryption_key'],self.config['member'],body,ident=ident,ttl=ttl)
        raw=p.canonical(envelope)
        with self.desk._db() as db:
            db.execute('BEGIN IMMEDIATE')
            pending=db.execute("SELECT COUNT(*) FROM wan19_out WHERE state IN ('prepared','queued','unknown')").fetchone()[0]
            total=db.execute('SELECT COUNT(*),COALESCE(SUM(length(envelope)+length(result)),0) FROM wan19_out').fetchone()
            if pending>=32 or total[0]>=10000 or total[1]+len(raw)>256*1024**2:raise ValueError('WAN outbox limit reached. Inspect retained outcomes before creating more work.')
            db.execute('INSERT INTO wan19_out VALUES (?,?,?,?,?,?,?,?,?,?)',(ident,peer,kind,hashlib.sha256(raw).hexdigest(),raw.decode(),envelope['expires'],message_id,'prepared','{}',time.time()))
        try:
            self.client().call('enqueue',{'envelope':envelope})
            stage='queued'
        except Exception:
            with self.desk._db() as db:db.execute("UPDATE wan19_out SET state='unknown' WHERE id=?",(ident,))
            self.wake.set()
            raise
        with self.desk._db() as db:db.execute('UPDATE wan19_out SET state=? WHERE id=?',(stage,ident))
        self.wake.set()
        return {'wan_request_id':ident,'relay_stored':True,'receiver_confirmed':False,'wan_pending':True,
                'status':'queued_at_relay','expires':envelope['expires'],'transport_sha256':body.get('transport_sha256')}

    def send_frame(self,peer,raw:bytes,message_id:str):
        frame=BraidFrame.from_bytes(raw)
        ttl=min(p.MAX_TTL,int(frame.manifest['expires_at'])-int(time.time()))
        if ttl<1:raise ValueError('Prepared frame expired before WAN dispatch; nothing was sent.')
        return self._persist_out(peer,'frame',{'kind':'frame','frame':base64.b64encode(raw).decode('ascii'),
            'transport_sha256':hashlib.sha256(raw).hexdigest()},message_id=message_id,ttl=ttl)

    def ask_remote(self,peer,channel,question):
        self.preflight(peer);self.desk.channel(channel)
        if not isinstance(question,str) or not question.strip() or len(question.encode())>6000:raise ValueError('Write a question of 1 to 6,000 UTF-8 bytes.')
        # Explicit one-shot query, not hidden transcript upload or generic tool use.
        return self._persist_out(peer,'query',{'kind':'query','channel':p.hex64(channel),'question':question.strip()})

    def outcome(self,ident):
        p.packet_id(ident)
        with self.desk._db() as db:row=db.execute('SELECT * FROM wan19_out WHERE id=?',(ident,)).fetchone()
        if not row:raise ValueError('Unknown local WAN request.')
        return {'id':ident,'peer':row['peer'],'kind':row['kind'],'state':row['state'],'expires':row['expires'],'result':p.strict_json(row['result'])}

    def refresh_pending(self):
        with self.desk._db() as db:
            rows=db.execute("SELECT * FROM wan19_out WHERE state IN ('prepared','queued','unknown') ORDER BY created LIMIT 8").fetchall()
        for row in rows:
            if p.strict_json(row['envelope'])['member']!=self.config.get('member'):continue
            if row['message_id']:
                with self.desk._db() as db:d=db.execute('SELECT stage FROM deliveries WHERE message_id=?',(row['message_id'],)).fetchone()
                if not d or d['stage']=='sending':continue
                with self.desk._db() as db:
                    pending_note=db.execute('SELECT n.state FROM c6_notes n JOIN deliveries d ON n.id=d.handoff WHERE d.message_id=?',(row['message_id'],)).fetchone()
                if pending_note and pending_note['state']=='sending':continue
            result=self.client().call('result',{'id':row['id']})
            if result.get('reply'):
                self._finish(row,result['reply'])
            elif time.time()>row['expires']+30:
                with self.desk._db() as db:db.execute("UPDATE wan19_out SET state='expired_unconfirmed',result=? WHERE id=?",(p.canonical({'error':'Delivery deadline passed without a verified receiver response. No resend.'}).decode(),row['id']))
                self._message_outcome(row,'outcome_unknown',{'wan_request_id':row['id'],'reason':'ERR_WAN_DEADLINE_UNCONFIRMED','status':'transport_unproven'})

    def _check_record(self,row):
        if not self.preferences['enabled'] or not self.config:
            raise ValueError('Away-from-home access is paused. Enable it for an explicit receipt check.')
        if p.strict_json(row['envelope'])['member']!=self.config.get('member'):
            raise ValueError('This handoff belongs to another activation. No different relay was queried.')
        result=self.client().call('result',{'id':row['id']})
        if result.get('reply'):self._finish(row,result['reply'])
        return self.outcome(row['id'])

    def check_delivery(self,message_id):
        with self.desk._db() as db:row=db.execute('SELECT * FROM wan19_out WHERE message_id=?',(message_id,)).fetchone()
        if not row:raise ValueError('No WAN record for this message.')
        return self._check_record(row)

    def check_query(self,ident):
        p.packet_id(ident)
        with self.desk._db() as db:row=db.execute("SELECT * FROM wan19_out WHERE id=? AND kind='query'",(ident,)).fetchone()
        if not row:raise ValueError('No recorded remote question selected.')
        return self._check_record(row)

    def _finish(self,row,envelope):
        contact=self.contact(row['peer'])
        result=p.open_packet(envelope,contact['public_key'],self.key,self.desk.fingerprint,self.config['member'])
        if result.get('kind')!='reply' or result.get('request_id')!=row['id'] or result.get('request_sha256')!=row['sha'] or result.get('operation')!=row['kind']:
            raise ValueError('ERR_WAN_RECEIVER_REPLY_BINDING')
        report=result.get('result')
        if not isinstance(report,dict):raise ValueError('ERR_WAN_RECEIVER_RESULT')
        stage='answered' if row['kind']=='query' and 'response' in report and not report.get('error') else 'rejected'
        if row['kind']=='frame':
            path=self.desk.home/'outbox'/(row['message_id']+'.brad')
            expected=hashlib.sha256(path.read_bytes()).hexdigest()
            if report.get('transport_sha256')!=expected:raise ValueError('ERR_WAN_RECEIPT_FRAME_DIGEST')
            for field in ('accepted','stored','phase_b_committed','field_indexed'):
                if report.get(field) is not None and type(report[field]) is not bool:raise ValueError('ERR_WAN_RECEIPT_BOOLEAN')
            if report.get('phase_b_committed') is True:
                if report.get('accepted') is not True or report.get('stored') is not True:raise ValueError('ERR_WAN_CONTRADICTORY_RECEIPT')
                stage='indexed' if report.get('field_indexed') is True else 'accepted'
            elif report.get('phase_b_committed') is False and report.get('accepted') is False:
                # A receiver may retain rejected bytes for inspection. That stored
                # copy is not committed state. Only the exact, authenticated
                # pre-commit rejection record can resolve this case as rejected;
                # missing or contradictory evidence remains outcome_unknown.
                rejected_copy = (report.get('stored') is True
                    and report.get('phase_a_validated') is False
                    and report.get('field_indexed') is False
                    and report.get('accepted_and_indexed') is False
                    and report.get('result_summary') == 'REJECTED_BEFORE_PHASE_B')
                contradictory = report.get('field_indexed') is True or report.get('accepted_and_indexed') is True
                stage = 'rejected' if not contradictory and (report.get('stored') is False or rejected_copy) else 'outcome_unknown'
            else:stage='outcome_unknown'
        report={**report,'wan_request_id':row['id'],'relay_url':self.config['relay_url'],
                'receiver_signature_verified':True,'receiver':row['peer'],'signed_encrypted_response':envelope}
        with self.desk._db() as db:db.execute('UPDATE wan19_out SET state=?,result=? WHERE id=?',(stage,p.canonical(report).decode(),row['id']))
        self._message_outcome(row,stage,report)

    def _message_outcome(self,row,stage,report):
        if not row['message_id']:return
        with self.desk._db() as db:
            db.execute('BEGIN IMMEDIATE')
            message=db.execute('SELECT payload FROM messages WHERE id=?',(row['message_id'],)).fetchone()
            if message:
                payload={**p.strict_json(message['payload']),**report,'wan_pending':False}
                db.execute('UPDATE messages SET stage=?,payload=? WHERE id=?',(stage,p.canonical(payload).decode(),row['message_id']))
            delivery=db.execute('SELECT handoff FROM deliveries WHERE message_id=?',(row['message_id'],)).fetchone()
            result={'stage':stage,'message_id':row['message_id'],'receipt':report}
            db.execute('UPDATE deliveries SET stage=?,result=?,updated=? WHERE message_id=?',(stage,p.canonical(result).decode(),time.time(),row['message_id']))
            if delivery:
                note=db.execute('SELECT payload FROM c6_notes WHERE id=?',(delivery['handoff'],)).fetchone()
                if note:
                    payload=p.strict_json(note['payload'])
                    outcomes=payload.get('outcomes',[])
                    for o in outcomes:
                        if o.get('peer')==row['peer']:o.update(result)
                    if outcomes:
                        state='shared' if all(o.get('stage') in ('accepted','indexed') for o in outcomes) else 'attention'
                        db.execute('UPDATE c6_notes SET state=?,payload=? WHERE id=?',(state,p.canonical(payload).decode(),delivery['handoff']))

    def _process_guarded(self,envelope):
        self.live.pop('intake_error',None)
        try:self._process(envelope)
        except Exception as exc:self.live['intake_error']=str(exc)[:200]
        finally:
            with self.guard:self.processing.discard(envelope['id'])
            self.wake.set()

    def _query_permission(self,peer,channel):
        self.contact(peer)
        if not self.preferences['enabled'] or channel not in self.preferences['query_grants'].get(peer,[]):raise ValueError('ERR_WAN_REMOTE_QUERY_NOT_ALLOWED')
        ch=self.desk.channel(channel);policy=ch['policy']
        if policy['archived'] or policy['paused'] or not policy['use_in_chat'] or peer not in policy['send_to']:
            raise ValueError('ERR_WAN_CHANNEL_EXPORT_NOT_ALLOWED')
        objects,scope=self.desk.channel_scope(channel,True)
        return objects,scope

    def _process(self,envelope):
        peer=envelope.get('sender');contact=self.contact(peer)
        body=p.open_packet(envelope,contact['public_key'],self.key,self.desk.fingerprint,self.config['member'])
        if envelope['expires']-envelope['created']>p.MAX_TTL:raise ValueError('ERR_WAN_REQUEST_TTL')
        ident=envelope['id'];sha=hashlib.sha256(p.canonical(envelope)).hexdigest()
        with self.desk._db() as db:
            db.execute('BEGIN IMMEDIATE')
            old=db.execute('SELECT * FROM wan19_in WHERE id=?',(ident,)).fetchone()
            if old:
                if old['peer']!=peer or old['sha']!=sha:raise ValueError('ERR_WAN_LOCAL_REPLAY_MISMATCH')
                if old['state'] in ('ready','replied','processing','withheld'):return
                interrupted=old['state']=='interrupted'
            else:
                interrupted=False
                if db.execute('SELECT COUNT(*) FROM wan19_in').fetchone()[0]>=10000:raise ValueError('WAN intake history limit; retain/export evidence before accepting more.')
                db.execute('INSERT INTO wan19_in(id,peer,sha,state,envelope,response,created) VALUES (?,?,?,?,?,?,?)',(ident,peer,sha,'processing',p.canonical(envelope).decode(),'{}',time.time()))
        kind=body.get('kind');started=False;frame_digest=body.get('transport_sha256');export_scope={}
        report={'error':'ERR_WAN_UNSUPPORTED_OPERATION'}
        try:
            if interrupted:raise RuntimeError('Interrupted local operation; inspect receiver state. Nothing was re-executed.')
            if kind=='frame':
                if set(body)!={'kind','frame','transport_sha256'}:raise ValueError('ERR_WAN_FRAME_REQUEST')
                if not self.preferences['enabled'] or not self.preferences['receive_notes']:raise ValueError('ERR_WAN_RECEIVING_PAUSED')
                raw=p.decode64(body['frame'],p.MAX_PLAINTEXT)
                if hashlib.sha256(raw).hexdigest()!=frame_digest:raise ValueError('ERR_WAN_FRAME_HASH')
                frame=BraidFrame.from_bytes(raw)
                ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(contact['public_key'])).verify(frame.signature_bytes,frame.signature_preimage)
                # The outer sender cannot borrow a different approved inner signer.
                started=True
                observed=self.desk.receive(raw,source_transport='managed_wan')
                fields=('accepted','stored','validated','phase_a_validated','phase_b_committed','field_indexed',
                        'accepted_and_indexed','result_summary','reason','status','object_digest','error')
                report={k:observed[k] for k in fields if k in observed}
                report['transport_sha256']=frame_digest
            elif kind=='query':
                if set(body)!={'kind','channel','question'}:raise ValueError('ERR_WAN_QUERY_REQUEST')
                channel=p.hex64(body['channel']);question=body['question']
                if not isinstance(question,str) or not question.strip() or len(question.encode())>6000:raise ValueError('ERR_WAN_QUERY_SIZE')
                objects,scope=self._query_permission(peer,channel)
                export_scope=scope
                model=self.desk.settings.get('completion_model','')
                if not model:raise ValueError('Choose a local completion model on the home rig. No remote model was selected.')
                from .channel_chat import query_channel_chat
                started=True
                result=query_channel_chat(storage_dir=self.desk.inbox,question=question,
                    embedding_model=self.desk.settings['embed_model'],completion_model=model,
                    objects=objects,labels=self.desk.source_labels(channel,objects),history=[])
                _,current=self._query_permission(peer,channel)
                if scope!=current or self.desk.closed:raise ValueError('ERR_WAN_QUERY_POLICY_CHANGED')
                fields=('response','completion_model','completion_model_digest','generation_source','completion_guard',
                        'shared_note_count','supplied_notes','unresolved_conflict_count','context_sha256','count_meaning')
                report={k:result[k] for k in fields if k in result}
                report.update(channel=channel,question=question,answered_on=self.desk.settings['name'],remote_execution=True)
            else:raise ValueError('ERR_WAN_UNSUPPORTED_OPERATION')
        except Exception as exc:
            import re
            self.live['intake_error']=str(exc)[:350]
            match=re.search(r'ERR_[A-Z0-9_]+',str(exc))
            report={'error':match.group(0) if match else 'ERR_WAN_REMOTE_OPERATION_FAILED'}
            if kind=='frame':report.update(transport_sha256=frame_digest,
                accepted=None if started or interrupted else False,stored=None if started or interrupted else False,
                phase_b_committed=None if started or interrupted else False,status='transport_unproven' if started or interrupted else 'rejected')
        # Never claim rejection when a failure might have occurred after commit.
        response_body={'kind':'reply','operation':kind,'request_id':ident,'request_sha256':sha,'result':report}
        response=p.seal(self.desk.key,peer,contact['wan']['encryption_key'],self.config['member'],response_body,ttl=p.REPLY_TTL)
        with self.desk._db() as db:db.execute("UPDATE wan19_in SET state='ready',response=?,scope=? WHERE id=?",(p.canonical(response).decode(),p.canonical(export_scope).decode(),ident))

    def _upload_replies(self):
        with self.desk._db() as db:rows=db.execute("SELECT * FROM wan19_in WHERE state='ready' ORDER BY created LIMIT 4").fetchall()
        for row in rows:
            try:
                if self.desk.closed or not self.preferences['enabled']:return
                self.contact(row['peer'])
            except ValueError:
                with self.desk._db() as db:db.execute("UPDATE wan19_in SET state='withheld',response='{}' WHERE id=?",(row['id'],))
                continue
            envelope=p.strict_json(row['envelope'])
            if envelope['member']!=self.config.get('member'):
                with self.desk._db() as db:db.execute("UPDATE wan19_in SET state='withheld',response='{}' WHERE id=?",(row['id'],))
                continue
            # Remote query permission is rechecked again at the actual export.
            body=p.open_packet(envelope,self.contact(row['peer'])['public_key'],self.key,self.desk.fingerprint,self.config['member'],allow_expired=True)
            if body.get('kind')=='query' and p.strict_json(row['scope']):
                try:
                    _,scope=self._query_permission(row['peer'],body['channel'])
                    old_scope=p.strict_json(row['scope'])
                    if old_scope and scope!=old_scope:raise ValueError('Channel permissions changed before export.')
                except ValueError:
                    # Drop any generated answer rather than disclose after revocation.
                    with self.desk._db() as db:db.execute("UPDATE wan19_in SET state='withheld',response='{}' WHERE id=?",(row['id'],))
                    continue
            self.client().call('reply',{'id':row['id'],'envelope':p.strict_json(row['response'])})
            with self.desk._db() as db:db.execute("UPDATE wan19_in SET state='replied' WHERE id=?",(row['id'],))

    def action(self,action,data):
        if action=='requests':
            with self.desk._db() as db:
                rows=db.execute("SELECT id,peer,state,expires,created FROM wan19_out WHERE kind='query' ORDER BY created DESC LIMIT 30").fetchall()
            return {'requests':[dict(row) for row in rows]}
        if action=='request':return self.activation_request()
        if action=='inspect-activation':return self.inspect_activation(data.get('activation'))
        if action=='activate':return self.activate(data.get('activation'),data.get('confirmed'),str(data.get('operator_fingerprint','')))
        if action=='settings':return self.update_preferences(data.get('preferences',{}))
        if action=='clear':return self.clear_activation(data.get('confirmed'))
        if action=='peers':return self.discover()
        if action=='inspect-peer':return self.inspect_peer(str(data.get('peer','')))
        if action=='publish-card':return self.publish_card()
        if action=='ask':return self.ask_remote(str(data.get('peer','')),str(data.get('channel','')),data.get('question'))
        if action=='result':return self.outcome(str(data.get('id','')))
        if action=='check-query':return self.check_query(str(data.get('id','')))
        if action=='check':return self.check_delivery(str(data.get('message_id','')))
        if action=='status':return self.snapshot()
        raise ValueError('Unknown WAN operation.')
