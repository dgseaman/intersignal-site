/* Folio requests stay separate from ordinary rig approval until both people consent. */
'use strict';
(() => {
  const byId = id => document.getElementById(id);
  const dialog = byId('folioDialog');
  if (!dialog) return;
  let csrf = '';
  let referral = null;
  let working = false;
  const labels={publication_channel:'Discuss this publication in its own channel',messages:'Exchange messages in this publication channel',follow_publications:'Receive future material the publisher chooses to share'};
  const errors={ERR_FOLIO_RENDEZVOUS_UNAVAILABLE:'The connection service is unavailable. Check again when it returns.',ERR_FOLIO_PUBLICATION_DISABLED:'The publisher has closed requests for this Folio.',ERR_FOLIO_PUBLICATION_DELETED:'This Folio is no longer accepting requests.',ERR_FOLIO_REQUEST_EXPIRED:'This request has expired. Open the invitation again to send a new one.'};

  function node(tag, text = '', className = '') {
    const element = document.createElement(tag);
    element.textContent = text;
    if (className) element.className = className;
    return element;
  }
  function button(text, action, className = 'btn') {
    const element = node('button', text, className);
    element.type = 'button';
    element.disabled=working;
    element.addEventListener('click', () => run(() => action(element)));
    return element;
  }
  function line(parent, text, className = 'microcopy') {
    parent.append(node('p', text, className));
  }
  function checkbox(text, checked = false) {
    const label = node('label', '', 'folio-check');
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = checked;
    label.append(input, node('span', text));
    return {label, input};
  }
  function errorMessage(error) {
    const text = error && error.message ? error.message : String(error);
    byId('folioStatus').textContent = errors[text]||text;
    byId('folioStatus').hidden = false;
  }
  async function run(action) {
    if (working) return;
    working = true;
    dialog.setAttribute('aria-busy','true');
    const controls=[...dialog.querySelectorAll('button:not(:disabled)')];controls.forEach(b=>b.disabled=true);
    byId('folioStatus').hidden = true;
    try { await action(); }
    catch (error) { errorMessage(error); }
    finally { working = false; dialog.setAttribute('aria-busy','false');dialog.querySelectorAll('button').forEach(b=>b.disabled=false); }
  }
  async function api(path, payload) {
    const response = await fetch('/api/messenger/' + path, {
      method: payload === undefined ? 'GET' : 'POST', cache: 'no-store',
      headers: payload === undefined ? {} : {'Content-Type':'application/json', 'X-Braid-CSRF':csrf},
      body: payload === undefined ? undefined : JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok || result.error) throw new Error(result.message || result.error || 'Braid could not complete this action.');
    return result;
  }
  async function job(path, payload) {
    const submitted = await api(path, payload);
    if (!submitted.job_id) return submitted;
    for (let attempt = 0; attempt < 120; attempt++) {
      const progress = await api('job?id=' + encodeURIComponent(submitted.job_id));
      if (progress.status === 'done') return progress.result;
      if (progress.status === 'error') throw new Error(progress.error || 'The operation failed.');
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    throw new Error('This operation is still running. Check requests again shortly.');
  }
  async function load() {
    csrf = (await api('state')).csrf;
    const state = await api('folio/state');
    renderRequests(state.requests || [], new Set(state.contacts || []));
  }
  function renderReferral() {
    const target = byId('folioReferral');
    target.replaceChildren();
    if (!referral) return;
    target.append(node('h4', 'Publication ' + referral.publication_id.slice(0, 12)));
    line(target,'Invitation verified. Your introduction will go only to the publisher of this Folio.','folio-success');
    const identity=node('details');identity.append(node('summary','Publisher fingerprint'));line(identity,referral.source_network_id);target.append(identity);
    line(target, 'Select the permissions you would like to request. The publisher may grant fewer.');
    const choices = [];
    for (const scope of referral.offered_scopes) {
      const item = checkbox(labels[scope] || scope, true);
      choices.push({scope, input:item.input});
      target.append(item.label);
    }
    const noteLabel = node('label', 'Why would you like to connect? (optional)', 'form-label');
    const note = document.createElement('textarea');
    note.maxLength = 500;
    note.rows = 3;
    note.placeholder = 'A short note for the publisher';
    noteLabel.append(note);
    target.append(noteLabel);
    target.append(button('Send connection request', async () => {
      const requested_scope = choices.filter(item => item.input.checked).map(item => item.scope);
      if(new TextEncoder().encode(note.value).length>500)throw new Error('Keep the introduction under 500 bytes; shorten it a little and try again.');
      if (!requested_scope.length) throw new Error('Choose at least one permission to request.');
      const result = await job('folio/request', {
        publication_id:referral.publication_id, requested_scope,
        message:note.value, publication_url:''
      });
      line(target, 'Signed request ' + result.request_id.slice(0, 12) + ' is ' + result.status + '.');
      referral = null;
      await load();
      renderReferral();
    }, 'btn primary'));
  }
  function scopeText(scopes) {
    const names = {
      publication_channel:'publication discussion', messages:'Braid messages in that channel',
      follow_publications:'future material deliberately shared there'
    };
    return scopes.map(scope => names[scope] || scope).join(', ');
  }
  function renderRequest(record, contacts) {
    const request = record.request;
    const card = node('article', '', 'folio-request');
    card.append(node('h4', (record.direction === 'in' ? 'Reader request' : 'Your request') +
      ' · Folio ' + request.publication_id.slice(0, 12)));
    const status=node('p',record.status==='accepted'?'✓ Invitation accepted':record.status==='pending'?'Waiting for publisher approval':record.status.replaceAll('_',' '),'folio-state');card.append(status);
    const peer=node('details');peer.append(node('summary','Peer fingerprint'));line(peer,record.peer);card.append(peer);
    line(card, 'Requested: ' + scopeText(request.requested_scope));
    if (request.message) line(card, request.message, 'folio-note');
    if (record.direction === 'in' && record.status === 'pending') {
      line(card, 'Accept connection: this peer receives only the selected publication permission. Other Braid channels, local state, and private conversations remain unavailable.');
      const granted = [];
      for (const scope of request.requested_scope) {
        const item = checkbox(scopeText([scope]), true);
        granted.push({scope, input:item.input});
        card.append(item.label);
      }
      const confirmation = checkbox('I approve this publication-specific access.');
      card.append(confirmation.label);
      card.append(button('Accept connection', async () => {
        if (!confirmation.input.checked) throw new Error('Confirm the exact permission before accepting.');
        const granted_scope = granted.filter(item => item.input.checked).map(item => item.scope);
        if (!granted_scope.length) throw new Error('Select at least one permission, or decline.');
        await job('folio/decision', {request_id:record.id, decision:'accepted', granted_scope, confirmed:true});
        await load();
      }, 'btn primary'));
      card.append(button('Decline', async () => {
        await job('folio/decision', {request_id:record.id, decision:'declined', granted_scope:[], confirmed:true});
        await load();
      }));
    }
    if (record.direction === 'out' && ['pending','submission_unknown'].includes(record.status)) {
      card.append(button('Check publisher decision', async () => {
        await job('folio/status', {request_id:record.id});
        await load();
      }));
    }
    if (record.status === 'accepted') {
      const steps=node('div','','folio-steps');for(const [label,done] of [['Request accepted',true],['Your card shared',record.card_shared===true],['Peer card approved',contacts.has(record.peer)]])steps.append(node('span',(done?'✓ ':'○ ')+label,done?'is-done':''));card.append(steps);
      line(card, 'Accepted: ' + scopeText(record.decision?.granted_scope || []));
      if(record.channel_id){line(card,'A publication channel is ready.');card.append(button('Open publication channel',()=>{dialog.close();document.dispatchEvent(new CustomEvent('folio-open-channel',{detail:record.channel_id}));},'btn primary'));}
      line(card, 'For channel notes, each person chooses to share a signed rig card. It contains a rig name, local address, TLS certificate, and model route.');
      const shareConsent=checkbox('I choose to disclose my signed rig card for this connection.');
      card.append(shareConsent.label);
      card.append(button(record.card_shared?'Update my shared rig card':'Share my rig card',async()=>{
        if(!shareConsent.input.checked)throw new Error('Choose to share the rig card first.');
        await job('folio/share-card',{request_id:record.id,confirmed:true});
        await load();
      }));
      if (!contacts.has(record.peer)) {
        card.append(button('Review peer rig card', async () => {
          const result = await job('folio/inspect-peer-card', {request_id:record.id});
          if (!result.available) { line(card, result.message); return; }
          const review = node('div', '', 'folio-card-review');
          const inspected = result.inspection;
          review.append(node('h4', 'Review peer rig card'));
          line(review, 'Name: ' + inspected.name + ' · Address: ' + inspected.host + ':' + inspected.port);
          line(review, 'Full fingerprint: ' + inspected.id);
          line(review, 'This approval allows transport only for the accepted Folio channel. Compare the fingerprint with the reader or publisher through a trusted route.');
          const consent = checkbox('I checked this exact fingerprint and approve the Folio-only card.');
          review.append(consent.label);
          review.append(button('Approve scoped card', async () => {
            if (!consent.input.checked) throw new Error('Compare and confirm the exact fingerprint first.');
            await api('folio/approve-peer-card', {request_id:record.id,
              inspection_id:inspected.inspection_id, fingerprint:inspected.id, confirmed:true});
            await load();
          }, 'btn primary'));
          card.append(review);
        }));
      } else {
        line(card, 'Rig card approved. Use this publication channel to review and share notes. Direct or overlay reachability is still required.');
      }
    }
    return card;
  }
  function renderRequests(requests, contacts) {
    const target = byId('folioRequests');
    target.replaceChildren();
    if (!requests.length) { line(target, 'No connection requests yet.'); return; }
    const incoming = requests.filter(item => item.direction === 'in');
    const outgoing = requests.filter(item => item.direction === 'out');
    for (const [heading, items] of [['Received', incoming], ['Sent', outgoing]]) {
      if (!items.length) continue;
      target.append(node('h4', heading));
      for (const item of items) target.append(renderRequest(item, contacts));
    }
  }
  byId('folioButton').addEventListener('click', () => run(async () => {
    dialog.showModal();await load();
    try{await job('folio/inbox',{});await load();}catch(error){errorMessage(error);}
  }));
  byId('folioClose').addEventListener('click', () => dialog.close());
  byId('folioDone').addEventListener('click', () => dialog.close());
  byId('folioRefresh').addEventListener('click', () => run(async () => {
    await job('folio/inbox', {});
    await load();
  }));
  byId('folioOpenLink').addEventListener('click',()=>run(async()=>{
    csrf=(await api('state')).csrf;
    referral=await job('folio/import-link',{url:byId('folioLink').value.trim()});
    byId('folioLink').value='';renderReferral();
  }));
  if(location.hash==='#folio')byId('folioButton').click();
  byId('folioImport').addEventListener('click', () => byId('folioReferralFile').click());
  byId('folioReferralFile').addEventListener('change', () => run(async () => {
    const file = byId('folioReferralFile').files[0];
    if (!file) return;
    if (file.size > 16384) throw new Error('This referral file is too large.');
    const value = JSON.parse(await file.text());
    referral = await api('folio/import-referral', {referral:value});
    renderReferral();
    byId('folioReferralFile').value = '';
  }));
})();
