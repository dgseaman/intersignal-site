/* Copy only the visible, validated invitation. No local-app probing or requests. */
'use strict';
const link=document.getElementById('connection-link');
document.getElementById('copy-link').addEventListener('click',async()=>{
  const status=document.getElementById('copy-status');
  try{await navigator.clipboard.writeText(link.value);status.textContent='Copied. Bring it into Folio connections in Braid.';}
  catch{link.focus();link.select();status.textContent='Press Ctrl+C or ⌘C to copy the selected link.';}
});
link.addEventListener('click',()=>link.select());
