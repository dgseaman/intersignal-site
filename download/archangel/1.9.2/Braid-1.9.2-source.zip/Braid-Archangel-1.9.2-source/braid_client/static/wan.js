/* Away-from-home access. No credentials in public assets; all APIs remain loopback-only. */
(() => {
  'use strict';
  const D=window.BraidDesktop, $=id=>document.getElementById(id), e=D.esc;
  const api=(action,data={})=>D.api('wan',{action,...data});
  const job=(action,data={})=>D.job('wan',{action,...data});
  let state=D.getState(), activation=null, inspection=null, activeQuery=null, busy=false, actionError='';
  const saveFile=(name,data)=>{const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1500);};
  function showError(err){actionError=err.message||String(err);refreshStatus();}
  async function run(action){if(busy)return;busy=true;actionError='';try{await action();}catch(err){showError(err);}finally{busy=false;}}
  document.body.insertAdjacentHTML('beforeend', `
  <dialog id="wanDialog" class="modal settings-modal wan-dialog" aria-labelledby="wanTitle">
    <div class="modal-head"><div><span class="eyebrow">YOUR FLEET, BEYOND THIS NETWORK</span><h2 id="wanTitle">Away from home.</h2></div><button class="icon-button" id="closeWan" aria-label="Close away-from-home settings">\u00d7</button></div>
    <div class="modal-body" tabindex="0" aria-label="Away-from-home settings">
      <p class="body-intro">Use your home rig from another network. Intersignal operates the relay; you keep the keys, notes, and decisions about who may use them.</p>
      <div id="wanStatus" class="inline-result" role="status">Not activated. Local sharing is still available.</div>
      <p id="wanClockHint" class="microcopy" role="note" hidden></p>
      <section id="wanMembership" class="wan-membership" aria-labelledby="wanMembershipTitle">
        <h3 id="wanMembershipTitle">Free on your LAN. Your fleet can go further.</h3>
        <p class="microcopy">Braid Membership adds human support and separately activated Managed Relay access for supported rigs. Keep the same Braid download. No DigitalOcean account or router port forwarding is needed.</p>
        <div class="actions"><a class="btn" href="https://intersignal.org/#membership" target="_blank" rel="noopener noreferrer">Explore Braid Membership</a></div>
        <p class="microcopy">Local sharing stays free. Opening this panel does not activate a subscription or transmit your notes.</p>
      </section>
      <section class="tool-section"><h3>Member activation</h3><p class="microcopy">The same Braid installer on every rig. Save a request on each device and send it to member support. Import the signed activation returned for this device. No DigitalOcean account is needed.</p>
        <div class="actions"><button class="btn" id="wanRequest">Save activation request</button><button class="btn" id="wanImport">Import activation</button></div>
        <div id="wanActivationReview" hidden><pre id="wanActivationDetails" class="wan-evidence"></pre><label class="form-label">Relay operator fingerprint supplied by Intersignal support<input id="wanOperatorFingerprint" maxlength="64" autocomplete="off" spellcheck="false"></label><label class="wan-check"><input type="checkbox" id="wanConfirm">I compared this full fingerprint through a trusted channel.</label><button class="btn primary" id="wanActivate">Activate this rig</button></div>
        <p class="microcopy" id="wanEntitlement"></p>
      </section>
      <section class="tool-section"><h3>Connection and permissions</h3>
        <label class="wan-check"><input type="checkbox" id="wanEnabled">Enable away-from-home access on this rig</label>
        <label class="wan-check"><input type="checkbox" id="wanReceive">Allow approved rigs to deliver notes over the relay</label>
        <p class="microcopy">LAN receiving is separate. Turning this off never disables the free local client. Keep the home rig awake, connected, and Braid running; closing its browser is fine. There is no remote wake-up.</p>
        <div id="wanRoutes"></div><p class="microcopy">Select a path per destination. A failed LAN connection never silently becomes a WAN transfer. Channel send/receive permissions still apply.</p>
        <h3>Allow remote questions</h3><div id="wanGrants"></div>
        <p class="microcopy">A grant lets this peer ask the home rig about this channel and receive its answer plus source evidence. Also enable the channel's Use in chat and Send to that peer. Only the home rig's configured local model runs. No shell, file browsing, or public Ollama endpoint.</p>
        <button class="btn primary" id="wanSave">Save WAN settings</button>
      </section>
      <section class="tool-section"><h3>Other member rigs</h3><div class="actions"><button class="btn" id="wanPublish">Publish current rig card</button><button class="btn" id="wanDiscover">Find member rigs</button></div><div id="wanDiscovered"></div>
        <div id="wanPeerReview" hidden><pre id="wanPeerDetails" class="wan-evidence"></pre><label class="wan-check"><input type="checkbox" id="wanPeerConfirm">I compared the full signing fingerprint with the owning rig.</label><button class="btn" id="wanApprove">Approve rig</button></div>
        <p class="microcopy">Discovery is account-scoped, not trust. Approve current 1.9 cards on both rigs. Signing fingerprints stay the same; new cards bind the additional encryption key. Channel identities still require their own signed card.</p>
      </section>
      <section class="tool-section"><h3>Ask your home rig</h3><div class="two-cols"><label class="form-label">Answer on<select id="wanAskPeer"></select></label><label class="form-label">Channel<select id="wanAskChannel"></select></label></div>
        <label class="form-label">Question<textarea id="wanQuestion" rows="3" maxlength="6000" placeholder="What is the current project constraint?"></textarea></label>
        <p class="microcopy">Only this question is sent, not your conversation history. The selected home rig must explicitly allow it. Replies are inspected here, not silently inserted into another chat.</p>
        <div class="actions"><button class="btn primary" id="wanAsk">Send question to home rig</button><button class="btn" id="wanCheckQuestion">Check response (no resend)</button></div>
        <div id="wanAnswer" class="inline-result" role="status" hidden></div><details id="wanAnswerEvidence" hidden><summary>Shared notes and remote answer evidence</summary><pre id="wanAnswerRaw" class="wan-evidence"></pre></details>
        <label class="form-label">Recent remote questions<select id="wanQueryHistory"></select></label><button class="text-button" id="wanLoadHistory">Refresh question history</button>
      </section>
      <details class="tool-section" id="wanClockHelp"><summary>Clock synchronization &amp; delivery help</summary>
        <p class="microcopy">Signed handoffs have short delivery windows. A few seconds of clock disagreement can cause a future-timestamp rejection even when the relay connection works. Braid does not adjust system clocks or weaken the validation window.</p>
        <p class="microcopy"><strong>Mac:</strong> System Settings &gt; General &gt; Date &amp; Time &gt; Set time and date automatically. <strong>Windows:</strong> Settings &gt; Time &amp; language &gt; Date &amp; time &gt; Set time automatically, then Sync now where available. Check both rigs; the receipt alone cannot establish which clock is correct.</p>
        <p class="microcopy">Use the existing receipt to distinguish a definite rejection from an unknown outcome. Check receipt does not resend. An expired or missing acknowledgment does not authorize an automatic retry.</p>
      </details>
      <details class="tool-section"><summary>Disconnect membership on this rig</summary><p class="microcopy">Clears local activation and WAN permissions; does not delete notes or revoke the device on the server. Contact support to revoke a lost device. Delivery uncertainty is never cleared by disconnecting.</p><button class="btn" id="wanClear">Disconnect and clear activation</button></details>
    </div><div class="modal-foot"><span class="microcopy">Encrypted relay path. Acceptance stays with the receiver.</span><button class="btn" id="wanDone">Done</button></div>
  </dialog><input type="file" id="wanActivationFile" accept=".braidmember,.json" hidden>`);
  function refreshStatus(){
    const w=state?.wan;if(!w)return;
    $('wanBadge').textContent=!w.configured?'Not active':!w.preferences.enabled?'Off':w.connected?'Online':'Reconnecting';
    const error=actionError||w.error||w.intake_error||'';
    $('wanStatus').classList.toggle('wan-error',!!error);
    $('wanClockHint').textContent=D.clockGuidance({reason:error});$('wanClockHint').hidden=!$('wanClockHint').textContent;
    $('wanMembership').hidden=!!w.configured;
    $('wanStatus').textContent=error||(!w.configured?'Not activated. Local sharing is still available.':!w.preferences.enabled?'Membership activated; WAN access paused.':w.connected?'Connected to '+w.relay_url+'. This is not a receiver receipt.':'Connecting to '+w.relay_url+'...');
    const t=w.status;$('wanEntitlement').textContent=t?`${t.devices} / ${t.device_limit} device identities; access through ${new Date(t.expires*1000).toLocaleDateString()}. Relay payload usage ${(t.month_bytes/1048576).toFixed(1)} MiB of ${(t.month_limit/1048576).toFixed(0)} MiB this UTC month.`:'';
    // Label a WAN-selected contact without claiming that its model or receiver is available.
    document.querySelectorAll('#rigList [data-peer]').forEach(b=>{const id=b.dataset.peer;if(w.preferences.routes[id]!=='relay')return;const found=w.peers?.find(x=>x.device===id),s=b.querySelector('small');if(s)s.textContent=(found?.online&&Date.now()/1000-found.last_seen<75)?'Seen at relay - WAN':'Approved - WAN';b.title='WAN selected. Relay presence is not receiver acceptance.';});
  }
  function renderSettings(){
    state=D.getState();const w=state.wan,p=w.preferences;
    $('wanEnabled').checked=p.enabled;$('wanReceive').checked=p.receive_notes;
    $('wanRoutes').innerHTML=state.peers.map(r=>`<label class="wan-route"><span>${e(r.name)}</span><select data-wan-route="${e(r.id)}"><option value="lan">LAN only</option><option value="relay" ${r.wan?'':'disabled'}>Managed WAN</option></select></label>`).join('')||'<p class="microcopy">Approve a rig to select its path.</p>';
    document.querySelectorAll('[data-wan-route]').forEach(x=>x.value=p.routes[x.dataset.wanRoute]||'lan');
    $('wanGrants').innerHTML=state.peers.filter(x=>x.wan).map(r=>`<fieldset class="wan-peer-grants"><legend>${e(r.name)}</legend>${state.channels.map(c=>`<label class="wan-check"><input type="checkbox" data-grant-peer="${e(r.id)}" data-grant-channel="${e(c.id)}" ${(p.query_grants[r.id]||[]).includes(c.id)?'checked':''}>#${e(c.descriptor.name)}</label>`).join('')||'<p class="microcopy">Create or import a channel first.</p>'}</fieldset>`).join('')||'<p class="microcopy">Current 1.9 rig cards required.</p>';
    $('wanAskPeer').innerHTML=state.peers.filter(x=>x.wan).map(r=>`<option value="${e(r.id)}">${e(r.name)}</option>`).join('');
    $('wanAskChannel').innerHTML=state.channels.map(c=>`<option value="${e(c.id)}">#${e(c.descriptor.name)}</option>`).join('');
    refreshStatus();
  }
  async function open(){await D.refresh();renderSettings();if(!$('wanDialog').open)$('wanDialog').showModal();$('wanDialog').querySelector('.modal-body').scrollTop=0;}
  $('wanButton').onclick=()=>open().catch(D.toast);
  for(const id of ['closeWan','wanDone'])$(id).onclick=()=>$('wanDialog').close();
  window.addEventListener('braid:state',ev=>{state=ev.detail;refreshStatus();});
  $('wanRequest').onclick=()=>run(async()=>saveFile('Braid-'+state.fingerprint.slice(0,12)+'.braidjoin',await api('request')));
  $('wanImport').onclick=()=>$('wanActivationFile').click();
  $('wanActivationFile').onchange=()=>run(async()=>{
    const file=$('wanActivationFile').files[0];$('wanActivationFile').value='';if(!file)return;
    activation=null;$('wanActivationReview').hidden=true;$('wanActivationDetails').textContent='';
    if(file.size>32768)throw Error('Activation file too large.');
    const candidate=JSON.parse(await file.text());const v=await api('inspect-activation',{activation:candidate});activation=candidate;
    $('wanActivationDetails').textContent=JSON.stringify(v,null,2);$('wanActivationReview').hidden=false;$('wanConfirm').checked=false;$('wanOperatorFingerprint').value='';$('wanActivationFile').value='';
  });
  $('wanActivate').onclick=()=>run(async()=>{await job('activate',{activation,confirmed:$('wanConfirm').checked,operator_fingerprint:$('wanOperatorFingerprint').value.trim()});activation=null;$('wanActivationReview').hidden=true;await D.refresh();renderSettings();D.toast('Activated. Choose your WAN permissions.');});
  $('wanSave').onclick=()=>run(async()=>{
    const routes={},query_grants={};document.querySelectorAll('[data-wan-route]').forEach(x=>routes[x.dataset.wanRoute]=x.value);
    document.querySelectorAll('[data-grant-peer]:checked').forEach(x=>(query_grants[x.dataset.grantPeer]||=[]).push(x.dataset.grantChannel));
    await api('settings',{preferences:{enabled:$('wanEnabled').checked,receive_notes:$('wanReceive').checked,routes,query_grants}});await D.refresh();D.toast('WAN settings saved.');
  });
  $('wanPublish').onclick=()=>run(async()=>{await job('publish-card');D.toast('Current public card published. Other rigs must still approve it.');});
  $('wanDiscover').onclick=()=>run(async()=>{const r=await job('peers');$('wanDiscovered').innerHTML=r.peers.map(x=>`<div class="wan-route"><span>${e(x.name)}<small>${x.online?'Recently seen':'Not recently seen'} at relay</small></span><button class="btn small" data-inspect-wan="${e(x.device)}" ${x.card_available?'':'disabled'}>Review rig</button></div>`).join('')||'<p class="microcopy">No other enrolled devices. Activate and publish a card on your other rig.</p>';await D.refresh();});
  $('wanDiscovered').onclick=ev=>{const b=ev.target.closest('[data-inspect-wan]');if(b)run(async()=>{inspection=await job('inspect-peer',{peer:b.dataset.inspectWan});$('wanPeerDetails').textContent=JSON.stringify(inspection,null,2);$('wanPeerConfirm').checked=false;$('wanPeerReview').hidden=false;});};
  $('wanApprove').onclick=()=>run(async()=>{if(!$('wanPeerConfirm').checked)throw Error('Compare the fingerprint on your other rig first.');await D.api('approve-card',{inspection_id:inspection.inspection_id,fingerprint:inspection.fingerprint||inspection.id,confirmed:true});$('wanPeerReview').hidden=true;await D.refresh();renderSettings();});
  function answer(r){
    activeQuery=r.id;$('wanAnswer').hidden=false;
    const v=r.result||{};$('wanAnswer').textContent=r.state==='answered'?`${v.response}\n\nAnswered on ${v.answered_on||'the approved remote rig'} - ${v.shared_note_count||0} shared ${(v.shared_note_count===1)?'note':'notes'} supplied there.`:v.error||`Status: ${r.state}. Queued is not executed. This check never resends the question.`;
    $('wanAnswerEvidence').hidden=r.state!=='answered';$('wanAnswerRaw').textContent=JSON.stringify(v,null,2);
  }
  $('wanAsk').onclick=()=>run(async()=>{if(!confirm('Send only this question to the selected home rig and receive its answer and permitted source evidence?'))return;
    $('wanAsk').disabled=true;try{const r=await job('ask',{peer:$('wanAskPeer').value,channel:$('wanAskChannel').value,question:$('wanQuestion').value});activeQuery=r.wan_request_id;answer(await api('result',{id:activeQuery}));}finally{$('wanAsk').disabled=false;}});
  $('wanCheckQuestion').onclick=()=>run(async()=>{if(!activeQuery)throw Error('Select a previously sent question first.');answer(await job('check-query',{id:activeQuery}));});
  $('wanLoadHistory').onclick=()=>run(async()=>{const r=await api('requests');$('wanQueryHistory').innerHTML='<option value="">Choose a recorded question</option>'+r.requests.map(x=>`<option value="${e(x.id)}">${e(new Date(x.created*1000).toLocaleString())} - ${e(x.state)} - ${e(state.peers.find(p=>p.id===x.peer)?.name||x.peer.slice(0,12))}</option>`).join('');});
  $('wanQueryHistory').onchange=()=>run(async()=>{if($('wanQueryHistory').value)answer(await api('result',{id:$('wanQueryHistory').value}));});
  $('wanClear').onclick=()=>run(async()=>{if(!confirm('Disconnect this rig from Managed Relay? Local notes remain. This does not revoke the server-side device.'))return;await api('clear',{confirmed:true});await D.refresh();renderSettings();});
  document.addEventListener('click',ev=>{const b=ev.target.closest('[data-wan-check]');if(b){b.disabled=true;job('check',{message_id:b.dataset.wanCheck}).then(async r=>{D.toast('WAN result: '+r.state+'. No resend.');await D.refresh();}).catch(err=>D.toast(err.message)).finally(()=>b.disabled=false);}});
})();
