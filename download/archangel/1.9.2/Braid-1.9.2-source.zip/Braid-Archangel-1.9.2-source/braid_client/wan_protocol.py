"""Versioned, bounded WAN control messages and sealed peer payloads.

This is an application envelope, not a new cryptographic primitive or an HPKE
implementation. X25519/HKDF-SHA256/AES-256-GCM and Ed25519 come from cryptography.
Peer encryption keys are approved through signed rig cards, never relay discovery.
"""
from __future__ import annotations
import base64
import hashlib
import ipaddress
import json
import math
import os
import re
import time
import uuid
from typing import Any
from urllib.parse import urlsplit
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, x25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

API = '/braid/v1'
DEFAULT_RELAY = 'https://relay.intersignal.org'
CAPABILITY = 'managed-wan.v1'
SUITE = 'X25519-HKDF-SHA256-AES256GCM-Ed25519-v1'
MAX_HTTP = 16 * 1024 * 1024
MAX_PLAINTEXT = 2 * 1024 * 1024
MAX_PACKET = 3 * 1024 * 1024
MAX_CARD = 12 * 1024 * 1024
MAX_TTL = 300  # Never extend the retained BRAD frame's lifetime.
REPLY_TTL = 86400
HEX64 = re.compile(r'^[0-9a-f]{64}$')
HEX32 = re.compile(r'^[0-9a-f]{32}$')
MEMBER = re.compile(r'^[A-Za-z0-9_-]{1,64}$')


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                      allow_nan=False).encode('ascii')


def strict_json(raw: bytes | str, *, limit: int = MAX_HTTP) -> Any:
    if isinstance(raw, str):
        raw = raw.encode('utf-8', errors='strict')
    if not isinstance(raw, bytes) or len(raw) > limit:
        raise ValueError('ERR_WAN_SIZE')
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result: raise ValueError('ERR_WAN_DUPLICATE_JSON_KEY')
            result[key] = value
        return result
    try:
        value = json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=pairs,
            parse_constant=lambda _: (_ for _ in ()).throw(ValueError('ERR_WAN_NONFINITE')))
    except (RecursionError, UnicodeError) as exc:
        raise ValueError('ERR_WAN_JSON') from exc
    stack = [(value, 0)]; nodes = 0
    while stack:
        item, depth = stack.pop(); nodes += 1
        if depth > 24 or nodes > 60000: raise ValueError('ERR_WAN_STRUCTURE_LIMIT')
        if isinstance(item, str): item.encode('utf-8', 'strict')
        elif isinstance(item, dict):
            stack.extend((x, depth + 1) for pair in item.items() for x in pair)
        elif isinstance(item, list): stack.extend((x, depth + 1) for x in item)
        elif isinstance(item,float) and not math.isfinite(item):raise ValueError('ERR_WAN_NONFINITE')
        elif isinstance(item, int) and not isinstance(item, bool) and abs(item) > 2**63:
            raise ValueError('ERR_WAN_INTEGER_RANGE')
    return value


def hex64(value: Any) -> str:
    if not isinstance(value, str) or not HEX64.fullmatch(value): raise ValueError('ERR_WAN_IDENTITY')
    return value


def packet_id(value: Any) -> str:
    if not isinstance(value, str) or not HEX32.fullmatch(value): raise ValueError('ERR_WAN_PACKET_ID')
    return value


def member_id(value: Any) -> str:
    if not isinstance(value, str) or not MEMBER.fullmatch(value): raise ValueError('ERR_WAN_MEMBER_ID')
    return value


def public_hex(key) -> str:
    if hasattr(key, 'public_key'): key = key.public_key()
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()


def fingerprint(public: str) -> str:
    return hashlib.sha256(bytes.fromhex(hex64(public))).hexdigest()


def decode64(value: Any, maximum: int) -> bytes:
    if not isinstance(value, str) or len(value) > ((maximum + 2) // 3) * 4:
        raise ValueError('ERR_WAN_BASE64_SIZE')
    try: raw = base64.b64decode(value, validate=True)
    except Exception as exc: raise ValueError('ERR_WAN_BASE64') from exc
    if len(raw) > maximum: raise ValueError('ERR_WAN_BASE64_SIZE')
    return raw


def signed(key, value: dict, domain: bytes) -> dict:
    if 'signature' in value: raise ValueError('Already signed')
    return {**value, 'signature': key.sign(domain + canonical(value)).hex()}


def verified(value: dict, public: str, domain: bytes) -> dict:
    if not isinstance(value, dict): raise ValueError('ERR_WAN_OBJECT')
    raw = dict(value); sig = raw.pop('signature', '')
    if not isinstance(sig, str) or not re.fullmatch('[0-9a-f]{128}', sig):
        raise ValueError('ERR_WAN_SIGNATURE')
    try:
        ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(hex64(public))).verify(
            bytes.fromhex(sig), domain + canonical(raw))
    except Exception as exc: raise ValueError('ERR_WAN_SIGNATURE') from exc
    return raw


def relay_url(value: str, *, test_loopback: bool = False) -> str:
    u = urlsplit(value)
    if u.username or u.password or u.query or u.fragment or u.path not in ('', '/'):
        raise ValueError('ERR_WAN_RELAY_URL')
    host = u.hostname or ''
    if test_loopback:
        try: loopback = ipaddress.ip_address(host).is_loopback
        except ValueError: loopback = host == 'localhost'
        if loopback and u.scheme == 'https': return value.rstrip('/')
    if u.scheme != 'https' or not (host == 'relay.intersignal.org' or host.endswith('.relay.intersignal.org')):
        raise ValueError('Use an HTTPS Intersignal relay endpoint from your activation file.')
    if u.port not in (None, 443, 8443, 8751): raise ValueError('ERR_WAN_RELAY_PORT')
    return value.rstrip('/')


def rig_wan(card: dict) -> dict | None:
    value = card.get('wan')
    if value is None: return None
    if not isinstance(value, dict) or set(value) != {'protocol', 'encryption_key'}:
        raise ValueError('ERR_WAN_CARD_EXTENSION')
    if value['protocol'] != CAPABILITY: raise ValueError('ERR_WAN_CARD_PROTOCOL')
    public = hex64(value['encryption_key'])
    # Reject low-order points here as well as at every actual exchange.
    x25519.X25519PrivateKey.generate().exchange(x25519.X25519PublicKey.from_public_bytes(bytes.fromhex(public)))
    return dict(value)


def join_request(key, encryption_key: str, name: str) -> dict:
    return signed(key, {'schema': 'intersignal.braid.member-request.v1',
        'device': fingerprint(public_hex(key)), 'public_key': public_hex(key),
        'encryption_key': hex64(encryption_key), 'name': str(name)[:80], 'created': int(time.time())},
        b'BRAID-MEMBER-REQUEST-v1\0')


def verify_join(value: dict) -> dict:
    raw = verified(value, value.get('public_key', ''), b'BRAID-MEMBER-REQUEST-v1\0')
    if set(raw) != {'schema','device','public_key','encryption_key','name','created'} or raw['schema'] != 'intersignal.braid.member-request.v1':
        raise ValueError('ERR_WAN_MEMBER_REQUEST')
    if fingerprint(raw['public_key']) != raw['device']: raise ValueError('ERR_WAN_MEMBER_IDENTITY')
    hex64(raw['encryption_key'])
    x25519.X25519PrivateKey.generate().exchange(x25519.X25519PublicKey.from_public_bytes(bytes.fromhex(raw['encryption_key'])))
    if not isinstance(raw['name'], str) or not 1 <= len(raw['name']) <= 80: raise ValueError('ERR_WAN_NAME')
    return raw


def make_request(key, member: str, action: str, data: dict, *, now: int | None = None) -> dict:
    return signed(key, {'schema':'intersignal.braid.wan-request.v1', 'member':member_id(member),
        'device':fingerprint(public_hex(key)), 'action':action, 'data':data,
        'timestamp':int(time.time()) if now is None else now, 'nonce':uuid.uuid4().hex}, b'BRAID-WAN-REQUEST-v1\0')


def check_request(req: dict, public: str, *, now: int | None = None) -> dict:
    raw = verified(req, public, b'BRAID-WAN-REQUEST-v1\0')
    if set(raw) != {'schema','member','device','action','data','timestamp','nonce'} or raw['schema'] != 'intersignal.braid.wan-request.v1':
        raise ValueError('ERR_WAN_REQUEST_SCHEMA')
    if fingerprint(public) != raw['device']: raise ValueError('ERR_WAN_REQUEST_IDENTITY')
    member_id(raw['member']); packet_id(raw['nonce'])
    now = int(time.time()) if now is None else now
    if type(raw['timestamp']) is not int or abs(now - raw['timestamp']) > 60:
        raise ValueError('ERR_WAN_CLOCK: enable automatic time on both rigs; no clock checks were relaxed.')
    if not isinstance(raw['data'], dict): raise ValueError('ERR_WAN_REQUEST_DATA')
    return raw


def server_response(key, request: dict, data: dict) -> dict:
    return signed(key, {'schema':'intersignal.braid.wan-response.v1',
        'request_nonce':request['nonce'], 'request_sha256':hashlib.sha256(canonical(request)).hexdigest(),
        'timestamp':int(time.time()), 'data':data}, b'BRAID-WAN-RESPONSE-v1\0')


def check_response(value: dict, public: str, request: dict) -> dict:
    raw = verified(value, public, b'BRAID-WAN-RESPONSE-v1\0')
    if raw.get('schema') != 'intersignal.braid.wan-response.v1' or raw.get('request_nonce') != request['nonce'] or raw.get('request_sha256') != hashlib.sha256(canonical(request)).hexdigest():
        raise ValueError('ERR_WAN_RESPONSE_BINDING')
    if type(raw.get('timestamp')) is not int or abs(time.time()-raw['timestamp']) > 90:
        raise ValueError('ERR_WAN_RESPONSE_CLOCK')
    if not isinstance(raw.get('data'), dict): raise ValueError('ERR_WAN_RESPONSE_DATA')
    return raw['data']


def seal(key, recipient: str, encryption_public: str, member: str, payload: dict,
         *, ident: str | None = None, ttl: int = MAX_TTL, now: int | None = None) -> dict:
    plain = canonical(payload)
    if len(plain) > MAX_PLAINTEXT: raise ValueError('ERR_WAN_PAYLOAD_LIMIT')
    if type(ttl) is not int or not 1 <= ttl <= REPLY_TTL: raise ValueError('ERR_WAN_TTL')
    now = int(time.time()) if now is None else now
    eph = x25519.X25519PrivateKey.generate()
    header = {'schema':'intersignal.braid.sealed.v1','suite':SUITE, 'id':packet_id(ident or uuid.uuid4().hex),
        'member':member_id(member),'sender':fingerprint(public_hex(key)), 'recipient':hex64(recipient),
        'recipient_key_sha256':hashlib.sha256(bytes.fromhex(hex64(encryption_public))).hexdigest(),
        'ephemeral_key':public_hex(eph), 'nonce':os.urandom(12).hex(), 'created':now,'expires':now+ttl}
    aad = canonical(header)
    shared = eph.exchange(x25519.X25519PublicKey.from_public_bytes(bytes.fromhex(encryption_public)))
    aes = HKDF(algorithm=hashes.SHA256(),length=32,salt=hashlib.sha256(aad).digest(),
               info=b'BRAID-WAN-SEAL-v1\0'+aad).derive(shared)
    cipher = AESGCM(aes).encrypt(bytes.fromhex(header['nonce']), plain, aad)
    return signed(key, {**header,'ciphertext':base64.b64encode(cipher).decode('ascii')}, b'BRAID-WAN-SEALED-v1\0')


def verify_packet(packet: dict, public: str, *, allow_expired: bool = False, now: int | None = None) -> dict:
    if len(canonical(packet)) > MAX_PACKET: raise ValueError('ERR_WAN_PACKET_LIMIT')
    raw = verified(packet, public, b'BRAID-WAN-SEALED-v1\0')
    fields={'schema','suite','id','member','sender','recipient','recipient_key_sha256','ephemeral_key','nonce','created','expires','ciphertext'}
    if set(raw)!=fields or raw['schema']!='intersignal.braid.sealed.v1' or raw['suite']!=SUITE:
        raise ValueError('ERR_WAN_ENVELOPE_SCHEMA')
    packet_id(raw['id']);member_id(raw['member'])
    for field in ('sender','recipient','recipient_key_sha256','ephemeral_key'):hex64(raw[field])
    if raw['sender']!=fingerprint(public):raise ValueError('ERR_WAN_SENDER_BINDING')
    if not isinstance(raw['nonce'],str) or not re.fullmatch('[0-9a-f]{24}',raw['nonce']):raise ValueError('ERR_WAN_NONCE')
    if type(raw['created']) is not int or type(raw['expires']) is not int or not 0 < raw['expires']-raw['created'] <= REPLY_TTL:
        raise ValueError('ERR_WAN_EXPIRY')
    now=int(time.time()) if now is None else now
    if raw['created']>now+60 or (not allow_expired and raw['expires']<=now):raise ValueError('ERR_WAN_EXPIRED_OR_FUTURE')
    decode64(raw['ciphertext'],MAX_PLAINTEXT+16)
    return raw


def open_packet(packet: dict, sender_public: str, key, recipient: str, member: str,
                *, allow_expired: bool = False) -> dict:
    raw=verify_packet(packet,sender_public,allow_expired=allow_expired)
    if raw['recipient']!=recipient or raw['member']!=member:raise ValueError('ERR_WAN_DESTINATION')
    if raw['recipient_key_sha256']!=hashlib.sha256(bytes.fromhex(public_hex(key))).hexdigest():
        raise ValueError('ERR_WAN_RECIPIENT_KEY')
    cipher=decode64(raw.pop('ciphertext'),MAX_PLAINTEXT+16)
    aad=canonical(raw)
    shared=key.exchange(x25519.X25519PublicKey.from_public_bytes(bytes.fromhex(raw['ephemeral_key'])))
    aes=HKDF(algorithm=hashes.SHA256(),length=32,salt=hashlib.sha256(aad).digest(),info=b'BRAID-WAN-SEAL-v1\0'+aad).derive(shared)
    plain=AESGCM(aes).decrypt(bytes.fromhex(raw['nonce']),cipher,aad)
    value=strict_json(plain,limit=MAX_PLAINTEXT)
    if not isinstance(value,dict):raise ValueError('ERR_WAN_PLAINTEXT_OBJECT')
    return value
