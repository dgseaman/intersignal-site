"""Intersignal-operated, multi-tenant encrypted relay; administration is CLI-only.

The HTTP service stores opaque peer envelopes. Its success is NEVER receiver
acceptance. Run behind an HTTPS reverse proxy or with the supplied TLS options.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
import secrets
import socket
import sqlite3
import ssl
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from socketserver import ThreadingMixIn
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from .private_files import private_dir, atomic_private_write, secure_path
from . import wan_protocol as p


class RelayStore:
    def __init__(self, root: Path, *, max_storage: int = 512 * 1024 * 1024):
        self.root=Path(root);private_dir(self.root)
        self.path=self.root/'relay.sqlite3';self.max_storage=max_storage
        keypath=self.root/'operator-signing.pem'
        if not keypath.exists():
            if self.path.exists():raise ValueError('Existing relay database has no operator key. Restore the original key; refusing silent rotation.')
            key=ed25519.Ed25519PrivateKey.generate()
            atomic_private_write(keypath,key.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        self.key=serialization.load_pem_private_key(keypath.read_bytes(),password=None)
        if not isinstance(self.key,ed25519.Ed25519PrivateKey):raise ValueError('Operator key must be Ed25519')
        self.public=p.public_hex(self.key)
        with self.db() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS members(id TEXT PRIMARY KEY,enabled INTEGER NOT NULL,expires INTEGER NOT NULL,
                max_devices INTEGER NOT NULL,month_limit INTEGER NOT NULL,queue_limit INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS devices(member TEXT,device TEXT,public_key TEXT,encryption_key TEXT,name TEXT,
                active INTEGER,card TEXT,card_revision INTEGER,last_seen REAL,PRIMARY KEY(member,device));
            CREATE TABLE IF NOT EXISTS invites(token_hash TEXT PRIMARY KEY,member TEXT,device TEXT,public_key TEXT,
                encryption_key TEXT,name TEXT,expires INTEGER,used INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS nonces(member TEXT,device TEXT,nonce TEXT,created REAL,PRIMARY KEY(member,device,nonce));
            CREATE INDEX IF NOT EXISTS nonce_expiry ON nonces(created);
            CREATE TABLE IF NOT EXISTS rates(member TEXT,device TEXT,bucket INTEGER,count INTEGER,PRIMARY KEY(member,device,bucket));
            CREATE TABLE IF NOT EXISTS usage(member TEXT,month TEXT,bytes INTEGER,PRIMARY KEY(member,month));
            CREATE TABLE IF NOT EXISTS packets(member TEXT,id TEXT,sender TEXT,recipient TEXT,sha TEXT,
                envelope BLOB,expires INTEGER,reply BLOB,created REAL,lease REAL DEFAULT 0,
                PRIMARY KEY(member,id));
            CREATE INDEX IF NOT EXISTS packet_expiry ON packets(expires);
            CREATE INDEX IF NOT EXISTS recipient_queue ON packets(member,recipient,expires);
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,created REAL,event TEXT,member TEXT,device TEXT);
            ''')
        secure_path(self.path)

    @contextlib.contextmanager
    def db(self):
        db=sqlite3.connect(self.path,timeout=10);db.row_factory=sqlite3.Row
        db.execute('PRAGMA synchronous=FULL')
        try:
            with db:yield db
        finally:db.close()

    def member(self, ident: str, *, devices: int=2, expires: int, month_limit: int=1024**3,
               queue_limit: int=16*1024**2):
        p.member_id(ident)
        if type(devices) is not int or not 2<=devices<=16:raise ValueError('Choose 2 to 16 device identities.')
        if expires<=time.time() or not 1<=month_limit<=1024**4 or not 1<=queue_limit<=256*1024**2:raise ValueError('Invalid member limits or expiry')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT COUNT(*) FROM devices WHERE member=? AND active=1',(ident,)).fetchone()[0]>devices:
                raise ValueError('Revoke surplus devices explicitly before lowering this member limit.')
            db.execute('INSERT INTO members VALUES (?,1,?,?,?,?) ON CONFLICT(id) DO UPDATE SET expires=excluded.expires,max_devices=excluded.max_devices,month_limit=excluded.month_limit,queue_limit=excluded.queue_limit',
                       (ident,expires,devices,month_limit,queue_limit))
            self.audit(db,'member-configured',ident,'')

    def audit(self,db,event,member,device):
        db.execute('INSERT INTO audit(created,event,member,device) VALUES (?,?,?,?)',(time.time(),event,member,device))

    def set_member_enabled(self,member,enabled):
        with self.db() as db:
            if db.execute('UPDATE members SET enabled=? WHERE id=?',(int(enabled),member)).rowcount!=1:raise ValueError('Unknown member')
            self.audit(db,'member-resumed' if enabled else 'member-suspended',member,'')

    def revoke_device(self,member,device):
        with self.db() as db:
            db.execute('UPDATE devices SET active=0 WHERE member=? AND device=?',(member,device))
            db.execute('DELETE FROM invites WHERE member=? AND device=?',(member,device))
            self.audit(db,'device-revoked',member,device)

    def issue(self,request:dict,member:str,base_url:str,*,ca_pem:str='',test_loopback:bool=False)->dict:
        join=p.verify_join(request);base=p.relay_url(base_url,test_loopback=test_loopback)
        token=secrets.token_urlsafe(32);expire=int(time.time())+7*86400
        with self.db() as db:
            self._active_member(db,member)
            db.execute('DELETE FROM invites WHERE member=? AND device=?',(member,join['device']))
            db.execute('INSERT INTO invites VALUES (?,?,?,?,?,?,?,0)',(hashlib.sha256(token.encode()).hexdigest(),member,join['device'],join['public_key'],join['encryption_key'],join['name'],expire))
            self.audit(db,'activation-issued',member,join['device'])
        return p.signed(self.key,{'schema':'intersignal.braid.member-activation.v1','member':member,
            'device':join['device'],'encryption_key':join['encryption_key'],'relay_url':base,
            'operator_key':self.public,'enrollment_token':token,'expires':expire,'ca_pem':ca_pem},b'BRAID-MEMBER-ACTIVATION-v1\0')

    def _active_member(self,db,member):
        row=db.execute('SELECT * FROM members WHERE id=?',(member,)).fetchone()
        if row is None or not row['enabled']:raise ValueError('ERR_WAN_MEMBERSHIP_INACTIVE')
        if row['expires']<=time.time():raise ValueError('ERR_WAN_MEMBERSHIP_EXPIRED')
        return row

    def _active_device(self,db,member,device):
        row=db.execute('SELECT * FROM devices WHERE member=? AND device=? AND active=1',(member,device)).fetchone()
        if row is None:raise ValueError('ERR_WAN_DEVICE_NOT_ENROLLED')
        return row

    def _status(self,db,m):
        used=db.execute('SELECT bytes FROM usage WHERE member=? AND month=?',(m['id'],self._month())).fetchone()
        return {'member':m['id'],'expires':m['expires'],'device_limit':m['max_devices'],
            'devices':db.execute('SELECT COUNT(*) FROM devices WHERE member=? AND active=1',(m['id'],)).fetchone()[0],
            'month_bytes':used[0] if used else 0,'month_limit':m['month_limit'], 'server_time':int(time.time())}

    @staticmethod
    def _month():return datetime.now(timezone.utc).strftime('%Y-%m')

    def _stored_bytes(self,db):
        packets=db.execute('SELECT COALESCE(SUM(length(envelope)+COALESCE(length(reply),0)),0) FROM packets').fetchone()[0]
        cards=db.execute('SELECT COALESCE(SUM(length(card)),0) FROM devices').fetchone()[0]
        return packets+cards

    def _charge(self,db,m,size):
        month=self._month()
        used=db.execute('SELECT bytes FROM usage WHERE member=? AND month=?',(m['id'],month)).fetchone()
        if (used[0] if used else 0)+size>m['month_limit']:raise ValueError('ERR_WAN_BANDWIDTH_LIMIT')
        db.execute('INSERT INTO usage VALUES (?,?,?) ON CONFLICT(member,month) DO UPDATE SET bytes=bytes+excluded.bytes',(m['id'],month,size))

    def apply(self,request:dict)->dict:
        # Authentication, nonce reservation, entitlement, quota and operation all
        # share one DB transaction. No HTTP endpoint can administer membership.
        if not isinstance(request,dict):raise ValueError('ERR_WAN_REQUEST')
        member=p.member_id(request.get('member'));device=p.hex64(request.get('device'))
        action=request.get('action');data=request.get('data')
        if not isinstance(data,dict):raise ValueError('ERR_WAN_REQUEST_DATA')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            m=self._active_member(db,member)
            invite=None
            if action=='enroll':
                token=data.get('enrollment_token','')
                if not isinstance(token,str) or not 20<=len(token)<=100:raise ValueError('ERR_WAN_ENROLLMENT')
                invite=db.execute('SELECT * FROM invites WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
                if not invite or invite['member']!=member or invite['device']!=device or invite['expires']<=time.time():raise ValueError('ERR_WAN_ENROLLMENT')
                public=invite['public_key']
            else:public=self._active_device(db,member,device)['public_key']
            req=p.check_request(request,public)
            now=time.time()
            db.execute('DELETE FROM nonces WHERE created<?',(now-180,))
            try:db.execute('INSERT INTO nonces VALUES (?,?,?,?)',(member,device,req['nonce'],now))
            except sqlite3.IntegrityError as exc:raise ValueError('ERR_WAN_REQUEST_REPLAY') from exc
            bucket=int(now)//60
            db.execute('DELETE FROM rates WHERE bucket<?',(bucket-2,))
            db.execute('INSERT INTO rates VALUES (?,?,?,1) ON CONFLICT(member,device,bucket) DO UPDATE SET count=count+1',(member,device,bucket))
            if db.execute('SELECT count FROM rates WHERE member=? AND device=? AND bucket=?',(member,device,bucket)).fetchone()[0]>180:
                raise ValueError('ERR_WAN_RATE_LIMIT')
            # Expired envelopes are no longer delivered; response evidence remains
            # for 24 hours. Deletion is NOT a negative receiver acknowledgment.
            db.execute('DELETE FROM packets WHERE expires<?',(now-86400,))
            db.execute('DELETE FROM invites WHERE expires<?',(now-86400,))
            db.execute('DELETE FROM audit WHERE created<?',(now-180*86400,))
            if action=='enroll':
                old=db.execute('SELECT * FROM devices WHERE member=? AND device=?',(member,device)).fetchone()
                if invite['used'] and (not old or not old['active']):raise ValueError('ERR_WAN_ACTIVATION_USED')
                if old and (old['public_key']!=public or old['encryption_key']!=invite['encryption_key']):raise ValueError('ERR_WAN_DEVICE_KEY_CHANGED')
                if not old or not old['active']:
                    count=db.execute('SELECT COUNT(*) FROM devices WHERE member=? AND active=1',(member,)).fetchone()[0]
                    if count>=m['max_devices']:raise ValueError('ERR_WAN_DEVICE_LIMIT')
                    db.execute('INSERT INTO devices VALUES (?,?,?,?,?,1,NULL,0,?) ON CONFLICT(member,device) DO UPDATE SET active=1,last_seen=excluded.last_seen',
                               (member,device,public,invite['encryption_key'],invite['name'],now))
                    self.audit(db,'device-enrolled',member,device)
                db.execute('UPDATE invites SET used=1 WHERE token_hash=?',(invite['token_hash'],))
                result={'enrolled':True,'status':self._status(db,m)}
            elif action=='status':result={'status':self._status(db,m)}
            elif action=='publish-card':
                card=data.get('card');raw=p.canonical(card)
                if len(raw)>p.MAX_CARD:raise ValueError('ERR_WAN_CARD_SIZE')
                checked=p.verified(card,public,b'BRAID-RIG-CARD-v1\0')
                if checked.get('schema')!='intersignal.braid.rig-card.v1' or checked.get('fingerprint')!=device:raise ValueError('ERR_WAN_CARD_IDENTITY')
                device_row=self._active_device(db,member,device);wan=p.rig_wan(checked)
                if not wan or wan['encryption_key']!=device_row['encryption_key'] or p.CAPABILITY not in checked.get('capabilities',[]):raise ValueError('ERR_WAN_CARD_KEY')
                rev=checked.get('revision')
                if type(rev) is not int or not 0<rev<2**63:raise ValueError('ERR_WAN_CARD_REVISION')
                if rev<device_row['card_revision'] or (rev==device_row['card_revision'] and device_row['card']!=raw.decode()):raise ValueError('ERR_WAN_CARD_ROLLBACK')
                old_size=len((device_row['card'] or '').encode())
                if self._stored_bytes(db)-old_size+len(raw)>self.max_storage:raise ValueError('ERR_WAN_GLOBAL_STORAGE_LIMIT')
                self._charge(db,m,len(raw))
                db.execute('UPDATE devices SET card=?,card_revision=?,name=? WHERE member=? AND device=?',(raw.decode(),rev,str(checked.get('name',''))[:80],member,device))
                result={'published':True,'revision':rev}
            elif action=='peers':
                peers=db.execute('SELECT device,name,last_seen,card_revision FROM devices WHERE member=? AND active=1 AND device!=?',(member,device)).fetchall()
                result={'peers':[dict(r,online=now-r['last_seen']<75,card_available=bool(r['card_revision'])) for r in peers], 'status':self._status(db,m),
                    'meaning':'Recent authenticated relay activity only; not admission or model availability.'}
            elif action=='card':
                peer=self._active_device(db,member,p.hex64(data.get('peer')))
                if not peer['card']:raise ValueError('ERR_WAN_CARD_NOT_PUBLISHED')
                self._charge(db,m,len(peer['card'].encode()))
                result={'card':p.strict_json(peer['card'])}
            elif action=='enqueue':
                envelope=data.get('envelope');checked=p.verify_packet(envelope,public)
                if checked['member']!=member or checked['sender']!=device or checked['recipient']==device:raise ValueError('ERR_WAN_ROUTING')
                if checked['expires']-checked['created']>p.MAX_TTL:raise ValueError('ERR_WAN_REQUEST_TTL')
                peer=self._active_device(db,member,checked['recipient'])
                if checked['recipient_key_sha256']!=hashlib.sha256(bytes.fromhex(peer['encryption_key'])).hexdigest():raise ValueError('ERR_WAN_DESTINATION_KEY')
                raw=p.canonical(envelope);sha=hashlib.sha256(raw).hexdigest()
                old=db.execute('SELECT * FROM packets WHERE member=? AND id=?',(member,checked['id'])).fetchone()
                if old:
                    if old['sha']!=sha or old['sender']!=device:raise ValueError('ERR_WAN_PACKET_COLLISION')
                else:
                    outstanding=db.execute('SELECT COUNT(*),COALESCE(SUM(length(envelope)+COALESCE(length(reply),0)),0) FROM packets WHERE member=?',(member,)).fetchone()
                    if outstanding[0]>=256 or outstanding[1]+len(raw)>m['queue_limit']:raise ValueError('ERR_WAN_QUEUE_LIMIT')
                    total=self._stored_bytes(db)
                    if total+len(raw)>self.max_storage:raise ValueError('ERR_WAN_GLOBAL_STORAGE_LIMIT')
                    self._charge(db,m,len(raw))
                    db.execute('INSERT INTO packets(member,id,sender,recipient,sha,envelope,expires,created) VALUES (?,?,?,?,?,?,?,?)',
                               (member,checked['id'],device,checked['recipient'],sha,raw,checked['expires'],now))
                result={'stored_at_relay':True,'receiver_confirmed':False,'id':checked['id'],'expires':checked['expires']}
            elif action=='poll':
                row=db.execute('SELECT * FROM packets WHERE member=? AND recipient=? AND reply IS NULL AND expires>? AND lease<? ORDER BY created LIMIT 1',(member,device,now,now)).fetchone()
                if row:
                    # Revoked publishers cannot continue dispatching queued work.
                    sender=db.execute('SELECT active FROM devices WHERE member=? AND device=?',(member,row['sender'])).fetchone()
                    if not sender or not sender[0]:
                        db.execute('DELETE FROM packets WHERE member=? AND id=?',(member,row['id']));row=None
                if row:
                    self._charge(db,m,len(row['envelope']))
                    db.execute('UPDATE packets SET lease=? WHERE member=? AND id=?',(now+20,member,row['id']))
                result={'envelope':p.strict_json(bytes(row['envelope'])) if row else None,'status':self._status(db,m)}
            elif action=='reply':
                ident=p.packet_id(data.get('id'));row=db.execute('SELECT * FROM packets WHERE member=? AND id=? AND recipient=?',(member,ident,device)).fetchone()
                if row is None:raise ValueError('ERR_WAN_REQUEST_NOT_FOUND')
                reply=data.get('envelope');checked=p.verify_packet(reply,public)
                peer=self._active_device(db,member,row['sender'])
                if checked['member']!=member or checked['recipient']!=row['sender'] or checked['recipient_key_sha256']!=hashlib.sha256(bytes.fromhex(peer['encryption_key'])).hexdigest():raise ValueError('ERR_WAN_REPLY_DESTINATION')
                raw=p.canonical(reply)
                if row['reply'] is not None and bytes(row['reply'])!=raw:raise ValueError('ERR_WAN_REPLY_IMMUTABLE')
                if row['reply'] is None:
                    used=db.execute('SELECT COALESCE(SUM(length(envelope)+COALESCE(length(reply),0)),0) FROM packets WHERE member=?',(member,)).fetchone()[0]
                    total=self._stored_bytes(db)
                    if used+len(raw)>m['queue_limit'] or total+len(raw)>self.max_storage:raise ValueError('ERR_WAN_REPLY_STORAGE_LIMIT')
                    self._charge(db,m,len(raw));db.execute('UPDATE packets SET reply=? WHERE member=? AND id=?',(raw,member,ident))
                result={'stored_reply':True,'id':ident}
            elif action=='result':
                ident=p.packet_id(data.get('id'));row=db.execute('SELECT * FROM packets WHERE member=? AND id=? AND sender=?',(member,ident,device)).fetchone()
                if row and row['reply']:
                    self._charge(db,m,len(row['reply']))
                    result={'reply':p.strict_json(bytes(row['reply'])),'state':'receiver_response_available'}
                else:result={'reply':None,'state':('waiting' if row and row['expires']>now else 'unconfirmed'),'receiver_confirmed':False}
            else:raise ValueError('ERR_WAN_UNKNOWN_ACTION')
            db.execute('UPDATE devices SET last_seen=? WHERE member=? AND device=?',(now,member,device))
        return p.server_response(self.key,request,result)

    def maintenance(self):
        now=time.time()
        with self.db() as db:
            db.execute('DELETE FROM packets WHERE expires<?',(now-86400,))
            db.execute('DELETE FROM invites WHERE expires<?',(now-86400,))
            db.execute('DELETE FROM nonces WHERE created<?',(now-180,))
            db.execute('DELETE FROM rates WHERE bucket<?',(int(now)//60-2,))
            db.execute('DELETE FROM audit WHERE created<?',(now-180*86400,))

    def summary(self):
        with self.db() as db:
            return {'operator_fingerprint':p.fingerprint(self.public),
                'members':[dict(r) for r in db.execute('SELECT * FROM members')],
                'active_devices':db.execute('SELECT COUNT(*) FROM devices WHERE active=1').fetchone()[0],
                'retained_packets':db.execute('SELECT COUNT(*) FROM packets').fetchone()[0]}


class RelayHTTPServer(ThreadingMixIn,HTTPServer):
    daemon_threads=True;allow_reuse_address=True;request_queue_size=64
    def __init__(self,address,store:RelayStore,tls_context=None):
        self.store=store;self.tls_context=tls_context;self.slots=threading.BoundedSemaphore(8);self.maintenance_due=0
        super().__init__(address,RelayHandler)
    def service_actions(self):
        if time.monotonic()>self.maintenance_due:
            try:self.store.maintenance()
            except sqlite3.Error:pass
            self.maintenance_due=time.monotonic()+60
    def process_request(self,request,client_address):
        if not self.slots.acquire(False):self.shutdown_request(request);return
        try:super().process_request(request,client_address)
        except BaseException:self.slots.release();raise
    def process_request_thread(self,request,client_address):
        try:
            request.settimeout(5)
            if self.tls_context:
                request=self.tls_context.wrap_socket(request,server_side=True)
            super().process_request_thread(request,client_address)
        except (OSError,ssl.SSLError):self.shutdown_request(request)
        finally:self.slots.release()


class RelayHandler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.0';server_version='BraidRelay/1.9'
    def log_message(self,*args):pass  # Never log activation bodies or peer content.
    def handle(self):
        def expire():
            try:self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:pass
        timer=threading.Timer(15,expire);timer.daemon=True;timer.start()
        try:super().handle()
        finally:timer.cancel()
    def output(self,value,code=200):
        raw=p.canonical(value);self.send_response(code)
        self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.end_headers()
        try:self.wfile.write(raw)
        except OSError:pass
    def do_GET(self):
        if self.path==p.API+'/health':self.output({'service':'braid-managed-wan','protocol':1,'receiver_authority':False})
        else:self.output({'error':'NOT_FOUND'},404)
    def do_POST(self):
        if self.path!=p.API+'/rpc':self.output({'error':'NOT_FOUND'},404);return
        if self.headers.get('Origin') or self.headers.get('Sec-Fetch-Site'):
            self.output({'error':'ERR_WAN_BROWSER_NOT_ALLOWED'},403);return
        try:
            lengths=self.headers.get_all('Content-Length') or []
            if len(lengths)!=1 or not lengths[0].isdigit() or self.headers.get('Transfer-Encoding'):
                raise ValueError('ERR_WAN_LENGTH')
            size=int(lengths[0])
            if not 1<=size<=p.MAX_HTTP:raise ValueError('ERR_WAN_BODY_LIMIT')
            if self.headers.get_content_type()!='application/json':raise ValueError('ERR_WAN_JSON_REQUIRED')
            raw=self.rfile.read(size)
            if len(raw)!=size:raise ValueError('ERR_WAN_TRUNCATED_BODY')
            self.output(self.server.store.apply(p.strict_json(raw)))
        except (ValueError,KeyError,TypeError) as exc:
            # Error codes only. Raw requests/tokens/signatures never become logs.
            self.output({'error':str(exc)[:220]},403)
        except Exception:
            self.output({'error':'ERR_WAN_SERVICE_UNAVAILABLE'},503)


def _expiry(value):
    dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def main(argv=None):
    parser=argparse.ArgumentParser(description='Intersignal relay operator. Not a member-side setup requirement.')
    parser.add_argument('--state',type=Path,required=True)
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('status')
    create=sub.add_parser('member');create.add_argument('id');create.add_argument('--devices',type=int,default=2)
    create.add_argument('--expires',required=True);create.add_argument('--month-bytes',type=int,default=1024**3)
    create.add_argument('--queue-bytes',type=int,default=16*1024**2)
    for name in ('suspend','resume'):
        c=sub.add_parser(name);c.add_argument('id')
    revoke=sub.add_parser('revoke-device');revoke.add_argument('id');revoke.add_argument('device')
    issue=sub.add_parser('issue');issue.add_argument('member');issue.add_argument('--request',type=Path,required=True)
    issue.add_argument('--out',type=Path,required=True);issue.add_argument('--relay',default=p.DEFAULT_RELAY)
    issue.add_argument('--ca',type=Path)
    serve=sub.add_parser('serve');serve.add_argument('--bind',default='127.0.0.1');serve.add_argument('--port',type=int,default=8765)
    serve.add_argument('--tls-cert',type=Path);serve.add_argument('--tls-key',type=Path)
    args=parser.parse_args(argv);store=RelayStore(args.state)
    if args.command=='member':store.member(args.id,devices=args.devices,expires=_expiry(args.expires),month_limit=args.month_bytes,queue_limit=args.queue_bytes)
    elif args.command in ('suspend','resume'):store.set_member_enabled(args.id,args.command=='resume')
    elif args.command=='revoke-device':store.revoke_device(args.id,args.device)
    elif args.command=='issue':
        if args.out.exists():raise SystemExit('Refusing to overwrite an activation file.')
        result=store.issue(p.strict_json(args.request.read_bytes(),limit=16384),args.member,args.relay,
            ca_pem=args.ca.read_text() if args.ca else '')
        atomic_private_write(args.out,p.canonical(result))
        print('Activation written privately. Operator fingerprint:',p.fingerprint(store.public));return
    elif args.command=='serve':
        ctx=None
        if args.tls_cert and args.tls_key:
            ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.minimum_version=ssl.TLSVersion.TLSv1_3
            ctx.load_cert_chain(str(args.tls_cert),str(args.tls_key))
        elif args.bind not in ('127.0.0.1','::1','localhost'):raise SystemExit('Public binding requires TLS; normally use the loopback reverse-proxy deployment.')
        server=RelayHTTPServer((args.bind,args.port),store,ctx)
        print('Braid managed relay listening; CLI-only administration. No receiver acceptance at relay.')
        try:server.serve_forever()
        except KeyboardInterrupt:pass
        finally:server.server_close()
        return
    print(json.dumps(store.summary(),indent=2))


if __name__=='__main__':main()
