"""Bounded, signed Folio connection metadata.

Folio publications expose only the publisher's public signing identity. Rig cards
are exchanged privately through the request/decision queue after a reader opts in.
"""
from __future__ import annotations

import hashlib
import re
import time
from typing import Any
from urllib.parse import urlsplit

from . import wan_protocol as wire

PUBLICATION_DOMAIN = b'BRAID-FOLIO-PUBLICATION-v1\0'
REQUEST_DOMAIN = b'BRAID-FOLIO-REQUEST-v1\0'
DECISION_DOMAIN = b'BRAID-FOLIO-DECISION-v1\0'
AUTH_DOMAIN = b'BRAID-FOLIO-AUTH-v1\0'
CARD_DOMAIN = b'BRAID-FOLIO-CARD-v1\0'
FIRST_MESSAGE_DOMAIN = b'BRAID-FOLIO-FIRST-MESSAGE-v1\0'
PUBLICATION_TYPE = 'braid_folio_publication'
REQUEST_TYPE = 'braid_connection_request'
DECISION_TYPE = 'braid_connection_decision'
AUTH_TYPE = 'braid_folio_auth'
SCOPES = frozenset({'follow_publications', 'messages', 'publication_channel'})
ID32 = re.compile(r'^[0-9a-f]{32}$')
ID64 = re.compile(r'^[0-9a-f]{64}$')
MAX_REFERRAL_BYTES = 16 * 1024
MAX_REQUEST_BYTES = 16 * 1024
REQUEST_LIFETIME = 7 * 86400


def _id(value: Any, length: int) -> str:
    pattern = ID32 if length == 32 else ID64
    if not isinstance(value, str) or not pattern.fullmatch(value):
        raise ValueError('ERR_FOLIO_ID')
    return value


def _identity(public: Any, fingerprint: Any) -> tuple[str, str]:
    public = _id(public, 64)
    fingerprint = _id(fingerprint, 64)
    if hashlib.sha256(bytes.fromhex(public)).hexdigest() != fingerprint:
        raise ValueError('ERR_FOLIO_IDENTITY_BINDING')
    return public, fingerprint


def scopes(value: Any, *, allow_empty: bool = False) -> list[str]:
    if not isinstance(value, list) or len(value) > len(SCOPES) or any(x not in SCOPES for x in value):
        raise ValueError('ERR_FOLIO_SCOPE')
    result = sorted(set(value))
    if len(result) != len(value) or (not result and not allow_empty):
        raise ValueError('ERR_FOLIO_SCOPE')
    return result


def publication_url(value: Any) -> str:
    if value in ('', None):
        return ''
    if not isinstance(value, str) or len(value.encode('utf-8')) > 2048 or any(ord(c) < 33 for c in value):
        raise ValueError('ERR_FOLIO_PUBLICATION_URL')
    parsed = urlsplit(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('ERR_FOLIO_PUBLICATION_URL')
    try:
        _ = parsed.port
    except ValueError as exc:
        raise ValueError('ERR_FOLIO_PUBLICATION_URL') from exc
    return value


def _time(value: Any) -> int:
    if type(value) is not int or value < 0 or value > 2**53:
        raise ValueError('ERR_FOLIO_TIME')
    return value


def validate_publication(value: Any, *, now: int | None = None) -> dict:
    if not isinstance(value, dict) or len(wire.canonical(value)) > MAX_REFERRAL_BYTES:
        raise ValueError('ERR_FOLIO_PUBLICATION_SIZE')
    expected = {'type', 'version', 'publication_id', 'source_network_id',
                'publisher_public_key', 'offered_scopes', 'requests_enabled',
                'revision', 'created_at', 'signature'}
    if set(value) - (expected | {'deleted', 'expires_at'}) or expected - set(value):
        raise ValueError('ERR_FOLIO_PUBLICATION_SCHEMA')
    if value['type'] != PUBLICATION_TYPE or type(value['version']) is not int or value['version'] != 1:
        raise ValueError('ERR_FOLIO_PUBLICATION_VERSION')
    _id(value['publication_id'], 32)
    public, _ = _identity(value['publisher_public_key'], value['source_network_id'])
    scopes(value['offered_scopes'])
    if type(value['requests_enabled']) is not bool or type(value.get('deleted', False)) is not bool:
        raise ValueError('ERR_FOLIO_PUBLICATION_FLAGS')
    if type(value['revision']) is not int or value['revision'] < 1 or value['revision'] > 2**31:
        raise ValueError('ERR_FOLIO_PUBLICATION_REVISION')
    created = _time(value['created_at'])
    expiry = _time(value.get('expires_at', 0))
    now = int(time.time()) if now is None else now
    if created > now + 300 or (expiry and expiry <= created):
        raise ValueError('ERR_FOLIO_PUBLICATION_TIME')
    wire.verified(value, public, PUBLICATION_DOMAIN)
    return dict(value)


def validate_request(value: Any, *, now: int | None = None, publication: dict | None = None) -> dict:
    if not isinstance(value, dict) or len(wire.canonical(value)) > MAX_REQUEST_BYTES:
        raise ValueError('ERR_FOLIO_REQUEST_SIZE')
    expected = {'type', 'version', 'request_id', 'publication_id', 'source_network_id',
                'requester_id', 'requester_public_key', 'requested_scope', 'message',
                'publication_url', 'referral_id', 'created_at',
                'expires_at', 'signature'}
    if set(value) != expected or value['type'] != REQUEST_TYPE or type(value['version']) is not int or value['version'] != 1:
        raise ValueError('ERR_FOLIO_REQUEST_SCHEMA')
    _id(value['request_id'], 32)
    _id(value['publication_id'], 32)
    _id(value['source_network_id'], 64)
    public, fingerprint = _identity(value['requester_public_key'], value['requester_id'])
    if fingerprint == value['source_network_id']:
        raise ValueError('ERR_FOLIO_SELF_REQUEST')
    scopes(value['requested_scope'])
    message = value['message']
    if not isinstance(message, str) or len(message.encode('utf-8')) > 500 or any(ord(c) < 32 and c not in '\n\t' for c in message):
        raise ValueError('ERR_FOLIO_MESSAGE')
    publication_url(value['publication_url'])
    if value['referral_id'] not in ('', None):
        _id(value['referral_id'], 32)
    created, expiry = _time(value['created_at']), _time(value['expires_at'])
    now = int(time.time()) if now is None else now
    if created > now + 300 or expiry <= now or expiry <= created or expiry - created > REQUEST_LIFETIME:
        raise ValueError('ERR_FOLIO_REQUEST_EXPIRED')
    wire.verified(value, public, REQUEST_DOMAIN)
    if publication:
        p = validate_publication(publication, now=now)
        if p['publication_id'] != value['publication_id'] or p['source_network_id'] != value['source_network_id']:
            raise ValueError('ERR_FOLIO_PUBLICATION_MISMATCH')
        if not p['requests_enabled'] or p.get('deleted') or (p.get('expires_at') and p['expires_at'] <= now):
            raise ValueError('ERR_FOLIO_REQUESTS_DISABLED')
        if not set(value['requested_scope']).issubset(p['offered_scopes']):
            raise ValueError('ERR_FOLIO_SCOPE_NOT_OFFERED')
    return dict(value)


def validate_decision(value: Any, request: dict) -> dict:
    if not isinstance(value, dict) or len(wire.canonical(value)) > MAX_REQUEST_BYTES:
        raise ValueError('ERR_FOLIO_DECISION_SIZE')
    expected = {'type', 'version', 'request_id', 'publication_id', 'source_network_id',
                'requester_id', 'decision', 'granted_scope', 'channel_descriptor',
                'created_at', 'signature'}
    if set(value) != expected or value['type'] != DECISION_TYPE or type(value['version']) is not int or value['version'] != 1:
        raise ValueError('ERR_FOLIO_DECISION_SCHEMA')
    for key in ('request_id', 'publication_id', 'source_network_id', 'requester_id'):
        if value[key] != request[key]:
            raise ValueError('ERR_FOLIO_DECISION_BINDING')
    if value['decision'] not in ('accepted', 'declined'):
        raise ValueError('ERR_FOLIO_DECISION')
    granted = scopes(value['granted_scope'], allow_empty=value['decision'] == 'declined')
    if not set(granted).issubset(request['requested_scope']):
        raise ValueError('ERR_FOLIO_SCOPE_ESCALATION')
    if value['decision'] == 'declined':
        if granted or value['channel_descriptor'] is not None:
            raise ValueError('ERR_FOLIO_DECLINE_SCOPE')
    else:
        from .channel_protocol import validate_channel_descriptor
        d = validate_channel_descriptor(value['channel_descriptor'])
        if hashlib.sha256(bytes.fromhex(d['creator_key'])).hexdigest() != value['source_network_id']:
            raise ValueError('ERR_FOLIO_CHANNEL_CREATOR')
    _time(value['created_at'])
    publisher_key = request.get('_publisher_public_key')
    if not publisher_key:
        raise ValueError('ERR_FOLIO_PUBLISHER_KEY_REQUIRED')
    _identity(publisher_key, value['source_network_id'])
    wire.verified(value, publisher_key, DECISION_DOMAIN)
    return dict(value)


def validate_referral(value: Any) -> dict:
    if not isinstance(value, dict) or len(wire.canonical(value)) > MAX_REFERRAL_BYTES:
        raise ValueError('ERR_FOLIO_REFERRAL_SIZE')
    if value.get('type') != 'braid_folio_referral' or value.get('version') != 1:
        raise ValueError('ERR_FOLIO_REFERRAL_SCHEMA')
    p = validate_publication(value.get('publication'))
    edition = value.get('edition_id', '')
    if edition:
        _id(edition, 32)
    return {**value, 'publication': p}


def validate_auth(value: Any, *, request: dict | None = None, now: int | None = None) -> dict:
    if not isinstance(value, dict) or len(wire.canonical(value)) > 4096:
        raise ValueError('ERR_FOLIO_AUTH_SIZE')
    publisher = {'type', 'version', 'source_network_id', 'publisher_public_key',
                 'timestamp', 'nonce', 'signature'}
    requester = {'type', 'version', 'request_id', 'requester_id',
                 'requester_public_key', 'timestamp', 'nonce', 'signature'}
    if value.get('type') != AUTH_TYPE or type(value.get('version')) is not int or value['version'] != 1:
        raise ValueError('ERR_FOLIO_AUTH_SCHEMA')
    if set(value) == publisher:
        public, party = _identity(value['publisher_public_key'], value['source_network_id'])
    elif set(value) == requester:
        _id(value['request_id'], 32)
        public, party = _identity(value['requester_public_key'], value['requester_id'])
        if request and (value['request_id'] != request['request_id'] or party != request['requester_id']):
            raise ValueError('ERR_FOLIO_AUTH_BINDING')
    else:
        raise ValueError('ERR_FOLIO_AUTH_SCHEMA')
    now = int(time.time()) if now is None else now
    timestamp = _time(value['timestamp'])
    if abs(timestamp - now) > 300:
        raise ValueError('ERR_FOLIO_AUTH_EXPIRED')
    _id(value['nonce'], 32)
    wire.verified(value, public, AUTH_DOMAIN)
    return dict(value)


def validate_card_share(value: Any, request: dict) -> dict:
    if not isinstance(value, dict) or len(wire.canonical(value)) > wire.MAX_CARD + 16384:
        raise ValueError('ERR_FOLIO_CARD_SHARE_SIZE')
    expected = {'type', 'version', 'request_id', 'party_id', 'party_public_key',
                'card', 'created_at', 'signature'}
    if set(value) != expected or value.get('type') != 'braid_folio_card_share' or type(value.get('version')) is not int or value['version'] != 1:
        raise ValueError('ERR_FOLIO_CARD_SHARE_SCHEMA')
    if value['request_id'] != request['request_id']:
        raise ValueError('ERR_FOLIO_CARD_SHARE_BINDING')
    public, party = _identity(value['party_public_key'], value['party_id'])
    if party not in (request['requester_id'], request['source_network_id']):
        raise ValueError('ERR_FOLIO_CARD_SHARE_PARTY')
    card = value['card']
    if not isinstance(card, dict) or card.get('schema') != 'intersignal.braid.rig-card.v1' or card.get('public_key') != public or card.get('fingerprint') != party:
        raise ValueError('ERR_FOLIO_CARD_SHARE_CARD')
    wire.verified(card, public, b'BRAID-RIG-CARD-v1\0')
    _time(value['created_at'])
    wire.verified(value, public, CARD_DOMAIN)
    return dict(value)


def validate_first_message(value: Any, request: dict, publication: dict) -> dict:
    if not isinstance(value, dict) or len(wire.canonical(value)) > 4096:
        raise ValueError('ERR_FOLIO_EVENT_SIZE')
    expected = {'type', 'version', 'request_id', 'publication_id', 'sender_id',
                'sender_public_key', 'recipient_id', 'note_id', 'created_at', 'signature'}
    if set(value) != expected or value['type'] != 'braid_folio_first_message' or type(value['version']) is not int or value['version'] != 1:
        raise ValueError('ERR_FOLIO_EVENT_SCHEMA')
    if value['request_id'] != request['request_id'] or value['publication_id'] != request['publication_id']:
        raise ValueError('ERR_FOLIO_EVENT_BINDING')
    sender_key, sender_id = _identity(value['sender_public_key'], value['sender_id'])
    pair = {request['requester_id'], publication['source_network_id']}
    if {sender_id, value['recipient_id']} != pair or sender_id == value['recipient_id']:
        raise ValueError('ERR_FOLIO_EVENT_PARTY')
    if sender_id == request['requester_id'] and sender_key != request['requester_public_key']:
        raise ValueError('ERR_FOLIO_EVENT_PARTY')
    if sender_id == publication['source_network_id'] and sender_key != publication['publisher_public_key']:
        raise ValueError('ERR_FOLIO_EVENT_PARTY')
    _id(value['note_id'], 32)
    created = _time(value['created_at'])
    if created > int(time.time()) + 300:
        raise ValueError('ERR_FOLIO_EVENT_TIME')
    wire.verified(value, sender_key, FIRST_MESSAGE_DOMAIN)
    return dict(value)
