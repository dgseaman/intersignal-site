"""Loopback-only desktop HTTP facade. No network authority is granted by the UI."""
from __future__ import annotations
import json
import secrets
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from . import __version__
from .messenger import MessengerService, MAX_CARD_BYTES, private_write
from .server import HardenedBraidHTTPHandler
from .context_workflow import summarize_context, list_approved_peers

STATIC = Path(__file__).parent / 'static'


class MessengerHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    block_on_close = True
    daemon_threads = False

    def server_close(self):
        if hasattr(self, 'folio'):
            self.folio.stop.set()
        super().server_close()  # Drain local HTTP work before Folio releases its lock.
        if hasattr(self, 'folio'):
            self.folio.close()
        if hasattr(self, 'messenger'):
            self.messenger.close()


class MessengerHandler(HardenedBraidHTTPHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(15)

    @property
    def desk(self) -> MessengerService:
        return self.server.messenger

    def _same_origin(self):
        if not self._enforce_local_browser_context():
            return False
        origin = self.headers.get('Origin')
        if origin and origin != 'http://' + self.headers.get('Host', ''):
            self._json({'error':'ERR_SAME_ORIGIN_REQUIRED'}, 403)
            return False
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            self._json({'error':'ERR_CROSS_SITE_REQUEST'}, 403)
            return False
        return True

    def _json(self, value, code=200):
        payload = json.dumps(value, ensure_ascii=True, allow_nan=False).encode()
        self._set_security_headers('application/json; charset=utf-8', code, content_length=len(payload))
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _get_receiver_automation(self):
        handler = self
        desk = self.desk
        class ChannelIntake:
            def __getattr__(self, name):
                return getattr(super(MessengerHandler, handler)._get_receiver_automation(), name)
            def process_bytes(self, payload, **source):
                from .mcp_core.protocol import BraidFrame
                frame = BraidFrame.from_bytes(payload)
                if "braid_channel_note" in (frame.manifest.get("extensions") or {}):
                    return desk.receive(payload, **source)
                return super(MessengerHandler, handler)._get_receiver_automation().process_bytes(payload, **source)
        return ChannelIntake()

    def do_GET(self):
        path = urlparse(self.path).path
        if not self._same_origin():
            return
        if path == '/folio' or path.startswith('/folio/'):
            return self.server.folio.handle(self)
        try:
            static = {'/':'messenger.html', '/index.html':'messenger.html',
                '/static/messenger.css':'messenger.css', '/static/messenger.js':'messenger.js',
                '/static/channels.js':'channels.js', '/static/channels.css':'channels.css',
                '/static/wan.js':'wan.js', '/static/wan.css':'wan.css',
                '/static/folio.js':'folio.js', '/static/folio.css':'folio.css'}
            if path in static:
                name = static[path]
                content = (STATIC / name).read_text('utf-8').replace('__BRAID_VERSION__', __version__)
                mime = 'text/html' if name.endswith('.html') else ('text/css' if name.endswith('.css') else 'application/javascript')
                self._set_security_headers(mime + '; charset=utf-8')
                self.wfile.write(content.encode())
            elif path == '/api/messenger/state':
                self._json(self.desk.snapshot())
            elif path == '/api/messenger/job':
                self._json(self.desk.job(parse_qs(urlparse(self.path).query).get('id',[''])[0]))
            elif path == '/api/messenger/card':
                self._json(self.desk.export_card())
            elif path == '/api/messenger/folio/identity':
                self._json(self.desk.folio_identity())
            elif path == '/api/messenger/folio/state':
                self._json({'identity':self.desk.folio_identity(),
                    'requests':self.desk.folio_requests(),
                    'contacts':[c['id'] for c in self.desk.contacts()]})
            elif path == '/favicon.ico':
                self._set_security_headers('image/x-icon', 204)
            elif path == '/advanced':
                self.path = '/'
                super().do_GET()
            else:
                super().do_GET()
        except Exception as exc:
            self._json({'error':exc.__class__.__name__, 'message':str(exc)[:600]}, 400)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == '/folio' or path.startswith('/folio/'):
            if self._same_origin():
                return self.server.folio.handle(self)
            return
        if not path.startswith('/api/messenger/'):
            return super().do_POST()
        if not self._same_origin():
            return
        if not secrets.compare_digest(self.headers.get('X-Braid-CSRF',''), self.desk.csrf):
            self._json({'error':'ERR_SESSION_TOKEN_REQUIRED', 'message':'Reload Braid to refresh this local session.'}, 403)
            return
        try:
            length = int(self.headers.get('Content-Length','-1'))
            maximum = MAX_CARD_BYTES if path == '/api/messenger/inspect-card' else 102400
            if length < 0 or length > maximum:
                self._json({'error':'ERR_BODY_LIMIT'}, 413)
                return
            if self.headers.get_content_type() != 'application/json':
                self._json({'error':'ERR_JSON_REQUIRED'}, 415)
                return
            raw_body = self.rfile.read(length)
            if path == '/api/messenger/wan':
                from .wan_protocol import strict_json
                data = strict_json(raw_body, limit=102400)
            else:
                data = json.loads(raw_body, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite JSON')))
            if not isinstance(data, dict):
                raise ValueError('JSON object required.')
            service = self.desk
            if path == '/api/messenger/shutdown':
                service.closed = True
                private_write(service.home/'shutdown-requested.json', b'{"requested":true}')
                result = {'shutting_down':True, 'message':'Receiving will stop; unfinished sends remain unconfirmed, never auto-retried.'}
                threading.Thread(target=self.server.shutdown, daemon=True).start()
            elif service.closed:
                raise ValueError('Archangel is shutting down. No new operation accepted.')
            elif path == '/api/messenger/address':
                result = service.update_address(str(data.get('host','')))
            elif path == '/api/messenger/settings':
                result = service.save_settings(data)
            elif path == '/api/messenger/prepare':
                result = service.submit('Preparing local route', service.prepare)
            elif path == '/api/messenger/inspect-card':
                result = service.submit('Checking rig card', lambda: service.inspect_card(data.get('card')))
            elif path == '/api/messenger/approve-card':
                result = service.approve_card(str(data.get('inspection_id','')), str(data.get('fingerprint','')), data.get('confirmed'))
            elif path == '/api/messenger/remove-peer':
                result = service.remove_contact(str(data.get('peer','')))
            elif path == '/api/messenger/listen':
                result = service.start_listener() if data.get('enabled') is True else service.stop_listener()
            elif path == '/api/messenger/summary':
                result = service.submit('Summarizing locally', lambda: summarize_context(data.get('text'),
                    completion_model=service.settings.get('completion_model') or None))
            elif path == '/api/messenger/send':
                if not data.get('handoff_id'):
                    raise ValueError('A durable handoff identity is required. Reload Archangel before sending.')
                result = service.submit('Sharing state', lambda: service.send(str(data.get('peer','')),
                    data.get('text'), str(data.get('title') or 'Shared summary'), str(data.get('kind') or 'summary'), str(data.get('object_digest') or ''), str(data.get('handoff_id') or '')))
            elif path == '/api/messenger/message':
                result = service.message_action(str(data.get('id','')), str(data.get('action','')))
            elif path == '/api/messenger/draft':
                draft = data.get('draft')
                if draft is not None and (not isinstance(draft, dict) or len(json.dumps(draft).encode()) > 50000):
                    raise ValueError('Draft is too large.')
                service.set_value('draft', draft)
                result = {'saved':True}
            elif path == '/api/messenger/probe':
                result = service.submit('Checking approved rigs', service.probe)
            elif path == '/api/messenger/models':
                result = service.submit('Finding local models', service.models)
            elif path == '/api/messenger/wan':
                from .wan_protocol import strict_json
                data = strict_json(json.dumps(data), limit=102400)
                action = str(data.get('action', 'status'))
                if action in ('activate', 'peers', 'inspect-peer', 'publish-card', 'ask', 'check', 'check-query'):
                    result = service.submit('Away from home: ' + action, lambda: service.wan.action(action, data))
                else:
                    result = service.wan.action(action, data)
            elif path == '/api/messenger/relay':
                result = service.submit('Checking Managed Relay', lambda: list_approved_peers(probe=True))
            elif path == '/api/messenger/channel':
                action = str(data.get('action','list'))
                if action in ('publish','import-frame','export-reel','reconcile'):
                    result = service.submit('Channel: ' + action, lambda: service.channel_action(action, data))
                else:
                    result = service.channel_action(action, data)
            elif path == '/api/messenger/chat':
                action = str(data.get('action','view'))
                result = service.submit('Chat: thinking locally', lambda: service.chat_action(action, data)) if action == 'turn' else service.chat_action(action, data)
            elif path == '/api/messenger/field':
                action = str(data.get('action','status'))
                result = service.submit('Shared field: ' + action, lambda: service.field_action(action, data))
            elif path == '/api/messenger/folio/draft':
                result = self.server.folio.handoff(data)
            elif path == '/api/messenger/folio/publication':
                result = service.folio_publication(data)
            elif path == '/api/messenger/folio/import-referral':
                result = service.folio_import_referral(data.get('referral'))
            elif path == '/api/messenger/folio/import-link':
                result = service.submit('Opening Folio invitation',lambda: service.folio_import_link(data))
            elif path == '/api/messenger/folio/readiness':
                result = service.folio_readiness(data)
            elif path == '/api/messenger/folio/request':
                result = service.submit('Sending Folio connection request', lambda: service.folio_send_request(data))
            elif path == '/api/messenger/folio/inbox':
                result = service.submit('Checking Folio requests', service.folio_refresh_inbox)
            elif path == '/api/messenger/folio/decision':
                result = service.submit('Sending Folio decision', lambda: service.folio_decide(data))
            elif path == '/api/messenger/folio/status':
                result = service.submit('Checking Folio request', lambda: service.folio_check_request(str(data.get('request_id',''))))
            elif path == '/api/messenger/folio/share-card':
                result = service.submit('Sharing reviewed rig card', lambda: service.folio_share_card(
                    str(data.get('request_id','')), confirmed=data.get('confirmed') is True))
            elif path == '/api/messenger/folio/inspect-peer-card':
                result = service.submit('Inspecting peer rig card', lambda: service.folio_inspect_peer_card(
                    str(data.get('request_id',''))))
            elif path == '/api/messenger/folio/approve-peer-card':
                result = service.folio_approve_peer_card(
                    str(data.get('request_id','')), str(data.get('inspection_id','')),
                    str(data.get('fingerprint','')), data.get('confirmed') is True)
            else:
                self._json({'error':'ERR_UNKNOWN_ACTION'}, 404)
                return
            self._json(result)
        except Exception as exc:
            self._json({'error':exc.__class__.__name__, 'message':str(exc)[:600]}, 400)


def create_messenger_server(address, signing_key, inbox):
    service = MessengerService(signing_key, inbox)
    try:
        server = MessengerHTTPServer(address, MessengerHandler)
        server.messenger = service
        from folio.integration import FolioSurface
        server.folio = FolioSurface(service, server.server_port)
        return server
    except Exception:
        if 'server' in locals():
            server.server_close()
        else:
            service.close()
        raise
