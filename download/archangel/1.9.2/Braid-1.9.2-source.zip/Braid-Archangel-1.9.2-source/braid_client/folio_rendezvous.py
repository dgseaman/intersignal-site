"""First-party Folio discovery queue for Braid connection requests.

This service holds signed *requests*, never Braid frames, local field state, or
conversation history. It is deliberately separate from the same-member WAN relay:
a Folio reader may have a different Braid identity and no approved rig card yet.
The publisher still decides whether to approve the request in Braid.

Run behind a first-party HTTPS reverse proxy bound to loopback, or pass TLS
certificate/key paths to this server for a directly reachable two-rig demo.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import html
import ipaddress
import json
import os
import re
import sqlite3
import ssl
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit

from . import wan_protocol as p
from . import folio_protocol as fp
from .channel_protocol import validate_channel_descriptor
from .private_files import private_dir

PUBLICATION_DOMAIN = fp.PUBLICATION_DOMAIN
REQUEST_DOMAIN = fp.REQUEST_DOMAIN
DECISION_DOMAIN = fp.DECISION_DOMAIN
AUTH_DOMAIN = fp.AUTH_DOMAIN
CARD_SHARE_DOMAIN = fp.CARD_DOMAIN
SCOPES = fp.SCOPES
HEX32 = re.compile(r'^[0-9a-f]{32}$')
HEX64 = re.compile(r'^[0-9a-f]{64}$')
MAX_POST_BYTES = 13 * 1024 * 1024
MAX_CARD_BYTES = p.MAX_CARD
MAX_REQUEST_AGE = 24 * 3600
MAX_REQUEST_LIFETIME = 30 * 86400
AUTH_SKEW = 300
MAX_REQUESTS_PER_PUBLICATION = 128
MAX_GLOBAL_STORAGE = 512 * 1024 * 1024
PIXEL = bytes.fromhex('47494638396101000100800000000000ffffff21f90401000001002c00000000010001000002024401003b')


class ReferralError(ValueError):
    def __init__(self, code: str, status: int = 400):
        super().__init__(code)
        self.code = code
        self.status = status


def _need(condition: bool, code: str, status: int = 400) -> None:
    if not condition:
        raise ReferralError(code, status)


def _hex32(value, code='ERR_FOLIO_ID') -> str:
    _need(isinstance(value, str) and bool(HEX32.fullmatch(value)), code)
    return value


def _hex64(value, code='ERR_FOLIO_IDENTITY') -> str:
    _need(isinstance(value, str) and bool(HEX64.fullmatch(value)), code)
    return value


def _integer(value, code='ERR_FOLIO_TIME') -> int:
    _need(type(value) is int and 0 <= value < 2**63, code)
    return value


def _scope(value, *, allow_empty=False) -> list[str]:
    _need(isinstance(value, list) and (allow_empty or bool(value)) and len(value) <= len(SCOPES)
          and all(isinstance(v, str) and v in SCOPES for v in value)
          and len(set(value)) == len(value), 'ERR_FOLIO_SCOPE')
    return value


def _keys(value, required: set[str], optional: set[str] = frozenset()) -> None:
    _need(isinstance(value, dict) and required <= set(value) and set(value) <= required | optional,
          'ERR_FOLIO_SCHEMA')


def _url(value, *, allow_loopback_http=False, base=False, optional=False,
         allow_fragment=False) -> str:
    if optional and value in ('', None):
        return ''
    _need(isinstance(value, str) and 0 < len(value) <= 2048, 'ERR_FOLIO_URL')
    try:
        parsed = urlsplit(value)
        host = parsed.hostname or ''
        port = parsed.port
    except ValueError as exc:
        raise ReferralError('ERR_FOLIO_URL') from exc
    _need(bool(host) and not parsed.username and not parsed.password
          and (allow_fragment or not parsed.fragment),
          'ERR_FOLIO_URL')
    _need(all(ord(c) >= 32 for c in value), 'ERR_FOLIO_URL')
    try:
        loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        loopback = host == 'localhost'
    _need(parsed.scheme == 'https' or (allow_loopback_http and loopback and parsed.scheme == 'http'),
          'ERR_FOLIO_URL')
    _need(port is None or 1 <= port <= 65535, 'ERR_FOLIO_URL')
    if base:
        _need(parsed.path in ('', '/') and not parsed.query, 'ERR_FOLIO_URL')
        return value.rstrip('/')
    return value


def _verify(value: dict, public: str, domain: bytes) -> dict:
    try:
        return p.verified(value, public, domain)
    except (ValueError, TypeError, OverflowError, KeyError) as exc:
        raise ReferralError('ERR_FOLIO_SIGNATURE', 401) from exc


def _fingerprint(public: str) -> str:
    try:
        return p.fingerprint(_hex64(public))
    except ValueError as exc:
        raise ReferralError('ERR_FOLIO_IDENTITY') from exc


def validate_publication(value: dict, *, now: int | None = None) -> dict:
    try:
        return fp.validate_publication(value, now=now)
    except (ValueError, TypeError, KeyError) as exc:
        raise ReferralError(str(exc) or 'ERR_FOLIO_PUBLICATION') from exc


def _verify_card(card: dict, public: str) -> None:
    _need(isinstance(card, dict), 'ERR_FOLIO_CARD')
    _need(len(p.canonical(card)) <= MAX_CARD_BYTES, 'ERR_FOLIO_CARD_SIZE', 413)
    _need(card.get('schema') == 'intersignal.braid.rig-card.v1'
          and card.get('public_key') == public
          and card.get('fingerprint') == _fingerprint(public), 'ERR_FOLIO_CARD')
    _verify(card, public, b'BRAID-RIG-CARD-v1\0')


def validate_request(value: dict, *, now: int | None = None,
                     publication: dict | None = None) -> dict:
    try:
        return fp.validate_request(value, now=now, publication=publication)
    except (ValueError, TypeError, KeyError) as exc:
        raise ReferralError(str(exc) or 'ERR_FOLIO_REQUEST') from exc


def validate_decision(value: dict, publication: dict, request: dict,
                      *, now: int | None = None) -> dict:
    try:
        bound = {**request, '_publisher_public_key': publication['publisher_public_key']}
        result = fp.validate_decision(value, bound)
        _need(set(result['granted_scope']) <= set(publication['offered_scopes']),
              'ERR_FOLIO_SCOPE')
        created = _integer(result['created_at'])
        now = int(time.time()) if now is None else now
        _need(now - MAX_REQUEST_AGE <= created <= now + AUTH_SKEW,
              'ERR_FOLIO_TIME')
        return result
    except (ValueError, TypeError, KeyError) as exc:
        if isinstance(exc, ReferralError):
            raise
        raise ReferralError(str(exc) or 'ERR_FOLIO_DECISION') from exc


def validate_card_share(value: dict, request: dict, publication: dict,
                        *, now: int | None = None) -> dict:
    try:
        result = fp.validate_card_share(value, request)
        expected_key = (request['requester_public_key']
                        if result['party_id'] == request['requester_id']
                        else publication['publisher_public_key'])
        _need(result['party_public_key'] == expected_key, 'ERR_FOLIO_CARD_PARTY', 403)
        created = _integer(result['created_at'])
        now = int(time.time()) if now is None else now
        _need(now - MAX_REQUEST_AGE <= created <= now + AUTH_SKEW,
              'ERR_FOLIO_TIME')
        return result
    except (ValueError, TypeError, KeyError) as exc:
        if isinstance(exc, ReferralError):
            raise
        raise ReferralError(str(exc) or 'ERR_FOLIO_CARD') from exc


def validate_auth(value: dict, *, requester=False, now: int | None = None) -> dict:
    try:
        result = fp.validate_auth(value, now=now)
        _need(('requester_id' in result) == requester, 'ERR_FOLIO_AUTH', 403)
        return result
    except (ValueError, TypeError, KeyError) as exc:
        if isinstance(exc, ReferralError):
            raise
        raise ReferralError(str(exc) or 'ERR_FOLIO_AUTH', 401) from exc


class RendezvousStore:
    def __init__(self, root: Path, *, base_url: str, download_url: str,
                 allow_loopback_http=False, max_storage=MAX_GLOBAL_STORAGE):
        self.root = Path(root)
        private_dir(self.root)
        self.path = self.root / 'folio-rendezvous.sqlite3'
        self.allow_loopback_http = allow_loopback_http
        self.base_url = _url(base_url, allow_loopback_http=allow_loopback_http, base=True)
        self.download_url = (_url(download_url, allow_loopback_http=allow_loopback_http,
                                  allow_fragment=True) if download_url else '')
        self.max_storage = max_storage
        with self.db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS publications(
                    id TEXT PRIMARY KEY, source_network_id TEXT NOT NULL, publisher_public_key TEXT NOT NULL,
                    revision INTEGER NOT NULL, body TEXT NOT NULL, created INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS requests(
                    id TEXT PRIMARY KEY, publication_id TEXT NOT NULL, requester_id TEXT NOT NULL,
                    body TEXT NOT NULL, decision TEXT, status TEXT NOT NULL, created INTEGER NOT NULL,
                    expires INTEGER NOT NULL);
                CREATE INDEX IF NOT EXISTS folio_inbox ON requests(publication_id,status,created);
                CREATE INDEX IF NOT EXISTS folio_requester ON requests(publication_id,requester_id,created);
                CREATE TABLE IF NOT EXISTS auth_nonces(
                    identity TEXT NOT NULL, nonce TEXT NOT NULL, created INTEGER NOT NULL,
                    PRIMARY KEY(identity,nonce));
                CREATE TABLE IF NOT EXISTS card_shares(
                    request_id TEXT NOT NULL, party_id TEXT NOT NULL, body TEXT NOT NULL,
                    created INTEGER NOT NULL, PRIMARY KEY(request_id,party_id));
                CREATE TABLE IF NOT EXISTS first_messages(
                    request_id TEXT PRIMARY KEY, note_id TEXT NOT NULL, created INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS analytics(
                    publication_id TEXT NOT NULL, event TEXT NOT NULL, edition_id TEXT NOT NULL,
                    day TEXT NOT NULL, count INTEGER NOT NULL,
                    PRIMARY KEY(publication_id,event,edition_id,day));
            ''')
        os.chmod(self.path, 0o600)

    @contextlib.contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def _publication(db, publication_id: str) -> dict:
        row = db.execute('SELECT body FROM publications WHERE id=?', (publication_id,)).fetchone()
        if not row:
            raise ReferralError('ERR_FOLIO_PUBLICATION_NOT_FOUND', 404)
        return json.loads(row['body'])

    @staticmethod
    def _availability(publication: dict, now: int) -> str:
        if publication.get('deleted', False):
            return 'deleted'
        if publication.get('expires_at', 0) and publication['expires_at'] <= now:
            return 'expired'
        if not publication['requests_enabled']:
            return 'disabled'
        return 'enabled'

    @staticmethod
    def _event(db, publication_id: str, event: str, edition_id='') -> None:
        _need(event in ('folio_viewed', 'continue_clicked', 'install_initiated',
                        'request_created', 'request_accepted', 'request_declined',
                        'first_message_exchanged'), 'ERR_FOLIO_EVENT')
        if edition_id:
            _hex32(edition_id, 'ERR_FOLIO_EDITION')
        day = datetime.now(timezone.utc).strftime('%Y-%m-%d')
        db.execute('''INSERT INTO analytics VALUES (?,?,?,?,1)
                      ON CONFLICT(publication_id,event,edition_id,day)
                      DO UPDATE SET count=count+1''', (publication_id,event,edition_id,day))

    def register(self, value: dict) -> dict:
        publication = validate_publication(value)
        ident = publication['publication_id']
        raw = p.canonical(publication).decode('ascii')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM publications WHERE id=?', (ident,)).fetchone()
            if old:
                _need(old['source_network_id'] == publication['source_network_id']
                      and old['publisher_public_key'] == publication['publisher_public_key'],
                      'ERR_FOLIO_PUBLICATION_OWNER', 409)
                _need(publication['revision'] >= old['revision'],
                      'ERR_FOLIO_REVISION', 409)
                if publication['revision'] == old['revision']:
                    _need(raw == old['body'], 'ERR_FOLIO_REVISION', 409)
                else:
                    prior = json.loads(old['body'])
                    _need(not prior.get('deleted', False) or publication.get('deleted', False),
                          'ERR_FOLIO_DELETED', 410)
                    db.execute('''UPDATE publications SET revision=?,body=? WHERE id=?''',
                               (publication['revision'], raw, ident))
            else:
                db.execute('INSERT INTO publications VALUES (?,?,?,?,?,?)',
                           (ident,publication['source_network_id'],publication['publisher_public_key'],
                            publication['revision'],raw,int(time.time())))
        return {'publication': publication, 'availability': self._availability(publication, int(time.time()))}

    def public_publication(self, ident: str) -> dict:
        _hex32(ident)
        with self.db() as db:
            publication = self._publication(db, ident)
        return {'publication': publication, 'availability': self._availability(publication, int(time.time()))}

    def create_request(self, value: dict) -> dict:
        request = validate_request(value)
        raw = p.canonical(request).decode('ascii')
        ident = request['publication_id']
        now = int(time.time())
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            publication = self._publication(db, ident)
            validate_request(value, publication=publication)
            availability = self._availability(publication, now)
            _need(availability == 'enabled', 'ERR_FOLIO_PUBLICATION_' + availability.upper(),
                  410 if availability in ('deleted','expired') else 403)
            _need(publication['source_network_id'] == request['source_network_id'],
                  'ERR_FOLIO_PUBLICATION_IDENTITY')
            _need(set(request['requested_scope']) <= set(publication['offered_scopes']),
                  'ERR_FOLIO_SCOPE')
            old = db.execute('''SELECT id,body,status,expires FROM requests
                WHERE id=? OR (publication_id=? AND requester_id=? AND
                (status!='pending' OR expires>?)) ORDER BY created DESC LIMIT 1''',
                (request['request_id'], ident, request['requester_id'], now)).fetchone()
            if old:
                _need(old['body'] == raw or (json.loads(old['body'])['requester_id'] == request['requester_id']
                      and json.loads(old['body'])['publication_id'] == ident),
                      'ERR_FOLIO_DUPLICATE_CONFLICT', 409)
                status = old['status'] if old['status'] != 'pending' or old['expires'] > now else 'expired'
                return {'request_id': old['id'], 'status': 'duplicate', 'existing_status': status}
            count = db.execute('SELECT COUNT(*) FROM requests WHERE publication_id=?', (ident,)).fetchone()[0]
            _need(count < MAX_REQUESTS_PER_PUBLICATION, 'ERR_FOLIO_QUEUE_FULL', 429)
            used = db.execute('SELECT COALESCE(SUM(length(body)+COALESCE(length(decision),0)),0) FROM requests').fetchone()[0]
            _need(used + len(raw) <= self.max_storage, 'ERR_FOLIO_STORAGE_FULL', 507)
            db.execute('INSERT INTO requests VALUES (?,?,?,?,?,?,?,?)',
                       (request['request_id'],ident,request['requester_id'],raw,None,'pending',now,request['expires_at']))
            self._event(db, ident, 'request_created')
        return {'request_id': request['request_id'], 'status': 'pending'}

    def _reserve_auth(self, db, auth: dict, identity: str) -> None:
        now = int(time.time())
        db.execute('DELETE FROM auth_nonces WHERE created<?', (now - 2*AUTH_SKEW,))
        try:
            db.execute('INSERT INTO auth_nonces VALUES (?,?,?)', (identity, auth['nonce'], now))
        except sqlite3.IntegrityError as exc:
            raise ReferralError('ERR_FOLIO_AUTH_REPLAY', 409) from exc

    def inbox(self, value: dict) -> dict:
        auth = validate_auth(value)
        identity = auth['source_network_id']
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            self._reserve_auth(db, auth, identity)
            rows = db.execute('''SELECT r.body,r.expires FROM requests r
                      JOIN publications p ON p.id=r.publication_id
                      WHERE p.source_network_id=? AND p.publisher_public_key=?
                      AND r.status='pending' ORDER BY r.created LIMIT 100''',
                      (identity,auth['publisher_public_key'])).fetchall()
        now = int(time.time())
        return {'requests': [json.loads(row['body']) for row in rows if row['expires'] > now]}

    def decide(self, value: dict) -> dict:
        _need(isinstance(value, dict), 'ERR_FOLIO_SCHEMA')
        ident = _hex32(value.get('request_id'), 'ERR_FOLIO_REQUEST_ID')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM requests WHERE id=?', (ident,)).fetchone()
            _need(row is not None, 'ERR_FOLIO_REQUEST_NOT_FOUND', 404)
            request = json.loads(row['body'])
            publication = self._publication(db, row['publication_id'])
            decision = validate_decision(value, publication, request)
            raw = p.canonical(decision).decode('ascii')
            if row['status'] != 'pending':
                _need(row['decision'] == raw, 'ERR_FOLIO_ALREADY_DECIDED', 409)
                return {'request_id': ident, 'status': row['status']}
            _need(row['expires'] > int(time.time()), 'ERR_FOLIO_REQUEST_EXPIRED', 410)
            _need(not publication.get('deleted', False) or decision['decision'] == 'declined',
                  'ERR_FOLIO_PUBLICATION_DELETED', 410)
            used = db.execute('SELECT COALESCE(SUM(length(body)+COALESCE(length(decision),0)),0) FROM requests').fetchone()[0]
            _need(used + len(raw) <= self.max_storage, 'ERR_FOLIO_STORAGE_FULL', 507)
            db.execute('UPDATE requests SET decision=?,status=? WHERE id=?',
                       (raw,decision['decision'],ident))
            self._event(db, row['publication_id'], 'request_' + decision['decision'])
        return {'request_id': ident, 'status': decision['decision']}

    def status(self, value: dict) -> dict:
        auth = validate_auth(value, requester=True)
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            self._reserve_auth(db, auth, auth['requester_id'])
            row = db.execute('SELECT * FROM requests WHERE id=?', (auth['request_id'],)).fetchone()
            _need(row is not None and row['requester_id'] == auth['requester_id'],
                  'ERR_FOLIO_REQUEST_NOT_FOUND', 404)
        status = row['status'] if row['status'] != 'pending' or row['expires'] > time.time() else 'expired'
        return {'request_id': row['id'], 'status': status,
                'decision': json.loads(row['decision']) if row['decision'] else None}

    def analytics(self, value: dict) -> dict:
        auth = validate_auth(value)
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            self._reserve_auth(db, auth, auth['source_network_id'])
            rows = db.execute('''SELECT a.* FROM analytics a JOIN publications p
                      ON p.id=a.publication_id WHERE p.source_network_id=?
                      AND p.publisher_public_key=? ORDER BY a.day DESC,a.publication_id,a.event LIMIT 1000''',
                      (auth['source_network_id'],auth['publisher_public_key'])).fetchall()
        return {'events': [dict(row) for row in rows]}

    def share_card(self, value: dict) -> dict:
        _need(isinstance(value, dict), 'ERR_FOLIO_SCHEMA')
        ident = _hex32(value.get('request_id'), 'ERR_FOLIO_REQUEST_ID')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM requests WHERE id=?', (ident,)).fetchone()
            _need(row is not None, 'ERR_FOLIO_REQUEST_NOT_FOUND', 404)
            _need(row['status'] == 'accepted', 'ERR_FOLIO_NOT_ACCEPTED', 403)
            request = json.loads(row['body'])
            publication = self._publication(db, row['publication_id'])
            share = validate_card_share(value, request, publication)
            raw = p.canonical(share).decode('ascii')
            old = db.execute('SELECT body FROM card_shares WHERE request_id=? AND party_id=?',
                             (ident,share['party_id'])).fetchone()
            if old:
                _need(old['body'] == raw, 'ERR_FOLIO_CARD_ALREADY_SHARED', 409)
            else:
                used = db.execute('''SELECT COALESCE(SUM(length(body)),0)
                                     FROM card_shares''').fetchone()[0]
                _need(used + len(raw) <= self.max_storage, 'ERR_FOLIO_STORAGE_FULL', 507)
                db.execute('INSERT INTO card_shares VALUES (?,?,?,?)',
                           (ident,share['party_id'],raw,int(time.time())))
        return {'request_id':ident, 'status':'shared'}

    def first_message(self, value: dict) -> dict:
        _need(isinstance(value, dict), 'ERR_FOLIO_SCHEMA')
        ident = _hex32(value.get('request_id'), 'ERR_FOLIO_REQUEST_ID')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM requests WHERE id=?', (ident,)).fetchone()
            _need(row is not None and row['status'] == 'accepted',
                  'ERR_FOLIO_NOT_ACCEPTED', 403)
            request = json.loads(row['body'])
            publication = self._publication(db, row['publication_id'])
            try:
                event = fp.validate_first_message(value, request, publication)
            except (ValueError, TypeError, KeyError) as exc:
                raise ReferralError(str(exc) or 'ERR_FOLIO_EVENT') from exc
            old = db.execute('SELECT note_id FROM first_messages WHERE request_id=?', (ident,)).fetchone()
            if old:
                return {'request_id': ident, 'recorded': True, 'duplicate': True}
            db.execute('INSERT INTO first_messages VALUES (?,?,?)',
                       (ident, event['note_id'], int(time.time())))
            self._event(db, row['publication_id'], 'first_message_exchanged')
        return {'request_id': ident, 'recorded': True, 'duplicate': False}

    def card_inbox(self, auth_value: dict, request_id: str) -> dict:
        ident = _hex32(request_id, 'ERR_FOLIO_REQUEST_ID')
        requester = isinstance(auth_value, dict) and 'requester_id' in auth_value
        auth = validate_auth(auth_value, requester=requester)
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM requests WHERE id=?', (ident,)).fetchone()
            _need(row is not None and row['status'] == 'accepted',
                  'ERR_FOLIO_NOT_ACCEPTED', 403)
            request = json.loads(row['body'])
            publication = self._publication(db, row['publication_id'])
            if requester:
                _need(auth['request_id'] == ident and
                      auth['requester_id'] == request['requester_id'],
                      'ERR_FOLIO_AUTH', 403)
                party, other = request['requester_id'], publication['source_network_id']
            else:
                _need(auth['source_network_id'] == publication['source_network_id']
                      and auth['publisher_public_key'] == publication['publisher_public_key'],
                      'ERR_FOLIO_AUTH', 403)
                party, other = publication['source_network_id'], request['requester_id']
            self._reserve_auth(db, auth, party)
            card = db.execute('SELECT body FROM card_shares WHERE request_id=? AND party_id=?',
                              (ident,other)).fetchone()
        return {'request_id':ident, 'share':json.loads(card['body']) if card else None}

    def record_public_event(self, publication_id: str, event: str, edition_id='') -> None:
        _hex32(publication_id)
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            self._publication(db, publication_id)
            self._event(db, publication_id, event, edition_id)

    def referral(self, publication_id: str, edition_id='') -> dict:
        _hex32(publication_id)
        if edition_id:
            _hex32(edition_id, 'ERR_FOLIO_EDITION')
        data = self.public_publication(publication_id)
        _need(data['availability'] == 'enabled', 'ERR_FOLIO_PUBLICATION_' + data['availability'].upper(),
              410 if data['availability'] in ('deleted','expired') else 403)
        return {'type':'braid_folio_referral', 'version':1, 'publication':data['publication'],
                'rendezvous_url':self.base_url, 'edition_id':edition_id}


class RendezvousServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, store: RendezvousStore):
        self.store = store
        super().__init__(address, RendezvousHandler)


class RendezvousHandler(BaseHTTPRequestHandler):
    server: RendezvousServer
    protocol_version = 'HTTP/1.1'

    def log_message(self, *_args):
        # Never put request paths, notes, or IP addresses in access logs.
        pass

    def _send(self, status: int, body: bytes, content_type='application/json; charset=utf-8',
              *, extra=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Frame-Options', 'DENY')
        for key, val in (extra or {}).items():
            self.send_header(key, val)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, value: dict):
        self._send(status, p.canonical(value))

    def _error(self, exc: ReferralError):
        self._json(exc.status, {'error':exc.code})

    def _continue_error(self, exc: ReferralError):
        messages = {
            'ERR_FOLIO_PUBLICATION_DELETED': 'This publication is no longer available for connection requests.',
            'ERR_FOLIO_PUBLICATION_DISABLED': 'The publisher has closed connection requests for this publication.',
            'ERR_FOLIO_PUBLICATION_EXPIRED': 'The connection invitation for this publication has expired.',
            'ERR_FOLIO_PUBLICATION_NOT_FOUND': 'This publication could not be found.',
            'ERR_FOLIO_PUBLICATION_IDENTITY': 'This publication link does not match its publisher identity.',
            'ERR_FOLIO_DOWNLOAD_UNAVAILABLE': 'A Braid download is not available here yet. Keep your referral file and try again later.',
        }
        message = messages.get(exc.code, 'This publication link cannot be used. Check the link with its publisher.')
        page = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1">'
                '<title>Folio connection unavailable</title><style>body{margin:9vh auto;max-width:38rem;'
                'padding:2rem;color:#26312b;background:#f7f5ef;font:17px/1.5 system-ui,sans-serif}'
                'h1{font:normal 2.1rem Georgia,serif}</style></head><body>'
                '<p>BRAID / FOLIO</p><h1>Connection unavailable</h1><p>' +
                html.escape(message) + '</p></body></html>')
        self._send(exc.status, page.encode(), 'text/html; charset=utf-8')

    @staticmethod
    def _query(path: str):
        parsed = urlsplit(path)
        _need(len(path) <= 4096, 'ERR_FOLIO_URL')
        try:
            query = parse_qs(parsed.query, keep_blank_values=True, strict_parsing=False,
                             max_num_fields=8)
        except ValueError as exc:
            raise ReferralError('ERR_FOLIO_URL') from exc
        _need(all(len(v) == 1 for v in query.values()), 'ERR_FOLIO_URL')
        return parsed.path, {k:v[0] for k,v in query.items()}

    def do_GET(self):
        path = ''
        try:
            path, query = self._query(self.path)
            store = self.server.store
            if path == '/health':
                self._json(200, {'status':'ok','download_available':bool(store.download_url),'link_import':True})
            elif path == '/continue.js':
                self._send(200,(Path(__file__).parent/'static'/'folio-continue.js').read_bytes(),'application/javascript; charset=utf-8')
            elif path.startswith('/v1/publications/'):
                ident = path.removeprefix('/v1/publications/')
                _need(not query, 'ERR_FOLIO_URL')
                self._json(200, store.public_publication(ident))
            elif path.startswith('/v1/referrals/') and path.endswith('.braidref'):
                ident = path[len('/v1/referrals/'):-len('.braidref')]
                _need(set(query) <= {'edition_id'}, 'ERR_FOLIO_URL')
                referral = store.referral(ident, query.get('edition_id',''))
                self._send(200, p.canonical(referral), 'application/vnd.braid.folio-referral+json',
                           extra={'Content-Disposition':f'attachment; filename="Folio-{ident}.braidref"'})
            elif path == '/continue':
                _need(set(query) <= {'publication_id','source_network_id','edition_id'}, 'ERR_FOLIO_URL')
                ident = _hex32(query.get('publication_id'))
                network = _hex64(query.get('source_network_id'))
                edition = query.get('edition_id','')
                data = store.referral(ident, edition)
                _need(data['publication']['source_network_id'] == network,
                      'ERR_FOLIO_PUBLICATION_IDENTITY')
                store.record_public_event(ident, 'continue_clicked', edition)
                suffix = '?edition_id=' + edition if edition else ''
                ref_url = store.base_url + '/v1/referrals/' + ident + '.braidref' + suffix
                install_url = store.base_url + '/install?publication_id=' + ident + '&source_network_id=' + network
                if edition:
                    install_url += '&edition_id=' + edition
                continue_url=store.base_url+'/continue?publication_id='+ident+'&source_network_id='+network+('&edition_id='+edition if edition else '')
                install_copy=('<a class="secondary" href="'+html.escape(install_url,quote=True)+'" target="_blank" rel="noopener noreferrer">Get Braid ↗</a>' if store.download_url else '<span class="muted">The Braid download has not been configured yet. Keep this link for later.</span>')
                page = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
                        '<meta name="viewport" content="width=device-width,initial-scale=1">'
                        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
                        'script-src \'self\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">'
                        '<title>Continue this on Braid</title><script src="/continue.js" defer></script>'
                        '<style>*{box-sizing:border-box}body{margin:0;background:#f6f2ec;color:#393446;font:16px/1.7 system-ui,sans-serif}main{max-width:700px;margin:7vh auto;padding:30px}h1{font:normal clamp(38px,6vw,58px)/1.1 Georgia,serif;letter-spacing:-2px;margin:20px 0}a{color:#745288}.eyebrow{font-size:10px;letter-spacing:2px;color:#766e7c}.star{font:60px/1 Georgia,serif;color:#bd8972}.muted{color:#766e7c;font-size:13px}.card{background:#fffdf8;border:1px solid #e2d9e4;border-radius:10px;padding:26px;margin:28px 0}label{font-size:12px;font-weight:600}input{display:block;width:100%;margin:10px 0 15px;padding:13px;border:1px solid #d8cedf;border-radius:6px;color:#6c527d;background:#f6f2ec;font:12px system-ui}button,.secondary{display:inline-block;font:13px system-ui;padding:12px 17px;border-radius:6px;cursor:pointer;text-decoration:none;border:1px solid #d8cedf}button{background:#745288;color:white;border-color:#745288}ol{padding-left:22px;font-size:14px}li{padding:9px 0}.actions{display:flex;gap:18px;align-items:center;flex-wrap:wrap}.backup{font-size:12px;border-top:1px solid #e2d9e4;padding-top:18px;margin-top:22px}#copy-status{font-size:12px;color:#766e7c}footer{font-size:12px;color:#766e7c}@media(max-width:520px){main{margin:3vh auto;padding:24px}.card{padding:22px}h1{font-size:42px}}</style></head><body><main><div class="star" aria-hidden="true">✳</div><p class="eyebrow">FOLIO / BRAID</p><h1>Good ideas deserve<br>another conversation.</h1><p>Continue this conversation with Braid. Send a short introduction to the publisher, then pick up the thread when they accept.</p><div class="card"><label for="connection-link">Your connection link</label><input id="connection-link" readonly value="'+html.escape(continue_url,quote=True)+'"><div class="actions"><button id="copy-link">Copy connection link</button><span id="copy-status" role="status">Keep it for after installation, too.</span></div><ol><li>Copy this link.</li><li>Open Braid → <strong>Folio connections</strong>, paste the link, and choose <strong>Open invitation</strong>.</li><li>Choose what to request and send your introduction.</li></ol><div class="actions">'+install_copy+'</div><p class="backup">Prefer a file? <a href="'+html.escape(ref_url,quote=True)+'">Save the signed referral</a> and import it in Braid.</p></div><footer>The publisher chooses who can join this publication channel. Your private conversations stay yours. Rig cards are shared only after a separate choice.</footer></main></body></html>')
                self._send(200, page.encode(), 'text/html; charset=utf-8')
            elif path == '/install':
                _need(bool(store.download_url), 'ERR_FOLIO_DOWNLOAD_UNAVAILABLE', 503)
                _need(set(query) <= {'publication_id','source_network_id','edition_id'}, 'ERR_FOLIO_URL')
                ident = _hex32(query.get('publication_id'))
                network = _hex64(query.get('source_network_id'))
                edition = query.get('edition_id','')
                data = store.referral(ident, edition)
                _need(data['publication']['source_network_id'] == network,
                      'ERR_FOLIO_PUBLICATION_IDENTITY')
                store.record_public_event(ident, 'install_initiated', edition)
                self._send(302, b'', extra={'Location':store.download_url})
            elif path == '/v1/events/view.gif':
                _need(set(query) <= {'publication_id','edition_id'}, 'ERR_FOLIO_URL')
                ident = _hex32(query.get('publication_id'))
                store.record_public_event(ident, 'folio_viewed', query.get('edition_id',''))
                self._send(200, PIXEL, 'image/gif')
            else:
                raise ReferralError('ERR_FOLIO_NOT_FOUND', 404)
        except ReferralError as exc:
            self._continue_error(exc) if path in ('/continue', '/install') else self._error(exc)
        except (ValueError, TypeError, OverflowError):
            error = ReferralError('ERR_FOLIO_INVALID')
            self._continue_error(error) if path in ('/continue', '/install') else self._error(error)

    def do_POST(self):
        try:
            path, query = self._query(self.path)
            _need(not query, 'ERR_FOLIO_URL')
            _need(path in ('/v1/publications','/v1/requests','/v1/inbox','/v1/decisions',
                           '/v1/status','/v1/analytics','/v1/cards','/v1/cards/inbox',
                           '/v1/events/first-message'),
                  'ERR_FOLIO_NOT_FOUND', 404)
            _need(self.headers.get('Content-Type','').split(';')[0].strip().lower() == 'application/json',
                  'ERR_FOLIO_CONTENT_TYPE', 415)
            try:
                length = int(self.headers.get('Content-Length',''))
            except ValueError as exc:
                raise ReferralError('ERR_FOLIO_LENGTH', 411) from exc
            _need(0 < length <= MAX_POST_BYTES, 'ERR_FOLIO_SIZE', 413)
            raw = self.rfile.read(length)
            _need(len(raw) == length, 'ERR_FOLIO_LENGTH', 400)
            try:
                data = p.strict_json(raw, limit=MAX_POST_BYTES)
            except (ValueError, TypeError) as exc:
                raise ReferralError('ERR_FOLIO_JSON') from exc
            _need(isinstance(data, dict), 'ERR_FOLIO_SCHEMA')
            if path == '/v1/cards/inbox':
                _need(set(data) == {'auth','request_id'}, 'ERR_FOLIO_SCHEMA')
                self._json(200, self.server.store.card_inbox(data['auth'],data['request_id']))
                return
            _need(len(data) == 1, 'ERR_FOLIO_SCHEMA')
            field = {'/v1/publications':'publication','/v1/requests':'request',
                     '/v1/inbox':'auth','/v1/decisions':'decision','/v1/status':'auth',
                     '/v1/analytics':'auth','/v1/cards':'share',
                     '/v1/events/first-message':'event'}[path]
            _need(field in data, 'ERR_FOLIO_SCHEMA')
            store = self.server.store
            operation = {'/v1/publications':store.register,'/v1/requests':store.create_request,
                         '/v1/inbox':store.inbox,'/v1/decisions':store.decide,
                         '/v1/status':store.status,'/v1/analytics':store.analytics,
                         '/v1/cards':store.share_card,
                         '/v1/events/first-message':store.first_message}[path]
            self._json(200, operation(data[field]))
        except ReferralError as exc:
            self._error(exc)
        except (ValueError, TypeError, OverflowError, sqlite3.Error):
            self._error(ReferralError('ERR_FOLIO_INVALID'))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='First-party Braid/Folio request rendezvous')
    parser.add_argument('--root', type=Path, required=True, help='private server data directory')
    parser.add_argument('--base-url', required=True, help='public HTTPS origin (no path)')
    parser.add_argument('--download-url', default='', help='first-party Braid download route')
    parser.add_argument('--bind', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8766)
    parser.add_argument('--cert', type=Path)
    parser.add_argument('--key', type=Path)
    parser.add_argument('--allow-loopback-http', action='store_true',
                        help='only for a local development demo')
    args = parser.parse_args(argv)
    if bool(args.cert) != bool(args.key):
        parser.error('--cert and --key must be supplied together')
    try:
        loopback = ipaddress.ip_address(args.bind).is_loopback
    except ValueError:
        loopback = args.bind == 'localhost'
    if not loopback and not args.cert:
        parser.error('A non-loopback listener requires --cert and --key; otherwise bind a reverse proxy to loopback')
    store = RendezvousStore(args.root, base_url=args.base_url,
                            download_url=args.download_url,
                            allow_loopback_http=args.allow_loopback_http)
    server = RendezvousServer((args.bind,args.port), store)
    if args.cert:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(args.cert, args.key)
        server.socket = context.wrap_socket(server.socket, server_side=True)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
