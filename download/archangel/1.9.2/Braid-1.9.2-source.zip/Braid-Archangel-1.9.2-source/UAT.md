# Braid Archangel 1.9.2 qualification checklist

Executed results are in TEST_RESULTS.md. This checklist is work remaining on
actual target hosts, not evidence that these steps passed.

1. On a new OS account, install one native Braid package and launch Braid by its
   ordinary desktop entry. Open Folio — Publish to Web. Confirm `/folio` needs
   no separate Python, terminal, profile selection, or Connect to Braid setup.
2. Create a local note and a completed conversation. Publish with Folio each,
   confirm an unapproved private draft, review exact public output, approve,
   and export. Edit the public body and confirm approval becomes invalid.
3. Import a real backed-up Folio 0.3.0 library. Confirm the source is unchanged,
   IDs and archive bytes persist, and legacy approvals need fresh review.
   Confirm legacy Broadcast configuration queues drafts without releasing them.
4. Quit through Settings & tools, restart, and verify identity, grants, notes,
   drafts and editions remain. Confirm duplicate launch reuses the same app.
   Exercise paths containing spaces and non-ASCII text on each target OS.
5. Complete the unchanged full test suite on a macOS host with the assigned
   loopback alias required by the address-change test. Exercise actual Windows
   DACLs/locks, Linux file-descriptor checks and native UI on those hosts.
6. Rehearse deliberate invitation acceptance, each rig-card exchange, fingerprint
   approval and Channel scopes across physical rigs. Test privacy sentinels in
   private originals against public exports and ordinary Braid network payloads.

See packaging/QUALIFY_PLATFORMS.md for native build/test instructions and
limits. docs/UAT_WAN.md retains the WAN qualification matrix. No production
service deployment or website change is required or authorized by this build.
