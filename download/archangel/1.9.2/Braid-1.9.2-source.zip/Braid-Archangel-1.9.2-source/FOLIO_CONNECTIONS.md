# Folio → Braid connections

Braid Archangel 1.9.2 integrates Folio 0.3.0 as a local studio at `/folio`. It retains a
publisher signed Folio referral, a signed reader request, an offline request
queue, explicit acceptance, and one publication channel per Folio. It does not
publish a website or deploy the rendezvous service for you.

## What the reader and publisher do

1. The publisher starts this Braid build, starts the matching Folio build, and
   connects Folio to the local Braid UI. In a Folio draft, they enable **Allow
   Braid connection requests**, choose offered permissions, use **Check setup**, then review and export.
   Folio registers the publication with the rendezvous before releasing a page
   that contains **Continue this on Braid**. The publisher puts the exported page
   on their own public site.
2. The reader opens the public page and follows that link. The acquisition page
   offers **Copy connection link**, a configured Braid download link, and a
   signed-file fallback. The reader opens **Folio connections** in Braid, pastes
   the link, and chooses **Open invitation**. Braid verifies the publisher-signed
   referral before saving. The reader selects permissions, optionally writes a
   short introduction, and sends the signed request. No request is sent on import.
3. The publisher opens **Folio connections** (the inbox loads on opening; **Check requests** refreshes it), reviews the
   requester fingerprint, originating Folio, note, and exact selected scope,
   then accepts or declines. The queued request remains available while the
   publisher is offline. The reader uses **Check publisher decision**. An
   accepted decision imports the same signed publication channel on both sides.
4. To deliver a channel note, each side separately chooses to share its signed
   rig card, inspects the other's card, compares its fingerprint through a
   trusted route, and approves it. The connection panel shows which steps remain and offers **Open publication
   channel**. Both start receiving. Direct or overlay
   reachability between their Braid receivers is required. They then use the
   normal Braid channel note composer. The sender reviews the exact text before
   sharing; the receiver's existing validation and indexing remain in force.

The request itself contains the publication ID, publisher fingerprint, reader
public key and fingerprint, requested scope, optional note, reference URL, and
time limits. It contains no rig card, private key, model route, transcript,
channel inventory, or semantic capsule. A publication channel does not turn on
**Use in chat**. `follow_publications` means the publisher may deliberately send
future material to this channel; v1 has no automatic publication feed.
`messages` is limited to reviewed notes in this channel, not arbitrary private
Braid handoffs. Future semantic lineage needs a new explicit permission and is
not included here.

## Rendezvous operator setup

Run one first party rendezvous reachable at an HTTPS origin under
`intersignal.org`, for example `https://connect.intersignal.org`. Terminate TLS
at a trusted reverse proxy and forward to a loopback listener. Install this
integration wheel and its declared dependencies in a private server Python
environment before starting it:

```sh
python3 -m braid_client.folio_rendezvous \
  --root /private/path/folio-rendezvous \
  --base-url https://connect.intersignal.org \
  --download-url https://intersignal.org/braid \
  --bind 127.0.0.1 --port 8766
```

Configure the download URL to a real Braid distribution before publishing the
CTA. The rendezvous is separate from the existing Managed WAN relay and does not
enroll a stranger in a member account. It stores signed publication records,
requests, decisions, and, only after acceptance and consent, signed rig cards.
The `/health` response reports whether a download is configured; **Check setup**
confirms this configuration but does not test that the download route resolves.
Use the dedicated examples in `operator/FOLIO_DEPLOY.md` in the companion package.
Protect and back up its private SQLite directory, put normal HTTPS ingress and
capacity controls around it, and monitor `/health`. Its HTTP handler suppresses
access logs containing IP addresses or request paths; proxy logs need the same
privacy policy. It limits objects and queue size, rejects redirects in the
client, and authenticates publisher inbox and analytics reads with short lived
signed nonces. See `braid_client/folio_rendezvous.py` for exact paths.

For a same computer development run, set `BRAID_FOLIO_TEST_LOOPBACK=1` on Braid,
use `--base-url http://127.0.0.1:8766 --allow-loopback-http`, and enter that
URL in Folio's connection settings. That loopback mode does not work across two
different machines.

## Two machine demonstration

Use two separate Braid profiles and signing identities on two physical machines
or networks. Both must run this integration build. The publisher also runs the
matching Folio build. Put the rendezvous at the same public HTTPS origin for
both machines, publish one exported Folio page, and follow the four steps above.
For the last step, give the two Braid receivers direct or private overlay
reachability and start both listeners; the Folio rendezvous queues requests and
cards but does not relay Braid note frames. Use a harmless new channel note to
check a signed, indexed receipt on the reader. Try an ordinary summary handoff
to the same Folio-only contact: it must be rejected as outside the publication
scope. This is also exercised with two independent local profiles in
`tests/test_folio_connection.py`; a physical two-machine run is still needed.

## Events and boundaries

The first party service keeps daily aggregate counts by publication, event, and
optional edition ID: view, Continue click, install click, request created,
accepted, declined, and first confirmed channel note. It uses no cookies or
third party analytics. First-note reporting sends the publication ID, request
ID, two public peer IDs, note ID, and time after a normal channel delivery is
confirmed. No note text is sent to the rendezvous. The sender persists the
event locally and can retry when checking inbox or status; a telemetry failure
never changes a confirmed channel delivery. The service deduplicates that event
per request. These counts are operational attribution, not cryptographic proof
of a human reading a page or receiving a note.

Deleting an enabled Folio signs a permanent deleted revision before removing
the local draft. Disabling requests signs a disabled revision. Old static pages
can still contain the link, but the acquisition page reports that requests are
closed or the publication is gone. Expired requests cannot be accepted. A
publisher offline does not block request submission. A failed registration
blocks export of an enabled CTA.

## Architectural limits

- The rendezvous is new first party infrastructure; the existing Managed WAN
  relay does not accept unknown external peers into a member account. This
  public HTTPS service is deployed at https://connect.intersignal.org; its
  installer route leads to the updated homepage downloads.
- Card exchange after acceptance is deliberate because Braid's existing
  transport needs a pinned signed card and a reachable receiver. Acceptance
  alone creates the channel, not transport reachability.
- `source_network_id` is the publishing Braid installation's existing public
  fingerprint. Material from several rigs can inform the Folio, but this first
  version does not create a collective network key or disclose those rigs.
- The product version is `1.9.2`. Its invitation protocol is retained. Quit an
  older application before upgrading and back up the complete profile. Existing
  identity and explicit scopes are preserved; see MIGRATION_NOTES.md.
