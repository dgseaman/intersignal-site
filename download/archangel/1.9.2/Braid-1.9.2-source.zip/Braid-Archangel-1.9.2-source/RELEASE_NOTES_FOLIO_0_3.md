# Folio 0.3.0 connection integration — 2026-09-30

Readers can paste a Continue invitation link directly into Folio connections.
Braid accepts only the exact first-party link format, retrieves only the bounded
signed referral, rejects redirects, and verifies that its identity and origin
match the link before saving. This step neither sends a request nor trusts a peer.
The signed-file import remains available under details.

The acquisition page is a readable three-step guide with Copy connection link,
optional Get Braid, and the saved-file fallback. It makes no probes to local
applications and needs no browser permission to inspect the reader's computer.

The inbox loads when the connection panel opens. Acceptance, confirmed card
sharing, peer-card approval, and the remaining receive/reachability steps are
shown separately. Sharing remains available even for an already-approved contact.
An accepted request has an Open publication channel shortcut. Busy actions disable
newly rendered controls as well as existing ones.

Folio can ask Braid to check the rendezvous and configured acquisition download.
Error JSON responses now include their response length, fixing connection resets
when an oversized local API request is correctly rejected.

Wire protocol, cryptographic validation, arbitrary-peer enrollment, channel
permissions, and model-use grants are unchanged. This service queues requests and
consented cards; it does not relay Braid note frames. Existing metadata-only
first-message reporting still occurs only after confirmed delivery.
