"""Real POSIX lifecycle and command-launcher checks; no Finder/Windows UI claims."""
from pathlib import Path
import sys, os, subprocess, tempfile, json, time, urllib.request, hashlib, zipfile, signal, platform
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,condition):
    assert condition,name
    checks.append({'name':name,'passed':True})
    print('PASS '+name,flush=True)
def run(args,env=None):return subprocess.run(args,env=env,capture_output=True,text=True,timeout=10)
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def api(session,path,body=None):
    headers={'X-Folio-Token':session['token']}
    raw=None
    if body is not None:headers['Content-Type']='application/json';raw=json.dumps(body).encode()
    with opener.open(urllib.request.Request('http://127.0.0.1:'+str(session['port'])+'/api/'+path,data=raw,headers=headers),timeout=5) as r:return json.load(r)
def ready(home,proc):
    for _ in range(80):
        if proc.poll() is not None:raise RuntimeError('Launcher exited early')
        try:
            session=json.loads((home/'session.json').read_text())
            if api(session,'state')['app']=='intersignal.folio':return session
        except Exception:pass
        time.sleep(.1)
    raise RuntimeError('Launch timeout')
with tempfile.TemporaryDirectory(prefix='folio launch spaces ') as t:
    temp=Path(t);env=dict(os.environ);env['FOLIO_PYTHON']=sys.executable;env['PYTHONPATH']='/does/not/exist'
    a=run(['/bin/sh',str(ROOT/'Start Folio.command'),'--runtime-info'],env)
    check('Mac command launcher discovers explicit runtime',a.returncode==0 and sys.executable in a.stdout)
    a=run(['/bin/sh',str(ROOT/'Start Folio.sh'),'--runtime-info'],env)
    check('Linux entry point discovers runtime',a.returncode==0)
    spaced=temp/'python with spaces';spaced.symlink_to(sys.executable)
    e=dict(env,FOLIO_PYTHON=str(spaced))
    a=run(['/bin/sh',str(ROOT/'Start Folio.command'),'--runtime-info'],e)
    check('Explicit executable path with spaces',a.returncode==0 and str(spaced) in a.stdout)
    e=dict(env,FOLIO_PYTHON='/definitely/missing/python')
    a=run(['/bin/sh',str(ROOT/'Start Folio.command'),'--profile',str(temp/'never-opened'),'--no-browser'],e)
    check('Invalid explicit runtime fails closed',a.returncode!=0 and 'No fallback' in a.stderr and not (temp/'never-opened').exists())
    home=temp/'private library';log=(temp/'process.log').open('w')
    proc=subprocess.Popen(['/bin/sh',str(ROOT/'Start Folio.sh'),'--no-browser','--profile',str(home)],env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        first=ready(home,proc)
        check('Real launcher starts loopback service',api(first,'state')['version']=='0.3.0')
        check('Session file uses private Unix permissions',(home/'session.json').stat().st_mode&0o777==0o600)
        a=run(['/bin/sh',str(ROOT/'Start Folio.command'),'--no-browser','--profile',str(home)],env)
        check('Second launch reuses existing service',a.returncode==0 and 'already running' in a.stdout and json.loads((home/'session.json').read_text())['pid']==first['pid'])
        d=api(first,'sample',{});title=d['title']
        a=run([sys.executable,'-I',str(ROOT/'start_folio.py'),'--stop','--profile',str(home)],env)
        proc.wait(6)
        check('Stop closes Folio cleanly',a.returncode==0 and proc.returncode==0 and not (home/'session.json').exists())
        proc=subprocess.Popen(['/bin/sh',str(ROOT/'Start Folio.sh'),'--no-browser','--profile',str(home)],env=env,stdout=log,stderr=subprocess.STDOUT)
        second=ready(home,proc)
        check('Restart preserves private draft',api(second,'draft?id='+d['id'])['title']==title)
        check('Restart rotates session token',first['token']!=second['token'])
        api(second,'quit',{});proc.wait(6)
        check('App quit stops server and removes session',proc.returncode==0 and not (home/'session.json').exists())
        a=run([sys.executable,'-I',str(ROOT/'start_folio.py'),'--stop','--profile',str(home)],env)
        check('Stopping absent session fails honestly',a.returncode!=0 and 'No responsive Folio session' in a.stderr)
    finally:
        if proc.poll() is None:proc.terminate();proc.wait(6)
        log.close()
result={'method':__doc__,'platform':platform.system(),'passed':len(checks),'checks':checks}
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
