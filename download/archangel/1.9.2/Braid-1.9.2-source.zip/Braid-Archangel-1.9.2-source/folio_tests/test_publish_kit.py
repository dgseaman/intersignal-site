"""The CMS publish kit must come from an immutable exported edition."""
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace

from folio.core import MAX_BYTES, ValidationError, block, canonical, new_draft, review_digest, strict_json
from folio.server import Handler
from folio.store import Store, MAX_SAVED_EDITION_BYTES


class PublishKitStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.tmp.name)/'folio')
        first=block('human','Reviewed <script>alert(1)</script>\nsecond line')
        first['original']='PRIVATE-ORIGINAL'
        excluded=block('ai','PRIVATE-EXCLUDED')
        excluded['include']=False
        draft=new_draft('A public <title>',[first,excluded],{'token':'PRIVATE-SOURCE'})
        draft['subtitle']='Subtitle & context'
        draft['author']='Author Name'
        draft['introduction']='Opening note'
        draft['conclusion']='Closing note'
        draft['sources']='Source attribution'
        draft['parent']={'title':'Earlier folio','content_sha256':'f'*64}
        draft['stream']={'id':'a'*32,'name':'Research stream'}
        draft['capsule']['enabled']=True
        draft['capsule']['passage_ids']=[first['id']]
        for key in ('background','question','observations','attempted','constraints','uncertainty'):
            draft['capsule'][key]='Context '+key
        self.draft=self.store.insert(draft)

    def tearDown(self):self.tmp.cleanup()

    def export(self):
        self.store.approve(self.draft['id'],review_digest(self.draft),True)
        return self.store.export(self.draft['id'])

    def test_unexported_id_rejected(self):
        with self.assertRaises(ValidationError):self.store.publish_kit(self.draft['id'])

    def test_kit_is_escaped_complete_and_from_saved_edition(self):
        record=self.export()
        kit=self.store.publish_kit(record['id'])
        self.assertEqual(set(kit),{'edition_number','title','subtitle','content_sha256','styled_html','plain_html','styled_chars','plain_chars'})
        self.assertEqual(kit['title'],'A public <title>')
        self.assertEqual(kit['subtitle'],'Subtitle & context')
        self.assertEqual(kit['content_sha256'],record['content_sha256'])
        self.assertEqual(kit['styled_chars'],len(kit['styled_html']))
        self.assertEqual(kit['plain_chars'],len(kit['plain_html']))
        self.assertTrue(kit['styled_html'].startswith('<style>'))
        self.assertNotIn('<style',kit['plain_html'])
        for fragment in (kit['styled_html'],kit['plain_html']):
            self.assertIn('href="#folio-p-'+self.draft['blocks'][0]['id']+'"',fragment)
            self.assertNotIn('<blockquote>',fragment)
            for expected in ('A public &lt;title&gt;','Subtitle &amp; context','Author Name',
                             'Opening note','Reviewed &lt;script&gt;alert(1)&lt;/script&gt;<br>second line',
                             'Edited excerpt','Closing note','Source attribution','Earlier folio',
                             'Research stream','Context background','Context question',
                             'Context observations','Context attempted','Context constraints',
                             'Context uncertainty','Content SHA-256:'):
                self.assertIn(expected,fragment)
            for forbidden in ('PRIVATE-ORIGINAL','PRIVATE-EXCLUDED','PRIVATE-SOURCE',
                              '<html>','<head>','<body>','<script>','Content-Security-Policy',
                              'Stream ID:',
                              'href="edition.json"','href="publication.md"'):
                self.assertNotIn(forbidden,fragment)
        changed=self.store.get(self.draft['id']);changed['title']='A later draft';self.store.save(changed['id'],changed)
        self.assertEqual(self.store.publish_kit(record['id']),kit)

    def test_tampered_saved_edition_is_rejected(self):
        record=self.export()
        path=self.store.exports/(record['id']+'.zip')
        with zipfile.ZipFile(path) as source:
            files={name:source.read(name) for name in source.namelist()}
        edition=json.loads(files['edition.json'])
        edition['body']['title']='Tampered'
        files['edition.json']=json.dumps(edition).encode()
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as target:
            for name,data in files.items():target.writestr(name,data)
        with self.assertRaises(ValidationError):self.store.publish_kit(record['id'])

    def test_near_limit_valid_export_still_has_a_publish_kit(self):
        draft=new_draft('Near-limit edition',[block('note','x') for _ in range(400)])
        for passage in draft['blocks']:passage['text']='x'*10320
        self.assertLess(len(canonical(draft)),MAX_BYTES)
        saved=self.store.insert(draft)
        self.store.approve(saved['id'],review_digest(saved),True)
        record=self.store.export(saved['id'])
        _,archive=self.store.download(record['id'])
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            self.assertGreater(z.getinfo('edition.json').file_size,MAX_BYTES)
            self.assertLess(z.getinfo('edition.json').file_size,MAX_SAVED_EDITION_BYTES)
        kit=self.store.publish_kit(record['id'])
        self.assertEqual(kit['title'],'Near-limit edition')
        self.assertEqual(kit['content_sha256'],record['content_sha256'])

    def test_saved_edition_read_remains_bounded_and_strict(self):
        record=self.export()
        path=self.store.exports/(record['id']+'.zip')
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('edition.json',b'x'*(MAX_SAVED_EDITION_BYTES+1))
        with self.assertRaises(ValidationError):self.store.publish_kit(record['id'])
        for bad in ('{"a":1,"a":2}','NaN','['*65+']'*65):
            with self.subTest(bad=bad[:20]),self.assertRaises(ValidationError):
                strict_json(bad,max_bytes=MAX_SAVED_EDITION_BYTES)


class PublishKitHTTPTests(unittest.TestCase):
    def test_route_requires_token_and_exported_edition(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp))
            draft=store.insert(new_draft('HTTP publish kit',[block('note','Approved copy')]))
            server=SimpleNamespace(store=store,token='test-session-secret',server_port=8745,
                                   origin='http://127.0.0.1:8745')
            def get(ident,token=True):
                handler=Handler.__new__(Handler)
                handler.server=server
                handler.path='/api/publish-kit?id='+ident
                handler.headers={'Host':'127.0.0.1:8745',**({'X-Folio-Token':server.token} if token else {})}
                result=[]
                handler.response=lambda value,status=200,mime=None,extra=None:result.append((status,value))
                handler.do_GET()
                return result[0]
            self.assertEqual(get(draft['id'],False)[0],401)
            self.assertEqual(get(draft['id'])[0],400)
            store.approve(draft['id'],review_digest(draft),True)
            record=store.export(draft['id'])
            status,kit=get(record['id'])
            self.assertEqual(status,200)
            self.assertEqual(kit['title'],'HTTP publish kit')
            self.assertIn('Approved copy',kit['plain_html'])
            self.assertNotIn(server.token,json.dumps(kit))


if __name__=='__main__':unittest.main()
