"""Private rediscovery metadata and reviewed public presentation boundaries."""
import io,json,tempfile,unittest,zipfile
from pathlib import Path
from folio.core import new_draft,block,review_digest,public_body,ValidationError,render_html
from folio.store import Store
class ShelfTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name);self.s=Store(self.path)
        d=new_draft('A useful thought',[block('note','PUBLIC_EDIT'),block('note','EXCLUDED_SECRET')]);d['blocks'][0]['original']='PRIVATE_ORIGINAL';d['blocks'][1]['include']=False
        self.d=self.s.insert(d)
    def tearDown(self):self.tmp.cleanup()
    def test_shelf_uses_only_selected_text(self):
        listing=json.dumps(self.s.list());self.assertIn('PUBLIC_EDIT',listing);self.assertNotIn('PRIVATE_ORIGINAL',listing);self.assertNotIn('EXCLUDED_SECRET',listing)
    def test_pins_mood_and_resume_persist_without_revoking_approval(self):
        d=self.s.approve(self.d['id'],review_digest(self.d),True)
        self.s.save_preferences({'mood':'midnight','pin':{'id':d['id'],'enabled':True},'last_opened':d['id']})
        reloaded=Store(self.path);self.assertEqual(reloaded.preferences()['pins'],[d['id']]);self.assertEqual(reloaded.preferences()['mood'],'midnight');self.assertEqual(reloaded.preferences()['last_opened'],d['id'])
        current=reloaded.get(d['id']);self.assertEqual(current['approved_digest'],review_digest(current));self.assertEqual(current['revision'],d['revision'])
        body=json.dumps(public_body(current));self.assertNotIn('pins',body);self.assertNotIn('last_opened',body);self.assertNotIn('midnight',body)
    def test_untrusted_preferences_are_rejected(self):
        for v in ({'mood':'<script>'},{'pin':{'id':self.d['id'],'enabled':1}},{'last_opened':'missing'},{'token':'private'}):
            with self.assertRaises(ValidationError):self.s.save_preferences(v)
    def test_default_theme_preserves_legacy_review_hash(self):
        legacy=self.s.get(self.d['id']);legacy.pop('theme',None);before=review_digest(legacy)
        saved=self.s.save(legacy['id'],legacy);self.assertEqual(before,review_digest(saved));self.assertNotIn('theme',public_body(saved))
    def test_theme_change_revokes_review_and_exports_the_reviewed_style(self):
        d=self.s.approve(self.d['id'],review_digest(self.d),True);d['theme']='midnight';d=self.s.save(d['id'],d)
        self.assertIsNone(d['approved_digest']);self.s.approve(d['id'],review_digest(d),True);r=self.s.export(d['id']);_,raw=self.s.download(r['id'])
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            self.assertEqual(json.loads(z.read('edition.json'))['body']['theme'],'midnight');self.assertIn(b'background:#242b41',z.read('index.html'));self.assertNotIn(b'EXCLUDED_SECRET',z.read('index.html'))
        kit=self.s.publish_kit(r['id']);self.assertIn('background:#242b41',kit['styled_html']);self.assertEqual(kit['styled_html'].count('<article'),1)
    def test_arbitrary_theme_is_not_css(self):
        d=self.s.get(self.d['id']);d['theme']='url(https://evil.test)'
        with self.assertRaises(ValidationError):self.s.save(d['id'],d)
    def test_saved_theme_does_not_change_when_draft_changes(self):
        d=self.s.get(self.d['id']);d['theme']='rose';d=self.s.save(d['id'],d);self.s.approve(d['id'],review_digest(d),True);r=self.s.export(d['id'])
        d=self.s.get(d['id']);d['theme']='midnight';self.s.save(d['id'],d)
        kit=self.s.publish_kit(r['id']);self.assertIn('background:#f9ece8',kit['styled_html']);self.assertNotIn('background:#242b41',kit['styled_html'])
