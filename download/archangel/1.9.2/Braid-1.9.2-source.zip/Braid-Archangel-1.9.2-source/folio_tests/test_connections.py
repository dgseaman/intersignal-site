"""Public Folio connection links require an approved, registered capability."""
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from folio.core import (ValidationError, block, import_document, new_draft,
                        render_html, review_digest)
from folio.store import Store


NETWORK_ID = 'a' * 64
RENDEZVOUS = 'https://connect.intersignal.org'


class RegistrationBridge:
    def __init__(self, fail=False):
        self.calls = []
        self.fail = fail

    def register_publication(self, connection, edition_id=None, enabled=True, deleted=False):
        self.calls.append((connection.copy(), edition_id, enabled, deleted))
        if self.fail:
            raise ValidationError('Rendezvous registration did not complete.')
        return {'registered': True, 'source_network_id': NETWORK_ID}


class FolioConnectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.tmp.name))
        self.draft = self.store.insert(new_draft('A source-grounded folio',
                                                [block('note', 'Public work')],
                                                {'rig_name': 'PRIVATE-ATLAS-2'}))

    def tearDown(self):
        self.tmp.cleanup()

    def enabled(self):
        draft = self.store.get(self.draft['id'])
        draft['connection'] = {
            'enabled': True, 'source_network_id': NETWORK_ID,
            'rendezvous_url': RENDEZVOUS,
            'allowed_scopes': ['publication_channel', 'messages'],
        }
        return self.store.save(draft['id'], draft)

    def approve(self, draft):
        return self.store.approve(draft['id'], review_digest(draft), True)

    def test_enabled_edition_has_same_reviewed_cta_in_zip_and_publish_kit(self):
        draft = self.enabled()
        self.approve(draft)
        bridge = RegistrationBridge()
        record = self.store.export(draft['id'], bridge)
        self.assertEqual(len(bridge.calls), 1)
        self.assertEqual(bridge.calls[0][0]['publication_id'], draft['id'])
        self.assertTrue(bridge.calls[0][2])
        _, archive = self.store.download(record['id'])
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            edition = json.loads(z.read('edition.json'))
            page = z.read('index.html').decode()
        connection = edition['body']['connection']
        self.assertEqual(connection['publication_id'], draft['id'])
        self.assertEqual(connection['source_network_id'], NETWORK_ID)
        self.assertEqual(connection['allowed_scopes'], ['publication_channel', 'messages'])
        for rendered in (page, self.store.publish_kit(record['id'])['plain_html']):
            self.assertIn('Continue this on Braid', rendered)
            self.assertIn('/continue?publication_id=' + draft['id'], rendered)
            self.assertIn('source_network_id=' + NETWORK_ID, rendered)
            self.assertIn('edition_id=' + record['id'], rendered)
            self.assertIn('/v1/events/view.gif?publication_id=' + draft['id'], rendered)
            self.assertNotIn('PRIVATE-ATLAS-2', rendered)
        self.assertIn('img-src ' + RENDEZVOUS, page)
        self.assertNotIn('script-src', page)
        preview = render_html({'body': edition['body'], 'content_sha256': record['content_sha256'],
                               'edition_number': 2, 'published_at': 'Not exported'}, preview=True)
        self.assertNotIn('/v1/events/view.gif', preview)

    def test_registration_failure_never_exports_inert_cta(self):
        draft = self.enabled()
        self.approve(draft)
        with self.assertRaisesRegex(ValidationError, 'register'):
            self.store.export(draft['id'])
        with self.assertRaisesRegex(ValidationError, 'did not complete'):
            self.store.export(draft['id'], RegistrationBridge(fail=True))
        self.assertEqual(self.store.get(draft['id'])['editions'], [])

    def test_disable_existing_publication_revokes_before_local_save(self):
        draft = self.enabled()
        self.approve(draft)
        bridge = RegistrationBridge()
        self.store.export(draft['id'], bridge)
        edited = self.store.get(draft['id'])
        edited['connection']['enabled'] = False
        with self.assertRaisesRegex(ValidationError, 'Connect to Braid'):
            self.store.save(draft['id'], edited)
        self.assertTrue(self.store.get(draft['id'])['connection']['enabled'])
        bridge.fail = True
        with self.assertRaisesRegex(ValidationError, 'did not complete'):
            self.store.save(draft['id'], edited, bridge)
        self.assertTrue(self.store.get(draft['id'])['connection']['enabled'])
        bridge.fail = False
        saved = self.store.save(draft['id'], edited, bridge)
        self.assertFalse(saved['connection']['enabled'])
        self.assertFalse(bridge.calls[-1][2])
        self.assertIsNone(saved['approved_digest'])

    def test_delete_existing_publication_revokes_first(self):
        draft = self.enabled()
        self.approve(draft)
        bridge = RegistrationBridge()
        self.store.export(draft['id'], bridge)
        current = self.store.get(draft['id'])
        with self.assertRaisesRegex(ValidationError, 'close connection requests'):
            self.store.delete(draft['id'], current['revision'])
        self.store.delete(draft['id'], current['revision'], bridge)
        self.assertFalse(bridge.calls[-1][2])
        self.assertTrue(bridge.calls[-1][3])
        with self.assertRaises(ValidationError):
            self.store.get(draft['id'])

    def test_incomplete_settings_can_be_drafted_but_not_exported(self):
        draft = self.store.get(self.draft['id'])
        draft['connection']['enabled'] = True
        saved = self.store.save(draft['id'], draft)
        with self.assertRaisesRegex(ValidationError, 'public Braid network identity'):
            self.approve(saved)

    def test_untrusted_scopes_and_urls_are_rejected(self):
        draft = self.store.get(self.draft['id'])
        draft['connection'] = {'enabled': True, 'source_network_id': NETWORK_ID,
                               'rendezvous_url': RENDEZVOUS,
                               'allowed_scopes': ['entire_field']}
        with self.assertRaisesRegex(ValidationError, 'supported'):
            self.store.save(draft['id'], draft)
        draft['connection']['allowed_scopes'] = ['messages']
        draft['connection']['rendezvous_url'] = 'javascript:alert(1)'
        saved = self.store.save(draft['id'], draft)
        with self.assertRaisesRegex(ValidationError, 'HTTPS'):
            self.approve(saved)

    def test_imported_public_edition_does_not_inherit_connection_permission(self):
        draft = self.enabled()
        self.approve(draft)
        record = self.store.export(draft['id'], RegistrationBridge())
        _, archive = self.store.download(record['id'])
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            imported = import_document(z.read('edition.json'), 'edition.json')
        self.assertFalse(imported['connection']['enabled'])


if __name__ == '__main__':
    unittest.main()
