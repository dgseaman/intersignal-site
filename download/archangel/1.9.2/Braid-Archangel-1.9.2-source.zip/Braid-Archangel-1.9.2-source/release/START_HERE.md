# Developer and compatibility launcher bundle — Braid Archangel 1.9.2

The normal release is the self-contained native Braid application. See the
release-root START_HERE.md. This source directory retains Python launchers for
developer testing and upgrades; they are not an additional Folio application.

Use CPython 3.10–3.13 and the declared dependencies. The developer bundle
creates a version-specific runtime, so this path requires Python and may use a
terminal. Start Braid once with `start_braid.py` or the matching command launcher.
The same local server includes `/folio` and Publish with Folio actions.

Do not run two versions against a live profile. Back up the complete profile,
quit the previous application, then launch the new version. An older running
version is rejected rather than silently reopened. Existing identities, WAN
choices, Channels, grants, and history remain in their current profile.
Read MIGRATION_NOTES.md and TEST_RESULTS.md in the release root.
