# Braid Archangel 1.9.2

One Braid application, from private local work to deliberate public publishing.
Folio 0.3.0 is now a first-class internal studio at `/folio` on Braid's local
server. There is no separate Folio download, Python launch, terminal, profile
search, or Connect to Braid setup in the normal journey.

Install the self-contained Braid application for your operating system. On
macOS, copy Braid.app to Applications and open Braid. Choose **Folio — Publish
to Web** in the left sidebar. A conversation with completed exchanges or a
saved Channel note also offers **Publish with Folio**. That action copies only
the selected bounded view into a private, unapproved Folio draft.

Compose and edit, choose any optional context capsule, inspect the public page
and exact public JSON, explicitly approve that edition, and export its ZIP or
publication kit. Public edits invalidate approval. Exported editions retain
their stable identities and immutable archive bytes. A configured stream site
folder may be made public by a host or sync service after an approved export.
Braid does not deploy hosting or post to social networks on launch.

Folio owns its library, private originals, review receipts, editions, themes,
preferences, stream queue, export logic, and privacy protections. These records
are stored under the Braid profile's separate `folio` directory, outside the
receiver inbox and Braid desktop database. The private Folio capability is
distinct from Braid's session token. Its in-process adapter permits bounded
source views and public identity/publication registration; it has no generic
network-send, trust-approval, or field-write operation.

Nothing publishes from Archangel without explicit Folio review and approval.
Stream observations prepare private review drafts. Legacy Broadcast settings
are retained but execute as Review queue. Private originals and excluded text
never enter public exports or publication registration. A Folio invitation
does not grant Braid authority: acceptance, each rig-card exchange, fingerprint
approval, and publication scope remain separate explicit decisions.

Use **Back to Braid** to leave the studio. Closing a browser tab leaves Braid
running. Use Braid's Settings & tools → Quit Archangel to stop both surfaces.
Restart retains private drafts and editions and rotates local session tokens.

See `MIGRATION_NOTES.md`, `RELEASE_NOTES.md`, and `TEST_RESULTS.md` for migration,
release qualification, exact tests, and platform limits. This build does not
modify production services or the live Intersignal website. Existing LAN,
receiver-sovereign signed transport, WAN opt-ins, scoped Channels, local chat,
semantic fields, and invitation controls remain available.

## Developer and compatibility entry points

The source package includes the existing Python Braid launcher in `release/`
and the standalone Folio launcher for compatibility testing. They are not the
normal installation journey. Do not open a library simultaneously with its
standalone launcher and integrated Braid studio.

Build on the target operating system using the pinned dependencies in
`packaging/desktop-requirements.txt`, then run `python packaging/build_desktop.py`.
The build produces a self-contained native directory/application with its own
runtime. PyInstaller must run on the target OS; it does not cross-build native
applications. `pytest -q` runs Braid, Folio, and the new integration tests.
`tests/native_launch192.py` tests the actual frozen binary; `--http-only` selects
native lifecycle/HTTP checks when browser process launch is restricted. Browser
results must be reported separately in that case. Optional physical hardware
and real multi-machine/model qualification are not implied by synthetic tests.
