import sys,os,json,time,subprocess,tempfile,urllib.request,platform
from pathlib import Path
ROOT=Path('/mnt/data/archangel_work/Braid-Archangel-1.7.0a5');E=Path('/mnt/data/archangel_work/evidence')
env=dict(os.environ);env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
checks=[]
def check(name,value):
 assert value,name
 checks.append(name);print('PASS',name,flush=True)
def launch(profile,args,log):
 return subprocess.Popen([sys.executable,str(ROOT/'start_braid.py'),'--profile',str(profile),'--no-browser','--offline',*args],cwd='/tmp',env=env,stdout=log,stderr=subprocess.STDOUT)
def wait(profile,p):
 for _ in range(1200):
  if p.poll() is not None:raise AssertionError('Early exit '+str(p.returncode))
  try:
   meta=json.loads((profile/'session.json').read_text())
   opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
   with opener.open('http://127.0.0.1:'+str(meta['port'])+'/api/messenger/state',timeout=2) as r:return json.load(r)
  except (OSError,ValueError,KeyError):time.sleep(.1)
 raise AssertionError('Timeout')
def stop(profile,p):
 r=subprocess.run([sys.executable,str(ROOT/'start_braid.py'),'--profile',str(profile),'--stop'],cwd='/tmp',env=env,text=True,capture_output=True,timeout=10)
 assert r.returncode==0,r.stderr
 assert p.wait(timeout=25)==0
with tempfile.TemporaryDirectory(prefix='archangel-host-') as d:
 profile=Path(d)/'profile'
 with (E/'launcher-host-log.txt').open('w') as log:
  p=launch(profile,['--use-existing-env'],log)
  try:
   state=wait(profile,p)
   check('explicit host mode serves app',state['version']=='1.7.0a5')
   policy=json.loads((profile/'install-policy.json').read_text())
   check('explicit choice persisted',policy['mode']=='host-explicit')
   rt=profile/('runtime-1.7.0a5-host-explicit-py'+'.'.join(map(str,sys.version_info[:2]))+'-'+platform.machine().lower())
   pth=list(rt.rglob('archangel-host-explicit.pth'))
   check('only explicit mode has visible host path link',len(pth)==1 and '/opt/pyvenv' in pth[0].read_text())
   r=subprocess.run([str(rt/'bin'/'python'),'-I','-c','import jsonschema,braid_client;print(braid_client.__version__)'],env=env,cwd='/tmp',capture_output=True,text=True)
   check('nested host venv dependencies usable',r.returncode==0 and '1.7.0a5' in r.stdout)
   stop(profile,p);check('explicit mode shuts down cleanly',True)
   p=launch(profile,[],log);wait(profile,p)
   check('ordinary restart preserves explicit operator choice',json.loads((profile/'install-policy.json').read_text())['mode']=='host-explicit')
   stop(profile,p)
   # Switching back must genuinely produce an isolated install, not host leakage.
   p=launch(profile,['--isolated-runtime','--wheelhouse','/mnt/data/archangel_work/test-offline-pack-final'],log)
   wait(profile,p)
   check('switch back records isolated mode',json.loads((profile/'install-policy.json').read_text())['mode']=='isolated')
   iso=profile/('runtime-1.7.0a5-isolated-py'+'.'.join(map(str,sys.version_info[:2]))+'-'+platform.machine().lower())
   check('isolated mode never inherits explicit pth',not list(iso.rglob('archangel-host-explicit.pth')))
   r=subprocess.run([str(iso/'bin'/'python'),'-I','-c','import sys,json;print(json.dumps(sys.path))'],env=env,cwd='/tmp',capture_output=True,text=True,check=True)
   check('isolated sys.path excludes host venv',not any('/opt/pyvenv' in x for x in json.loads(r.stdout)))
   stop(profile,p)
   E.joinpath('launcher-host-smoke.json').write_text(json.dumps({'passed':True,'checks':checks,'scope':'Real Linux host-linked installation from an existing virtual environment, persistent explicit policy, and switch back to isolated offline pack; package-link file is intentional only in explicit host mode.'},indent=2))
  finally:
   if p.poll() is None:
    try:stop(profile,p)
    except Exception:p.kill();p.wait()
