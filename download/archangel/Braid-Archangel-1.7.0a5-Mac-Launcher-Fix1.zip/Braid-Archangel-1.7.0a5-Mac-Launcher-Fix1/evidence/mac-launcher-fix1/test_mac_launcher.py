"""macOS runtime-discovery control-flow tests on Linux, with simulated layouts."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(os.environ.get('ARCHANGEL_LAUNCHER', str(Path(__file__).with_name('Start_Braid.command')))).read_text()
REAL = sys.executable

class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='Archangel tests ')
        self.root = Path(self.tmp.name)
        self.bundle = self.root / 'Bundle with spaces'
        self.bundle.mkdir()
        self.bin = self.root / 'path'
        self.bin.mkdir()
        for name in ['dirname']:
            (self.bin / name).symlink_to(shutil.which(name))
        # Redirect ONLY the fixed installation prefixes into a hermetic fixture.
        # The script's executable discovery and control flow are unchanged.
        script = SCRIPT
        for prefix in ['/opt/homebrew', '/usr/local', '/Library/Frameworks', '/opt/local']:
            script = script.replace(prefix, str(self.root / prefix.lstrip('/')))
        self.script = self.bundle / 'Start Braid.command'
        self.script.write_text(script)
        self.script.chmod(0o755)
        (self.bundle / 'start_braid.py').write_text(
            "import json,os,sys\n"
            "print('APP '+json.dumps({'args':sys.argv[1:],'cwd':os.getcwd()}))\n"
            "sys.exit(int(os.environ.get('APP_EXIT','0')))\n")
        self.env = {k:v for k,v in os.environ.items() if k not in ('BRAID_PYTHON', 'PYTHONHOME', 'PYTHONPATH')}
        self.env.update(PATH=str(self.bin), HOME=str(self.root / 'home'))

    def tearDown(self):
        self.tmp.cleanup()

    def fake(self, path, *, rejected=None):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if rejected:
            text = '#!/bin/sh\nprintf "%s\\n" "'+rejected+'"\nexit 2\n'
        else:
            text = '#!/bin/sh\nexec "'+REAL+'" "$@"\n'
        path.write_text(text)
        path.chmod(0o755)
        return path

    def run_script(self, *args, **env):
        return subprocess.run(['/bin/sh', str(self.script), *args], env={**self.env, **env}, text=True, capture_output=True, timeout=15)

    def good(self, result):
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn('APP ', result.stdout)

    def test_supported_default_preserved(self):
        self.fake(self.bin / 'python3')
        self.fake(self.bin / 'python3.13', rejected='Must not be called')
        r=self.run_script('--profile','a profile')
        self.good(r)
        self.assertNotIn('Must not be called',r.stderr)

    def test_old_default_falls_back_to_versioned_path(self):
        self.fake(self.bin/'python3',rejected='CPython 3.9.6 requires 3.10-3.13')
        self.fake(self.bin/'python3.12')
        r=self.run_script()
        self.good(r)
        self.assertIn('3.9.6',r.stderr)

    def test_new_default_falls_back(self):
        self.fake(self.bin/'python3',rejected='CPython 3.14.0 requires 3.10-3.13')
        self.fake(self.bin/'python3.13')
        r=self.run_script()
        self.good(r)
        self.assertIn('3.14.0',r.stderr)

    def test_homebrew_without_path(self):
        self.fake(self.root/'opt/homebrew/opt/python@3.12/bin/python3.12')
        self.good(self.run_script())

    def test_intel_homebrew_without_path(self):
        self.fake(self.root/'usr/local/opt/python@3.13/bin/python3.13')
        self.good(self.run_script())

    def test_python_org_framework_without_path(self):
        self.fake(self.root/'Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12')
        self.good(self.run_script())

    def test_user_pyenv_shims(self):
        self.fake(self.root/'home/.pyenv/shims/python3.11')
        self.good(self.run_script())

    def test_explicit_override_with_spaces(self):
        target=self.fake(self.root/'Chosen Python/bin/python3')
        self.good(self.run_script(BRAID_PYTHON=str(target)))

    def test_invalid_override_never_falls_back(self):
        self.fake(self.bin/'python3')
        r=self.run_script(BRAID_PYTHON=str(self.root/'missing'))
        self.assertEqual(r.returncode,1)
        self.assertNotIn('APP ',r.stdout)
        self.assertIn('No fallback',r.stderr)

    def test_no_interpreter_has_actionable_error(self):
        r=self.run_script()
        self.assertEqual(r.returncode,1)
        self.assertIn('No supported Python',r.stderr)
        self.assertNotIn('APP ',r.stdout)
        self.assertFalse((self.root/'home').exists())

    def test_runtime_info_does_not_start_application(self):
        self.fake(self.bin/'python3')
        r=self.run_script('--runtime-info')
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('Archangel selected',r.stdout)
        self.assertNotIn('APP ',r.stdout)

    def test_application_failure_does_not_trigger_fallback(self):
        self.fake(self.bin/'python3')
        self.fake(self.bin/'python3.12',rejected='Second startup attempted')
        r=self.run_script(APP_EXIT='7')
        self.assertEqual(r.returncode,7)
        self.assertEqual(r.stdout.count('APP '),1)
        self.assertNotIn('Second startup',r.stderr)

    def test_arguments_and_bundle_directory_preserved(self):
        self.fake(self.bin/'python3')
        args=['--offline','--wheelhouse','/path with spaces/wheels','--profile','/a/b c','--no-browser']
        r=self.run_script(*args)
        self.good(r)
        record=json.loads(next(line[4:] for line in r.stdout.splitlines() if line.startswith('APP ')))
        self.assertEqual(record['args'],args)
        self.assertEqual(record['cwd'],str(self.bundle))

    def test_missing_runtime_components_fall_back(self):
        self.fake(self.bin/'python3',rejected='CPython 3.12 missing runtime component: ensurepip')
        self.fake(self.bin/'python3.13')
        r=self.run_script()
        self.good(r)
        self.assertIn('ensurepip',r.stderr)

    def test_missing_application_fails_before_discovery(self):
        (self.bundle/'start_braid.py').unlink()
        r=self.run_script()
        self.assertEqual(r.returncode,1)
        self.assertIn('beside the bundled start_braid.py',r.stderr)

    def test_free_threaded_runtime_rejected_then_fallback(self):
        self.fake(self.bin/'python3',rejected='CPython 3.13 free-threaded builds are not supported')
        self.fake(self.bin/'python3.12')
        r=self.run_script()
        self.good(r)
        self.assertIn('free-threaded',r.stderr)

if __name__=='__main__':
    unittest.main(verbosity=2)
