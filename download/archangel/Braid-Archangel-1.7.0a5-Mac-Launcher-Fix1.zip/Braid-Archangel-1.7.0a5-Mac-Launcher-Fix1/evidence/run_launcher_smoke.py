import json,os,subprocess,sys,time,urllib.request,tempfile,hashlib
from pathlib import Path
ROOT=Path('/mnt/data/archangel_work/Braid-Archangel-1.7.0a5')
E=Path('/mnt/data/archangel_work/evidence')
PACK=Path('/mnt/data/archangel_work/test-offline-pack-final')
env=dict(os.environ);env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
checks=[]
def check(name,value):
    assert value,name
    checks.append(name);print('PASS',name,flush=True)
def run(*args,timeout=120):
    return subprocess.run([sys.executable,str(ROOT/'start_braid.py'),*map(str,args)],cwd='/tmp',env=env,text=True,capture_output=True,timeout=timeout)
def url_for(profile,process):
    for n in range(1800):
        if process.poll() is not None:raise AssertionError('Launcher exited '+str(process.returncode))
        try:
            meta=json.loads((profile/'session.json').read_text());url='http://127.0.0.1:'+str(meta['port'])
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(url+'/api/messenger/state',timeout=2) as response:state=json.load(response)
            return url,state,opener
        except (OSError,ValueError,KeyError):time.sleep(.1)
    raise AssertionError('Ready timeout')
with tempfile.TemporaryDirectory(prefix='archangel-installed-') as d:
    d=Path(d);profile=d/'profile'
    log=(E/'launcher-install-log.txt').open('w')
    process=subprocess.Popen([sys.executable,str(ROOT/'start_braid.py'),'--profile',str(profile),'--no-browser','--offline','--wheelhouse',str(PACK)],cwd='/tmp',env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        url,state,opener=url_for(profile,process)
        check('installed wheel version',state['version']=='1.7.0a5')
        check('fresh inbox empty',not state['messages'])
        print('STATE KEYS',list(state),flush=True)
        check('receiving paused by default',not state['listener']['running'])
        with opener.open(url+'/',timeout=5) as response:html=response.read().decode()
        check('HTTP substitutes real version','1.7.0a5' in html and '__BRAID_VERSION__' not in html)
        check('HTTP serves Archangel controls','Quit Archangel' in html and 'updateAddress' in html)
        import platform
        python=profile/('runtime-1.7.0a5-isolated-py'+'.'.join(map(str,sys.version_info[:2]))+'-'+platform.machine().lower())/'bin'/'python'
        code="import sys,json,importlib.metadata as m;print(json.dumps({'prefix':sys.prefix,'base_prefix':sys.base_prefix,'path':sys.path,'braid':m.version('braid-client'),'numpy':m.version('numpy'),'cryptography':m.version('cryptography')}))"
        rr=subprocess.run([str(python),'-I','-c',code],env=env,cwd='/tmp',capture_output=True,text=True,check=True)
        runtime=json.loads(rr.stdout)
        check('independent isolated venv',runtime['prefix']!=runtime['base_prefix'] and all(not('site-packages' in p) or p.startswith(runtime['prefix']) for p in runtime['path']))
        check('no test pth bridge',not any('braid' in p.name.lower() or 'bridge' in p.name.lower() for p in (python.parent.parent/'lib'/'python3.13'/'site-packages').glob('*.pth')))
        rr=subprocess.run([str(python),'-m','pip','check'],env=env,cwd='/tmp',capture_output=True,text=True)
        check('installed dependency consistency',rr.returncode==0)
        duplicate=run('--profile',profile,'--no-browser','--offline')
        check('second launch does not create second process',duplicate.returncode==0 and 'already running' in duplicate.stdout)
        request=urllib.request.Request(url+'/api/messenger/shutdown',data=b'{}',headers={'Content-Type':'application/json'},method='POST')
        import urllib.error
        try:
            opener.open(request,timeout=3);raise AssertionError('unauthenticated shutdown accepted')
        except urllib.error.HTTPError as exc:check('shutdown requires CSRF',exc.code==403)
        stop=run('--profile',profile,'--stop')
        check('cooperative stop request accepted',stop.returncode==0)
        check('launcher exits cleanly',process.wait(timeout=25)==0)
        check('session cleared',not (profile/'session.json').exists())
        check('lock filename may remain', (profile/'launcher.lock').is_file())
        old_db=profile/'messenger.sqlite3'
        import sqlite3
        with sqlite3.connect(old_db) as conn:conn.execute("INSERT OR REPLACE INTO kv(key,value) VALUES ('smoke_preserve','\"kept\"')")
        # A second launch uses the already installed isolated runtime, offline,
        # without the pack. It must preserve the existing profile and identity.
        identity=hashlib.sha256((profile/'identity.pem').read_bytes()).hexdigest()
        process=subprocess.Popen([sys.executable,str(ROOT/'start_braid.py'),'--profile',str(profile),'--no-browser','--offline'],cwd='/tmp',env=env,stdout=log,stderr=subprocess.STDOUT)
        url,state,opener=url_for(profile,process)
        check('restart reacquires OS lock',state['version']=='1.7.0a5')
        check('restart preserves identity',identity==hashlib.sha256((profile/'identity.pem').read_bytes()).hexdigest())
        with sqlite3.connect(old_db) as conn:check('restart preserves local database',conn.execute("SELECT value FROM kv WHERE key='smoke_preserve'").fetchone()[0]=='"kept"')
        check('desktop backup made before existing-profile open',(profile/'archangel-upgrade.json').is_file())
        stop=run('--profile',profile,'--stop')
        check('second cooperative exit',stop.returncode==0 and process.wait(timeout=25)==0)
        # Cold installation has no pack: fail with a useful message, no network fallback.
        cold=run('--profile',d/'cold','--offline','--no-browser')
        check('cold offline failure is explicit',cold.returncode==1 and 'Offline first launch needs a verified wheelhouse' in cold.stderr)
        check('no package-index attempt for cold offline','Looking in indexes' not in cold.stdout and 'Downloading' not in cold.stdout)
        verified=run('--check')
        check('bundle integrity command succeeds',verified.returncode==0)
        E.joinpath('launcher-smoke.json').write_text(json.dumps({'passed':True,'checks':checks,'python':sys.version,'scope':'Real Linux fresh isolated venv and installed wheel; dependency wheels reconstructed from installed distributions solely as test fixtures, not upstream wheel bytes. No host .pth bridge. Real loopback HTTP and cooperative process lifecycle.','runtime_versions':{k:runtime[k] for k in ['braid','numpy','cryptography']},'wheel_sha256':hashlib.sha256((ROOT/'braid_client-1.7.0a5-py3-none-any.whl').read_bytes()).hexdigest()},indent=2))
    finally:
        if process.poll() is None:
            try:run('--profile',profile,'--stop',timeout=8);process.wait(timeout=20)
            except Exception:process.kill();process.wait()
        log.close()
