# Reproducing the evidence

The source archive includes all pytest tests and `tests/browser_archangel.py`. Run the suite with a suitable development environment from the source directory: `python -m pytest -q`. Browser checks additionally require Playwright and Chromium; the harness labels its simulated API.

Launcher smoke harnesses and dependency-reconstruction tooling are retained here as build-lab scripts, not release launchers. Their defaults point at the original ephemeral build workspace; see each script for paths to adapt in another lab. The reconstructed dependency wheels themselves are intentionally not distributed. For ordinary use, create an upstream offline pack with `prepare_offline.py` or install normally.

Historical test logs in the source archive are not new Archangel platform evidence. Native macOS/Windows, real models and physical multi-rig/WAN qualification remain unexecuted here.
