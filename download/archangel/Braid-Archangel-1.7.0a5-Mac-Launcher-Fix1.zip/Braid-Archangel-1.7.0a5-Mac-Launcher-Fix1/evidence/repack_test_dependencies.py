"""TEST ONLY: reconstruct wheels from this container's installed distributions.

Not upstream wheel bytes and not a distributable official offline pack. Used only
to test isolated, no-index installation when the build container has no DNS.
"""
import base64,csv,hashlib,importlib.metadata as m,io,json,zipfile
from pathlib import Path
root=Path('/mnt/data/archangel_work/test_dependency_wheels');root.mkdir(exist_ok=True)
report=[]
for name in ['numpy','cryptography','jsonschema','attrs','jsonschema-specifications','referencing','rpds-py','cffi','pycparser','typing-extensions']:
 d=m.distribution(name)
 wheel_file=next(f for f in d.files if str(f).endswith('.dist-info/WHEEL'))
 wheel_text=d.locate_file(wheel_file).read_text()
 tag=next(line[5:].strip() for line in wheel_text.splitlines() if line.startswith('Tag: '))
 basename=d.metadata['Name'].replace('-','_')+'-'+d.version+'-'+tag+'.whl'
 record_name=str(wheel_file).rsplit('/',1)[0]+'/RECORD'
 records=[]
 with zipfile.ZipFile(root/basename,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
  for f in d.files:
   fstr=str(f)
   if '..' in f.parts or fstr.endswith(('.pyc','/RECORD','/RECORD.jws','/RECORD.p7s')):continue
   path=d.locate_file(f)
   if not path.is_file():continue
   data=path.read_bytes();z.writestr(fstr,data)
   digest=base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode()
   records.append((fstr,'sha256='+digest,str(len(data))))
  buf=io.StringIO();writer=csv.writer(buf,lineterminator='\n');writer.writerows(records);writer.writerow((record_name,'',''));z.writestr(record_name,buf.getvalue())
 report.append({'package':name,'version':d.version,'test_wheel':basename,'files':len(records)})
 print(name,d.version)
Path('/mnt/data/archangel_work/evidence/test-wheel-reconstruction.json').write_text(json.dumps({'scope':'test fixtures reconstructed from installed distributions, not upstream wheel bytes; NOT included in release','packages':report},indent=2))
