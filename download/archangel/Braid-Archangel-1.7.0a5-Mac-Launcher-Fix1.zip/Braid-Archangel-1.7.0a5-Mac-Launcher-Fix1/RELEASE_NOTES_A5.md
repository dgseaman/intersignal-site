# Release notes - 1.7.0a5 Archangel

Status: runnable engineering alpha; supersedes a4 for focused reliability testing. The compact rig list, inbox, reviewed summary composer and explicit receipt model remain the product surface.

## Delivery and storage

A transactionally reserved `(handoff, recipient)` ledger persists content identity and outcome before network work. Successful, in-flight and unknown outcomes are not automatically sent again. Explicit rejection and preparation failure can be retried with the same fixed reviewed content. A new intentional handoff is a separate action. Interrupted entries recover as unknown. This is sender-local idempotency, not a global exactly-once guarantee.

SQLite contexts now commit/rollback and close deterministically. Incoming receipts are ingested from the receive callback, with bounded incremental directory reconciliation. The old whole-directory sort and per-poll restat loop are gone. Metadata is durable; a periodic cycle still notices in-place receipt edits even when directory mtime is unchanged. Malformed, oversized and symlink receipt candidates are skipped.

## Network and identity

TLS handshakes run in bounded worker slots, not the accept loop; timeout begins before the handshake. Active sockets can be interrupted at shutdown. The Messenger direct listener requires client certificates from approved rig cards and exact certificate authorization before Braid frame parsing. The incoming frame signer must match the authenticated TLS contact. Receiver certificates are also exact-pinned on sends. Removing a contact updates admission policy without deleting its committed history.

Private LAN, explicit CGNAT overlay, direct-link IPv4 and IPv6 ULA/loopback now share a coordinated address policy from discovery through card validation, binding and connection. Public/wildcard/multicast and known metadata endpoints remain rejected. Scoped IPv6 link-local is deliberately not accepted because source-local scope names cannot be copied as receiver-side endpoints.

Address updates preserve the same signing/TLS identity, route and history; a signed, monotonic card revision updates the peer endpoint after explicit approval. Trust high-water marks survive removal and block rollback. Certificate/route replacement requires deliberate re-enrollment, not an endpoint-only update. New a4 card imports are refused: exchange refreshed Archangel cards in both directions.

## Cross-platform lifecycle and packaging

Private writes use POSIX permissions or an explicit Windows protected DACL. The unconditional Windows `os.fchmod` dependency is removed; ACL errors fail closed. Windows native execution remains a physical test gate.

The launcher defaults to an isolated venv, supports a target/hash-verified offline wheel pack, and offers validated host dependency reuse only by explicit choice. Normal online dependencies are pinned and binary-only. Standard CPython 3.10-3.13 is the packaged target. Python, Ollama and model files are separately provisioned.

Cooperative authenticated Quit/stop replaces immediate subprocess termination as the normal path. A bounded forced fallback remains for operations that do not drain. The OS profile lock prevents concurrent upgrades; a stale lock filename does not represent ownership. Existing a4 profiles are retained, with a desktop/trust snapshot before migration. Native code signing/notarization is not claimed; safe per-item/manual macOS launch instructions are provided.

## Compatibility and authority

Braid frame, capsule, field and delta schema authority is unchanged. Route validation, signature verification, replay checks, receiver-owned Phase B finality, canonical FP16 rules, conflict preservation and the completion guard remain enforced. Transport admission, file protection and desktop bookkeeping code were intentionally changed rather than preserving inherited defects byte-for-byte.

Rig-card v1 gains signed capability, mTLS and revision metadata. An address-only update does not grant new signing authority. TLS admission does not replace Braid signatures or the receiver's acceptance policy. Unsupported future payloads are not decoded by guesswork. Archangel does not claim native hidden-state, KV-cache or universal latent-coordinate interchange.

See QA for exact evidence and limitations. The source contains historical a3/a4 guides, packaging inputs and test logs, labeled as historical; they are not fresh Archangel platform certifications.
