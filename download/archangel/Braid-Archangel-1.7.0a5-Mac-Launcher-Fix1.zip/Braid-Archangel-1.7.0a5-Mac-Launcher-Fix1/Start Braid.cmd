@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python "%~dp0start_braid.py" %*
) else (
  py -3 "%~dp0start_braid.py" %*
)
if errorlevel 1 (
  echo.
  echo Braid did not start. See START_HERE.md for requirements and manual setup.
  pause
  exit /b 1
)
