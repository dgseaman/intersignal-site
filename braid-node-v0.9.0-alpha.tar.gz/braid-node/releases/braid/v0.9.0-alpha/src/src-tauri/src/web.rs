use std::sync::Arc;
use tokio::net::TcpListener;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use crate::AppState;

// =====================================================================
// LOCALHOST WEB VISUALIZER VIEWPORT (Pillar 5)
// =====================================================================

pub async fn start_web_server(state: Arc<AppState>, web_port: u16) {
    let addr = format!("127.0.0.1:{}", web_port);
    let listener = match TcpListener::bind(&addr).await {
        Ok(l) => l,
        Err(_) => {
            TcpListener::bind("127.0.0.1:0").await.expect("Failed to bind web server to any port")
        }
    };

    let bound_addr = listener.local_addr().unwrap();
    println!("[WEB] Localhost Web Visualizer live at: http://{}", bound_addr);

    loop {
        match listener.accept().await {
            Ok((mut stream, _)) => {
                let state_clone = Arc::clone(&state);
                tokio::spawn(async move {
                    let mut buf = vec![0u8; 1024];
                    if let Ok(size) = stream.read(&mut buf).await {
                        let req_str = String::from_utf8_lossy(&buf[..size]);
                        
                        if req_str.starts_with("GET /api/state ") {
                            let node_id_hex = crate::format_hex(&state_clone.node_id);
                            
                            let peers_list = {
                                let table = state_clone.peer_table.lock().await;
                                table.values()
                                    .filter(|r| r.status != crate::main_status_stale())
                                    .map(|r| r.observed_addr.to_string())
                                    .collect::<Vec<String>>()
                            };

                            let latest_vec = {
                                let vec_guard = state_clone.latest_received_vector.lock().await;
                                vec_guard.clone()
                            };

                            let roster_list = {
                                let peer_table = state_clone.peer_table.lock().await;
                                let telemetry = state_clone.peer_telemetry.lock().await;
                                let now_ms = std::time::SystemTime::now()
                                    .duration_since(std::time::UNIX_EPOCH)
                                    .unwrap_or_default()
                                    .as_millis() as u64;

                                let mut roster = Vec::new();
                                for (node_id, record) in peer_table.iter() {
                                    let node_id_hex = crate::format_hex(node_id);
                                    let display_name = format!("Node-{}", &node_id_hex[0..8]);
                                    
                                    let elapsed = now_ms.saturating_sub(record.last_seen_ms);
                                    let presence_state = if elapsed >= crate::presence::PRESENCE_OFFLINE_AFTER_MS {
                                        "Offline".to_string()
                                    } else if elapsed >= crate::presence::PRESENCE_STALE_AFTER_MS {
                                        "Stale".to_string()
                                    } else {
                                        "Active".to_string()
                                    };

                                    let route_table = state_clone.route_table.lock().await;
                                    let route_state = if let Some(candidates) = route_table.get(node_id) {
                                        if candidates.iter().any(|c| c.state == crate::route::RouteState::Verified && matches!(c.endpoint, crate::route::RouteEndpoint::Udp(_))) {
                                            "direct".to_string()
                                        } else if candidates.iter().any(|c| c.state == crate::route::RouteState::Verified && matches!(c.endpoint, crate::route::RouteEndpoint::Relay { .. })) {
                                            "relay".to_string()
                                        } else if candidates.iter().any(|c| c.state == crate::route::RouteState::Probing) {
                                            "probing".to_string()
                                        } else {
                                            "failed".to_string()
                                        }
                                    } else {
                                        "unknown".to_string()
                                    };

                                    let (adapter, last_event) = telemetry.get(node_id)
                                        .cloned()
                                        .unwrap_or_else(|| ("text_projection".to_string(), None));

                                    roster.push(crate::presence::PresenceRosterView {
                                        node_id_hex,
                                        display_name,
                                        presence_state,
                                        route_state,
                                        nat_classification: "NAT-Restricted".to_string(),
                                        latency_ms: if record.round_trip_latency_ms > 0 { Some(record.round_trip_latency_ms) } else { None },
                                        last_seen_ms_ago: elapsed,
                                        active_adapter: adapter,
                                        last_payload_event: last_event,
                                    });
                                }
                                roster
                            };

                            let json_state = serde_json::json!({
                                "node_id": node_id_hex,
                                "local_address": format!("0.0.0.0:{}", state_clone.local_port),
                                "peers": peers_list,
                                "latest_vector": latest_vec,
                                "roster": roster_list,
                            });

                            let body = serde_json::to_string(&json_state).unwrap_or_default();
                            let response = format!(
                                "HTTP/1.1 200 OK\r\n\
                                Content-Type: application/json\r\n\
                                Content-Length: {}\r\n\
                                Access-Control-Allow-Origin: *\r\n\
                                Connection: close\r\n\r\n\
                                {}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else if req_str.starts_with("GET /api/poke") {
                            let json_res = serde_json::json!({
                                "status": "success"
                            });
                            let body = serde_json::to_string(&json_res).unwrap_or_default();
                            let response = format!(
                                "HTTP/1.1 200 OK\r\n\                                Content-Type: application/json\r\n\                                Content-Length: {}\r\n\                                Access-Control-Allow-Origin: *\r\n\                                Connection: close\r\n\r\n\                                {}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else if req_str.starts_with("GET /api/scan") {
                            let json_res = serde_json::json!({
                                "status": "success"
                            });
                            let body = serde_json::to_string(&json_res).unwrap_or_default();
                            let response = format!(
                                "HTTP/1.1 200 OK\r\n\                                Content-Type: application/json\r\n\                                Content-Length: {}\r\n\                                Access-Control-Allow-Origin: *\r\n\                                Connection: close\r\n\r\n\                                {}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else if req_str.starts_with("GET / ") {
                            let html_body = include_str!("visualizer.html");
                            let response = format!(
                                "HTTP/1.1 200 OK\r\n\
                                Content-Type: text/html\r\n\
                                Content-Length: {}\r\n\
                                Connection: close\r\n\r\n\
                                {}",
                                html_body.len(),
                                html_body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        } else {
                            let body = "Not Found";
                            let response = format!(
                                "HTTP/1.1 404 Not Found\r\n\
                                Content-Length: {}\r\n\
                                Connection: close\r\n\r\n\
                                {}",
                                body.len(),
                                body
                            );
                            let _ = stream.write_all(response.as_bytes()).await;
                        }
                        let _ = stream.flush().await;
                    }
                });
            }
            Err(_) => {
                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
            }
        }
    }
}
