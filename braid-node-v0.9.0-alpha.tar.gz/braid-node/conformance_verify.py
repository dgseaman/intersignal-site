#!/usr/bin/env python3
import hashlib
import binascii
import struct
import sys
import os
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

def log_pass(msg):
    print(f"\x1b[32m[PASS]\x1b[0m {msg}")

def log_fail(msg):
    print(f"\x1b[31m[FAIL]\x1b[0m {msg}")

def run_verification():
    print("=====================================================================")
    print("BRAID WAN TENDRIL v0.9.0 CONFORMANCE VERIFICATION SUITE (Pillar 7)")
    print("=====================================================================")

    # Resolve paths to conformance-fixtures directory
    fixture_dir = "conformance-fixtures"
    if not os.path.exists(fixture_dir):
        # Check if we are inside the fixtures directory itself
        if os.path.exists("keys.ed25519.public.hex"):
            fixture_dir = "."
        else:
            log_fail(f"Could not find conformance-fixtures directory.")
            sys.exit(1)

    try:
        # Load keys
        pub_bytes = binascii.unhexlify(open(os.path.join(fixture_dir, "keys.ed25519.public.hex")).read().strip())
        expected_node_id = binascii.unhexlify(open(os.path.join(fixture_dir, "derived_node_id.hex")).read().strip())
    except Exception as e:
        log_fail(f"Failed to load keys: {e}")
        sys.exit(1)

    # 1. Verify NodeId Derivation
    scheme_id = 1
    hasher = hashlib.sha256()
    hasher.update(b"braid-node-id-v1")
    hasher.update(scheme_id.to_bytes(2, "big"))
    hasher.update(pub_bytes)
    derived_node_id = hasher.digest()

    if derived_node_id == expected_node_id:
        log_pass(f"NodeId derivation matches expected: {binascii.hexlify(derived_node_id).decode()}")
    else:
        log_fail(f"NodeId derivation mismatch! Derived: {binascii.hexlify(derived_node_id).decode()}, Expected: {binascii.hexlify(expected_node_id).decode()}")
        sys.exit(1)

    # 2. Verify Deterministic Packed Signing Preimage
    try:
        packed_preimage = binascii.unhexlify(open(os.path.join(fixture_dir, "BraidSigningBody.state_drift.f32.packed.hex")).read().strip())
        signature_f32 = binascii.unhexlify(open(os.path.join(fixture_dir, "signature.state_drift.f32.ed25519.hex")).read().strip())
    except Exception as e:
        log_fail(f"Failed to load preimages or signatures: {e}")
        sys.exit(1)

    # Verify packed fields manually
    # version (u16): 8, msg_type (u16): 1, scheme (u16): 1, wire_enc (u16): 2, vector_enc (u16): 1
    offset = 0
    version, msg_type, scheme, wire_enc, vector_enc = struct.unpack_from(">HHHHH", packed_preimage, offset)
    offset += 10

    if version != 8:
        log_fail(f"Preimage wire protocol version mismatch: expected 8, found {version}")
        sys.exit(1)
    if wire_enc != 2: # ENCODING_CANONICAL_PACKED
        log_fail(f"Preimage wire encoding mismatch: expected 2 (CANONICAL_PACKED), found {wire_enc}")
        sys.exit(1)

    log_pass("Preimage packed header fields verified (Wire Protocol v8, Canonical Preimage Packing v2)")

    # 3. Verify Cryptographic Ed25519 Signatures
    public_key = ed25519.Ed25519PublicKey.from_public_bytes(pub_bytes)
    try:
        public_key.verify(signature_f32, packed_preimage)
        log_pass("Ed25519 signature verified successfully against BraidSigningBody preimage")
    except Exception as e:
        log_fail(f"Ed25519 signature verification failed: {e}")
        sys.exit(1)

    # 4. Verify BraidEnvelope Serialization & Invariants
    try:
        envelope_data = binascii.unhexlify(open(os.path.join(fixture_dir, "BraidEnvelope.state_drift.f32.bincode.hex")).read().strip())
    except Exception as e:
        log_fail(f"Failed to load envelope bincode: {e}")
        sys.exit(1)

    # Unpack little-endian serialized envelope
    offset = 0
    env_version, env_msg_type, env_scheme, env_wire, env_vector = struct.unpack_from("<HHHHH", envelope_data, offset)
    offset += 10

    if env_version != 8:
        log_fail(f"Envelope wire protocol version mismatch: expected 8, found {env_version}")
        sys.exit(1)
    if env_wire != 1: # ENCODING_BINCODE
        log_fail(f"Envelope wire encoding mismatch: expected 1 (BINCODE), found {env_wire}")
        sys.exit(1)

    log_pass("BraidEnvelope serialization constraints verified (Wire Protocol v8, Bincode Outer format)")

    # 5. Verify Packet Ceiling Invariants
    packet_size = len(envelope_data)
    if packet_size <= 2048:
         log_pass(f"Packet ceiling invariants verified: serialized size {packet_size} bytes (<= 2048 maximum MTU bounds)")
    else:
         log_fail(f"Packet ceiling violated! Serialized size {packet_size} exceeds maximum MTU bounds of 2048 bytes")
         sys.exit(1)

    # 6. Verify QINT8 Quantization
    try:
        qint8_payload = binascii.unhexlify(open(os.path.join(fixture_dir, "payload.state_drift.qint8.bincode.hex")).read().strip())
    except Exception as e:
        log_fail(f"Failed to load QINT8 payload: {e}")
        sys.exit(1)

    # Decode QINT8 struct: scale (f32, LE), zero_point (i8), values length (u64, LE)
    scale, zero_point, values_len = struct.unpack_from("<fbQ", qint8_payload, 0)
    if values_len != 384:
         log_fail(f"Quantized payload has invalid vector length: expected 384, found {values_len}")
         sys.exit(1)

    log_pass("Quantized QINT8 state vector layout verified (384 dimensions, scale metadata, zero-point calibration)")

    print("=====================================================================")
    print("\x1b[32m[SUCCESS]\x1b[0m All Braid Pathfinder v0.9.0 protocol invariants verified successfully!")
    print("=====================================================================")

if __name__ == "__main__":
    run_verification()
