# Braid Pathfinder: Product Roadmap & Technical Specification

This document outlines the product milestones, packaging specifications, and SDK designs for transitioning Braid Tendril from a source-build developer release to a user-facing desktop application and developer ecosystem.

---

## Milestone 1: Frictionless macOS DMG Packaging (`Braid-Tendril-v0.9.0-alpha-aarch64.dmg`)

To eliminate prerequisites like Homebrew, Python, Node, Cargo, and Terminal execution, Braid will be distributed as a native macOS Disk Image (DMG) for Apple Silicon (`aarch64`) and Intel (`x64`) architectures.

### 1. Tauri Bundler Configuration (`tauri.conf.json`)
The Tauri bundler will be configured to package the compiled native binary and React web assets into a self-contained `.app` bundle, which is then wrapped in a drag-and-drop installer DMG.

```json
{
  "tauri": {
    "bundle": {
      "active": true,
      "targets": ["dmg"],
      "identifier": "ai.intersignal.braid-tendril",
      "icon": [
        "icons/32x32.png",
        "icons/128x128.png",
        "icons/128x128@2x.png",
        "icons/icon.png"
      ],
      "resources": [],
      "macOS": {
        "frameworks": [],
        "minimumSystemVersion": "11.0",
        "exceptionDomain": "",
        "signingIdentity": null,
        "providerBundleIdentifier": null,
        "useCommandWidthCheck": false,
        "dmg": {
          "background": "icons/dmg-background.png",
          "windowPosition": {
            "x": 400,
            "y": 400
          },
          "windowSize": {
            "width": 660,
            "height": 400
          },
          "appPosition": {
            "x": 180,
            "y": 170
          },
          "linkPosition": {
            "x": 480,
            "y": 170
          }
        }
      }
    }
  }
}
```

### 2. DMG Build Pipeline
The build pipeline is executed on an Apple Silicon or x64 macOS host:
```bash
# 1. Install frontend dependencies
npm ci

# 2. Build Tauri desktop bundle (outputs dmg)
npm run tauri build -- --target aarch64-apple-darwin
```
Upon completion, the installer is located at `src-tauri/target/release/bundle/dmg/Braid-Tendril-v0.9.0-alpha-aarch64.dmg`.

---

## Milestone 2: One-Click GUI "Local Demo" Mode

To allow immediate verification of Braid's core loopback state transport, the visualizer interface will introduce a "Start Here" Local Demo panel.

### 1. Loopback Mechanics
- **State Generation**: Node A generates a deterministic, mock 384-dimensional latent vector (representing local state).
- **Preimage Signing**: Builds a canonical prebiotic preimage (`BraidSigningBody`) and signs it using its local Ed25519 private key.
- **Envelope Packing**: Encapsulates the payload into a standard `BraidEnvelope` using `ENCODING_BINCODE` outer format.
- **UDP Loopback Dispatch**: Dispatches the packet over a local loopback port (`127.0.0.1:12000`).
- **Pipeline Ingestion**: Receives, validates signatures, commits to the replay ledger, dequantizes (if using `qint8`), and animates the received coordinate states in the UI feed.

### 2. UI Visualization Elements
- **Metrics Dashboard**: Displays live counts of *Packets Sent*, *Packets Received*, and *Signatures Verified*.
- **Wire Size Comparison**: Shows an interactive bar comparing the two serialization modes:
  - **`raw-f32` (f32 encoding)**: `1738` bytes (1544 bytes payload + 194 bytes envelope metadata).
  - **`qint8` (compressed quantization)**: `591` bytes (397 bytes payload + 194 bytes envelope metadata).
- **Interactive Scatter Feed**: Renders the 384 dequantized float coordinates as a glowing, animating technical wave or point cloud.

---

## Milestone 3: Braid Adapter SDK (Semantic State Adapters)

Braid is not an LLM itself; it is a specialized state-transport protocol. AI systems and local agents interface with Braid through **Adapters** that map rich semantic states to exactly 384-dimensional float arrays.

```
Rich Agent State (Text, Memory, Tool Trace, Model Internals)
                     │
                     ▼
           [ EMBEDDING / PROJECTION ]
                     │
                     ▼
             384d Float32Array
                     │
                     ▼
       [ BRAID STATE TRANSPORT LAYER ] (f32 / qint8)
```

### Standard Adapter SDK Schema
Adapters must implement a clean, lightweight interface:
```typescript
interface BraidAdapter {
  /**
   * Encodes a rich semantic input string or object into a 384-dimensional vector.
   */
  encode(input: string | object): Promise<Float32Array>;

  /**
   * Decodes a received 384-dimensional vector back into text, concepts, or routing alignments.
   */
  decode(vector: Float32Array): Promise<string | object>;
}
```

### Initial SDK Adaptations
1. **Local Text-to-384d Demo Adapter**: A CPU-optimized, zero-dependency in-browser TF-IDF or small transformer projection mapping text inputs directly to 384 dimensions on the fly.
2. **Ollama / Local Model Adapter**: Queries a local Ollama instance (such as `nomic-embed-text` or `all-minilm`) and uses a linear projection head to down-sample or up-sample embeddings to the standard 384-dimension coordinate space.
3. **OpenAI-Compatible Embedding Adapter**: Interfaces with standard cloud endpoints (`text-embedding-3-small` with `dimensions: 384` parameter) to generate ready-to-transport coordinates.
4. **Document Chunk Adapter**: Chunks long documents, vectorizes them, and streams individual signed 384-dimensional chunks over Braid's multi-path WAN mesh.

---

## Milestone 4: Next-Gen Interactive State-Alignment Demo

To showcase Braid's capability as a lightweight, secure semantic alignment transport layer, we will build an interactive cross-node alignment demo.

### Demo Architecture
```
  [ Node A ]                                                     [ Node B ]
Text: "Paired trust verified"                                Verified signed vector
        │                                                                │
        ▼                                                                ▼
384d Vector State ─────────► [ Braid WAN Transport ] ─────────►  Nearest Interpretation
                                                               (Matches: "Secure Session Ready")
```

1. **Input Conversion (Node A)**: User types a sentence or statement into Node A's input panel. Node A's local embedding adapter converts the input into a 384-dimensional vector.
2. **Secure Packaging**: signs the vector with Node A's private key, wraps it in a bounded `BraidEnvelope` (using qint8 compression to fit nicely within a single `591`-byte MTU packet), and sends it to Node B over a WAN route or relay.
3. **Receipt & Verification (Node B)**: Node B receives the envelope, validates the signature, and accepts the coordinate state.
4. **State Interpretation (Node B)**: Node B passes the coordinate vector to its local decoder. It computes the cosine similarity against its local database of known system states, concepts, or routes, displaying:
   - **Nearest Concept Match**: e.g., *"Secure Session Ready"* (similarity: `0.91`).
   - **Verification Banner**: NodeId identity verification status and packet integrity.
   - **Route Alignment Visual**: A glowing nearest-neighbor point projection showing how Node A's semantic coordinate aligns with Node B's state map.
