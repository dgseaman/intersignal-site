#!/usr/bin/env sh
set -eu

VERSION="${BRAID_VERSION:-latest}"
INSTALL_DIR="${BRAID_INSTALL_DIR:-$HOME/.local/bin}"
BASE_URL="${BRAID_BASE_URL:-https://intersignal.org/releases/braid}"

mkdir -p "$INSTALL_DIR"

OS="$(uname -s)"
ARCH="$(uname -m)"

case "$OS" in
  Darwin) OS_NAME="macos" ;;
  Linux) OS_NAME="linux" ;;
  *) echo "Unsupported OS: $OS" >&2; exit 1 ;;
esac

case "$ARCH" in
  arm64|aarch64) ARCH_NAME="arm64" ;;
  x86_64|amd64) ARCH_NAME="x64" ;;
  *) echo "Unsupported architecture: $ARCH" >&2; exit 1 ;;
esac

if [ "$VERSION" = "latest" ]; then
  VERSION="$(curl -fsSL "$BASE_URL/latest.txt")"
fi

ARTIFACT="braid-${VERSION}-${OS_NAME}-${ARCH_NAME}.tar.gz"
SHA_FILE="${ARTIFACT}.sha256"

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

cd "$TMP_DIR"

curl -fsSLO "$BASE_URL/$VERSION/$ARTIFACT"
curl -fsSLO "$BASE_URL/$VERSION/$SHA_FILE"

EXPECTED="$(cut -d ' ' -f 1 "$SHA_FILE")"
ACTUAL="$(sha256sum "$ARTIFACT" 2>/dev/null | cut -d ' ' -f 1 || shasum -a 256 "$ARTIFACT" | cut -d ' ' -f 1)"

if [ "$EXPECTED" != "$ACTUAL" ]; then
  echo "Checksum verification failed." >&2
  exit 1
fi

tar -xzf "$ARTIFACT"
chmod +x braid
mv braid "$INSTALL_DIR/braid"

echo "Braid installed to $INSTALL_DIR/braid"
echo
echo "Next:"
echo "  braid node"
