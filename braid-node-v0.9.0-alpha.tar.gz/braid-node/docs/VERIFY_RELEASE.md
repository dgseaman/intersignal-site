# Verification and Release Guidelines

To verify the integrity and protocol conformance of Braid Tendril v0.9.0, run the following steps.

## Platform Installer Script Artifacts Disclosure
Since the Braid Tendril node runtime is implemented as an executable Python script payload, the `.tar.gz` distribution packages for Linux (x64) and macOS (ARM64) represent standardized platform installer script artifacts rather than native compiled CPU binaries.

## Step 1: Checksums Verification
Validate that all files match the signed checksum manifest:
```bash
sha256sum -c checksums.txt
```

## Step 2: Protocol Conformance
Verify the wire protocol against the static test vectors:
```bash
python3 conformance_verify.py
```

## Step 3: Vector Transfer Verification
Execute the local loopback vector-transfer demo:
```bash
./braid demo vector-transfer --real-local --encoding raw-f32
./braid demo vector-transfer --real-local --encoding qint8
```
