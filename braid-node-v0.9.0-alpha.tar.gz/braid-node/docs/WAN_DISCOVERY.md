# WAN Discovery Specification (v0.9.0)

## Architectural Design

Braid Tendril v0.9.0 introduces a dedicated, typed peer configuration layer designed to safely navigate multi-path WAN setups without relying on unsafe, blind IP scanning or background connection storms.

### NAT Honesty Statement
Direct WAN peer mode requires reachable UDP ports or compatible NAT/router configuration. If direct UDP is unavailable, use a relay route. 

Currently, Braid Tendril v0.9.0 does NOT implement automatic STUN/TURN/ICE NAT hole punching, nor does it support an active public DHT or global peer search. All WAN peers must be manually declared, populated from a local seed list, or discovered via LAN broadcast when local.

### Capabilities and Verification Status

| Capability | Status | Description |
|---|---|---|
| Direct UDP Seed Peers | **Verified** | Connection via direct IP:port routing. |
| Relay Endpoint Routing | **Verified** | Forwarding via zero-trust, opaque relay frames. |
| Automatic NAT Traversal | *Unclaimed* | Requires manual router/NAT port forwarding. |
| Global public DHT | *Unclaimed* | Decentralized but requires explicit manual peers. |
