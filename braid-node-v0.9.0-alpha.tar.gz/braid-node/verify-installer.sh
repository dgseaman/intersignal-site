#!/usr/bin/env sh
set -eu

echo "Testing install-braid.sh locally..."

# Set environment overrides to point to our local files
export BRAID_VERSION="v0.9.0-alpha"
export BRAID_INSTALL_DIR="/tmp/braid_test_bin"
export BRAID_BASE_URL="file://$(pwd)/releases/braid"

# Ensure clean state
rm -rf "$BRAID_INSTALL_DIR"

# Run the installer
sh install-braid.sh

# Verify execution of the installed binary
if [ -x "$BRAID_INSTALL_DIR/braid" ]; then
  "$BRAID_INSTALL_DIR/braid" version
  echo "====================================================================="
  echo "Installer verification: PASS"
  echo "====================================================================="
else
  echo "Installer verification: FAIL"
  exit 1
fi
