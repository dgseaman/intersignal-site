# Braid Changelog

## Braid Tendril v0.9.0-alpha — July 4, 2026
*   **NAT Traversal Lab**: Introduced a minimal STUN Binding client in Rust to perform public endpoint discovery with no account, no paid API, and no central Braid service, discovering observed mapped IP addresses and ports across multiple STUN servers.
*   **Honest NAT Classification**: Implemented RFC1918 private IPv4 detection and multi-server mapped endpoint variance analysis to detect Symmetric NAT and diagnose direct reachability realistically.
*   **Direct UDP Hole-Punch Lab**: Added bounded signed direct endpoint probing/punching commands that run asynchronously to establish direct socket-level routes without blocking the UI thread.
*   **Relay Fallback Routing**: Designed a strict selection policy favoring verified direct UDP routes and falling back to relays when direct paths are unavailable.
*   **Polished Connection Lab**: Polished the dashboard with sections for Local Node metadata, Reachability diagnostics, Manual Peer forms, Routes, Sessions, deterministic 384d vector transfers, and Diagnostics.
*   **Privacy & Safety Guardrails**: Integrated explicit rate-limiting and global action limits to protect network resources, accompanied by explicit privacy copy disclosures on the frontend.

## Braid Tendril v0.8.3-alpha — July 3, 2026
*   **Explicit Peer Configuration Model**: Created a structured, typed peer config layer supporting manual WAN peer forms, label and port validation, and duplicate seed endpoint rejection.
*   **Manual WAN Peer Flow**: Added a dedicated Tauri command to dynamically add manual peers, updating active route lists and trust policies instantly.
*   **WAN-Safe Discovery Probing**: Introduced explicit rate-limited endpoint probing that safely dispatches signed discovery beacons with strict MTU, sequence, and timeout checks.
*   **Introspection Engine**: Implemented route and session state table introspection commands to expose real-time path health and handshake status without leaking secrets.
*   **Deterministic Test Vector Generator**: Built a seeded deterministic f32 generator yielding exact 384d vector samples with complete statistical metadata and SHA-256 byte checksums.
*   **Inbound Vector Receipt Events**: Integrated first-class, structured receipt events for verified state drift packages to feed a live receipt table.
*   **Relay MTU Safety**: Enforced qint8 quantization by default on relays to prevent outer packet ceiling overflows, gating raw f32 relays behind strict size checks.

## Braid Tendril v0.8.2-alpha — July 3, 2026
*   **Decentralized Signed-Presence Rendezvous**: Sockets and route hints are dynamically advertised and verified via signed `BraidPresenceRecord` packets containing raw cryptographic `public_material` and absolute lease expirations (`expires_at_ms`).
*   **Presence Signature Verification**: Node identity signatures inside presence announcements are verified directly against their supplied `public_material` rather than just assuming key bytes from NodeId.
*   **NodeId-First Routing**: Fully decoupled transport and session logic from direct socket addresses, routing exclusively based on `NodeId`. Implemented `send_to_node(NodeId, envelope)` dynamic route resolution.
*   **Message-Type-Keyed Replay Ledger**: Bounded replay ledgers track sequences independently across each message type to prevent inter-protocol sequence interference.
*   **Transit Relay Forwarding & Ingestion**: Built real transit packet forwarding via signed `BraidRelayFrame` envelopes supporting target NodeId routing, sender tracking, and absolute TTL expirations to prevent loop leaks. Supports final-recipient inline packet ingestion.
*   **Quantized INT8 State Decompression**: Rebuilt the QINT8 decompression path inside the receiver loop to seamlessly decompress and synchronize 384-dimension state vectors.
*   **Handshake Session State Machine**: Integrated full cryptographic multi-message WAN session handshake sequences over active route candidates.
*   **Persistent Trust Policies & Pairing Pending**: Implemented persistent `trust_policy.json` to manage trusted, denied, and pending pairing states.
*   **Portable Conformance Verification**: Shipped a clean, executable `conformance_verify.py` script that validates protocol compliance down to the byte.
