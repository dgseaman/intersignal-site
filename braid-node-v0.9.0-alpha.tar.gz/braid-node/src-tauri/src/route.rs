use serde::{Serialize, Deserialize};
use std::net::SocketAddr;
use crate::protocol::NodeId;

// =====================================================================
// MULTI-PATH WAN ROUTING ENGINE (Pillar 4)
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum TransportKind {
    Udp,
    Relay,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub enum RouteEndpoint {
    Udp(SocketAddr),
    Relay { relay_node_id: NodeId, target_endpoint: String },
}

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum RouteSource {
    Discovery,
    Presence,
    Manual,
}

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum RouteState {
    Probing,
    Verified,
    Failed,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct RouteCandidate {
    pub route_id: [u8; 16],
    pub target_node_id: NodeId,
    pub transport: TransportKind,
    pub endpoint: RouteEndpoint,
    pub source: RouteSource,
    pub verified_by_presence: bool,
    pub verified_by_session: bool,
    pub latency_ms: Option<u64>,
    pub failure_count: u32,
    pub expires_at_ms: u64,
    pub state: RouteState,
    pub preferred_vector_encoding: u16,
}

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum PeerStatus {
    Active,
    Verified,
    Stale,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq)]
pub struct PeerRecord {
    pub node_id: NodeId,
    pub observed_addr: SocketAddr,
    pub status: PeerStatus,
    pub protocol_version: u16,
    pub capabilities: u64,
    pub vector_dim: u16,
    pub session_id: [u8; 16],
    pub last_seen_ms: u64,
    pub expires_at_ms: u64,
    pub highest_sequence: u64,
    pub round_trip_latency_ms: u64,
    pub preferred_vector_encoding: u16, // using u16 to align with other protocol encodings internally
}

use std::fmt;

impl fmt::Display for RouteEndpoint {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RouteEndpoint::Udp(addr) => write!(f, "{}", addr),
            RouteEndpoint::Relay { relay_node_id, target_endpoint } => {
                write!(f, "relay:{}->{}", hex::encode(relay_node_id), target_endpoint)
            }
        }
    }
}
