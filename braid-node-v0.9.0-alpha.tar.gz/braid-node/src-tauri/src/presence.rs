use serde::{Serialize, Deserialize};
use ed25519_dalek::{VerifyingKey, Signature};
use crate::protocol::{NodeId, SCHEME_ED25519};
use crate::identity::derive_node_id;

// =====================================================================
// SOVEREIGN WAN PRESENCE ADVERTISEMENT (Pillar 2)
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct PresenceRecord {
    pub version: u16,
    pub signature_scheme: u16,
    pub public_material: Vec<u8>,
    pub capabilities: u64,
    pub route_hints: Vec<String>, // e.g. ["udp://a.b.c.d:12000", "relay://r.r.r.r:8788"]
    pub sequence: u64,
    pub issued_at_ms: u64,
    pub expires_at_ms: u64,
    pub signature: Vec<u8>,
}

impl PresenceRecord {
    /// Serialize presence fields canonically for deterministic signing (Pillar 2)
    pub fn serialize_canonical(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&self.version.to_be_bytes());
        bytes.extend_from_slice(&self.signature_scheme.to_be_bytes());
        
        bytes.extend_from_slice(&(self.public_material.len() as u32).to_be_bytes());
        bytes.extend_from_slice(&self.public_material);
        
        bytes.extend_from_slice(&self.capabilities.to_be_bytes());
        
        bytes.extend_from_slice(&(self.route_hints.len() as u32).to_be_bytes());
        for hint in &self.route_hints {
            let h_bytes = hint.as_bytes();
            bytes.extend_from_slice(&(h_bytes.len() as u32).to_be_bytes());
            bytes.extend_from_slice(h_bytes);
        }
        
        bytes.extend_from_slice(&self.sequence.to_be_bytes());
        bytes.extend_from_slice(&self.issued_at_ms.to_be_bytes());
        bytes.extend_from_slice(&self.expires_at_ms.to_be_bytes());
        bytes
    }

    /// Derive NodeId of the advertiser
    pub fn node_id(&self) -> NodeId {
        derive_node_id(self.signature_scheme, &self.public_material)
    }

    /// Verify signature on the presence record
    pub fn verify_signature(&self) -> bool {
        if self.signature_scheme == SCHEME_ED25519 {
            let key_bytes: Result<[u8; 32], _> = self.public_material.clone().try_into();
            let signature_bytes: Result<[u8; 64], _> = self.signature.clone().try_into();

            match (key_bytes, signature_bytes) {
                (Ok(key_arr), Ok(sig_arr)) => {
                    let verifying_key_res = VerifyingKey::from_bytes(&key_arr);
                    let signature = Signature::from_bytes(&sig_arr);

                    match verifying_key_res {
                        Ok(pubkey) => {
                            let canonical_data = self.serialize_canonical();
                            use ed25519_dalek::Verifier;
                            pubkey.verify(&canonical_data, &signature).is_ok()
                        }
                        _ => false,
                    }
                }
                _ => false,
            }
        } else {
            false
        }
    }
}

// =====================================================================
// PEER PRESENCE TIMINGS AND STATES (v0.9)
// =====================================================================

pub const PRESENCE_HEARTBEAT_MS: u64 = 5_000;
pub const PRESENCE_STALE_AFTER_MS: u64 = 15_000;
pub const PRESENCE_OFFLINE_AFTER_MS: u64 = 45_000;

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq, Eq)]
pub enum PeerPresenceState {
    Active,
    Stale,
    Offline,
    Unknown,
}

impl PeerPresenceState {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Active => "Active",
            Self::Stale => "Stale",
            Self::Offline => "Offline",
            Self::Unknown => "Unknown",
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct PresenceRosterView {
    pub node_id_hex: String,
    pub display_name: String,
    pub presence_state: String, // "Active" | "Stale" | "Offline" | "Unknown"
    pub route_state: String,    // "direct" | "relay" | "probing" | "failed" | "unknown"
    pub nat_classification: String,
    pub latency_ms: Option<u64>,
    pub last_seen_ms_ago: u64,
    pub active_adapter: String,
    pub last_payload_event: Option<String>,
}
