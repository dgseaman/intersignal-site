use std::path::PathBuf;
use std::fs;
use ed25519_dalek::{SigningKey, VerifyingKey};
use rand::rngs::OsRng;
use sha2::{Sha256, Digest};
use crate::protocol::{NodeId, SCHEME_ED25519, IdentityProvider};

// =====================================================================
// CRYPTOGRAPHIC IDENTITY ABSTRACTION & DERIVATION (Pillar 1)
// =====================================================================

pub fn derive_node_id(scheme_id: u16, public_material: &[u8]) -> NodeId {
    let mut hasher = Sha256::new();
    hasher.update(b"braid-node-id-v1");
    hasher.update(&scheme_id.to_be_bytes());
    hasher.update(public_material);
    let result = hasher.finalize();
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&result);
    node_id
}

pub struct NodeIdentity {
    pub signing_key: SigningKey,
}

impl NodeIdentity {
    pub fn load_or_create(path: PathBuf) -> Result<Self, String> {
        if path.exists() {
            let bytes = fs::read(&path).map_err(|e| e.to_string())?;
            if bytes.len() == 32 {
                let key_bytes: [u8; 32] = bytes.try_into().unwrap();
                let signing_key = SigningKey::from_bytes(&key_bytes);
                return Ok(Self { signing_key });
            }
        }
        
        let mut csprng = OsRng;
        let signing_key = SigningKey::generate(&mut csprng);
        fs::write(&path, signing_key.to_bytes()).map_err(|e| e.to_string())?;
        Ok(Self { signing_key })
    }

    pub fn public_key(&self) -> VerifyingKey {
        self.signing_key.verifying_key()
    }
}

pub struct Ed25519LocalIdentityProvider {
    pub signing_key: SigningKey,
}

impl Ed25519LocalIdentityProvider {
    pub fn new(signing_key: SigningKey) -> Self {
        Self { signing_key }
    }
}

impl IdentityProvider for Ed25519LocalIdentityProvider {
    fn scheme_id(&self) -> u16 {
        SCHEME_ED25519
    }

    fn public_material(&self) -> Vec<u8> {
        self.signing_key.verifying_key().to_bytes().to_vec()
    }

    fn node_id(&self) -> NodeId {
        derive_node_id(self.scheme_id(), &self.public_material())
    }

    fn sign(&self, message: &[u8]) -> Result<Vec<u8>, String> {
        use ed25519_dalek::Signer;
        let sig = self.signing_key.sign(message);
        Ok(sig.to_bytes().to_vec())
    }
}
