use serde::{Serialize, Deserialize};
use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use crate::protocol::NodeId;

// =====================================================================
// POLICY & CRITICAL PEER TRUST ENGINE (Pillar 6)
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub enum TrustMode {
    Manual,  // Only connect to explicitly allowed NodeIds (Unknown goes to pending)
    Pinned,  // TOFU mode: connection requires explicit approval and pinning
    OpenDev, // Debug mode: accept handshakes from any valid signature automatically
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Admission {
    Allowed,
    Denied,
    Pending,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TrustPolicyConfig {
    pub mode: String,                          // "manual", "pinned", "open_dev"
    pub trusted_nodes: HashMap<String, bool>,  // Hex NodeId -> bool
    pub pending_nodes: Vec<String>,            // Hex NodeId
}

pub struct TrustPolicyEngine {
    pub path: PathBuf,
    pub mode: TrustMode,
    pub allowlist: HashMap<NodeId, bool>,
    pub pendinglist: HashMap<NodeId, bool>,
}

fn format_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect::<Vec<String>>().join("")
}

fn parse_hex(hex_str: &str) -> Option<[u8; 32]> {
    let bytes = hex::decode(hex_str).ok()?;
    if bytes.len() == 32 {
        let mut arr = [0u8; 32];
        arr.copy_from_slice(&bytes);
        Some(arr)
    } else {
        None
    }
}

impl TrustPolicyEngine {
    pub fn load_or_create(path: PathBuf) -> Self {
        let mut engine = Self {
            path: path.clone(),
            mode: TrustMode::Pinned, // Default to Pinned (TOFU with manual approval)
            allowlist: HashMap::new(),
            pendinglist: HashMap::new(),
        };

        if path.exists() {
            if let Ok(content) = fs::read_to_string(&path) {
                if let Ok(config) = serde_json::from_str::<TrustPolicyConfig>(&content) {
                    engine.mode = match config.mode.as_str() {
                        "manual" => TrustMode::Manual,
                        "pinned" => TrustMode::Pinned,
                        "open_dev" => TrustMode::OpenDev,
                        _ => TrustMode::Pinned,
                    };
                    for (hex_id, allowed) in config.trusted_nodes {
                        if let Some(node_id) = parse_hex(&hex_id) {
                            engine.allowlist.insert(node_id, allowed);
                        }
                    }
                    for hex_id in config.pending_nodes {
                        if let Some(node_id) = parse_hex(&hex_id) {
                            engine.pendinglist.insert(node_id, true);
                        }
                    }
                }
            }
        } else {
            engine.save();
        }

        engine
    }

    pub fn save(&self) {
        let mode_str = match self.mode {
            TrustMode::Manual => "manual",
            TrustMode::Pinned => "pinned",
            TrustMode::OpenDev => "open_dev",
        };

        let mut trusted_nodes = HashMap::new();
        for (node_id, allowed) in &self.allowlist {
            trusted_nodes.insert(format_hex(node_id), *allowed);
        }

        let mut pending_nodes = Vec::new();
        for node_id in self.pendinglist.keys() {
            pending_nodes.push(format_hex(node_id));
        }

        let config = TrustPolicyConfig {
            mode: mode_str.to_string(),
            trusted_nodes,
            pending_nodes,
        };

        // CRITICAL PERSISTENCE FIX: Ensure parent directory is created before writing!
        if let Some(parent) = self.path.parent() {
            let _ = fs::create_dir_all(parent);
        }

        if let Ok(content) = serde_json::to_string_pretty(&config) {
            let _ = fs::write(&self.path, content);
        }
    }

    pub fn set_mode(&mut self, mode: TrustMode) {
        self.mode = mode;
        self.save();
    }

    pub fn allow_node(&mut self, node_id: NodeId) {
        self.allowlist.insert(node_id, true);
        self.pendinglist.remove(&node_id);
        self.save();
    }

    pub fn deny_node(&mut self, node_id: NodeId) {
        self.allowlist.insert(node_id, false);
        self.pendinglist.remove(&node_id);
        self.save();
    }

    pub fn remove_node(&mut self, node_id: NodeId) {
        self.allowlist.remove(&node_id);
        self.pendinglist.remove(&node_id);
        self.save();
    }

    /// Core policy check: evaluate the admission of a NodeId under the active TrustMode
    pub fn check_admission(&mut self, node_id: NodeId) -> Admission {
        match self.mode {
            TrustMode::OpenDev => Admission::Allowed,
            TrustMode::Pinned | TrustMode::Manual => {
                if let Some(allowed) = self.allowlist.get(&node_id) {
                    if *allowed {
                        Admission::Allowed
                    } else {
                        Admission::Denied
                    }
                } else {
                    // Unknown peer! In Manual/Pinned mode, we put them to pending list
                    self.pendinglist.insert(node_id, true);
                    self.save();
                    Admission::Pending
                }
            }
        }
    }

    /// Helper to fetch allowlist and pending states as JSON
    pub fn get_policy_json(&self) -> serde_json::Value {
        let mode_str = match self.mode {
            TrustMode::Manual => "manual",
            TrustMode::Pinned => "pinned",
            TrustMode::OpenDev => "open_dev",
        };

        let mut trusted = Vec::new();
        for (node, allowed) in &self.allowlist {
            trusted.push(serde_json::json!({
                "node_id": format_hex(node),
                "allowed": *allowed
            }));
        }

        let mut pending = Vec::new();
        for node in self.pendinglist.keys() {
            pending.push(format_hex(node));
        }

        serde_json::json!({
            "mode": mode_str,
            "trusted": trusted,
            "pending": pending,
        })
    }
}

// =====================================================================
// SYSTEM-LEVEL TRUST POLICY ENGINE UNIT TEST
// =====================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;

    #[test]
    fn test_trust_policy_engine_flows() {
        let mut path = env::temp_dir();
        path.push("trust_policy_test.json");
        let _ = fs::remove_file(&path); // Ensure clean state

        // 1. Verify default load-or-create behavior
        let mut engine = TrustPolicyEngine::load_or_create(path.clone());
        assert_eq!(engine.mode, TrustMode::Pinned);

        // 2. Verify pending admission on unknown NodeId
        let dummy_node = [9u8; 32];
        let admission = engine.check_admission(dummy_node);
        assert_eq!(admission, Admission::Pending);
        assert!(engine.pendinglist.contains_key(&dummy_node));

        // 3. Verify allow-node manual pairing approval
        engine.allow_node(dummy_node);
        let admission_after_allow = engine.check_admission(dummy_node);
        assert_eq!(admission_after_allow, Admission::Allowed);
        assert!(!engine.pendinglist.contains_key(&dummy_node));

        // 4. Verify deny-node behavior
        engine.deny_node(dummy_node);
        let admission_after_deny = engine.check_admission(dummy_node);
        assert_eq!(admission_after_deny, Admission::Denied);

        // 5. Clean up temporary test file
        let _ = fs::remove_file(&path);
    }
}
