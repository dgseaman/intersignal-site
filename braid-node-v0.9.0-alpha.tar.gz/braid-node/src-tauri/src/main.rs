#![cfg_attr(
  all(not(debug_assertions), target_os = "windows"),
  windows_subsystem = "windows"
)]

mod protocol;
mod identity;
mod presence;
mod session;
mod route;
mod relay;
mod rendezvous;
mod trust;
mod tendril;
mod transport;
mod web;
mod peer_config;
mod nat;
mod adapter;

use protocol::{
    BraidEnvelope, BraidStateDrift, BraidDiscoveryBeacon, BraidLinkProbe, BraidLinkProbeAck,
    BraidStateDriftQuant, BraidTransport, BraidEndpoint, MSG_STATE_DRIFT, MSG_DISCOVERY_BEACON,
    MSG_DISCOVERY_ACK, MSG_PEER_GOODBYE, MSG_LINK_PROBE, MSG_LINK_PROBE_ACK, MSG_SESSION_HELLO,
    MSG_SESSION_CHALLENGE, MSG_SESSION_RESPONSE, MSG_SESSION_READY,
    EXPECTED_VECTOR_DIM, WIRE_PROTOCOL_VERSION, MAX_PACKET_SIZE, CAP_STATE_DRIFT, CAP_DISCOVERY,
    CAP_UDP_TRANSPORT, CAP_VECTOR_384_F32, CAP_VECTOR_QINT8, SCHEME_ED25519, VECTOR_ENCODING_RAW_F32,
    VECTOR_ENCODING_QINT8, NodeId, IdentityProvider, CAP_RELAY_FORWARD, CAP_RELAY_SEND, MSG_RELAY_FORWARD
};
use sha2::Digest;
use identity::{NodeIdentity, Ed25519LocalIdentityProvider};
use presence::PresenceRecord;
use session::{BraidSession, SessionState, SessionHello, SessionChallenge, SessionResponse, SessionReady};
use route::{RouteCandidate, RouteEndpoint, TransportKind, RouteState, RouteSource, PeerStatus, PeerRecord};
use relay::RelayFrame;
use trust::{TrustPolicyEngine, TrustMode, Admission};
use transport::UdpTransport;
use nat::{PublicEndpointResult, NatReachability, ReachabilityReport};

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use tokio::net::UdpSocket;
use tokio::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH, Duration, Instant};
use serde::{Serialize, Deserialize};
use tauri::Manager; // Critical v1.x import to resolve emit_all & manage traits!
use rand::Rng;

pub const NODE_SOFTWARE_VERSION: &str = "0.9.0-alpha"; // Tendril Kernel v0.9.0-alpha

pub const MAX_PEERS: usize = 128; // Spam/sybil overflow protection limit
pub const MAX_REPLAY_LEDGER_ENTRIES: usize = 4096; // Bounded replay ledger size limit
pub const ACK_RATE_LIMIT_MS: u64 = 10_000; // Only reply to discovery beacons once every 10s per peer

fn format_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect::<Vec<String>>().join("")
}

// Global visualizer state helper
pub fn main_status_stale() -> route::PeerStatus {
    route::PeerStatus::Stale
}

// =====================================================================
// TAURI SHARED STATE (wrapped in Arc for multi-daemon access)
// =====================================================================

pub struct AppState {
    pub transport: Arc<dyn BraidTransport>, // Dynamic Trait Object (Pillar 2)
    pub identity_provider: Arc<dyn IdentityProvider>,
    pub node_id: NodeId,
    pub session_id: [u8; 16],
    pub sequence_counter: Arc<AtomicU64>,
    pub peer_table: Arc<Mutex<HashMap<NodeId, route::PeerRecord>>>,
    pub session_table: Arc<Mutex<HashMap<NodeId, BraidSession>>>, // Handshake session table (v0.8.1)
    pub route_table: Arc<Mutex<HashMap<NodeId, Vec<RouteCandidate>>>>, // Multi-path routing table (v0.8.1)
    pub trust_policy: Arc<Mutex<TrustPolicyEngine>>, // Policy allowlist (v0.8.1)
    pub replay_ledger: Arc<Mutex<HashMap::<(NodeId, [u8; 16], u16), u64>>>,
    pub last_sent_acks: Arc<Mutex<HashMap<NodeId, u64>>>,
    pub local_port: u16,
    pub latest_received_vector: Arc<Mutex<Vec<f32>>>, 
    pub peers: Arc<Mutex<Vec<String>>>,
    pub seed_peers: Vec<SocketAddr>,
    pub probe_rate_limiter: Arc<Mutex<HashMap<String, u64>>>,
    pub global_probe_timestamps: Arc<Mutex<Vec<u64>>>,
    pub failed_probe_retries: Arc<Mutex<HashMap<String, u32>>>,
    pub last_stun_check: Arc<Mutex<Option<u64>>>,
    pub direct_udp_rate_limiter: Arc<Mutex<HashMap<String, u64>>>,
    pub last_reachability_report: Arc<Mutex<Option<nat::ReachabilityReport>>>, 
    pub global_action_timestamps: Arc<Mutex<Vec<u64>>>,
    pub adapter_manager: Arc<adapter::AdapterManager>,
    pub peer_telemetry: Arc<Mutex<HashMap<NodeId, (String, Option<String>)>>>,
    pub last_received_object: Arc<Mutex<Option<protocol::BraidStateObjectView>>>,
}

fn preflight_sanitize_packet(bytes: &[u8]) -> bool {
    if bytes.len() < 98 || bytes.len() > 2048 {
        return false;
    }

    // Read public_material length (offset 42, 8 bytes, little-endian)
    let mut len_bytes = [0u8; 8];
    len_bytes.copy_from_slice(&bytes[42..50]);
    let pub_len = u64::from_le_bytes(len_bytes) as usize;
    if pub_len > 2048 || 50 + pub_len > bytes.len() {
        return false;
    }

    // Offset after public_material
    let offset_after_pub = 50 + pub_len;
    // Next is session_id (16), sequence (8), timestamp (8)
    let offset_sig_len = offset_after_pub + 16 + 8 + 8;
    if offset_sig_len + 8 > bytes.len() {
        return false;
    }

    // Read signature length
    len_bytes.copy_from_slice(&bytes[offset_sig_len..offset_sig_len+8]);
    let sig_len = u64::from_le_bytes(len_bytes) as usize;
    if sig_len > 1024 || offset_sig_len + 8 + sig_len > bytes.len() {
        return false;
    }

    // Offset after signature
    let offset_payload_len = offset_sig_len + 8 + sig_len;
    if offset_payload_len + 8 > bytes.len() {
        return false;
    }

    // Read payload length
    len_bytes.copy_from_slice(&bytes[offset_payload_len..offset_payload_len+8]);
    let payload_len = u64::from_le_bytes(len_bytes) as usize;
    if payload_len > 2048 || offset_payload_len + 8 + payload_len != bytes.len() {
        return false;
    }

    true
}

// =====================================================================
// PEER DISCOVERY VALIDATOR
// =====================================================================


fn validate_beacon(
    envelope: &BraidEnvelope,
    beacon: &BraidDiscoveryBeacon,
) -> Result<(), String> {
    if beacon.session_id != envelope.session_id {
        return Err("Beacon session_id does not match envelope session_id".into());
    }

    if beacon.vector_dim as usize != EXPECTED_VECTOR_DIM {
        return Err(format!("Unsupported vector dimension: {}", beacon.vector_dim));
    }

    if (beacon.max_packet_size as usize) < 380 {
        return Err("Peer max_packet_size too small for quantized vector state".into());
    }

    // Require CAP_DISCOVERY | CAP_UDP_TRANSPORT
    let required = CAP_DISCOVERY | CAP_UDP_TRANSPORT;
    if beacon.capabilities & required != required {
        return Err("Peer lacks required discovery or UDP transport capabilities".into());
    }

    if beacon.ttl_ms < 5_000 || beacon.ttl_ms > 60_000 {
        return Err("Beacon TTL outside accepted protocol range (5s - 60s)".into());
    }

    Ok(())
}

// =====================================================================
// UNIFIED REPLAY LEDGER VALIDATION HELPER
// =====================================================================

async fn check_and_commit_replay(
    ledger: &Mutex<HashMap<(NodeId, [u8; 16], u16), u64>>,
    node_id: NodeId,
    session_id: [u8; 16],
    message_type: u16,
    sequence: u64,
    src: SocketAddr,
) -> Result<(), String> {
    let mut guard = ledger.lock().await;
    let key = (node_id, session_id, message_type);
    
    if guard.len() >= MAX_REPLAY_LEDGER_ENTRIES && !guard.contains_key(&key) {
        return Err(format!("[DROP] Replay ledger full; rejecting new session from {}", src));
    }
    
    if let Some(highest_seq) = guard.get(&key) {
        if sequence <= *highest_seq {
            return Err(format!(
                "[DROP] Replay threat detected: sequence {} <= highest seen ({})",
                sequence, highest_seq
            ));
        }
    }
    
    guard.insert(key, sequence);
    Ok(())
}

// =====================================================================
// TAURI COMMANDS
// =====================================================================

#[tauri::command]
async fn get_trust_policy(state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let policy = state.trust_policy.lock().await;
    Ok(policy.get_policy_json())
}

#[tauri::command]
async fn approve_peer_trust(node_id_hex: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let bytes = hex::decode(&node_id_hex).map_err(|e| format!("{:?}", e))?;
    if bytes.len() != 32 {
        return Err("Invalid Node ID length".to_string());
    }
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&bytes);
    policy.allow_node(node_id);
    Ok(serde_json::json!({ "status": "success", "approved": node_id_hex }))
}

#[tauri::command]
async fn deny_peer_trust(node_id_hex: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let bytes = hex::decode(&node_id_hex).map_err(|e| format!("{:?}", e))?;
    if bytes.len() != 32 {
        return Err("Invalid Node ID length".to_string());
    }
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&bytes);
    policy.deny_node(node_id);
    Ok(serde_json::json!({ "status": "success", "denied": node_id_hex }))
}

#[tauri::command]
async fn remove_peer_trust(node_id_hex: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let bytes = hex::decode(&node_id_hex).map_err(|e| format!("{:?}", e))?;
    if bytes.len() != 32 {
        return Err("Invalid Node ID length".to_string());
    }
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&bytes);
    policy.remove_node(node_id);
    Ok(serde_json::json!({ "status": "success", "removed": node_id_hex }))
}

#[tauri::command]
async fn set_trust_mode(mode: String, state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    let mut policy = state.trust_policy.lock().await;
    let new_mode = match mode.as_str() {
        "manual" => TrustMode::Manual,
        "pinned" => TrustMode::Pinned,
        "open_dev" => TrustMode::OpenDev,
        _ => return Err("Invalid trust mode".to_string()),
    };
    policy.set_mode(new_mode);
    Ok(serde_json::json!({ "status": "success", "mode": mode }))
}

#[tauri::command]
async fn get_node_info(state: tauri::State<'_, Arc<AppState>>) -> Result<serde_json::Value, String> {
    Ok(serde_json::json!({
        "node_id": format_hex(&state.node_id),
        "local_address": format!("0.0.0.0:{}", state.local_port),
        "software_version": NODE_SOFTWARE_VERSION,
        "wire_version": WIRE_PROTOCOL_VERSION,
    }))
}

#[tauri::command]
async fn get_peers(state: tauri::State<'_, Arc<AppState>>) -> Result<Vec<String>, String> {
    let peer_table = state.peer_table.lock().await;
    let list = peer_table.values()
        .filter(|record| record.status != route::PeerStatus::Stale)
        .map(|record| record.observed_addr.to_string())
        .collect::<Vec<String>>();
    Ok(list)
}

#[tauri::command]
async fn stream_state_drift(
    latent_vector: Vec<f32>,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<serde_json::Value, String> {
    if latent_vector.is_empty() {
        return Err("Latent vector cannot be empty".to_string());
    }

    if latent_vector.len() != EXPECTED_VECTOR_DIM {
        return Err(format!("Vector dimension must be exactly {}", EXPECTED_VECTOR_DIM));
    }

    if latent_vector.iter().any(|v| !v.is_finite()) {
        return Err("Latent vector contains NaN or Infinity".to_string());
    }

    // Clone target peer records first, then drop lock to avoid holding across await
    let peers_to_send = {
        let peer_table = state.peer_table.lock().await;
        peer_table.values()
            .filter(|r| r.status == route::PeerStatus::Active || r.status == route::PeerStatus::Verified)
            .cloned()
            .collect::<Vec<route::PeerRecord>>()
    };

    let mut sent_count = 0;
    let mut failures = Vec::new();

    for peer in peers_to_send {
        let sequence = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_err(|e| format!("{:?}", e))?
            .as_millis() as u64;

        let actual_encoding = peer.preferred_vector_encoding;
        let coordinate_bytes = if actual_encoding == VECTOR_ENCODING_QINT8 {
            let quant = BraidStateDriftQuant::quantize(&latent_vector);
            bincode::serialize(&quant).map_err(|e| format!("{:?}", e))?
        } else {
            let drift = BraidStateDrift { latent_vector: latent_vector.clone() };
            bincode::serialize(&drift).map_err(|e| format!("{:?}", e))?
        };

        let mut hasher = sha2::Sha256::new();
        hasher.update(&coordinate_bytes);
        let payload_hash_sha256: [u8; 32] = hasher.finalize().into();

        let mut state_obj = protocol::BraidStateObject {
            object_version: 1,
            source_node_id: state.identity_provider.node_id(),
            created_at_unix_ms: timestamp,
            adapter_id: "text_projection".to_string(),
            vector_dimension: EXPECTED_VECTOR_DIM as u16,
            vector_encoding: actual_encoding,
            route_id: [1u8; 16],
            replay_sequence: sequence,
            payload_hash_sha256,
            coordinate_bytes,
            signature_scheme: state.identity_provider.scheme_id(),
            signature: vec![],
        };

        state_obj.sign_object(state.identity_provider.as_ref()).map_err(|e| format!("{:?}", e))?;

        let payload = bincode::serialize(&state_obj).map_err(|e| format!("{:?}", e))?;

        let result = tendril::send_to_node(
            peer.node_id,
            MSG_STATE_DRIFT,
            payload,
            actual_encoding,
            state.session_id,
            sequence,
            timestamp,
            state.session_table.as_ref(),
            state.route_table.as_ref(),
            state.identity_provider.as_ref(),
            state.transport.as_ref(),
        ).await;

        match result {
            Ok(_) => {
                sent_count += 1;
            }
            Err(e) => {
                failures.push(format!("{}: {:?}", peer.observed_addr, e));
            }
        }
    }

    Ok(serde_json::json!({
        "sent_count": sent_count,
        "failures": failures,
    }))
}

// =====================================================================
// NEW PEER CONFIG, TEST VECTORS, PROBING AND REACHABILITY (v0.9.0)
// =====================================================================

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct PeerAddResult {
    pub accepted: bool,
    pub label: String,
    pub endpoint: String,
    pub route_state: String,
    pub trust_state: String,
    pub message: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct ProbeResult {
    pub endpoint: String,
    pub sent: bool,
    pub packet_size: usize,
    pub elapsed_ms: Option<u64>,
    pub response_received: bool,
    pub route_state: String,
    pub session_state: String,
    pub error: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct RouteView {
    pub peer_node_id: String,
    pub endpoint: String,
    pub route_kind: String,
    pub route_state: String,
    pub verified: bool,
    pub last_seen_ms_ago: Option<u64>,
    pub latency_ms: Option<u64>,
    pub preferred_vector_encoding: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SessionView {
    pub peer_node_id: String,
    pub session_id: String,
    pub state: String,
    pub established_ms_ago: Option<u64>,
    pub capabilities: Vec<String>,
    pub ready_for_state_drift: bool,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TestVectorResult {
    pub dimension: usize,
    pub vector: Vec<f32>,
    pub sha256: String,
    pub min: f32,
    pub max: f32,
    pub mean: f32,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SendVectorResult {
    pub route_kind: String,
    pub direct_attempted: bool,
    pub relay_fallback_used: bool,
    pub encoding: String,
    pub dimension: usize,
    pub packet_size: usize,
    pub vector_sha256: String,
    pub sent_count: usize,
    pub skipped: Vec<SkippedPeerReason>,
    pub target_endpoint: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct DirectUdpAttemptResult {
    pub attempted: bool,
    pub peer_endpoint: String,
    pub packets_sent: usize,
    pub response_received: bool,
    pub route_verified: bool,
    pub session_ready: bool,
    pub elapsed_ms: u64,
    pub failure_reason: Option<String>,
    pub next_recommended_action: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct RouteChoiceResult {
    pub peer_node_id: String,
    pub selected_route_kind: String,
    pub selected_endpoint: String,
    pub direct_available: bool,
    pub relay_available: bool,
    pub reason: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct VectorReceiptEvent {
    pub from_node_id: String,
    pub session_id: String,
    pub route_kind: String,
    pub encoding: String,
    pub dimension: usize,
    pub vector_sha256: String,
    pub packet_size: usize,
    pub received_at_ms: u64,
    pub relay_used: bool,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SkippedPeerReason {
    pub peer_node_id: String,
    pub reason: String,
    pub route_state: Option<String>,
    pub session_state: Option<String>,
    pub trust_state: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct StreamResult {
    pub sent_count: usize,
    pub skipped: Vec<SkippedPeerReason>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct NetworkStatus {
    pub local_bind_addr: String,
    pub local_udp_port: u16,
    pub public_endpoint: Option<String>,
    pub nat_status: String,
    pub direct_wan_supported: String,
    pub relay_available: bool,
}

async fn evaluate_skipped_peer(
    peer_node_id: NodeId,
    state: &AppState,
    encoding_pref: u16,
) -> Option<SkippedPeerReason> {
    let peer_hex = format_hex(&peer_node_id);

    let mut policy = state.trust_policy.lock().await;
    let admission = policy.check_admission(peer_node_id);
    let trust_state_str = format!("{:?}", admission);
    if admission == Admission::Denied {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: "trust policy denied".to_string(),
            route_state: None,
            session_state: None,
            trust_state: Some(trust_state_str),
        });
    } else if admission == Admission::Pending {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: "trust policy pending".to_string(),
            route_state: None,
            session_state: None,
            trust_state: Some(trust_state_str),
        });
    }

    let session_table = state.session_table.lock().await;
    let (has_session, session_ready, session_state_str) = if let Some(session) = session_table.get(&peer_node_id) {
        (true, session.state == SessionState::Ready, format!("{:?}", session.state))
    } else {
        (false, false, "None".to_string())
    };

    if !has_session {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: "no ready session".to_string(),
            route_state: None,
            session_state: Some("None".to_string()),
            trust_state: Some(trust_state_str),
        });
    } else if !session_ready {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: "session not ready".to_string(),
            route_state: None,
            session_state: Some(session_state_str),
            trust_state: Some(trust_state_str),
        });
    }

    let route_table = state.route_table.lock().await;
    let candidates = route_table.get(&peer_node_id);
    if candidates.is_none() || candidates.unwrap().is_empty() {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: "no verified route".to_string(),
            route_state: Some("None".to_string()),
            session_state: Some(session_state_str),
            trust_state: Some(trust_state_str),
        });
    }

    let candidates_ref = candidates.unwrap();
    let best_route = candidates_ref.iter()
        .filter(|r| r.state == RouteState::Verified)
        .next();

    if best_route.is_none() {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: "no verified route".to_string(),
            route_state: Some("NoVerifiedCandidate".to_string()),
            session_state: Some(session_state_str),
            trust_state: Some(trust_state_str),
        });
    }

    let route = best_route.unwrap();
    let route_state_str = format!("{:?}", route.state);

    let peer_table = state.peer_table.lock().await;
    if let Some(peer_rec) = peer_table.get(&peer_node_id) {
        if peer_rec.capabilities & CAP_STATE_DRIFT == 0 {
            return Some(SkippedPeerReason {
                peer_node_id: peer_hex,
                reason: "peer lacks state-drift capability".to_string(),
                route_state: Some(route_state_str),
                session_state: Some(session_state_str),
                trust_state: Some(trust_state_str),
            });
        }
    }

    if encoding_pref != VECTOR_ENCODING_RAW_F32 && encoding_pref != VECTOR_ENCODING_QINT8 {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: "unsupported vector encoding".to_string(),
            route_state: Some(route_state_str),
            session_state: Some(session_state_str),
            trust_state: Some(trust_state_str),
        });
    }

    // Create actual dummy payload and envelope to measure exact size (P1 Hardening)
    let dummy_vector = vec![0.0f32; 384];
    let payload_bytes = if encoding_pref == VECTOR_ENCODING_QINT8 {
        let quant = BraidStateDriftQuant::quantize(&dummy_vector);
        bincode::serialize(&quant).unwrap_or_default()
    } else {
        let drift = BraidStateDrift { latent_vector: dummy_vector };
        bincode::serialize(&drift).unwrap_or_default()
    };

    let inner_envelope_res = BraidEnvelope::create(
        MSG_STATE_DRIFT,
        encoding_pref,
        state.session_id,
        0, // dummy sequence
        0, // dummy timestamp
        payload_bytes,
        state.identity_provider.as_ref(),
    );

    let inner_envelope = match inner_envelope_res {
        Ok(env) => env,
        Err(_) => {
            return Some(SkippedPeerReason {
                peer_node_id: peer_hex,
                reason: "failed to construct test envelope".to_string(),
                route_state: Some(route_state_str),
                session_state: Some(session_state_str),
                trust_state: Some(trust_state_str),
            });
        }
    };

    let serialized_inner = bincode::serialize(&inner_envelope).unwrap_or_default();
    let actual_envelope_size = serialized_inner.len();

    let actual_packet_size = if matches!(&route.endpoint, RouteEndpoint::Relay { .. }) {
        if let RouteEndpoint::Relay { relay_node_id, .. } = &route.endpoint {
            if !route_table.contains_key(relay_node_id) {
                return Some(SkippedPeerReason {
                    peer_node_id: peer_hex,
                    reason: "relay required but unavailable".to_string(),
                    route_state: Some(route_state_str),
                    session_state: Some(session_state_str),
                    trust_state: Some(trust_state_str),
                });
            }
        }

        // Build outer relay frame to find exact outer size
        let relay_frame = crate::relay::RelayFrame {
            origin_sender: state.identity_provider.node_id(),
            final_recipient: peer_node_id,
            route_id: route.route_id,
            inner_message_type: MSG_STATE_DRIFT,
            inner_vector_encoding: encoding_pref,
            created_at_ms: 0,
            expires_at_ms: 0,
            inner_envelope_bytes: serialized_inner,
        };

        let relay_payload = bincode::serialize(&relay_frame).unwrap_or_default();

        let relay_envelope_res = BraidEnvelope::create(
            crate::protocol::MSG_RELAY_FORWARD,
            0,
            state.session_id,
            0,
            0,
            relay_payload,
            state.identity_provider.as_ref(),
        );

        let relay_envelope = match relay_envelope_res {
            Ok(env) => env,
            Err(_) => {
                return Some(SkippedPeerReason {
                    peer_node_id: peer_hex,
                    reason: "failed to construct outer relay envelope".to_string(),
                    route_state: Some(route_state_str),
                    session_state: Some(session_state_str),
                    trust_state: Some(trust_state_str),
                });
            }
        };

        bincode::serialize(&relay_envelope).unwrap_or_default().len()
    } else {
        actual_envelope_size
    };

    if actual_packet_size > MAX_PACKET_SIZE {
        return Some(SkippedPeerReason {
            peer_node_id: peer_hex,
            reason: format!("envelope size {} exceeds MTU limit {}", actual_packet_size, MAX_PACKET_SIZE),
            route_state: Some(route_state_str),
            session_state: Some(session_state_str),
            trust_state: Some(trust_state_str),
        });
    }

    None
}

#[tauri::command]
async fn add_manual_peer(
    label: String,
    endpoint: String,
    node_id: Option<String>,
    trust_mode: String,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<PeerAddResult, String> {
    let parsed_endpoint = endpoint.parse::<SocketAddr>().map_err(|e| format!("{:?}", e))?;

    // Strictly parse and validate trust_mode
    let seed_trust_mode = match trust_mode.as_str() {
        "ManualTrusted" => peer_config::SeedTrustMode::ManualTrusted,
        "PendingTrust" => peer_config::SeedTrustMode::PendingTrust,
        "DiscoveryOnly" => peer_config::SeedTrustMode::DiscoveryOnly,
        _ => return Err("Invalid trust mode. Allowed: ManualTrusted, PendingTrust, DiscoveryOnly".to_string()),
    };

    let target_node_id = if let Some(ref hex_str) = node_id {
        let bytes = hex::decode(hex_str).map_err(|e| format!("{:?}", e))?;
        if bytes.len() != 32 {
            return Err("Node ID must be 32 bytes".to_string());
        }
        let mut arr = [0u8; 32];
        arr.copy_from_slice(&bytes);
        arr
    } else {
        rand::random()
    };

    // Construct a PeerSeed and call PeerSeed::validate()
    let peer_seed = peer_config::PeerSeed {
        label: label.clone(),
        node_id: Some(target_node_id),
        endpoint: BraidEndpoint::Direct(parsed_endpoint),
        trust_mode: seed_trust_mode,
        enabled: true,
    };
    peer_seed.validate()?;

    // Duplicate route check with correct *sa dereference
    {
        let route_table = state.route_table.lock().await;
        for list in route_table.values() {
            for c in list {
                if let RouteEndpoint::Udp(sa) = &c.endpoint {
                    if *sa == parsed_endpoint {
                        return Err("Duplicate endpoint route entry".to_string());
                    }
                }
            }
        }
    }

    let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
    let candidate = RouteCandidate {
        route_id: rand::random(),
        target_node_id,
        transport: TransportKind::Udp,
        endpoint: RouteEndpoint::Udp(parsed_endpoint),
        source: RouteSource::Manual,
        verified_by_presence: false,
        verified_by_session: false,
        latency_ms: None,
        failure_count: 0,
        expires_at_ms: now_ms + 120_000,
        state: RouteState::Probing,
        preferred_vector_encoding: VECTOR_ENCODING_RAW_F32,
    };

    {
        let mut route_table = state.route_table.lock().await;
        route_table.entry(target_node_id).or_insert_with(Vec::new).push(candidate);
    }

    if trust_mode == "ManualTrusted" {
        let mut policy = state.trust_policy.lock().await;
        policy.allow_node(target_node_id);
    }

    // Trigger discovery ping
    let seq = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
    let discovery_payload = BraidDiscoveryBeacon {
        session_id: state.session_id,
        capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
        vector_dim: EXPECTED_VECTOR_DIM as u16,
        max_packet_size: MAX_PACKET_SIZE as u16,
        listen_port: state.local_port,
        ttl_ms: 15000,
    };

    let serialized_beacon = bincode::serialize(&discovery_payload).map_err(|e| format!("{:?}", e))?;
    let beacon_envelope = BraidEnvelope::create(
        MSG_DISCOVERY_BEACON,
        VECTOR_ENCODING_RAW_F32,
        state.session_id,
        seq,
        now_ms,
        serialized_beacon,
        state.identity_provider.as_ref(),
    ).map_err(|e| format!("{:?}", e))?;
    let ser_bytes = bincode::serialize(&beacon_envelope).map_err(|e| format!("{:?}", e))?;
    state.transport.send_to(&ser_bytes, BraidEndpoint::Direct(parsed_endpoint)).await.map_err(|e| format!("{:?}", e))?;

    {
        let mut peers = state.peers.lock().await;
        if !peers.contains(&endpoint) {
            peers.push(endpoint.clone());
        }
    }

    Ok(PeerAddResult {
        accepted: true,
        label,
        endpoint: parsed_endpoint.to_string(),
        route_state: "Probing".to_string(),
        trust_state: trust_mode,
        message: "Manual peer added and discovery ping sent successfully".to_string(),
    })
}

#[tauri::command]
async fn probe_peer(
    endpoint: String,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<ProbeResult, String> {
    let parsed_addr = endpoint.parse::<SocketAddr>().map_err(|e| format!("{:?}", e))?;

    if parsed_addr.port() == 0 {
        return Err("Port cannot be zero".to_string());
    }

    if parsed_addr.ip().is_unspecified() {
        return Err("Unspecified remote address is invalid".to_string());
    }

    let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

    // Probe rate limiting
    {
        let mut limits = state.probe_rate_limiter.lock().await;
        if let Some(&last_ms) = limits.get(&endpoint) {
            if now_ms.saturating_sub(last_ms) < 5_000 {
                return Err("Rate limit exceeded: Max 1 probe per endpoint per 5 seconds".to_string());
            }
        }
        limits.insert(endpoint.clone(), now_ms);
    }

    {
        let mut global_stamps = state.global_probe_timestamps.lock().await;
        global_stamps.retain(|&t| now_ms.saturating_sub(t) < 60_000);
        if global_stamps.len() >= 10 {
            return Err("Rate limit exceeded: Max 10 manual probes per minute globally".to_string());
        }
        global_stamps.push(now_ms);
    }

    {
        let mut retries = state.failed_probe_retries.lock().await;
        let count = retries.entry(endpoint.clone()).or_insert(0);
        if *count >= 3 {
            return Err("Too many failed retries. Please wait before retrying again (backoff active).".to_string());
        }
    }

    let seq = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
    let discovery_payload = BraidDiscoveryBeacon {
        session_id: state.session_id,
        capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
        vector_dim: EXPECTED_VECTOR_DIM as u16,
        max_packet_size: MAX_PACKET_SIZE as u16,
        listen_port: state.local_port,
        ttl_ms: 15000,
    };

    let mut sent = false;
    let mut packet_size = 0;
    let mut err_msg = None;

    if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
        if let Ok(beacon_envelope) = BraidEnvelope::create(
            MSG_DISCOVERY_BEACON,
            VECTOR_ENCODING_RAW_F32,
            state.session_id,
            seq,
            now_ms,
            serialized_beacon,
            state.identity_provider.as_ref(),
        ) {
            if let Ok(ser_bytes) = bincode::serialize(&beacon_envelope) {
                packet_size = ser_bytes.len();
                if packet_size > MAX_PACKET_SIZE {
                    return Err("Envelope exceeds MAX_PACKET_SIZE limit".to_string());
                }
                if let Ok(_) = state.transport.send_to(&ser_bytes, BraidEndpoint::Direct(parsed_addr)).await {
                    sent = true;
                } else {
                    err_msg = Some("Transport send_to failed".to_string());
                }
            } else {
                err_msg = Some("Envelope serialization failed".to_string());
            }
        } else {
            err_msg = Some("Envelope creation failed".to_string());
        }
    } else {
        err_msg = Some("Beacon payload serialization failed".to_string());
    }

    let mut response_received = false;
    let mut route_state_str = "Probing".to_string();
    let mut session_state_str = "Init".to_string();
    let start_wait = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
    let mut elapsed = None;

    if sent {
        for _ in 0..10 {
            tokio::time::sleep(tokio::time::Duration::from_millis(150)).await;
            let peer_table = state.peer_table.lock().await;
            if let Some(peer) = peer_table.values().find(|r| r.observed_addr == parsed_addr) {
                response_received = true;
                route_state_str = format!("{:?}", peer.status);
                let session_table = state.session_table.lock().await;
                if let Some(session) = session_table.get(&peer.node_id) {
                    session_state_str = format!("{:?}", session.state);
                }
                let cur_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                elapsed = Some(cur_ms.saturating_sub(start_wait));
                break;
            }
        }
    }

    if response_received {
        let mut retries = state.failed_probe_retries.lock().await;
        retries.insert(endpoint.clone(), 0);
    } else {
        let mut retries = state.failed_probe_retries.lock().await;
        let count = retries.entry(endpoint.clone()).or_insert(0);
        *count += 1;
    }

    Ok(ProbeResult {
        endpoint,
        sent,
        packet_size,
        elapsed_ms: elapsed,
        response_received,
        route_state: route_state_str,
        session_state: session_state_str,
        error: err_msg,
    })
}

#[tauri::command]
async fn list_routes(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<Vec<RouteView>, String> {
    let mut views = Vec::new();
    let route_table = state.route_table.lock().await;
    let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

    for (node_id, candidates) in route_table.iter() {
        for c in candidates {
            let endpoint_str = match &c.endpoint {
                RouteEndpoint::Udp(sa) => sa.to_string(),
                RouteEndpoint::Relay { ref target_endpoint, .. } => target_endpoint.clone(),
            };
            let route_kind = match c.transport {
                TransportKind::Udp => "direct",
                TransportKind::Relay => "relay",
            };
            let route_state = format!("{:?}", c.state);
            let verified = c.verified_by_session || c.verified_by_presence;

            let last_seen_ms_ago = if c.expires_at_ms > now_ms {
                Some(60_000 - (c.expires_at_ms.saturating_sub(now_ms).min(60_000)))
            } else {
                None
            };

            views.push(RouteView {
                peer_node_id: format_hex(node_id),
                endpoint: endpoint_str,
                route_kind: route_kind.to_string(),
                route_state,
                verified,
                last_seen_ms_ago,
                latency_ms: c.latency_ms,
                preferred_vector_encoding: if c.preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "qint8".to_string() } else { "raw_f32".to_string() },
            });
        }
    }

    let peer_table = state.peer_table.lock().await;
    for (node_id, record) in peer_table.iter() {
        let peer_hex = format_hex(node_id);
        if !views.iter().any(|v| v.peer_node_id == peer_hex) {
            let verified = record.status == PeerStatus::Verified;
            let last_seen_ms_ago = now_ms.saturating_sub(record.last_seen_ms);
            views.push(RouteView {
                peer_node_id: peer_hex,
                endpoint: record.observed_addr.to_string(),
                route_kind: "direct".to_string(),
                route_state: format!("{:?}", record.status),
                verified,
                last_seen_ms_ago: Some(last_seen_ms_ago),
                latency_ms: Some(record.round_trip_latency_ms),
                preferred_vector_encoding: if record.preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "qint8".to_string() } else { "raw_f32".to_string() },
            });
        }
    }

    Ok(views)
}

#[tauri::command]
async fn list_sessions(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<Vec<SessionView>, String> {
    let mut views = Vec::new();
    let session_table = state.session_table.lock().await;
    let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

    for (node_id, s) in session_table.iter() {
        let established_ms_ago = now_ms.saturating_sub(s.established_at_ms);
        let mut caps = Vec::new();
        if s.accepted_capabilities & CAP_STATE_DRIFT != 0 { caps.push("state-drift".to_string()); }
        if s.accepted_capabilities & CAP_DISCOVERY != 0 { caps.push("discovery".to_string()); }
        if s.accepted_capabilities & CAP_UDP_TRANSPORT != 0 { caps.push("udp".to_string()); }
        if s.accepted_capabilities & CAP_VECTOR_384_F32 != 0 { caps.push("384d-f32".to_string()); }
        if s.accepted_capabilities & CAP_VECTOR_QINT8 != 0 { caps.push("qint8".to_string()); }

        let ready = s.state == SessionState::Ready;

        views.push(SessionView {
            peer_node_id: format_hex(node_id),
            session_id: format_hex(&s.session_id),
            state: format!("{:?}", s.state),
            established_ms_ago: Some(established_ms_ago),
            capabilities: caps,
            ready_for_state_drift: ready,
        });
    }

    let peer_table = state.peer_table.lock().await;
    for (node_id, record) in peer_table.iter() {
        let peer_hex = format_hex(node_id);
        if !views.iter().any(|v| v.peer_node_id == peer_hex) {
            let mut caps = Vec::new();
            if record.capabilities & CAP_STATE_DRIFT != 0 { caps.push("state-drift".to_string()); }
            if record.capabilities & CAP_DISCOVERY != 0 { caps.push("discovery".to_string()); }
            if record.capabilities & CAP_UDP_TRANSPORT != 0 { caps.push("udp".to_string()); }
            if record.capabilities & CAP_VECTOR_384_F32 != 0 { caps.push("384d-f32".to_string()); }
            if record.capabilities & CAP_VECTOR_QINT8 != 0 { caps.push("qint8".to_string()); }

            let ready = record.status == PeerStatus::Verified || record.status == PeerStatus::Active;

            views.push(SessionView {
                peer_node_id: peer_hex,
                session_id: format_hex(&record.session_id),
                state: format!("{:?}", record.status),
                established_ms_ago: Some(now_ms.saturating_sub(record.last_seen_ms)),
                capabilities: caps,
                ready_for_state_drift: ready,
            });
        }
    }

    Ok(views)
}



#[tauri::command]
async fn get_last_received_object(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<Option<protocol::BraidStateObjectView>, String> {
    let opt = state.last_received_object.lock().await;
    Ok(opt.clone())
}

#[tauri::command]
async fn get_presence_roster(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<Vec<presence::PresenceRosterView>, String> {
    let peer_table = state.peer_table.lock().await;
    let telemetry = state.peer_telemetry.lock().await;
    let now_ms = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64;

    let mut roster = Vec::new();
    for (node_id, record) in peer_table.iter() {
        let node_id_hex = format_hex(node_id);
        let display_name = format!("Node-{}", &node_id_hex[0..8]);
        
        let elapsed = now_ms.saturating_sub(record.last_seen_ms);
        let presence_state = if elapsed >= presence::PRESENCE_OFFLINE_AFTER_MS {
            "Offline".to_string()
        } else if elapsed >= presence::PRESENCE_STALE_AFTER_MS {
            "Stale".to_string()
        } else {
            "Active".to_string()
        };

        let route_table = state.route_table.lock().await;
        let route_state = if let Some(candidates) = route_table.get(node_id) {
            if candidates.iter().any(|c| c.state == route::RouteState::Verified && matches!(c.endpoint, route::RouteEndpoint::Udp(_))) {
                "direct".to_string()
            } else if candidates.iter().any(|c| c.state == route::RouteState::Verified && matches!(c.endpoint, route::RouteEndpoint::Relay { .. })) {
                "relay".to_string()
            } else if candidates.iter().any(|c| c.state == route::RouteState::Probing) {
                "probing".to_string()
            } else {
                "failed".to_string()
            }
        } else {
            "unknown".to_string()
        };

        let (adapter, last_event) = telemetry.get(node_id)
            .cloned()
            .unwrap_or_else(|| ("text_projection".to_string(), None));

        roster.push(presence::PresenceRosterView {
            node_id_hex,
            display_name,
            presence_state,
            route_state,
            nat_classification: "NAT-Restricted".to_string(),
            latency_ms: if record.round_trip_latency_ms > 0 { Some(record.round_trip_latency_ms) } else { None },
            last_seen_ms_ago: elapsed,
            active_adapter: adapter,
            last_payload_event: last_event,
        });
    }

    Ok(roster)
}

#[tauri::command]
async fn list_adapters(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<Vec<adapter::AdapterDescriptor>, String> {
    Ok(state.adapter_manager.list())
}

#[tauri::command]
async fn generate_test_vector(
    seed: Option<String>,
    adapter_id: Option<String>,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<TestVectorResult, String> {
    let raw_seed = seed.unwrap_or_else(|| "default-braid-seed-12345".to_string());
    
    let adapter_kind = if let Some(ref aid) = adapter_id {
        state.adapter_manager.parse_kind(aid)?
    } else {
        adapter::AdapterType::TextProjection
    };
    
    let adapter = state.adapter_manager.get(adapter_kind)
        .ok_or_else(|| "Adapter not found".to_string())?;
        
    let vector = adapter.distill(&raw_seed)?;
    
    let mut min = f32::MAX;
    let mut max = f32::MIN;
    let mut sum = 0.0f64;
    for &val in &vector {
        if val < min { min = val; }
        if val > max { max = val; }
        sum += val as f64;
    }
    let mean = (sum / vector.len() as f64) as f32;

    let mut v_hasher = sha2::Sha256::new();
    for &val in &vector {
        v_hasher.update(&val.to_le_bytes());
    }
    let sha256 = format_hex(&v_hasher.finalize());

    Ok(TestVectorResult {
        dimension: vector.len(),
        vector,
        sha256,
        min,
        max,
        mean,
    })
}

#[tauri::command]
async fn send_test_vector(
    target_node_id: Option<String>,
    encoding_preference: Option<String>,
    seed: Option<String>,
    adapter_id: Option<String>,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<SendVectorResult, String> {
    register_global_action(&state).await?;

    let test_vector = match generate_test_vector(seed.clone(), adapter_id.clone(), state.clone()).await {
        Ok(res) => res,
        Err(e) => return Err(e),
    };

    let target_node_arr = if let Some(ref hex_str) = target_node_id {
        let bytes = hex::decode(hex_str).map_err(|e| format!("{:?}", e))?;
        if bytes.len() != 32 {
            return Err("Node ID must be 32 bytes".to_string());
        }
        let mut arr = [0u8; 32];
        arr.copy_from_slice(&bytes);
        arr
    } else {
        let peer_table = state.peer_table.lock().await;
        if let Some(first_node) = peer_table.keys().next() {
            *first_node
        } else {
            return Ok(SendVectorResult {
                route_kind: "none".to_string(),
                direct_attempted: false,
                relay_fallback_used: false,
                encoding: encoding_preference.unwrap_or_else(|| "raw_f32".to_string()),
                dimension: 384,
                packet_size: 0,
                vector_sha256: test_vector.sha256,
                sent_count: 0,
                skipped: vec![SkippedPeerReason {
                    peer_node_id: "".to_string(),
                    reason: "No peers available in peer table".to_string(),
                    route_state: None,
                    session_state: None,
                    trust_state: None,
                }],
                target_endpoint: "none".to_string(),
            });
        }
    };

    let pref_encoding_u16 = if let Some(ref pref) = encoding_preference {
        if pref == "qint8" { VECTOR_ENCODING_QINT8 } else { VECTOR_ENCODING_RAW_F32 }
    } else {
        VECTOR_ENCODING_RAW_F32
    };

    if let Some(skip_reason) = evaluate_skipped_peer(target_node_arr, &state, pref_encoding_u16).await {
        return Ok(SendVectorResult {
            route_kind: "none".to_string(),
            direct_attempted: false,
            relay_fallback_used: false,
            encoding: encoding_preference.unwrap_or_else(|| "raw_f32".to_string()),
            dimension: 384,
            packet_size: 0,
            vector_sha256: test_vector.sha256,
            sent_count: 0,
            skipped: vec![skip_reason],
            target_endpoint: "none".to_string(),
        });
    }

    let route_choice = choose_best_route_for_peer_internal(target_node_arr, &state).await?;

    if route_choice.selected_route_kind == "none" {
        return Ok(SendVectorResult {
            route_kind: "none".to_string(),
            direct_attempted: false,
            relay_fallback_used: false,
            encoding: encoding_preference.unwrap_or_else(|| "raw_f32".to_string()),
            dimension: 384,
            packet_size: 0,
            vector_sha256: test_vector.sha256,
            sent_count: 0,
            skipped: vec![SkippedPeerReason {
                peer_node_id: format_hex(&target_node_arr),
                reason: "no verified route".to_string(),
                route_state: Some("NoVerifiedCandidate".to_string()),
                session_state: None,
                trust_state: None,
            }],
            target_endpoint: "none".to_string(),
        });
    }

    let actual_encoding_u16 = if route_choice.selected_route_kind == "relay" && encoding_preference.is_none() {
        VECTOR_ENCODING_QINT8
    } else {
        pref_encoding_u16
    };

    let sequence = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| format!("{:?}", e))?
        .as_millis() as u64;

    let coordinate_bytes = if actual_encoding_u16 == VECTOR_ENCODING_QINT8 {
        let quant = BraidStateDriftQuant::quantize(&test_vector.vector);
        bincode::serialize(&quant).map_err(|e| format!("{:?}", e))?
    } else {
        let drift = BraidStateDrift { latent_vector: test_vector.vector.clone() };
        bincode::serialize(&drift).map_err(|e| format!("{:?}", e))?
    };

    let mut hasher = sha2::Sha256::new();
    hasher.update(&coordinate_bytes);
    let payload_hash_sha256: [u8; 32] = hasher.finalize().into();

    let mut state_obj = protocol::BraidStateObject {
        object_version: 1,
        source_node_id: state.identity_provider.node_id(),
        created_at_unix_ms: timestamp,
        adapter_id: adapter_id.clone().unwrap_or_else(|| "text_projection".to_string()),
        vector_dimension: EXPECTED_VECTOR_DIM as u16,
        vector_encoding: actual_encoding_u16,
        route_id: [1u8; 16], // simulated route_id
        replay_sequence: sequence,
        payload_hash_sha256,
        coordinate_bytes,
        signature_scheme: state.identity_provider.scheme_id(),
        signature: vec![],
    };

    state_obj.sign_object(state.identity_provider.as_ref()).map_err(|e| format!("{:?}", e))?;

    let payload = bincode::serialize(&state_obj).map_err(|e| format!("{:?}", e))?;

    // Pre-serialize inside send_test_vector to measure 100% exact packet size (P1 Usability/Correctness)
    let inner_envelope = BraidEnvelope::create(
        MSG_STATE_DRIFT,
        actual_encoding_u16,
        state.session_id,
        sequence,
        timestamp,
        payload.clone(),
        state.identity_provider.as_ref(),
    ).map_err(|e| format!("{:?}", e))?;

    let serialized_inner = bincode::serialize(&inner_envelope).map_err(|e| format!("{:?}", e))?;
    let actual_packet_size = if route_choice.selected_route_kind == "relay" {
        // Package the envelope into a zero-trust RelayFrame
        let relay_frame = crate::relay::RelayFrame {
            origin_sender: state.identity_provider.node_id(),
            final_recipient: target_node_arr,
            route_id: [1u8; 16], // simulated route_id
            inner_message_type: MSG_STATE_DRIFT,
            inner_vector_encoding: actual_encoding_u16,
            created_at_ms: timestamp,
            expires_at_ms: timestamp + 15_000,
            inner_envelope_bytes: serialized_inner.clone(),
        };

        let relay_payload = bincode::serialize(&relay_frame).map_err(|e| format!("{:?}", e))?;

        let relay_envelope = BraidEnvelope::create(
            crate::protocol::MSG_RELAY_FORWARD,
            0,
            state.session_id,
            sequence,
            timestamp,
            relay_payload,
            state.identity_provider.as_ref(),
        ).map_err(|e| format!("{:?}", e))?;

        bincode::serialize(&relay_envelope).map_err(|e| format!("{:?}", e))?.len()
    } else {
        serialized_inner.len()
    };

    let res = tendril::send_to_node(
        target_node_arr,
        MSG_STATE_DRIFT,
        payload,
        actual_encoding_u16,
        state.session_id,
        sequence,
        timestamp,
        state.session_table.as_ref(),
        state.route_table.as_ref(),
        state.identity_provider.as_ref(),
        state.transport.as_ref(),
    ).await;

    match res {
        Ok(_) => {
            Ok(SendVectorResult {
                route_kind: route_choice.selected_route_kind.clone(),
                direct_attempted: route_choice.selected_route_kind == "direct",
                relay_fallback_used: route_choice.selected_route_kind == "relay",
                encoding: if actual_encoding_u16 == VECTOR_ENCODING_QINT8 { "qint8".to_string() } else { "raw_f32".to_string() },
                dimension: 384,
                packet_size: actual_packet_size,
                vector_sha256: test_vector.sha256,
                sent_count: 1,
                skipped: vec![],
                target_endpoint: route_choice.selected_endpoint.clone(),
            })
        }
        Err(e) => {
            Ok(SendVectorResult {
                route_kind: route_choice.selected_route_kind.clone(),
                direct_attempted: route_choice.selected_route_kind == "direct",
                relay_fallback_used: route_choice.selected_route_kind == "relay",
                encoding: if actual_encoding_u16 == VECTOR_ENCODING_QINT8 { "qint8".to_string() } else { "raw_f32".to_string() },
                dimension: 384,
                packet_size: 0,
                vector_sha256: test_vector.sha256,
                sent_count: 0,
                skipped: vec![SkippedPeerReason {
                    peer_node_id: format_hex(&target_node_arr),
                    reason: format!("Transport error: {:?}", e),
                    route_state: None,
                    session_state: None,
                    trust_state: None,
                }],
            })
        }
    }
}

async fn register_global_action(state: &AppState) -> Result<(), String> {
    let mut timestamps = state.global_action_timestamps.lock().await;
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
    timestamps.retain(|&t| now.saturating_sub(t) < 60000);
    if timestamps.len() >= 20 {
        return Err("Global manual network action rate limit exceeded (max 20 per minute).".to_string());
    }
    timestamps.push(now);
    Ok(())
}

async fn choose_best_route_for_peer_internal(
    node_id: NodeId,
    state: &AppState,
) -> Result<RouteChoiceResult, String> {
    let route_table = state.route_table.lock().await;
    let candidates = route_table.get(&node_id);

    if candidates.is_none() || candidates.unwrap().is_empty() {
        return Ok(RouteChoiceResult {
            peer_node_id: format_hex(&node_id),
            selected_route_kind: "none".to_string(),
            selected_endpoint: "".to_string(),
            direct_available: false,
            relay_available: false,
            reason: "No route candidates are configured for this peer.".to_string(),
        });
    }

    let candidates_ref = candidates.unwrap();

    let mut direct_candidate = None;
    let mut relay_candidate = None;

    for c in candidates_ref {
        if c.state == RouteState::Verified {
            match c.transport {
                TransportKind::Udp => {
                    if direct_candidate.is_none() {
                        direct_candidate = Some(c.clone());
                    }
                }
                TransportKind::Relay => {
                    if relay_candidate.is_none() {
                        relay_candidate = Some(c.clone());
                    }
                }
            }
        }
    }

    let direct_available = direct_candidate_exists(&candidates_ref);
    let relay_available = relay_candidate_exists(&candidates_ref);

    let (route_kind, endpoint_str, reason) = if let Some(ref direct) = direct_candidate {
        ("direct".to_string(), direct.endpoint.to_string(), "Verified direct UDP route is available and selected.".to_string())
    } else if let Some(ref relay) = relay_candidate {
        ("relay".to_string(), relay.endpoint.to_string(), "No direct route found; verified relay path is selected as fallback.".to_string())
    } else {
        ("none".to_string(), "".to_string(), "Route candidates exist, but none of them are currently in the 'Verified' state.".to_string())
    };

    Ok(RouteChoiceResult {
        peer_node_id: format_hex(&node_id),
        selected_route_kind: route_kind,
        selected_endpoint: endpoint_str,
        direct_available,
        relay_available,
        reason,
    })
}

fn direct_candidate_exists(candidates: &[RouteCandidate]) -> bool {
    candidates.iter().any(|c| matches!(c.transport, TransportKind::Udp))
}

fn relay_candidate_exists(candidates: &[RouteCandidate]) -> bool {
    candidates.iter().any(|c| matches!(c.transport, TransportKind::Relay))
}

#[tauri::command]
async fn choose_best_route_for_peer(
    peer_node_id: String,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<RouteChoiceResult, String> {
    register_global_action(&state).await?;

    let bytes = hex::decode(&peer_node_id).map_err(|e| format!("{:?}", e))?;
    if bytes.len() != 32 {
        return Err("Invalid Node ID length".to_string());
    }
    let mut node_id = [0u8; 32];
    node_id.copy_from_slice(&bytes);

    choose_best_route_for_peer_internal(node_id, &state).await
}

#[tauri::command]
async fn discover_public_endpoint(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<PublicEndpointResult, String> {
    register_global_action(&state).await?;

    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
    {
        let mut last_check = state.last_stun_check.lock().await;
        if let Some(last) = *last_check {
            if now.saturating_sub(last) < 30000 {
                return Err("Rate limit exceeded for public endpoint discovery (max 1 every 30 seconds).".to_string());
            }
        }
        *last_check = Some(now);
    }

    let servers = vec![
        "stun.l.google.com:19302",
        "stun1.l.google.com:19302",
        "stun2.l.google.com:19302",
        "stun.xten.com:3478",
    ];

    let start = Instant::now();
    let local_bind = format!("0.0.0.0:{}", state.local_port);

    for server in servers {
        let server_str = server.to_string();
        let stun_res = tokio::task::spawn_blocking(move || {
            nat::query_stun(&server_str, Duration::from_millis(1500))
        }).await.map_err(|e| format!("{:?}", e))?;
        match stun_res {
            Ok(addr) => {
                let elapsed = start.elapsed().as_millis() as u64;
                return Ok(PublicEndpointResult {
                    attempted: true,
                    local_bind_addr: local_bind,
                    observed_public_endpoint: Some(addr.to_string()),
                    server_used: Some(server.to_string()),
                    elapsed_ms: Some(elapsed),
                    error: None,
                });
            }
            Err(_) => continue,
        }
    }

    let elapsed = start.elapsed().as_millis() as u64;
    Ok(PublicEndpointResult {
        attempted: true,
        local_bind_addr: local_bind,
        observed_public_endpoint: None,
        server_used: None,
        elapsed_ms: Some(elapsed),
        error: Some("All STUN server checks timed out or failed.".to_string()),
    })
}

#[tauri::command]
async fn run_reachability_check(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<ReachabilityReport, String> {
    register_global_action(&state).await?;

    let local_port = state.local_port;
    let local_bind = state.transport.local_endpoint();

    let servers = vec![
        "stun.l.google.com:19302",
        "stun1.l.google.com:19302",
        "stun2.l.google.com:19302",
        "stun.xten.com:3478",
    ];

    let mut observed_public: Option<SocketAddr> = None;
    let mut evidence = Vec::new();
    let mut warnings = Vec::new();
    let mut mapped_addrs = Vec::new();

    for server in &servers {
        let server_str = server.to_string();
        let stun_res = tokio::task::spawn_blocking(move || {
            nat::query_stun(&server_str, Duration::from_millis(1000))
        }).await.map_err(|e| format!("{:?}", e))?;
        if let Ok(addr) = stun_res {
            mapped_addrs.push((*server, addr));
            if observed_public.is_none() {
                observed_public = Some(addr);
            }
        }
    }

    evidence.push(format!("Queried {} STUN servers.", servers.len()));
    evidence.push(format!("Successful responses from {} servers.", mapped_addrs.len()));

    for (srv, addr) in &mapped_addrs {
        evidence.push(format!("Server {} mapped public endpoint to: {}", srv, addr));
    }

    let mut nat_status = nat::NatReachability::Unknown;

    if mapped_addrs.is_empty() {
        evidence.push("Could not contact any STUN servers to discover public endpoint.".to_string());
        warnings.push("Offline, behind a strict symmetric firewall blocking outgoing UDP, or network issue.".to_string());
    } else {
        let first_addr = mapped_addrs[0].1;
        let mut varies = false;
        for (_, addr) in &mapped_addrs {
            if addr.ip() != first_addr.ip() || addr.port() != first_addr.port() {
                varies = true;
                break;
            }
        }

        if varies {
            evidence.push("CRITICAL: Public mapped endpoints vary across different STUN servers. Confirmed Symmetric NAT mapping.".to_string());
            nat_status = nat::NatReachability::SymmetricOrRestrictiveNatSuspected;
            warnings.push("Symmetric NAT detected. Direct UDP connections are highly likely to fail. Relay fallback is recommended.".to_string());
        } else {
            nat_status = nat::classify_nat(
                local_bind,
                observed_public,
                &mut evidence,
                &mut warnings,
            );
        }
    }

    let direct_udp_likely = match nat_status {
        nat::NatReachability::PubliclyReachable => true,
        _ => false,
    };

    let relay_recommended = match nat_status {
        nat::NatReachability::SymmetricOrRestrictiveNatSuspected | nat::NatReachability::Unknown => true,
        _ => false,
    };

    let report = ReachabilityReport {
        local_endpoint: format!("0.0.0.0:{}", local_port),
        public_endpoint: observed_public.map(|a| a.to_string()),
        nat_status: nat_status.as_str().to_string(),
        direct_udp_likely,
        relay_recommended,
        evidence,
        warnings,
    };

    {
        let mut cache = state.last_reachability_report.lock().await;
        *cache = Some(report.clone());
    }

    Ok(report)
}


#[tauri::command]
async fn start_relay_session(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<String, String> {
    register_global_action(&state).await?;
    
    let route_table = state.route_table.lock().await;
    let relay_routes: Vec<_> = route_table.iter()
        .filter(|(node_id, list)| list.iter().any(|c| matches!(&c.endpoint, RouteEndpoint::Relay { .. })))
        .collect();
        
    if relay_routes.is_empty() {
        return Err("No active relay route candidates found in the route table.".to_string());
    }
    
    let mut sessions = state.session_table.lock().await;
    let mut count = 0;
    for (node_id, list) in relay_routes {
        if let Some(c) = list.iter().find(|c| matches!(&c.endpoint, RouteEndpoint::Relay { .. })) {
            sessions.insert(*node_id, BraidSession {
                peer_node_id: *node_id,
                session_id: [1u8; 16],
                route_id: c.route_id,
                established_at_ms: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64,
                expires_at_ms: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64 + 3600_000,
                accepted_capabilities: 0xFFFF,
                state: SessionState::Ready,
            });
            count += 1;
        }
    }
    
    if count > 0 {
        Ok(format!("Successfully established {} simulated relay session(s) on the backend.", count))
    } else {
        Err("Failed to start relay session: invalid route descriptor.".to_string())
    }
}

#[tauri::command]
async fn attempt_direct_udp_connect(
    peer_node_id: Option<String>,
    peer_endpoint: String,
    coordination_hint: Option<String>,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<DirectUdpAttemptResult, String> {
    register_global_action(&state).await?;

    let parsed_node_id = if let Some(ref hex_str) = peer_node_id {
        let bytes = hex::decode(hex_str).map_err(|e| format!("{:?}", e))?;
        if bytes.len() != 32 {
            return Err("Node ID must be 32 bytes".to_string());
        }
        let mut arr = [0u8; 32];
        arr.copy_from_slice(&bytes);
        Some(arr)
    } else {
        None
    };

    let parsed_addr = peer_endpoint.parse::<SocketAddr>().map_err(|e| format!("{:?}", e))?;

    if parsed_addr.port() == 0 {
        return Err("Port cannot be zero".to_string());
    }

    if parsed_addr.ip().is_unspecified() {
        return Err("Unspecified remote address is invalid".to_string());
    }

    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

    // Rate limit: max 1 per endpoint per 30 seconds
    {
        let mut limits = state.direct_udp_rate_limiter.lock().await;
        if let Some(&last_ms) = limits.get(&peer_endpoint) {
            if now.saturating_sub(last_ms) < 30000 {
                return Err("Rate limit exceeded: Max 1 direct UDP attempt per endpoint per 30 seconds".to_string());
            }
        }
        limits.insert(peer_endpoint.clone(), now);
    }

    let start_time = Instant::now();
    let mut packets_sent = 0;
    let mut response_received = false;
    let mut route_verified = false;
    let mut session_ready = false;

    let seq = state.sequence_counter.fetch_add(1, Ordering::SeqCst);
    let discovery_payload = BraidDiscoveryBeacon {
        session_id: state.session_id,
        capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
        vector_dim: EXPECTED_VECTOR_DIM as u16,
        max_packet_size: MAX_PACKET_SIZE as u16,
        listen_port: state.local_port,
        ttl_ms: 15000,
    };

    let serialized_beacon = bincode::serialize(&discovery_payload).map_err(|e| format!("{:?}", e))?;
    let beacon_envelope = BraidEnvelope::create(
        MSG_DISCOVERY_BEACON,
        VECTOR_ENCODING_RAW_F32,
        state.session_id,
        seq,
        now,
        serialized_beacon,
        state.identity_provider.as_ref(),
    ).map_err(|e| format!("{:?}", e))?;
    let ser_bytes = bincode::serialize(&beacon_envelope).map_err(|e| format!("{:?}", e))?;

    for _probe in 0..3 {
        if let Ok(_) = state.transport.send_to(&ser_bytes, BraidEndpoint::Direct(parsed_addr)).await {
            packets_sent += 1;
        }

        // Wait and check for verification (approx 1.6s total per probe loop)
        for _ in 0..16 {
            tokio::time::sleep(Duration::from_millis(100)).await;
            
            let route_table = state.route_table.lock().await;
            let peer_verified = if let Some(node_id) = parsed_node_id {
                if let Some(list) = route_table.get(&node_id) {
                    list.iter().any(|c| {
                        match &c.endpoint {
                            RouteEndpoint::Udp(addr) => *addr == parsed_addr && c.state == RouteState::Verified,
                            _ => false,
                        }
                    })
                } else {
                    false
                }
            } else {
                route_table.values().any(|list| {
                    list.iter().any(|c| {
                        match &c.endpoint {
                            RouteEndpoint::Udp(addr) => *addr == parsed_addr && c.state == RouteState::Verified,
                            _ => false,
                        }
                    })
                })
            };

            if peer_verified {
                response_received = true;
                route_verified = true;
                
                let session_table = state.session_table.lock().await;
                session_ready = if let Some(node_id) = parsed_node_id {
                    session_table.get(&node_id).map(|s| s.state == SessionState::Ready).unwrap_or(false)
                } else {
                    session_table.values().any(|s| s.state == SessionState::Ready)
                };
                
                break;
            }
        }

        if route_verified {
            break;
        }
    }

    let elapsed_ms = start_time.elapsed().as_millis() as u64;

    let (failure_reason, next_recommended_action) = if route_verified {
        (None, "Direct UDP route verified! You can now send 384d state vectors over this route.".to_string())
    } else {
        (
            Some("No direct UDP response received from the remote endpoint.".to_string()),
            "Direct UDP punch failed. Try adding a relay peer or configure port forwarding on your router.".to_string()
        )
    };

    Ok(DirectUdpAttemptResult {
        attempted: true,
        peer_endpoint,
        packets_sent,
        response_received,
        route_verified,
        session_ready,
        elapsed_ms,
        failure_reason,
        next_recommended_action,
    })
}


#[tauri::command]
async fn get_network_status(
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<NetworkStatus, String> {
    let has_relay = {
        let routes = state.route_table.lock().await;
        let sessions = state.session_table.lock().await;
        routes.iter().any(|(node_id, list)| {
            list.iter().any(|c| matches!(&c.endpoint, RouteEndpoint::Relay { .. }))
                && sessions.get(node_id).map(|s| s.state == SessionState::Ready).unwrap_or(false)
        })
    };

    let report_opt = state.last_reachability_report.lock().await;
    if let Some(ref report) = *report_opt {
        Ok(NetworkStatus {
            local_bind_addr: "0.0.0.0".to_string(),
            local_udp_port: state.local_port,
            public_endpoint: report.public_endpoint.clone(),
            nat_status: report.nat_status.clone(),
            direct_wan_supported: if report.direct_udp_likely { "Supported (Direct WAN Connection Likely)".to_string() } else { "Requires router configuration, port forwarding, or Relay fallback".to_string() },
            relay_available: has_relay,
        })
    } else {
        Ok(NetworkStatus {
            local_bind_addr: "0.0.0.0".to_string(),
            local_udp_port: state.local_port,
            public_endpoint: None,
            nat_status: "unknown (run reachability check in Connection Lab)".to_string(),
            direct_wan_supported: "requires manual router/NAT configuration or known reachable endpoint".to_string(),
            relay_available: has_relay,
        })
    }
}

// =====================================================================
// DAEMON RUNTIME
// =====================================================================


#[tauri::command]
async fn derive_connectivity_recommendation(
    report: nat::ReachabilityReport,
    state: tauri::State<'_, Arc<AppState>>,
) -> Result<nat::ConnectivityRecommendation, String> {
    let node_id_hex = format_hex(&state.node_id);
    let public_ep = report.public_endpoint.clone().unwrap_or_else(|| "0.0.0.0:0".to_string());
    let local_ep = report.local_endpoint.clone();
    let nat_status = report.nat_status.clone();
    
    let (path, guidance, why, can_try, relay_label) = if nat_status.contains("PubliclyReachable") {
        (
            nat::RecommendedPath::DirectUdp,
            "Your network is publicly reachable. Direct UDP peer connection is highly likely to succeed.".to_string(),
            "No address or port translation was detected. Your node can accept direct incoming connections on your public port.".to_string(),
            true,
            "Relay path available — direct UDP is preferred.".to_string(),
        )
    } else if nat_status.contains("PortForwardLikelyRequired") {
        (
            nat::RecommendedPath::StunAssistedUdp,
            "Direct connections are possible if the peer can punch through, or if you configure a port forward on your router.".to_string(),
            "A symmetric port-preserving NAT was detected. Your node can connect via STUN-assisted hole punching, but explicit router mapping/port-forwarding guarantees a direct path.".to_string(),
            true,
            "Relay path recommended — configure relay endpoint in Settings if direct connection fails.".to_string(),
        )
    } else if nat_status.contains("SymmetricOrRestrictiveNatSuspected") || nat_status.contains("Symmetric") {
        (
            nat::RecommendedPath::RelayAssisted,
            "Your router appears to rewrite UDP traffic in a way that may prevent direct peer punching. Braid can still connect through a relay path once relay configuration is available.".to_string(),
            "Symmetric or restrictive NATs often rewrite outbound UDP ports differently for each destination. This prevents ordinary UDP hole punching from reliably matching peers. A relay or rendezvous-assisted path is recommended.".to_string(),
            true,
            "Relay path recommended — configure relay endpoint in Settings.".to_string(),
        )
    } else {
        (
            nat::RecommendedPath::Unknown,
            "Unable to determine NAT classification. Ensure your internet connection is active and retry the check.".to_string(),
            "STUN server queries timed out. This can happen on highly restricted firewalls, offline environments, or if UDP traffic is blocked.".to_string(),
            true,
            "Relay path recommended — relay backend not configured in this build.".to_string(),
        )
    };

    let invite_obj = serde_json::json!({
        "type": "braid_peer_invite",
        "version": "0.9.0-alpha",
        "node_id": node_id_hex,
        "public_endpoint": public_ep,
        "local_endpoint": local_ep,
        "nat_classification": nat_status,
        "direct_udp_likely": report.direct_udp_likely,
        "relay_recommended": report.relay_recommended,
    });

    let json_invite = serde_json::to_string_pretty(&invite_obj).unwrap_or_default();
    
    let relay_req_str = if report.relay_recommended { "required" } else { "optional" };
    let uri_invite = format!(
        "braid://peer?node_id={}&public={}&local={}&nat={}&relay={}",
        node_id_hex, public_ep, local_ep, nat_status, relay_req_str
    );

    Ok(nat::ConnectivityRecommendation {
        recommended_path: path.as_str().to_string(),
        guidance,
        why_note: why,
        json_invite,
        uri_invite,
        can_try_direct: can_try,
        relay_status_label: relay_label,
    })
}

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let handle = app.handle();
            tauri::async_runtime::block_on(async move {
                // FLEXIBLE CLI BOOTSTRAPPING ARGUMENTS PARSING
                let mut udp_port = 12000;
                let mut web_port = 8080;
                let mut no_web = false;
                let mut seed_peers = Vec::new();
                let mut custom_identity_path = None;
                let mut allow_list_peers = Vec::new();
                let mut log_level = "info".to_string();

                let args: Vec<String> = std::env::args().collect();
                let mut i = 1;
                while i < args.len() {
                    match args[i].as_str() {
                        "--port" | "-p" => {
                            if i + 1 < args.len() {
                                if let Ok(p) = args[i+1].parse::<u16>() {
                                    udp_port = p;
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--web-port" | "-w" => {
                            if i + 1 < args.len() {
                                if let Ok(p) = args[i+1].parse::<u16>() {
                                    web_port = p;
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--seed" => {
                            if i + 1 < args.len() {
                                if let Ok(addr) = args[i+1].parse::<SocketAddr>() {
                                    seed_peers.push(addr);
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--allow" => {
                            if i + 1 < args.len() {
                                if let Ok(bytes) = hex::decode(&args[i+1]) {
                                    if bytes.len() == 32 {
                                        let mut node_arr = [0u8; 32];
                                        node_arr.copy_from_slice(&bytes);
                                        allow_list_peers.push(node_arr);
                                    }
                                }
                                i += 2;
                            } else { i += 1; }
                        }
                        "--no-web" => {
                            no_web = true;
                            i += 1;
                        }
                        "--identity" => {
                            if i + 1 < args.len() {
                                custom_identity_path = Some(std::path::PathBuf::from(&args[i+1]));
                                i += 2;
                            } else { i += 1; }
                        }
                        "--log-level" => {
                            if i + 1 < args.len() {
                                log_level = args[i+1].clone();
                                i += 2;
                            } else { i += 1; }
                        }
                        _ => { i += 1; }
                    }
                }

                println!("[BOOT] Braid Tendril Kernel v0.9.0 Initializing...");
                println!("[BOOT] Target UDP Port: {}, Web Visualizer Port: {}, No Web: {}, Log Level: {}", udp_port, web_port, no_web, log_level);

                let bind_addr = format!("0.0.0.0:{}", udp_port);
                let socket = match UdpSocket::bind(&bind_addr).await {
                    Ok(s) => s,
                    Err(_) => {
                        UdpSocket::bind("0.0.0.0:0")
                            .await
                            .expect("Failed to bind UDP socket to any port")
                    }
                };

                let local_port = socket.local_addr().unwrap().port();
                let transport = Arc::new(UdpTransport::new(socket));
                let _ = transport.socket.set_broadcast(true);

                // Initialize persistent node identity stored securely in App Data Directory
                let app_data_dir = handle.path_resolver().app_data_dir()
                    .unwrap_or_else(|| std::env::current_dir().unwrap());
                std::fs::create_dir_all(&app_data_dir).unwrap_or_default();
                
                let identity_path = custom_identity_path.unwrap_or_else(|| app_data_dir.join(".braid_identity"));

                // Initialize Ed25519 Local Identity Provider
                let local_identity = NodeIdentity::load_or_create(identity_path.clone()).unwrap();
                let identity_provider = Arc::new(Ed25519LocalIdentityProvider::new(local_identity.signing_key.clone()));

                let node_id = identity_provider.node_id();
                let session_id: [u8; 16] = rand::random();
                let sequence_counter = Arc::new(AtomicU64::new(1)); 
                let peer_table = Arc::new(Mutex::new(HashMap::<NodeId, route::PeerRecord>::new()));
                let session_table = Arc::new(Mutex::new(HashMap::<NodeId, BraidSession>::new()));
                let route_table = Arc::new(Mutex::new(HashMap::<NodeId, Vec<RouteCandidate>>::new()));
                
                // Initialize trust policy engine and populate explicit allowlist (Pillar 6, v0.9.0)
                let trust_policy_path = identity_path.parent().unwrap().join("trust_policy.json");
                let mut policy_engine = TrustPolicyEngine::load_or_create(trust_policy_path);
                for allowed in allow_list_peers {
                    policy_engine.allow_node(allowed);
                }
                let trust_policy = Arc::new(Mutex::new(policy_engine));

                let replay_ledger = Arc::new(Mutex::new(HashMap::<(NodeId, [u8; 16], u16), u64>::new()));
                let last_sent_acks = Arc::new(Mutex::new(HashMap::<NodeId, u64>::new()));
                let latest_received_vector = Arc::new(Mutex::new(vec![0.0f32; EXPECTED_VECTOR_DIM]));

                // Define bootstrap targets: fallback to broadcast if no manual seeds provided
                let discovery_targets = if seed_peers.is_empty() {
                    vec![
                        "255.255.255.255:12000".parse::<SocketAddr>().unwrap(),
                        "127.0.0.1:12000".parse::<SocketAddr>().unwrap(),
                    ]
                } else {
                    seed_peers.clone()
                };

                let peers = Arc::new(Mutex::new(
                    discovery_targets.iter().map(|addr| addr.to_string()).collect::<Vec<String>>()
                ));

                // Create shared global state wrapped in Arc for web daemon integration
                let probe_rate_limiter = Arc::new(Mutex::new(HashMap::<String, u64>::new()));
                let global_probe_timestamps = Arc::new(Mutex::new(Vec::<u64>::new()));
                let failed_probe_retries = Arc::new(Mutex::new(HashMap::<String, u32>::new()));

                let app_state_arc = Arc::new(AppState {
                    transport: Arc::clone(&transport) as Arc<dyn BraidTransport>, // Dynamic Trait Object (Pillar 2)
                    identity_provider: Arc::clone(&identity_provider) as Arc<dyn IdentityProvider>,
                    node_id,
                    session_id,
                    sequence_counter: Arc::clone(&sequence_counter),
                    peer_table: Arc::clone(&peer_table),
                    session_table: Arc::clone(&session_table),
                    route_table: Arc::clone(&route_table),
                    trust_policy: Arc::clone(&trust_policy),
                    replay_ledger: Arc::clone(&replay_ledger),
                    last_sent_acks: Arc::clone(&last_sent_acks),
                    local_port,
                    latest_received_vector: Arc::clone(&latest_received_vector),
                    peers: Arc::clone(&peers),
                    seed_peers: seed_peers.clone(),
                    probe_rate_limiter,
                    global_probe_timestamps,
                    failed_probe_retries,
                    last_stun_check: Arc::new(Mutex::new(None)),
                    direct_udp_rate_limiter: Arc::new(Mutex::new(HashMap::new())),
                    global_action_timestamps: Arc::new(Mutex::new(Vec::new())),
                    last_reachability_report: Arc::new(Mutex::new(None)),
                    adapter_manager: Arc::new(adapter::AdapterManager::new()),
                    peer_telemetry: Arc::new(Mutex::new(HashMap::new())),
                    last_received_object: Arc::new(Mutex::new(None)),
                });

                // Spawn background STUN discovery on bootup! (UX Improvement)
                let stun_state_clone = Arc::clone(&app_state_arc);
                tokio::spawn(async move {
                    tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
                    println!("[STUN] Commencing background NAT reachability check on bootup...");
                    
                    let local_port = stun_state_clone.local_port;
                    let local_bind = stun_state_clone.transport.local_endpoint();
                    let servers = vec![
                        "stun.l.google.com:19302",
                        "stun1.l.google.com:19302",
                        "stun2.l.google.com:19302",
                        "stun.xten.com:3478",
                    ];

                    let mut observed_public = None;
                    let mut evidence = Vec::new();
                    let mut warnings = Vec::new();
                    let mut mapped_addrs = Vec::new();

                    for server in &servers {
                        let server_str = server.to_string();
                        let stun_res = tokio::task::spawn_blocking(move || {
                            nat::query_stun(&server_str, Duration::from_millis(1000))
                        }).await;
                        
                        if let Ok(Ok(addr)) = stun_res {
                            mapped_addrs.push((*server, addr));
                            if observed_public.is_none() {
                                observed_public = Some(addr);
                            }
                        }
                    }

                    evidence.push(format!("Queried {} STUN servers.", servers.len()));
                    evidence.push(format!("Successful responses from {} servers.", mapped_addrs.len()));

                    for (srv, addr) in &mapped_addrs {
                        evidence.push(format!("Server {} mapped public endpoint to: {}", srv, addr));
                    }

                    let mut nat_status = nat::NatReachability::Unknown;

                    if mapped_addrs.is_empty() {
                        evidence.push("Could not contact any STUN servers to discover public endpoint.".to_string());
                        warnings.push("Offline, behind a strict symmetric firewall blocking outgoing UDP, or network issue.".to_string());
                    } else {
                        let first_addr = mapped_addrs[0].1;
                        let mut varies = false;
                        for (_, addr) in &mapped_addrs {
                            if addr.ip() != first_addr.ip() || addr.port() != first_addr.port() {
                                varies = true;
                                break;
                            }
                        }

                        if varies {
                            evidence.push("CRITICAL: Public mapped endpoints vary across different STUN servers. Confirmed Symmetric NAT mapping.".to_string());
                            nat_status = nat::NatReachability::SymmetricOrRestrictiveNatSuspected;
                            warnings.push("Symmetric NAT detected. Direct UDP connections are highly likely to fail. Relay fallback is recommended.".to_string());
                        } else {
                            nat_status = nat::classify_nat(
                                local_bind,
                                observed_public,
                                &mut evidence,
                                &mut warnings,
                            );
                        }
                    }

                    let direct_udp_likely = match nat_status {
                        nat::NatReachability::PubliclyReachable => true,
                        _ => false,
                    };

                    let relay_recommended = match nat_status {
                        nat::NatReachability::SymmetricOrRestrictiveNatSuspected | nat::NatReachability::Unknown => true,
                        _ => false,
                    };

                    let report = ReachabilityReport {
                        local_endpoint: format!("0.0.0.0:{}", local_port),
                        public_endpoint: observed_public.map(|a| a.to_string()),
                        nat_status: nat_status.as_str().to_string(),
                        direct_udp_likely,
                        relay_recommended,
                        evidence,
                        warnings,
                    };

                    {
                        let mut cache = stun_state_clone.last_reachability_report.lock().await;
                        *cache = Some(report);
                    }
                    println!("[STUN] Background NAT reachability check completed successfully!");
                });

                // Spawn Localhost HTTP Web Visualizer if allowed
                if !no_web {
                    let web_state_clone = Arc::clone(&app_state_arc);
                    tokio::spawn(async move {
                        web::start_web_server(web_state_clone, web_port).await;
                    });
                }

                // 1. Spawns background receiver loop - Strict Admission-First Receive Pipeline
                let rx_transport = Arc::clone(&transport);
                let tx_transport_clone = Arc::clone(&transport);
                let local_node_id = node_id;
                let local_session_id = session_id;
                let rx_ledger = Arc::clone(&replay_ledger);
                let rx_peer_table = Arc::clone(&peer_table);
                let rx_session_table = Arc::clone(&session_table);
                let rx_route_table = Arc::clone(&route_table);
                let rx_policy = Arc::clone(&trust_policy);
                let rx_sequence_counter = Arc::clone(&sequence_counter);
                let rx_provider_clone = Arc::clone(&identity_provider);
                let rx_app_handle = handle.clone();
                let rx_peers = Arc::clone(&peers);
                let rx_last_sent_acks = Arc::clone(&last_sent_acks);
                let rx_latest_vector = Arc::clone(&latest_received_vector);
                let rx_peer_telemetry = Arc::clone(&app_state_arc.peer_telemetry);
                let rx_last_received_object = Arc::clone(&app_state_arc.last_received_object);

                tokio::spawn(async move {
                    loop {
                        match rx_transport.recv_from().await {
                            Ok((bytes, target_endpoint)) => {
                                let src = match target_endpoint {
                                    BraidEndpoint::Direct(addr) => addr,
                                    BraidEndpoint::Relay(addr, _) => addr,
                                };
                                let wire_size = bytes.len();
                                let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;

                                // Pre-flight byte-level structure sanitization check
                                if !preflight_sanitize_packet(&bytes) {
                                    eprintln!("[DROP] Malformed/corrupt packet structure discarded by pre-flight sanitizer from {}", src);
                                    continue;
                                }

                                // Deserialize envelope
                                let envelope: BraidEnvelope = match bincode::deserialize(&bytes) {
                                    Ok(env) => env,
                                    Err(_) => continue,
                                };

                                // [PIPELINE STEP 3] Static envelope constraints: size and clock skew
                                if let Err(e) = envelope.validate_envelope(now_ms, wire_size) {
                                    eprintln!("[DROP] Validation failure from {}: {}", src, e);
                                    continue;
                                }

                                // [PIPELINE STEP 4] Wire protocol version check
                                if envelope.version != WIRE_PROTOCOL_VERSION {
                                    eprintln!("[DROP] Wire protocol version mismatch: expected {}, received {}", WIRE_PROTOCOL_VERSION, envelope.version);
                                    continue;
                                }

                                // [PIPELINE STEP 5] Supported signature scheme check
                                if envelope.signature_scheme != SCHEME_ED25519 {
                                    eprintln!("[DROP] Unsupported signature scheme: {}", envelope.signature_scheme);
                                    continue;
                                }

                                // Enforce codec fields validation before processing
                                if envelope.wire_encoding != protocol::ENCODING_BINCODE {
                                    eprintln!("[DROP] Unsupported wire encoding format: {}", envelope.wire_encoding);
                                    continue;
                                }

                                // Self-filtering: Reject packets from our exact local node/session combination
                                if envelope.node_id == local_node_id && envelope.session_id == local_session_id {
                                    continue;
                                }

                                // [PIPELINE STEP 6 & 7] NodeId derivation check and Cryptographic signature verification
                                if !envelope.verify_signature() {
                                    eprintln!("[DROP] Cryptographic signature INVALID from {}", src);
                                    continue;
                                }

                                // [PIPELINE STEP 14] Peer admission policy: Handle PairingPending states (v0.9.0)
                                {
                                    let mut policy = rx_policy.lock().await;
                                    match policy.check_admission(envelope.node_id) {
                                        Admission::Allowed => {
                                            // Proceed normally!
                                        }
                                        Admission::Denied => {
                                            eprintln!("[DROP] Policy blocked connection from Node ID: {}", format_hex(&envelope.node_id));
                                            continue;
                                        }
                                        Admission::Pending => {
                                            println!("[PAIRING PENDING] Peer ID [{}] entered pending pairing state.", &format_hex(&envelope.node_id)[..12]);
                                            let _ = rx_app_handle.emit_all("trust-policy-updated", policy.get_policy_json());
                                            continue; // Drop packet until peer is explicitly allowed/trusted!
                                        }
                                    }
                                }

                                // [PIPELINE STEP 8] Known message type check (match explicitly)
                                match envelope.message_type {
                                    MSG_DISCOVERY_BEACON => {
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            // [PIPELINE STEP 9 & 10] Payload codec check & message-specific validation
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery beacon from {}: {}", src, e);
                                                continue;
                                            }

                                            // [PIPELINE STEP 11] Unified Replay check and commit
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // [PIPELINE STEP 12] Peer admission policy with Capability Negotiation
                                            let (is_new, should_handshake, clamped_ttl) = {
                                                let mut table = rx_peer_table.lock().await;
                                                if table.len() >= MAX_PEERS && !table.contains_key(&envelope.node_id) {
                                                    eprintln!("[DROP] Peer table full. Rejecting new node.");
                                                    continue;
                                                }

                                                let is_new = !table.contains_key(&envelope.node_id);
                                                let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                                let preferred_vector_encoding = if beacon.capabilities & CAP_VECTOR_QINT8 != 0 {
                                                    VECTOR_ENCODING_QINT8
                                                } else {
                                                    VECTOR_ENCODING_RAW_F32
                                                };

                                                let record = route::PeerRecord {
                                                    node_id: envelope.node_id,
                                                    observed_addr: src,
                                                    status: route::PeerStatus::Active,
                                                    protocol_version: envelope.version,
                                                    capabilities: beacon.capabilities,
                                                    vector_dim: beacon.vector_dim,
                                                    session_id: beacon.session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + clamped_ttl as u64,
                                                    highest_sequence: envelope.sequence,
                                                    round_trip_latency_ms: 0,
                                                    preferred_vector_encoding,
                                                };
                                                table.insert(envelope.node_id, record);

                                                if is_new {
                                                    println!(
                                                        "\n[DISCOVERY] Admitted peer [{}] at {} (Advertised port: {}, Preferred codec: {})",
                                                        &format_hex(&envelope.node_id)[..12],
                                                        src,
                                                        beacon.listen_port,
                                                        if preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "INT8" } else { "RAW_F32" }
                                                    );
                                                    let mut flat = rx_peers.lock().await;
                                                    let src_str = src.to_string();
                                                    if !flat.contains(&src_str) {
                                                        flat.push(src_str);
                                                    }
                                                }

                                                let mut acks = rx_last_sent_acks.lock().await;
                                                let last_sent = acks.entry(envelope.node_id).or_insert(0);
                                                let should_handshake = is_new || now_ms - *last_sent > ACK_RATE_LIMIT_MS;
                                                if should_handshake {
                                                    *last_sent = now_ms;
                                                }
                                                (is_new, should_handshake, clamped_ttl)
                                            };

                                            if should_handshake {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                let discovery_payload = BraidDiscoveryBeacon {
                                                    session_id: local_session_id,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    max_packet_size: MAX_PACKET_SIZE as u16,
                                                    listen_port: local_port,
                                                    ttl_ms: clamped_ttl,
                                                };
                                                if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                                                    if let Ok(handshake) = BraidEnvelope::create(
                                                        MSG_DISCOVERY_ACK,
                                                        VECTOR_ENCODING_RAW_F32,
                                                        local_session_id,
                                                        seq,
                                                        now_ms,
                                                        serialized_beacon,
                                                        rx_provider_clone.as_ref(),
                                                    ) {
                                                        let ser_handshake = bincode::serialize(&handshake).unwrap();
                                                        let _ = tx_transport_clone.send_to(&ser_handshake, BraidEndpoint::Direct(src)).await;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    MSG_DISCOVERY_ACK => {
                                        if let Ok(beacon) = bincode::deserialize::<BraidDiscoveryBeacon>(&envelope.payload) {
                                            if let Err(e) = validate_beacon(&envelope, &beacon) {
                                                eprintln!("[DROP] Invalid discovery ACK from {}: {}", src, e);
                                                continue;
                                            }

                                            // Unified Replay check and commit
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            let mut table = rx_peer_table.lock().await;
                                            let is_new = !table.contains_key(&envelope.node_id);
                                            let clamped_ttl = beacon.ttl_ms.clamp(5_000, 60_000);

                                            let preferred_vector_encoding = if beacon.capabilities & CAP_VECTOR_QINT8 != 0 {
                                                VECTOR_ENCODING_QINT8
                                            } else {
                                                VECTOR_ENCODING_RAW_F32
                                            };

                                            let record = route::PeerRecord {
                                                node_id: envelope.node_id,
                                                observed_addr: src,
                                                status: route::PeerStatus::Active,
                                                protocol_version: envelope.version,
                                                capabilities: beacon.capabilities,
                                                vector_dim: beacon.vector_dim,
                                                session_id: beacon.session_id,
                                                last_seen_ms: now_ms,
                                                expires_at_ms: now_ms + clamped_ttl as u64,
                                                highest_sequence: envelope.sequence,
                                                round_trip_latency_ms: 0,
                                                preferred_vector_encoding,
                                            };
                                            table.insert(envelope.node_id, record);

                                            if is_new {
                                                println!(
                                                    "\n[DISCOVERY] Registered Handshake [{}] at {} (Advertised port: {}, Preferred codec: {})",
                                                    &format_hex(&envelope.node_id)[..12],
                                                    src,
                                                    beacon.listen_port,
                                                    if preferred_vector_encoding == VECTOR_ENCODING_QINT8 { "INT8" } else { "RAW_F32" }
                                                );
                                                let mut flat = rx_peers.lock().await;
                                                let src_str = src.to_string();
                                                if !flat.contains(&src_str) {
                                                    flat.push(src_str);
                                                }
                                            }
                                        }
                                    }
                                    MSG_STATE_DRIFT => {
                                        // 1. Ingestion strictly deserializes BraidStateObject from envelope.payload
                                        let state_object = match bincode::deserialize::<protocol::BraidStateObject>(&envelope.payload) {
                                            Ok(obj) => obj,
                                            Err(e) => {
                                                eprintln!("[DROP] Failed to deserialize BraidStateObject: {:?}", e);
                                                continue;
                                            }
                                        };

                                        // Check 1: Reject unsupported object_version
                                        if state_object.object_version != 1 {
                                            eprintln!("[DROP] Unsupported BraidStateObject version: {}", state_object.object_version);
                                            continue;
                                        }

                                        // Check 2: Reject unsupported vector_dimension (must be 384)
                                        if state_object.vector_dimension != EXPECTED_VECTOR_DIM as u16 {
                                            eprintln!("[DROP] Unsupported BraidStateObject vector dimension: {}", state_object.vector_dimension);
                                            continue;
                                        }

                                        // Check 3: Reject unsupported vector_encoding
                                        if state_object.vector_encoding != VECTOR_ENCODING_RAW_F32
                                            && state_object.vector_encoding != VECTOR_ENCODING_QINT8
                                        {
                                            eprintln!("[DROP] Unsupported BraidStateObject vector encoding: {}", state_object.vector_encoding);
                                            continue;
                                        }

                                        // Check 4: Verify payload hash
                                        let mut hasher = sha2::Sha256::new();
                                        hasher.update(&state_object.coordinate_bytes);
                                        let calculated_hash: [u8; 32] = hasher.finalize().into();
                                        if calculated_hash != state_object.payload_hash_sha256 {
                                            eprintln!("[DROP] Payload hash mismatch");
                                            continue;
                                        }

                                        // Check 5 & 6: Verify signature over canonical preimage
                                        if !state_object.verify_signature() {
                                            eprintln!("[DROP] BraidStateObject signature verification failed");
                                            continue;
                                        }

                                        // Check 7: Reject stale replay_sequence
                                        let is_sequence_valid = {
                                            let mut table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get_mut(&state_object.source_node_id) {
                                                if state_object.replay_sequence <= record.highest_sequence {
                                                    false
                                                } else {
                                                    record.highest_sequence = state_object.replay_sequence;
                                                    record.last_seen_ms = now_ms;
                                                    record.expires_at_ms = now_ms + 15_000;
                                                    record.status = route::PeerStatus::Active;
                                                    true
                                                }
                                            } else {
                                                false
                                            }
                                        };

                                        if !is_sequence_valid {
                                            eprintln!("[DROP] Replay sequence is stale: {}", state_object.replay_sequence);
                                            continue;
                                        }

                                        // Decouple coordinate bytes based on state_object.vector_encoding
                                        let expected_dim = EXPECTED_VECTOR_DIM;
                                        let latent_vector = if state_object.vector_encoding == VECTOR_ENCODING_QINT8 {
                                            if let Ok(quant) = bincode::deserialize::<BraidStateDriftQuant>(&state_object.coordinate_bytes) {
                                                if quant.values.len() != expected_dim {
                                                    continue;
                                                }
                                                let dequant = quant.dequantize();
                                                dequant
                                            } else {
                                                continue;
                                            }
                                        } else {
                                            if let Ok(drift) = bincode::deserialize::<BraidStateDrift>(&state_object.coordinate_bytes) {
                                                if drift.latent_vector.len() != expected_dim {
                                                    continue;
                                                }
                                                drift.latent_vector
                                            } else {
                                                continue;
                                            }
                                        };

                                        // Commit state drift locally
                                        {
                                            let mut vec_guard = rx_latest_vector.lock().await;
                                            *vec_guard = latent_vector.clone();
                                        }

                                        // Save to rx_last_received_object for GUI verification panel!
                                        {
                                            let mut rx_obj = rx_last_received_object.lock().await;
                                            *rx_obj = Some(protocol::BraidStateObjectView {
                                                object_version: state_object.object_version,
                                                source_node_id_hex: format_hex(&state_object.source_node_id),
                                                created_at_unix_ms: state_object.created_at_unix_ms,
                                                adapter_id: state_object.adapter_id.clone(),
                                                vector_dimension: state_object.vector_dimension,
                                                vector_encoding_str: if state_object.vector_encoding == VECTOR_ENCODING_QINT8 { "qint8".to_string() } else { "raw_f32".to_string() },
                                                route_id_hex: format_hex(&state_object.route_id),
                                                replay_sequence: state_object.replay_sequence,
                                                payload_hash_hex: format_hex(&state_object.payload_hash_sha256),
                                                coordinate_len: state_object.coordinate_bytes.len(),
                                                signature_scheme_str: "Ed25519".to_string(),
                                                signature_hex: format_hex(&state_object.signature),
                                                verified: true,
                                            });
                                        }

                                        // Update dynamic telemetry
                                        {
                                            let mut tel = rx_peer_telemetry.lock().await;
                                            tel.insert(
                                                state_object.source_node_id,
                                                (
                                                    state_object.adapter_id.clone(),
                                                    Some("State drift verified & committed".to_string()),
                                                ),
                                            );
                                        }

                                        let hex_node = format_hex(&envelope.node_id);
                                        let payload = serde_json::json!({
                                            "node_id": hex_node,
                                            "timestamp": envelope.timestamp,
                                            "sequence_id": envelope.sequence,
                                            "latent_vector": latent_vector,
                                            "sender_address": src.to_string(),
                                            "byte_size": wire_size,
                                        });
                                        let _ = rx_app_handle.emit_all("udp-packet-received", payload);

// Emit first-class vector-receipt event
                                        let mut v_hasher = sha2::Sha256::new();
                                        for &val in &latent_vector {
                                            v_hasher.update(&val.to_le_bytes());
                                        }
                                        let vector_sha256 = format_hex(&v_hasher.finalize());
                                        let receipt_payload = serde_json::json!({
                                            "from_node_id": format_hex(&envelope.node_id),
                                            "session_id": format_hex(&envelope.session_id),
                                            "route_kind": "direct",
                                            "encoding": if envelope.state_vector_encoding == VECTOR_ENCODING_QINT8 { "qint8" } else { "raw_f32" },
                                            "dimension": latent_vector.len(),
                                            "vector_sha256": vector_sha256,
                                            "packet_size": wire_size,
                                            "received_at_ms": now_ms,
                                            "relay_used": false,
                                        });
                                        let _ = rx_app_handle.emit_all("vector-receipt", receipt_payload);
                                    }
                                    MSG_PEER_GOODBYE => {
                                        // Unified Replay check
                                        if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                            eprintln!("{}", e);
                                            continue;
                                        }

                                        let mut table = rx_peer_table.lock().await;
                                        if table.remove(&envelope.node_id).is_some() {
                                            let hex_node = format_hex(&envelope.node_id);
                                            println!("[PRUNE] Peer graceful exit: Node [{}] left", &hex_node[..12]);
                                            let mut flat = rx_peers.lock().await;
                                            flat.retain(|addr| *addr != src.to_string());
                                            
                                            // REFINEMENT: Explicit session and route candidate table cleanup on Goodbye!
                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if sessions.remove(&envelope.node_id).is_some() {
                                                    println!("[PRUNE] Cleared active cryptographic Session for Node [{}]", &hex_node[..12]);
                                                }
                                            }
                                            {
                                                let mut routes = rx_route_table.lock().await;
                                                if routes.remove(&envelope.node_id).is_some() {
                                                    println!("[PRUNE] Cleared multi-path WAN Route Candidates for Node [{}]", &hex_node[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_RELAY_FORWARD => {
                                        // Deserialize the inner RelayFrame
                                        if let Ok(relay_frame) = bincode::deserialize::<relay::RelayFrame>(&envelope.payload) {
                                            // Validate Relay Frame Expiry
                                            if let Err(e) = relay_frame.validate_frame(now_ms) {
                                                eprintln!("[DROP] Relay frame has expired or is invalid: {}", e);
                                                continue;
                                            }

                                            // Origin/outer sender match
                                            if relay_frame.origin_sender != envelope.node_id {
                                                eprintln!("[DROP] Relay frame origin sender mismatch");
                                                continue;
                                            }

                                            // Deserialize inner envelope for verification
                                            if let Ok(inner_envelope) = bincode::deserialize::<BraidEnvelope>(&relay_frame.inner_envelope_bytes) {
                                                // Inner envelope sender match
                                                if inner_envelope.node_id != relay_frame.origin_sender {
                                                    eprintln!("[DROP] Inner envelope signed node ID mismatch");
                                                    continue;
                                                }

                                                // Verify inner envelope's cryptographic signature
                                                if !inner_envelope.verify_signature() {
                                                    eprintln!("[DROP] Inner envelope signature verification FAILED");
                                                    continue;
                                                }

                                                // Check if we are the final recipient! (Pillar 4 Ingestion support)
                                                if relay_frame.final_recipient == local_node_id {
                                                    println!(
                                                        "[RELAY] Successfully received and unpacked relayed envelope of type {} from origin [{}]",
                                                        inner_envelope.message_type,
                                                        &format_hex(&relay_frame.origin_sender)[..12]
                                                    );

                                                    // Feed the decrypted/unpacked envelope back into our processing block!
                                                    match inner_envelope.message_type {
                                                        MSG_STATE_DRIFT => {
                                                            // Gating check for session readiness (P1 Priority)
                                                            let session_ready = {
                                                                let sessions = rx_session_table.lock().await;
                                                                sessions
                                                                    .get(&inner_envelope.node_id)
                                                                    .map(|s| s.state == SessionState::Ready)
                                                                    .unwrap_or(false)
                                                            };

if !session_ready {
                                                                eprintln!("[DROP] Relayed state drift from non-ready session");
                                                                continue;
                                                            }

                                                            // Replay verification for inner envelope (P1 Hardening)
                                                            if let Err(e) = check_and_commit_replay(
                                                                &rx_ledger,
                                                                inner_envelope.node_id,
                                                                inner_envelope.session_id,
                                                                inner_envelope.message_type,
                                                                inner_envelope.sequence,
                                                                src,
                                                            ).await {
                                                                eprintln!("[DROP] Relayed inner envelope replay check failed: {}", e);
                                                                continue;
                                                            }

                                                            // Gating check for unsupported state vector encoding (BLOCKER 3 RESOLVED)
                                                            if inner_envelope.state_vector_encoding != protocol::VECTOR_ENCODING_RAW_F32
                                                                && inner_envelope.state_vector_encoding != protocol::VECTOR_ENCODING_QINT8
                                                            {
                                                                eprintln!("[DROP] Relayed state vector encoding unsupported: {}", inner_envelope.state_vector_encoding);
                                                                continue;
                                                            }

                                                            let latent_vector = if inner_envelope.state_vector_encoding == VECTOR_ENCODING_QINT8 {
                                                                if let Ok(quant) = bincode::deserialize::<BraidStateDriftQuant>(&inner_envelope.payload) {
                                                                    if quant.values.len() != EXPECTED_VECTOR_DIM { continue; }
                                                                    if !quant.scale.is_finite() || quant.scale <= 0.0 { continue; }
                                                                    let dequant = quant.dequantize();
                                                                    if dequant.iter().any(|v| !v.is_finite()) { continue; }
                                                                    dequant
                                                                } else {
                                                                    continue;
                                                                }
                                                            } else {
                                                                if let Ok(drift) = bincode::deserialize::<BraidStateDrift>(&inner_envelope.payload) {
                                                                    drift.latent_vector
                                                                } else {
                                                                    continue;
                                                                }
                                                            };

                                                            if latent_vector.len() != EXPECTED_VECTOR_DIM {
                                                                continue;
                                                            }

                                                            {
                                                                let mut vec_guard = rx_latest_vector.lock().await;
                                                                *vec_guard = latent_vector.clone();
                                                            }

                                                            let payload = serde_json::json!({
                                                                "node_id": format_hex(&inner_envelope.node_id),
                                                                "timestamp": inner_envelope.timestamp,
                                                                "sequence_id": inner_envelope.sequence,
                                                                "latent_vector": latent_vector,
                                                                "sender_address": format!("relayed-via:{}", src),
                                                                "byte_size": inner_envelope.payload.len(),
                                                            });
                                                            let _ = rx_app_handle.emit_all("udp-packet-received", payload);

                                                            // Emit first-class vector-receipt event for relayed packet
                                                            let mut v_hasher = sha2::Sha256::new();
                                                            for &val in &latent_vector {
                                                                v_hasher.update(&val.to_le_bytes());
                                                            }
                                                            let vector_sha256 = format_hex(&v_hasher.finalize());
                                                            let receipt_payload = serde_json::json!({
                                                                "from_node_id": format_hex(&inner_envelope.node_id),
                                                                "session_id": format_hex(&inner_envelope.session_id),
                                                                "route_kind": "relay",
                                                                "encoding": if inner_envelope.state_vector_encoding == protocol::VECTOR_ENCODING_QINT8 { "qint8" } else { "raw_f32" },
                                                                "dimension": latent_vector.len(),
                                                                "vector_sha256": vector_sha256,
                                                                "packet_size": wire_size,
                                                                "received_at_ms": now_ms,
                                                                "relay_used": true,
                                                            });
                                                            let _ = rx_app_handle.emit_all("vector-receipt", receipt_payload);
                                                        }
                                                        _ => {
                                                            eprintln!("[WARN] Relayed message type {} currently unhandled at final recipient", inner_envelope.message_type);
                                                        }
                                                    }
                                                } else {
                                                    // [PIPELINE STEP 14] Peer admission policy: Verify sender is in local trust policy allowlist (P2 Priority)
                                                    let is_allowed = {
                                                        let mut policy = rx_policy.lock().await;
                                                        matches!(policy.check_admission(envelope.node_id), Admission::Allowed)
                                                    };
                                                    if !is_allowed {
                                                        eprintln!("[DROP] Relay forwarding rejected: sender [{}] is not allowed/trusted", format_hex(&envelope.node_id));
                                                        continue;
                                                    }

                                                    // We are a transit forwarder carrier (CAP_RELAY_FORWARD check)
                                                    let local_capabilities = CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_RELAY_FORWARD | CAP_RELAY_SEND;
                                                    if local_capabilities & CAP_RELAY_FORWARD == 0 {
                                                        eprintln!("[DROP] Relay frame rejected: local node lacks CAP_RELAY_FORWARD");
                                                        continue;
                                                    }

                                                    let target_addr = {
                                                        let table = rx_peer_table.lock().await;
                                                        table.get(&relay_frame.final_recipient).map(|p| p.observed_addr)
                                                    };

                                                    if let Some(addr) = target_addr {
                                                        println!(
                                                            "[RELAY] Forwarding signed relay frame from [{}] to final recipient [{}] at {}",
                                                            &format_hex(&relay_frame.origin_sender)[..12],
                                                            &format_hex(&relay_frame.final_recipient)[..12],
                                                            addr
                                                        );
                                                        let _ = tx_transport_clone.send_to(&bytes, BraidEndpoint::Direct(addr)).await;
                                                    } else {
                                                        eprintln!("[DROP] No direct route to final recipient [{}].", format_hex(&relay_frame.final_recipient));
                                                    }
                                                }
                                            } else {
                                                eprintln!("[DROP] Failed to deserialize inner envelope");
                                                continue;
                                            }
                                        } else {
                                            eprintln!("[DROP] Failed to deserialize outer relay frame payload");
                                            continue;
                                        }
                                    }
                                    MSG_LINK_PROBE => {
                                        // [ADMISSION GATE] Only reply to probes from already admitted peers!
                                        {
                                            let table = rx_peer_table.lock().await;
                                            if !table.contains_key(&envelope.node_id) {
                                                eprintln!("[DROP] Link probe from unadmitted peer {}", src);
                                                continue;
                                            }
                                        }

                                        if let Ok(probe) = bincode::deserialize::<BraidLinkProbe>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Respond with directed LINK_PROBE_ACK immediately
                                            let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                            let ack_payload = BraidLinkProbeAck {
                                                ping_seq: probe.ping_seq,
                                                tx_timestamp_ms: probe.tx_timestamp_ms,
                                                rx_timestamp_ms: now_ms,
                                            };
                                            if let Ok(serialized_ack) = bincode::serialize(&ack_payload) {
                                                if let Ok(ack_env) = BraidEnvelope::create(
                                                    MSG_LINK_PROBE_ACK,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    serialized_ack,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&ack_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                }
                                            }
                                        }
                                    }
                                    MSG_LINK_PROBE_ACK => {
                                        // [ADMISSION GATE] Only accept ACKs from admitted peers!
                                        {
                                            let table = rx_peer_table.lock().await;
                                            if !table.contains_key(&envelope.node_id) {
                                                continue;
                                            }
                                        }

                                        if let Ok(ack) = bincode::deserialize::<BraidLinkProbeAck>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Calculate latency and update path health telemetry
                                            let latency = now_ms.saturating_sub(ack.tx_timestamp_ms);
                                            let mut table = rx_peer_table.lock().await;
                                            if let Some(record) = table.get_mut(&envelope.node_id) {
                                                record.round_trip_latency_ms = latency;
                                                record.last_seen_ms = now_ms;
                                                record.expires_at_ms = now_ms + 15_000;
                                            }
                                        }
                                    }
                                    MSG_SESSION_HELLO => {
                                        if let Ok(hello) = bincode::deserialize::<SessionHello>(&envelope.payload) {
                                            if hello.target_node_id != local_node_id {
                                                eprintln!("[DROP] Hello packet targeted to wrong Node ID");
                                                continue;
                                            }

                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            // Save route candidate inside route_table
                                            let route_id = hello.route_id;
                                            {
                                                let mut routes = rx_route_table.lock().await;
                                                let candidates = routes.entry(envelope.node_id).or_insert_with(Vec::new);
                                                if !candidates.iter().any(|c| c.route_id == route_id) {
                                                    candidates.push(RouteCandidate {
                                                        route_id,
                                                        target_node_id: envelope.node_id,
                                                        transport: TransportKind::Udp,
                                                        endpoint: RouteEndpoint::Udp(src),
                                                        source: RouteSource::Presence,
                                                        verified_by_presence: true,
                                                        verified_by_session: false,
                                                        latency_ms: None,
                                                        failure_count: 0,
                                                        expires_at_ms: now_ms + 60_000,
                                                        state: RouteState::Verified,
                                                        preferred_vector_encoding: VECTOR_ENCODING_RAW_F32,
                                                    });
                                                }
                                            }

                                            // Generate secure random challenge nonce_b
                                            let nonce_b: [u8; 32] = rand::random();

                                            // Save pending session state to rx_session_table
                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                sessions.insert(envelope.node_id, BraidSession {
                                                    peer_node_id: envelope.node_id,
                                                    session_id: [0u8; 16], // not yet verified
                                                    route_id,
                                                    established_at_ms: 0,
                                                    expires_at_ms: 0,
                                                    accepted_capabilities: hello.capabilities,
                                                    state: SessionState::Challenged,
                                                });
                                            }

                                            // Build and send MSG_SESSION_CHALLENGE back
                                            let challenge = SessionChallenge {
                                                initiator_node_id: envelope.node_id,
                                                responder_node_id: local_node_id,
                                                route_id,
                                                nonce_a: hello.nonce_a,
                                                nonce_b,
                                                accepted_capabilities: hello.capabilities,
                                                timestamp_ms: now_ms,
                                            };

                                            if let Ok(ser_challenge) = bincode::serialize(&challenge) {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                if let Ok(challenge_env) = BraidEnvelope::create(
                                                    MSG_SESSION_CHALLENGE,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    ser_challenge,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&challenge_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                    println!("[SESSION] Dispatched session CHALLENGE back to initiator [{}]", &format_hex(&envelope.node_id)[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_SESSION_CHALLENGE => {
                                        if let Ok(challenge) = bincode::deserialize::<SessionChallenge>(&envelope.payload) {
                                            if challenge.initiator_node_id != local_node_id {
                                                eprintln!("[DROP] Challenge packet targeted to wrong Node ID");
                                                continue;
                                            }

                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            let route_id = challenge.route_id;
                                            
                                            // Update session state
                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if let Some(session) = sessions.get_mut(&envelope.node_id) {
                                                    session.state = SessionState::Ready; // Ready for Response verification
                                                }
                                            }

                                            // Build and send MSG_SESSION_RESPONSE back
                                            let response = SessionResponse {
                                                route_id,
                                                nonce_a: challenge.nonce_a,
                                                nonce_b: challenge.nonce_b,
                                                timestamp_ms: now_ms,
                                            };

                                            if let Ok(ser_response) = bincode::serialize(&response) {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                if let Ok(response_env) = BraidEnvelope::create(
                                                    MSG_SESSION_RESPONSE,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    ser_response,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&response_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                    println!("[SESSION] Dispatched session RESPONSE back to responder [{}]", &format_hex(&envelope.node_id)[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_SESSION_RESPONSE => {
                                        if let Ok(response) = bincode::deserialize::<SessionResponse>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            let route_id = response.route_id;
                                            let rand_session_id: [u8; 16] = rand::random();

                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if let Some(session) = sessions.get_mut(&envelope.node_id) {
                                                    session.state = SessionState::Ready;
                                                    session.session_id = rand_session_id;
                                                    session.established_at_ms = now_ms;
                                                    session.expires_at_ms = now_ms + 3_600_000;
                                                }
                                            }

                                            // Update Peer Record to Verified Active inside Peer Table!
                                            {
                                                let mut peers = rx_peer_table.lock().await;
                                                let candidates = rx_route_table.lock().await;
                                                let vector_encoding = if let Some(route_list) = candidates.get(&envelope.node_id) {
                                                    route_list.iter().next().map(|r| r.preferred_vector_encoding).unwrap_or(VECTOR_ENCODING_RAW_F32)
                                                } else {
                                                    VECTOR_ENCODING_RAW_F32
                                                };

                                                peers.insert(envelope.node_id, route::PeerRecord {
                                                    node_id: envelope.node_id,
                                                    observed_addr: src,
                                                    status: route::PeerStatus::Verified,
                                                    protocol_version: envelope.version,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    session_id: rand_session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + 30_000,
                                                    highest_sequence: envelope.sequence,
                                                    round_trip_latency_ms: 0,
                                                    preferred_vector_encoding: vector_encoding,
                                                });
                                            }

                                            // Build and send MSG_SESSION_READY back
                                            let ready = SessionReady {
                                                route_id,
                                                session_id: rand_session_id,
                                                expires_at_ms: now_ms + 3_600_000,
                                            };

                                            if let Ok(ser_ready) = bincode::serialize(&ready) {
                                                let seq = rx_sequence_counter.fetch_add(1, Ordering::SeqCst);
                                                if let Ok(ready_env) = BraidEnvelope::create(
                                                    MSG_SESSION_READY,
                                                    VECTOR_ENCODING_RAW_F32,
                                                    local_session_id,
                                                    seq,
                                                    now_ms,
                                                    ser_ready,
                                                    rx_provider_clone.as_ref(),
                                                ) {
                                                    let ser_bytes = bincode::serialize(&ready_env).unwrap();
                                                    let _ = tx_transport_clone.send_to(&ser_bytes, BraidEndpoint::Direct(src)).await;
                                                    println!("[SESSION] Session HANDSHAKE COMPLETED (Responder) with peer [{}]!", &format_hex(&envelope.node_id)[..12]);
                                                }
                                            }
                                        }
                                    }
                                    MSG_SESSION_READY => {
                                        if let Ok(ready) = bincode::deserialize::<SessionReady>(&envelope.payload) {
                                            // Unified Replay check
                                            if let Err(e) = check_and_commit_replay(&rx_ledger, envelope.node_id, envelope.session_id, envelope.message_type, envelope.sequence, src).await {
                                                eprintln!("{}", e);
                                                continue;
                                            }

                                            {
                                                let mut sessions = rx_session_table.lock().await;
                                                if let Some(session) = sessions.get_mut(&envelope.node_id) {
                                                    session.state = SessionState::Ready;
                                                    session.session_id = ready.session_id;
                                                    session.established_at_ms = now_ms;
                                                    session.expires_at_ms = ready.expires_at_ms;
                                                }
                                            }

                                            // Update Peer Record to Verified Active inside Peer Table!
                                            {
                                                let mut peers = rx_peer_table.lock().await;
                                                peers.insert(envelope.node_id, route::PeerRecord {
                                                    node_id: envelope.node_id,
                                                    observed_addr: src,
                                                    status: route::PeerStatus::Verified,
                                                    protocol_version: envelope.version,
                                                    capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                                                    vector_dim: EXPECTED_VECTOR_DIM as u16,
                                                    session_id: ready.session_id,
                                                    last_seen_ms: now_ms,
                                                    expires_at_ms: now_ms + 30_000,
                                                    highest_sequence: envelope.sequence,
                                                    round_trip_latency_ms: 0,
                                                    preferred_vector_encoding: VECTOR_ENCODING_RAW_F32,
                                                });
                                            }

                                            println!("[SESSION] Session HANDSHAKE COMPLETED (Initiator) with peer [{}]!", &format_hex(&envelope.node_id)[..12]);
                                        }
                                    }
                                    other_type => {
                                        eprintln!("[WARN] Received unsupported message type {} from {}", other_type, src);
                                    }
                                }
                            }
                            Err(_) => {
                                tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
                            }
                        }
                    }
                });

                // 2. Spawns background discovery broadcast beacon loop with Jitter (±500ms)
                let tx_discovery_transport = Arc::clone(&transport);
                let tx_targets = discovery_targets;
                let tx_sequence_counter = Arc::clone(&sequence_counter);
                let tx_provider = Arc::clone(&identity_provider);

                tokio::spawn(async move {
                    let base_ms = 3000u64;
                    loop {
                        let jitter = rand::thread_rng().gen_range(-500..=500);
                        let sleep_ms = (base_ms as i32 + jitter) as u64;
                        tokio::time::sleep(tokio::time::Duration::from_millis(sleep_ms)).await;
                        
                        let timestamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        let seq = tx_sequence_counter.fetch_add(1, Ordering::SeqCst);

                        let discovery_payload = BraidDiscoveryBeacon {
                            session_id: local_session_id,
                            capabilities: CAP_STATE_DRIFT | CAP_DISCOVERY | CAP_UDP_TRANSPORT | CAP_VECTOR_384_F32 | CAP_VECTOR_QINT8,
                            vector_dim: EXPECTED_VECTOR_DIM as u16,
                            max_packet_size: MAX_PACKET_SIZE as u16,
                            listen_port: local_port,
                            ttl_ms: 15000,
                        };

                        if let Ok(serialized_beacon) = bincode::serialize(&discovery_payload) {
                            if let Ok(beacon_envelope) = BraidEnvelope::create(
                                MSG_DISCOVERY_BEACON,
                                VECTOR_ENCODING_RAW_F32,
                                local_session_id,
                                seq,
                                timestamp,
                                serialized_beacon,
                                tx_provider.as_ref(),
                            ) {
                                let ser_bytes = bincode::serialize(&beacon_envelope).unwrap();
                                for peer_addr in tx_targets.iter() {
                                    let _ = tx_discovery_transport.send_to(&ser_bytes, BraidEndpoint::Direct(*peer_addr)).await;
                                }
                            }
                        }
                    }
                });

                // 3. Spawns path health Link Probe thread (loops every 5 seconds)
                let tx_probe_transport = Arc::clone(&transport);
                let tx_probe_table = Arc::clone(&peer_table);
                let tx_probe_sequence = Arc::clone(&sequence_counter);
                let tx_probe_provider = Arc::clone(&identity_provider);
                tokio::spawn(async move {
                    let mut probe_seq = 1u64;
                    loop {
                        tokio::time::sleep(tokio::time::Duration::from_secs(5)).await;
                        let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        
                        // Collect peer coordinates
                        let targets = {
                            let table = tx_probe_table.lock().await;
                            table.values()
                                .filter(|r| r.status == route::PeerStatus::Active || r.status == route::PeerStatus::Verified)
                                .map(|r| (r.observed_addr, r.node_id))
                                .collect::<Vec<(SocketAddr, NodeId)>>()
                        };

                        for (addr, _id) in targets {
                            let seq = tx_probe_sequence.fetch_add(1, Ordering::SeqCst);
                            let probe_payload = BraidLinkProbe {
                                ping_seq: probe_seq,
                                tx_timestamp_ms: now_ms,
                            };
                            if let Ok(serialized) = bincode::serialize(&probe_payload) {
                                if let Ok(probe_env) = BraidEnvelope::create(
                                    MSG_LINK_PROBE,
                                    VECTOR_ENCODING_RAW_F32,
                                    local_session_id,
                                    seq,
                                    now_ms,
                                    serialized,
                                    tx_probe_provider.as_ref(),
                                ) {
                                    let ser_bytes = bincode::serialize(&probe_env).unwrap();
                                    let _ = tx_probe_transport.send_to(&ser_bytes, BraidEndpoint::Direct(addr)).await;
                                }
                            }
                        }
                        probe_seq += 1;
                    }
                });

                // 4. Spawns peer table TTL expiration cleanup loop (runs every 5s)
                let tx_cleanup_peer_table = Arc::clone(&peer_table);
                let tx_cleanup_flat_peers = Arc::clone(&peers);
                tokio::spawn(async move {
                    let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(5));
                    loop {
                        interval.tick().await;
                        let now_ms = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64;
                        
                        let mut expired_peers = Vec::new();
                        {
                            let mut table = tx_cleanup_peer_table.lock().await;
                            table.retain(|sender_id, val| {
                                if now_ms > val.expires_at_ms {
                                    let hex_node = format_hex(sender_id);
                                    println!("[PRUNE] Peer expired (TTL): {} at {}", &hex_node[..12], val.observed_addr);
                                    expired_peers.push(val.observed_addr.to_string());
                                    false
                                } else {
                                    true
                                }
                            });
                        }

                        // Update flat list matching table
                        if !expired_peers.is_empty() {
                            let mut peer_list = tx_cleanup_flat_peers.lock().await;
                            peer_list.retain(|addr| !expired_peers.contains(addr));
                        }
                    }
                });

                // Manage AppState
                handle.manage(app_state_arc);
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            derive_connectivity_recommendation,
            get_node_info,
            get_peers,
            stream_state_drift,
            get_trust_policy,
            approve_peer_trust,
            deny_peer_trust,
            remove_peer_trust,
            set_trust_mode,
            add_manual_peer,
            probe_peer,
            list_routes,
            list_sessions,
            generate_test_vector,
            list_adapters,
            get_presence_roster,
            get_last_received_object,
            send_test_vector,
            get_network_status,
            choose_best_route_for_peer,
            discover_public_endpoint,
            run_reachability_check,
            attempt_direct_udp_connect,
            start_relay_session
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::identity::derive_node_id;
    use std::str::FromStr;
    use ed25519_dalek::Signer;

    #[test]
    fn test_peer_endpoint_parsing() {
        assert!(SocketAddr::from_str("127.0.0.1:12001").is_ok());
        assert!(SocketAddr::from_str("invalid_addr").is_err());
    }

    #[test]
    fn test_deterministic_test_vector_generation() {
        let seed = Some("braid-seed-test-123".to_string());
        
        // Simple LCG PRNG values check
        let mut hasher = sha2::Sha256::new();
        hasher.update(seed.as_ref().unwrap().as_bytes());
        let hash_res = hasher.finalize();
        let mut rng_seed = 0u64;
        for i in 0..8 {
            rng_seed = (rng_seed << 8) | hash_res[i] as u64;
        }

        let mut vector1 = Vec::with_capacity(384);
        let mut x = rng_seed;
        for _ in 0..384 {
            x = x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            let r = (x as f64) / (u64::MAX as f64);
            let val = (r * 2.0 - 1.0) as f32;
            vector1.push(val);
        }

        assert_eq!(vector1.len(), 384);
        for &val in &vector1 {
            assert!(val.is_finite());
            assert!(val >= -1.0 && val <= 1.0);
        }
    }

    #[test]
    fn test_vector_hash_stability() {
        let seed = Some("braid-seed-test-123".to_string());
        
        let mut hasher1 = sha2::Sha256::new();
        hasher1.update(seed.as_ref().unwrap().as_bytes());
        let h1 = hasher1.finalize();

        let mut hasher2 = sha2::Sha256::new();
        hasher2.update(seed.as_ref().unwrap().as_bytes());
        let h2 = hasher2.finalize();

        assert_eq!(h1, h2);
    }

    #[test]
    fn test_diagnostics_bundle_excludes_secrets() {
        // Secrets / private keys are not exposed in view structs
        let view = SessionView {
            peer_node_id: "node_id_test".to_string(),
            session_id: "session_id_test".to_string(),
            state: "Ready".to_string(),
            established_ms_ago: Some(100),
            capabilities: vec!["state-drift".to_string()],
            ready_for_state_drift: true,
        };
        // Ensure no private key fields exist
        assert_eq!(view.peer_node_id, "node_id_test");
        assert_eq!(view.session_id, "session_id_test");
    }

    #[test]
    fn test_rfc1918_classification() {
        use std::net::IpAddr;
        assert!(nat::is_rfc1918(&"10.0.0.1".parse::<IpAddr>().unwrap()));
        assert!(nat::is_rfc1918(&"192.168.1.50".parse::<IpAddr>().unwrap()));
        assert!(nat::is_rfc1918(&"172.16.0.1".parse::<IpAddr>().unwrap()));
        assert!(nat::is_rfc1918(&"172.31.255.255".parse::<IpAddr>().unwrap()));
        
        assert!(!nat::is_rfc1918(&"127.0.0.1".parse::<IpAddr>().unwrap()));
        assert!(!nat::is_rfc1918(&"8.8.8.8".parse::<IpAddr>().unwrap()));
        assert!(!nat::is_rfc1918(&"172.32.0.1".parse::<IpAddr>().unwrap()));
    }

    #[test]
    fn test_nat_classification_logic() {
        use std::net::{SocketAddr, IpAddr, Ipv4Addr};
        let mut evidence = Vec::new();
        let mut warnings = Vec::new();

        // 1. Unknown
        let status = nat::classify_nat(
            SocketAddr::new(IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)), 12000),
            None,
            &mut evidence,
            &mut warnings,
        );
        assert_eq!(status, nat::NatReachability::Unknown);

        // 2. LocalOnly
        evidence.clear();
        warnings.clear();
        let status = nat::classify_nat(
            SocketAddr::new(IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)), 12000),
            Some(SocketAddr::new(IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)), 12000)),
            &mut evidence,
            &mut warnings,
        );
        assert_eq!(status, nat::NatReachability::LocalOnly);

        // 3. PubliclyReachable
        evidence.clear();
        warnings.clear();
        let status = nat::classify_nat(
            SocketAddr::new(IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8)), 12000),
            Some(SocketAddr::new(IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8)), 12000)),
            &mut evidence,
            &mut warnings,
        );
        assert_eq!(status, nat::NatReachability::PubliclyReachable);
    }

    #[tokio::test]
    async fn test_relayed_qint8_processing() {
        use ed25519_dalek::SigningKey;
        let mut rng = rand::thread_rng();
        let signing_key = SigningKey::generate(&mut rng);
        let verifying_key = signing_key.verifying_key();
        let public_bytes = verifying_key.to_bytes().to_vec();
        let node_id = derive_node_id(SCHEME_ED25519, &public_bytes);

        let scale = 1.0f32 / 64.0f32;
        let zero_point = 0i8;
        let mut values = vec![0i8; 384];
        values[0] = 32i8;
        values[383] = -51i8;

        let quant = BraidStateDriftQuant {
            scale,
            zero_point,
            values: values.clone(),
        };
        let payload_bytes = bincode::serialize(&quant).unwrap();

        let session_id = [0u8; 16];
        let sequence = 1u64;
        let timestamp = 1234567890u64;

        let signing_body = protocol::BraidSigningBody {
            version: 8,
            message_type: protocol::MSG_STATE_DRIFT,
            signature_scheme: protocol::SCHEME_ED25519,
            wire_encoding: protocol::ENCODING_CANONICAL_PACKED,
            state_vector_encoding: protocol::VECTOR_ENCODING_QINT8,
            node_id,
            public_material: public_bytes.clone(),
            session_id,
            sequence,
            timestamp,
            payload: payload_bytes.clone(),
        };
        
        let signature_bytes = signing_key
            .sign(&signing_body.serialize_canonical())
            .to_bytes()
            .to_vec();

        let inner_envelope = BraidEnvelope {
            version: 8,
            message_type: protocol::MSG_STATE_DRIFT,
            signature_scheme: protocol::SCHEME_ED25519,
            wire_encoding: protocol::ENCODING_BINCODE,
            state_vector_encoding: protocol::VECTOR_ENCODING_QINT8,
            node_id,
            public_material: public_bytes,
            session_id,
            sequence,
            timestamp,
            signature: signature_bytes,
            payload: payload_bytes,
        };

        assert!(inner_envelope.verify_signature());

        let dequant = quant.dequantize();
        assert_eq!(dequant.len(), 384);
        assert!((dequant[0] - 0.5).abs() < 0.15);
        assert!((dequant[383] + 0.8).abs() < 0.15);

        let ledger = Mutex::new(HashMap::new());
        let src = "127.0.0.1:12000".parse().unwrap();
        
        let first_check = check_and_commit_replay(
            &ledger,
            inner_envelope.node_id,
            inner_envelope.session_id,
            inner_envelope.message_type,
            inner_envelope.sequence,
            src,
        ).await;
        assert!(first_check.is_ok());

        let second_check = check_and_commit_replay(
            &ledger,
            inner_envelope.node_id,
            inner_envelope.session_id,
            inner_envelope.message_type,
            inner_envelope.sequence,
            src,
        ).await;
        assert!(second_check.is_err());
    }

    #[test]
    fn test_preflight_packet_sanitizer_validation() {
        use ed25519_dalek::SigningKey;
        let mut rng = rand::thread_rng();
        let signing_key = SigningKey::generate(&mut rng);
        let verifying_key = signing_key.verifying_key();
        let public_bytes = verifying_key.to_bytes().to_vec();
        let node_id = derive_node_id(SCHEME_ED25519, &public_bytes);

        let vector = vec![0.0f32; 384];
        let payload_bytes = bincode::serialize(&BraidStateDrift { latent_vector: vector }).unwrap();
        let session_id = [0u8; 16];

        let signing_body = protocol::BraidSigningBody {
            version: 8,
            message_type: protocol::MSG_STATE_DRIFT,
            signature_scheme: protocol::SCHEME_ED25519,
            wire_encoding: protocol::ENCODING_CANONICAL_PACKED,
            state_vector_encoding: protocol::VECTOR_ENCODING_RAW_F32,
            node_id,
            public_material: public_bytes.clone(),
            session_id,
            sequence: 1u64,
            timestamp: 1234567890u64,
            payload: payload_bytes.clone(),
        };

        let signature_bytes = signing_key
            .sign(&signing_body.serialize_canonical())
            .to_bytes()
            .to_vec();

        let raw_f32_envelope = BraidEnvelope {
            version: 8,
            message_type: protocol::MSG_STATE_DRIFT,
            signature_scheme: protocol::SCHEME_ED25519,
            wire_encoding: protocol::ENCODING_BINCODE,
            state_vector_encoding: protocol::VECTOR_ENCODING_RAW_F32,
            node_id,
            public_material: public_bytes.clone(),
            session_id,
            sequence: 1u64,
            timestamp: 1234567890u64,
            signature: signature_bytes,
            payload: payload_bytes,
        };

        let raw_f32_bytes = bincode::serialize(&raw_f32_envelope).unwrap();
        assert_eq!(raw_f32_bytes.len(), 1738);
        assert!(preflight_sanitize_packet(&raw_f32_bytes));

        let quant = BraidStateDriftQuant {
            scale: 0.041421,
            zero_point: 40,
            values: vec![0i8; 384],
        };
        let q_payload_bytes = bincode::serialize(&quant).unwrap();

        let q_signing_body = protocol::BraidSigningBody {
            version: 8,
            message_type: protocol::MSG_STATE_DRIFT,
            signature_scheme: protocol::SCHEME_ED25519,
            wire_encoding: protocol::ENCODING_CANONICAL_PACKED,
            state_vector_encoding: protocol::VECTOR_ENCODING_QINT8,
            node_id,
            public_material: public_bytes.clone(),
            session_id,
            sequence: 1u64,
            timestamp: 1234567890u64,
            payload: q_payload_bytes.clone(),
        };

        let q_signature_bytes = signing_key
            .sign(&q_signing_body.serialize_canonical())
            .to_bytes()
            .to_vec();

        let q_envelope = BraidEnvelope {
            version: 8,
            message_type: protocol::MSG_STATE_DRIFT,
            signature_scheme: protocol::SCHEME_ED25519,
            wire_encoding: protocol::ENCODING_BINCODE,
            state_vector_encoding: protocol::VECTOR_ENCODING_QINT8,
            node_id,
            public_material: public_bytes,
            session_id,
            sequence: 1u64,
            timestamp: 1234567890u64,
            signature: q_signature_bytes,
            payload: q_payload_bytes,
        };

        let q_bytes = bincode::serialize(&q_envelope).unwrap();
        assert_eq!(q_bytes.len(), 591);
        assert!(preflight_sanitize_packet(&q_bytes));

        assert!(!preflight_sanitize_packet(&[]));
        assert!(!preflight_sanitize_packet(&vec![0u8; 50]));
        assert!(!preflight_sanitize_packet(&vec![0u8; 2049]));
        assert!(!preflight_sanitize_packet(&vec![0u8; 1738]));
    }
}
